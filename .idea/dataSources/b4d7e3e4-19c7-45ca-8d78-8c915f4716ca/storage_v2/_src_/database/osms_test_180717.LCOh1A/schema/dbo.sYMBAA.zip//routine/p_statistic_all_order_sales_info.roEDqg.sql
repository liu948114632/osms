 
/**
	统计店铺订单的商品销量
*/
CREATE PROC dbo.p_statistic_all_order_sales_info
(
	@startDate DATETIME=NULL,
	@endDate DATETIME=NULL,
	@updateModel TINYINT=NULL
)
AS 
BEGIN
    SELECT shop_seller_sku,o.shop_id,SUM(p.shop_quantity_Ordered) AS sum
	INTO #tmp 
	FROM dbo.[order] o
	INNER JOIN dbo.order_product p
	ON o.id=p.order_id 
	WHERE o.status<>132 AND o.shop_type=1 AND p.shop_seller_sku IS NOT NULL
	AND o.shop_order_status<>'CANCELED'
	AND o.shop_order_date<=@endDate AND o.shop_order_date>=@startDate
	AND p.is_cancel=0
	GROUP BY p.shop_seller_sku,o.shop_id

	IF @updateModel IS NULL OR @updateModel=0
	BEGIN
		UPDATE inv SET inv.days_sales_all=ISNULL(sum,0)
		FROM dbo.fba_shop_product_inventory inv
		INNER JOIN dbo.fba_shop_product fba ON fba.id=inv.fba_shop_product_id
		LEFT JOIN #tmp t ON  t.shop_seller_sku=fba.sku AND t.shop_id=fba.shop_id
	END
	IF @updateModel=1--总警戒库存=四周销量*2
	BEGIN
	    UPDATE inv SET inv.sum_security_line=ISNULL(sum,0)*2
		FROM dbo.fba_shop_product_inventory inv
		INNER JOIN dbo.fba_shop_product fba ON fba.id=inv.fba_shop_product_id
		LEFT JOIN #tmp t ON  t.shop_seller_sku=fba.sku AND t.shop_id=fba.shop_id
	END
END

go


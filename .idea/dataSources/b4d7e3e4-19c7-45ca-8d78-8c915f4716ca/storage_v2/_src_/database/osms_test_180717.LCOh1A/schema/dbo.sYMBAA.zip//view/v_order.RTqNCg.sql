CREATE VIEW dbo.v_order
AS
SELECT  
                      o.id, o.code, o.customer_account, o.customer_name, o.is_send, o.status, o.shipping_method, o.shop_id, o.order_amount, o.cost_freight, o.cost_price, 
                      o.send_group_id, o.tracking_code, o.remark, o.out_date, o.delivery_date, o.shop_order_code, o.shop_order_status, o.shop_order_date, o.order_item_num, 
                      o.order_item_prepare_num, o.shop_type, o.order_currency, o.order_amazon_id, o.latest_delivery_date, o.earliest_delivery_date, o.latest_ship_date, 
                      o.earliest_shipping_date, o.shop_shipping_method, o.add_order_date, o.shop_shipping_price, o.country, o.CPF_code, o.Is_Quality_Inspection, 
                      o.reimburse_freight_percent, o.merchandiser_id, o.cpf_type, o.first_web_order, o.cms_prepare, o.problem_status, o.problem_type, m.merchandiser_name,
                      o.fulfillmentChannel,o.delivery_customer_service,
                      o.await_confirm_cancel,o.await_confirm_resend,o.awaite_putaway,o.copy
FROM         dbo.[order] AS o LEFT OUTER JOIN
                      dbo.merchandiser AS m ON m.id = o.merchandiser_id
go


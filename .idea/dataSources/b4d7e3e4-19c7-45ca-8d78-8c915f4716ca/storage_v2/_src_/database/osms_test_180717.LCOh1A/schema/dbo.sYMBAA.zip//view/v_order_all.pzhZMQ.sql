

CREATE VIEW [dbo].[v_order_all]
AS 
SELECT id,code,send_group_id,status,1 AS type FROM dbo.[order] with(nolock)
UNION
SELECT id,code,send_group_id,status,2 AS type FROM dbo.replenishment_order with(nolock)

go


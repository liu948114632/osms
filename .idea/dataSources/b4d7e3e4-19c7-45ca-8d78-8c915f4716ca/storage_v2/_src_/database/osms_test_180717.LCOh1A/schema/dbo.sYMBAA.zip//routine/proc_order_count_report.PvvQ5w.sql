/**      
 @author whw      
 @desc 报表统计      
*/      
CREATE PROC dbo.proc_order_count_report(      
 @begin VARCHAR(50)=NULL,      
 @end VARCHAR(50)=NULL,      
 @type INT =1,      
  --* @param type      
  --*            <ul>      
  --*            1、月度业绩统计      
  --*            </ul>      
  --*            <ul>      
  --*            2、月度退款统计      
  --*            </ul>      
  --*            <ul>      
  --*            3、FBA商品实际收款统计      
  --*            </ul>      
  --*            <ul>      
  --*            4、非FBA订单总金额统计      
  --*            </ul>      
  --*            <ul>      
  --*            5、FBA订单总金额统计      
  --*            </ul>      
  --*            <ul>      
  --*            6、所有订单总金额统计      
  --*            </ul>      
  --*            <ul>      
  --*            7、非FBA实际收款统计      
  --*            </ul>      
  --*            <ul>      
  --*            8、FBA头程运费统计      
  --*            </ul>     
 @shopId VARCHAR(max)=NULL      
)      
AS      
BEGIN      
 DECLARE      
  @Condition varchar(MAX) --条件         
 SET @Condition='      
  WITH tmp AS (      
   SELECT *,CONVERT(VARCHAR(50),shop_order_date,23) AS reportDate FROM dbo.[order] WITH(NOLOCK)      
   WHERE status<132      
 '        
       
       
 IF @begin IS NOT NULL      
  BEGIN      
   SET @Condition=@Condition+' and shop_order_date>='''++ CONVERT(VARCHAR(50), @begin) + '''';       
  END      
        
 IF @end IS NOT NULL      
  BEGIN      
   SET @Condition=@Condition+'and shop_order_date<='''++ CONVERT(VARCHAR(50), @end) + '''';       
  END       
        
 IF @shopId IS NOT NULL      
  BEGIN      
   SET @Condition=@Condition+'and shop_id in ('+@shopId + ')';       
  END       
       
 IF @type=1 --      
 BEGIN      
  --AND cost_freight>0 AND cost_price>0        
  SET @Condition=@Condition+'       
    )      
       
   SELECT       
   reportDate,shop_id AS shopId,      
   SUM(order_amount) AS orderTotalAmount,      
   MIN(order_currency) AS currency,      
    COUNT(id) AS orderTotalNum       
    FROM tmp       
   GROUP BY reportDate,shop_id        
        
  ';      
        
 END       
       
 IF @type=2      
 BEGIN      
  SET @Condition=@Condition+'        
    )      
       
   SELECT reportDate,r.shop_id AS shopId,      
     SUM(r.amount) AS orderRefundAmount,      
       COUNT(DISTINCT r.shop_order_code) AS orderRefundNum      
       ,MIN(order_currency) AS currency      
       FROM dbo.order_payment_report r WITH(NOLOCK)      
       JOIN dbo.order_payment_data_type t WITH(NOLOCK)       
		   ON t.ACTION=1 AND ISNULL(r.payment_detail,'''') = t.payment_detail      
       AND r.payment_type = t.payment_type        
       AND r.transaction_type = t.transaction_type       
       INNER JOIN tmp o       
       ON o.shop_id=r.shop_id AND o.shop_order_code=r.shop_order_code      
       GROUP BY o.reportDate, r.shop_id       
        
  ';      
        
 END       
       
  IF @type=3      
 BEGIN      
  SET @Condition=@Condition+'   and fulfillmentChannel=''AFN''      
    )      
       
         
          SELECT reportDate,r.shop_id AS shopId,       
      SUM(r.amount) AS FBAPaymentTotalAmount,       
         COUNT(DISTINCT r.shop_order_code) AS FBAPaymentTotalNum       
         ,MIN(r.currency) AS currency ,  
         SUM(ISNULL(cost_price,0)) AS costPrice  ,
         sum(totalUnit) as totalUnit
         FROM dbo.v_order_payment_report_total r WITH(NOLOCK)      
         INNER JOIN tmp o        
         ON o.shop_id=r.shop_id AND o.shop_order_code=r.shop_order_code   
         inner join order_product_total_unit u
         on u.order_id=o.id
         GROUP BY reportDate,r.shop_id       
        
  ';      
        
 END       
       
  IF @type=4      
 BEGIN      
  SET @Condition=@Condition+'   and fulfillmentChannel=''MFN''      
    )      
       
  SELECT reportDate,shop_id as shopId,      
  SUM(order_amount) as orderTotalAmount,      
  MIN(order_currency) AS currency      
   FROM tmp GROUP BY reportDate ,shop_id      
        
  ';      
        
 END       
       
  IF @type=5      
 BEGIN      
  SET @Condition=@Condition+'   and fulfillmentChannel=''AFN''      
    )      
       
  SELECT reportDate,shop_id as shopId,    
  SUM(order_amount) as orderTotalAmount,      
  SUM(ISNULL(cost_price,0)) AS costPrice,      
  MIN(order_currency) AS currency      
   FROM tmp GROUP BY reportDate ,shop_id      
        
  ';      
        
 END       
       
  IF @type=6      
 BEGIN      
  SET @Condition=@Condition+'         
    )      
       
  SELECT reportDate,shop_id as shopId,      SUM(order_amount) as orderTotalAmount,      
  MIN(order_currency) AS currency      
   FROM tmp GROUP BY reportDate ,shop_id      
        
  ';      
        
 END       
       
  IF @type=7      
 BEGIN      
  SET @Condition=@Condition+'         
    and fulfillmentChannel=''MFN'' AND cost_freight>0      
    AND cost_price>0       
    )      
       
   SELECT       
    reportDate,      
    o.shop_id AS shopId,      
   SUM(p.amount) AS paymentAmount,       
   SUM(o.cost_price) AS costPrice,      
   SUM(o.cost_freight) AS costFreight,       
   SUM(o.order_amount) AS orderAmount,       
   MIN(currency) AS currency       
   FROM dbo.v_order_payment_report_total p       
   INNER JOIN tmp o       
   ON o.shop_order_code=p.shop_order_code AND p.shop_id=o.shop_id       
    GROUP BY reportDate ,o.shop_id      
        
  ';      
        
 END       
       
 IF @type=8      
 BEGIN      
  SET @Condition=@Condition+'         
    )      
         
         
  SELECT reportDate,      
  SUM(freight) as firstWayFreight,      
  t.shop_id as shopId      
   FROM tmp t      
  INNER JOIN dbo.FBA_order_product f WITH(NOLOCK)      
  ON f.order_id=t.id      
  GROUP BY reportDate,shop_id       
        
  ';      
        
 END       
       
       
 SET @Condition= @Condition +' ORDER BY reportDate DESC'      
 PRINT @Condition      
 EXEC (@Condition)      
       
END
go


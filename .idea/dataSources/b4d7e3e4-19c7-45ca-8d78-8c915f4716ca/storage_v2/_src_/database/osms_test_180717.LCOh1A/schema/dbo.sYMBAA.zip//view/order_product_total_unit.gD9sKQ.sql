

CREATE VIEW order_product_total_unit AS(

	SELECT order_id,SUM(shop_quantity_Ordered) AS totalUnit FROM dbo.order_product WITH(NOLOCK) 
	GROUP BY order_id
)

go


CREATE VIEW v_order_payment_report_total
AS
SELECT shop_id,shop_order_code,SUM(amount) amount ,MIN(currency) currency FROM dbo.order_payment_report 
GROUP BY shop_id,shop_order_code
go


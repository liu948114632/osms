
CREATE VIEW [dbo].[v_shop_upload_log]
AS
SELECT     dbo.am_shop_upload_log.id, dbo.am_shop_upload_log.type, dbo.am_shop_upload_log.remark, dbo.am_shop_upload_log.result, dbo.am_shop_upload_log.title, 
                      dbo.[user].name, dbo.am_shop_upload_log.upload_time, dbo.am_shop_upload_log.operator
FROM         dbo.am_shop_upload_log Left JOIN
                      dbo.[user] ON dbo.am_shop_upload_log.operator = dbo.[user].id

go



CREATE VIEW dbo.v_fba_repository
as
SELECT id ,
       repository_name AS repositoryName,
       department_id AS departmentId,
       state_or_region AS stateOrRegion,
       city ,
       postal_code AS postalCode,
       phone ,
       address_line1 AS addressLine1,
       address_line2 AS addressLine2,
       country_id AS countryId,
       remark,
	   r.name,
	   STUFF((SELECT ','+p.name FROM dbo.fba_repository_shop s 
	   INNER JOIN dbo.shop p ON p.id=s.shop_id
	   WHERE s.repository_id=r.id FOR XML PATH('')),1,1,'') AS shops FROM dbo.fba_repository r


go


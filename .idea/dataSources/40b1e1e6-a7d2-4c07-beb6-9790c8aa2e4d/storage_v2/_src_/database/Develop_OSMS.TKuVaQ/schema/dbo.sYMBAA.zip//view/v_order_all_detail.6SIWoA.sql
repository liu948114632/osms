 CREATE VIEW dbo.v_order_all_detail
 AS 
 SELECT id,code,send_group_id,status,1 AS type ,shop_id,merchandiser_id FROM dbo.[order]
 UNION
 SELECT id,code,send_group_id,status,2 AS type ,shop_id,merchandiser_id FROM dbo.replenishment_order
 go


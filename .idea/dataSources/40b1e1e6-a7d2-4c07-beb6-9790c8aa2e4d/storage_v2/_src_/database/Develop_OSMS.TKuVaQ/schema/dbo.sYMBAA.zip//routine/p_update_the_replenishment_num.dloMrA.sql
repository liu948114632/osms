

/**
	统计fba店铺商品cms信息的补货中的数量
*/
CREATE PROC dbo.p_update_the_replenishment_num
(
	@cmsProductId VARCHAR(max)=NULL
)
AS 
BEGIN
	IF @cmsProductId IS NULL
	BEGIN
		EXEC ('
			UPDATE  info SET the_replenishment=ISNULL(tmp.cmsTheReplenishment,0)
			FROM shop_product_cms_info info 
			LEFT JOIN (
			SELECT SUM(replenishment_num) AS cmsTheReplenishment,
			cms_product_id AS cmsProductId FROM dbo.replenishment_task_product
			--WHERE cms_product_id=@cmsProductId
			GROUP BY cms_product_id
			) tmp ON tmp.cmsProductId=info.cms_product_id
			')
	END
	ELSE
	BEGIN
		EXEC ('
	    	UPDATE  info SET the_replenishment=ISNULL(tmp.cmsTheReplenishment,0)
			FROM shop_product_cms_info info 
			INNER JOIN (
			SELECT SUM(replenishment_num) AS cmsTheReplenishment,
			cms_product_id AS cmsProductId FROM dbo.replenishment_task_product
			WHERE cms_product_id IN ('+@cmsProductId+')
			GROUP BY cms_product_id
			) tmp ON tmp.cmsProductId=info.cms_product_id
			')
	END

END
go


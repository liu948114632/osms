
			/**
				统计店铺FBA订单的商品销量
			*/
			CREATE PROC dbo.p_statistic_fba_order_sales_info
			(
				@startDate DATETIME=NULL,
				@endDate DATETIME=NULL
			)
			AS 
			BEGIN
			
				SELECT shop_seller_sku,o.shop_id,SUM(p.shop_quantity_Ordered) AS sum
				INTO #tmp 
				FROM dbo.[order] o
				INNER JOIN dbo.order_product p
				ON o.id=p.order_id AND o.fulfillmentChannel='afn'
				WHERE o.status<>132 AND o.shop_type=1 AND p.shop_seller_sku IS NOT NULL
				AND o.shop_order_status<>'CANCELED'
				AND o.shop_order_date<=@endDate AND o.shop_order_date>=@startDate
				GROUP BY p.shop_seller_sku,o.shop_id
			
			
				UPDATE inv SET inv.days_sales_fba=ISNULL(sum,0)
				FROM dbo.fba_shop_product_inventory inv
				INNER JOIN dbo.fba_shop_product fba ON fba.id=inv.fba_shop_product_id
				LEFT JOIN #tmp t ON  t.shop_seller_sku=fba.sku AND t.shop_id=fba.shop_id
			END

      go


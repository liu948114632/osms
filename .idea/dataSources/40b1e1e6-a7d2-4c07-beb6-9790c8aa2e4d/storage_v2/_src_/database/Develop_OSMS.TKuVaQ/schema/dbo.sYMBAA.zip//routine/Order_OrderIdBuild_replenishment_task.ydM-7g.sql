
/*  修改根据订单来源生成编号的规则  */    
CREATE PROC dbo.Order_OrderIdBuild_replenishment_task  
(  
    @Code NVARCHAR(15) = NULL OUTPUT  
)  
AS  
DECLARE @a INT, @b INT, @i INT,@prefix varchar(2);  
BEGIN  
    SET @prefix = ''  
 SET @i = 0;  
 SET @Code = CONVERT(nchar(6), GETDATE(), 12);  
 WHILE (@i < 1)  
 BEGIN  
  SET @a = CAST(RAND() * 899999 + 100000 AS INT);  
 
  IF NOT EXISTS (SELECT 1 FROM dbo.replenishment_task 
                 WHERE LEFT(RIGHT([code], 12), 2) =  LEFT(@Code, 2)   
        AND LEFT(RIGHT([code], 6), 6) = @a)   
  BEGIN 
   SET @Code = @Code + CONVERT(nchar(6), @a);  
  SET @i = @i + 1; 
  END 
    
 SELECT @prefix ='CB'
               
            
     SET @Code = @prefix + @Code;  
END  
END
go


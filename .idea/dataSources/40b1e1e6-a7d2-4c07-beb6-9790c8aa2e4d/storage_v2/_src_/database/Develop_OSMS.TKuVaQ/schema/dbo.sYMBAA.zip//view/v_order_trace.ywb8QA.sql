

/*********修改相应的订单跟踪视图************/
CREATE VIEW [dbo].[v_order_trace]
AS
SELECT  id ,
        code ,
        order_code,
        consultation_user ,
        content ,
        status ,
        type ,
        deleted ,
        create_user ,
        create_date ,
        last_reply_user ,
        last_reply_date ,
        last_reply_content ,
        consultation_user_name AS consultationUserName,
        is_read,
        is_from_cms,
        product_code,
        readed  
        FROM dbo.Order_trace 
WHERE deleted=0

go



/**
	@date 2017-03-25
	@desc 统计没有销量、有冻结库存商品（非FBA订单）
*/
CREATE PROC p_statistic_product_freeze_stock_and_no_sales
(
	@startDate DATETIME=NULL,
	@endDate DATETIME=NULL
)
AS
SELECT DISTINCT f.cms_product_code FROM dbo.product_freeze_stock f
LEFT JOIN 
(
SELECT DISTINCT pp.cms_product_code FROM dbo.[order] o WITH(NOLOCK)
INNER JOIN dbo.order_prepare_product pp WITH(NOLOCK)
ON o.id=pp.order_id AND pp.status<>12 AND pp.cms_product_code IS NOT NULL
WHERE o.status<132 AND o.shop_order_status<>'CANCELED'
AND o.shop_order_date<=@endDate AND o.shop_order_date>=@startDate
AND (o.fulfillmentChannel='mfn' OR o.fulfillmentChannel IS NULL)
) t
ON t.cms_product_code = f.cms_product_code
WHERE t.cms_product_code IS NULL


go


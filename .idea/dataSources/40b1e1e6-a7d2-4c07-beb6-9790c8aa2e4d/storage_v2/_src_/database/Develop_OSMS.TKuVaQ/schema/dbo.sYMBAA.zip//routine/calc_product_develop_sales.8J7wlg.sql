/**
	统计销售额（美元）
*/
CREATE PROC dbo.calc_product_develop_sales
(
	@begin DATETIME=NULL,
	@end DATETIME=NULL
)
AS
BEGIN
	WITH tmp as(
		 SELECT p.cms_product_code,SUM(dbo.current_currency_exchange_USD(c.shop_item_price,c.shop_item_curtype)) AS sales ,
		 SUM(c.shop_quantity_Ordered) AS qty
		 FROM product_develop p WITH(NOLOCK)
	 INNER JOIN dbo.order_product c WITH(NOLOCK) ON p.cms_product_code=c.cms_product_code AND c.is_cancel=0
	 INNER JOIN dbo.[order] a WITH(NOLOCK) ON a.status<132 AND a.shop_type=1 AND a.id=c.order_id
	 AND a.shop_order_date>=CASE WHEN ISNULL(@begin,p.putaway_date) >=p.putaway_date THEN ISNULL(@begin,p.putaway_date) ELSE p.putaway_date END
	  AND a.shop_order_date<=ISNULL( @end,GETDATE())
	 GROUP BY p.cms_product_code
	)
	
		UPDATE a SET a.sales=ISNULL(b.sales,0),a.sale_qty=ISNULL(b.qty,0)
     FROM product_develop a
		   LEFT JOIN tmp b
		   ON a.cms_product_code=b.cms_product_code 
END
go


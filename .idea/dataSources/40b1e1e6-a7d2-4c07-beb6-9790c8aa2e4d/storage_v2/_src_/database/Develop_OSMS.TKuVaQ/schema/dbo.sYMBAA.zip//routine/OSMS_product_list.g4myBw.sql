

/**  
 网店销售商品列表  
 2015-03-27  
 wanghw  
 isMain :0,主商品 1,副商品 2,没有主副关系   
*/  
CREATE PROC dbo.OSMS_product_list  
 @department INT = NULL ,  
 @category1 INT =NULL,  
 @category2 INT=NULL,  
 @category3 INT =NULL,  
 @productCode VARCHAR(50) =NULL,  
 @productCodes VARCHAR(max) =NULL,  
 @seriesId INT =NULL,  
 @isSmallQuantities INT =NULL,  
 @isPool INT =NULL,  
 @isMix INT =NULL,  
 @isGift INT =NULL,  
 @shopId INT =NULL,  
 @status INT =NULL,  
 @freezeStatus INT =NULL,  
 @batchId INT =NULL,  
 @name VARCHAR(500) =NULL,  
    @PageSize INT = 50 ,  --页大小                          
    @PageIndex INT = 1    --当前页号    
      
    AS   
    BEGIN  
   
        SET NOCOUNT ON;  
  
        DECLARE @SQL VARCHAR(MAX) ,  
            @CountSql NVARCHAR(MAX) , --查询数量用    
            @FromSQL NVARCHAR(MAX) , --查询表                                           
            @Column NVARCHAR(MAX) , --查询字段                         
            @Condition VARCHAR(MAX) , --条件                           
            @RowCount INT ,  
            @PageCount INT ,  
            @start INT ,  
            @end INT   
        --设置查询主表      
        SET @FromSQL = ' FROM dbo.product p  with(nolock)
                         left JOIN dbo.product_freeze_stock f with(nolock) ON p.id=f.product_id  AND f.department_id=p.department  
                         left JOIN dbo.[user] u ON u.id=p.add_user_id   
                         LEFT JOIN dbo.product_relation r ON r.product_id=p.id  '  
             
        SET @Condition = ' WHERE  1=1 '                
       --设置查询条件  
        IF @department IS NOT NULL   
            BEGIN  
                SET @Condition = @Condition + ' AND p.department=' + CONVERT(VARCHAR(10), @department)   
             
            END    
              
         IF @category1 IS NOT NULL  
   BEGIN  
    SET @Condition = @Condition + '  AND p.category_id_1=' + CONVERT(VARCHAR(10), @category1)  
   END    
     
  IF @category2 IS NOT NULL  
   BEGIN  
    SET @Condition = @Condition + '  AND p.category_id_2=' + CONVERT(VARCHAR(10), @category2)  
   END   
     
  IF @category3 IS NOT NULL  
   BEGIN  
    SET @Condition = @Condition + '  AND p.category_id_3=' + CONVERT(VARCHAR(10), @category3)  
   END   
  IF @seriesId IS NOT NULL  
   BEGIN  
    SET @Condition = @Condition + '  AND p.series=' + CONVERT(VARCHAR(10), @seriesId)  
   END    
  IF @productCode IS NOT NULL  
   BEGIN  
    SET @Condition = @Condition + ' AND  p.cms_product_code like ''' + @productCode + '%''';  
   END  
  IF @productCodes IS NOT NULL  
   BEGIN  
    SET @Condition = @Condition + ' AND p.cms_product_code in (''' + REPLACE(@productCodes,',',''',''') + ''')'     
   END   
     
  IF @isMix IS NOT NULL   
   BEGIN  
    SET @Condition = @Condition + ' AND P.is_mix=' + CONVERT(VARCHAR(10), @isMix);  
   END   
  IF @batchId IS NOT NULL   
   BEGIN  
    SET @Condition = @Condition + ' AND P.batch_id=' + CONVERT(VARCHAR(10), @batchId);  
   END   
    
  if @isPool is not null  
   begin  
    SET @Condition = @Condition + ' AND p.is_pool=' + CONVERT(VARCHAR(10), @isPool);  
   end  
  if @isSmallQuantities is not null  
   begin  
    SET @Condition = @Condition + ' AND p.is_small_quantities=' + CONVERT(VARCHAR(10), @isSmallQuantities);  
   end  
    
  if @IsGift is not null  
   begin  
    SET @Condition = @Condition + ' AND p.is_gift=' + CONVERT(VARCHAR(10), @IsGift);  
   end   
  IF @shopId IS NOT NULL  
   BEGIN  
    SET @FromSQL = @FromSQL + ' LEFT JOIN  dbo.am_shop_product  am ON p.id=am.product_id AND (am.sku_end<>''0'' or am.sku_end is null) AND am.shop_id=' + CONVERT(VARCHAR(10), @shopId);  
   END   
  IF @name IS NOT NULL  
   BEGIN  
    SET @Condition = @Condition + ' AND p.name like ''%' + @name + '%''';  
   END   
  IF @status IS NOT NULL  
   BEGIN  
    IF @status=0  
     BEGIN  
      SET @Condition = @Condition + ' AND am.id is null';  
     END  
    IF @status=1  
     BEGIN  
      SET @Condition = @Condition + ' AND am.id is not null';  
     END   
   END    
            
    --设置需要取的字段信息                          
        SET @Column = '   p.id ,  
     cms_product_id AS cmsProductId,  
     p.cms_product_code AS cmsProductCode ,       
     last_category_name AS lastCategoryName,  
     p.category_id_1 as categoryId1,  
     p.category_id_2 as categoryId2,  
     p.category_id_3 as categoryId3,  
     is_small_quantities AS isSamllQuantities,  
     is_pool AS ispool,  
     is_mix AS isMix,  
     is_gift AS isGift,  
     primary_picture_code AS primaryPictureCode,  
     p.name ,  
     unit ,  
     unit_quantity AS unitQuantity,  
     weight ,  
     cost_price AS costPrice,  
     ph_price AS phPrice,  
     CASE WHEN am.id IS NULL THEN 0 ELSE 1 END AS status,  
     picture_status AS pictureStatus,  
     ISNULL(should_qty,0) AS  safetyStock,  
     u.name AS addUser ,  
     CASE WHEN (r.product_id is not null AND r.main_product_id is null) THEN 0   
          WHEN (r.product_id is not null AND r.main_product_id is not null) THEN 1 ELSE 2  
     END AS isMian,  
     ISNULL(r.main_product_id,ISNULL(r.product_id,p.id)) AS parent_sort  
         '  
        
      
       
        --求符合条件的总数                        
        SET @CountSql = ' SELECT @RowCount = count(p.id) ' + @FromSQL + @Condition                   
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT              
                              
    
        IF ISNULL(@PageSize, 0) < 1   
            SET @PageSize = 50                                
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
        IF ISNULL(@PageIndex, 0) < 1   
            SET @PageIndex = 1                                
        ELSE   
            IF ISNULL(@PageIndex, 0) > @PageCount   
                SET @PageIndex = @PageCount                                
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                
        SET @end = @PageIndex * @PageSize     
      
        SET @SQL = 'SELECT * from                        
       (                        
       SELECT *,ROW_NUMBER() OVER(ORDER BY temp.parent_sort DESC,isMian ASC) rowIndex                        
       from (SELECT ' +@Column + @FromSQL + @Condition  
            + ') temp                        
       ) temp2                             
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '  
            + CAST(@end AS NVARCHAR(10))      
              
        EXEC(@SQL);   
        PRINT @SQL;              
        SELECT  @RowCount                  
    END

go


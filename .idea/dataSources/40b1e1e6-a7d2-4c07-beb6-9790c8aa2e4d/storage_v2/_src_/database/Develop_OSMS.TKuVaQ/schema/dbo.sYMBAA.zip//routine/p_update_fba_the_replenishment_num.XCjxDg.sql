
/**
	实时计算非已入仓的数量
*/
CREATE PROC dbo.p_update_fba_the_replenishment_num
(
	@shopProductId VARCHAR(max)=NULL
)
AS 
BEGIN
	IF @shopProductId IS NULL
	BEGIN
		EXEC ('
			UPDATE  fba SET fba.fba_the_replenishment=ISNULL(tmp.fbaTheReplenishment,0)
			FROM dbo.fba_shop_product_inventory fba 
			LEFT JOIN (
			SELECT fba_shop_product_id,SUM(p.order_qty) AS fbaTheReplenishment FROM dbo.replenishment_order o
			INNER JOIN dbo.replenishment_order_product p
			ON o.id=p.replenishment_order_id AND p.status<>12
			WHERE   o.status<130 
			--AND p.fba_shop_product_id IN (7)
			GROUP BY p.fba_shop_product_id
			) tmp ON fba.fba_shop_product_id=tmp.fba_shop_product_id
			')
	END
	ELSE
	BEGIN
		EXEC ('

			UPDATE  fba SET fba.fba_the_replenishment=ISNULL(tmp.fbaTheReplenishment,0)
			FROM dbo.fba_shop_product_inventory fba 
			 INNER JOIN (
			SELECT fba_shop_product_id,SUM(p.order_qty) AS fbaTheReplenishment FROM dbo.replenishment_order o
			INNER JOIN dbo.replenishment_order_product p
			ON o.id=p.replenishment_order_id AND p.status<>12
			WHERE   o.status<130 
			AND p.fba_shop_product_id IN ('+@shopProductId+')
			GROUP BY p.fba_shop_product_id
			) tmp ON fba.fba_shop_product_id=tmp.fba_shop_product_id

			')
	END

END
go


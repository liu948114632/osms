CREATE VIEW v_FBA_store_Product_report AS (
	SELECT * FROM dbo.FBA_store_Product f WITH(NOLOCK)
	 LEFT JOIN dbo.FBA_store_product_report r WITH(NOLOCK)
	ON f.id=r.fba_store_product_id
)
go


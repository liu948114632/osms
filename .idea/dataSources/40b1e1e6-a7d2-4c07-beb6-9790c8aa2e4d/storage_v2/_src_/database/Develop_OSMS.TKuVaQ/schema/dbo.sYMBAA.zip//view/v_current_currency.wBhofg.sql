CREATE VIEW v_current_currency
AS 
(
	SELECT temp.currency ,temp.version,temp.rate
	FROM 
	(
	SELECT *,ROW_NUMBER() OVER (PARTITION BY currency ORDER BY id DESC) AS rowIndex
	FROM currency_exchange_rate
	) temp
	WHERE temp.rowIndex=1
)
go


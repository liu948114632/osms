/**
	更新待补货数量
 */
 CREATE PROC dbo.update_cms_await_replenishment(
	@month INT,
	@beginDate DATETIME,
	@endDate DATETIME
 )AS
 BEGIN
		UPDATE a SET
		a.sales=ISNULL(b.sales,0)
	 FROM dbo.shop_product_cms_info a
	 LEFT JOIN dbo.calc_order_info_cms_product(@beginDate,@endDate) b
	 ON a.cms_product_code=b.cms_product_code
 END
go


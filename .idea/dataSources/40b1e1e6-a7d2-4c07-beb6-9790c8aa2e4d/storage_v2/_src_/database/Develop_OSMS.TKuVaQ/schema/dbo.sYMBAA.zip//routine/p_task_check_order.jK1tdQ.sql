CREATE PROC p_task_check_order
AS
BEGIN
    SELECT [order].* INTO #tmp  FROM dbo.[order]
	LEFT  JOIN dbo.order_address ON order_address.order_id = [order].id
	WHERE order_id IS NULL 
	AND shop_type=1

	DELETE FROM dbo.[order] WHERE id IN (
	SELECT id FROM #tmp
	)

	update dbo.am_order_communication_log SET status=0 ,dowm_count=0
	WHERE amazon_order_id IN (
	SELECT shop_order_code FROM #tmp)
END
go


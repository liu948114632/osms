--ALTER PROC dbo.p_cms_replenishment_product
--(
	
--	@cmsProductCode VARCHAR(100)=NULL,
--	@cmsProductCodes VARCHAR(max)=NULL,
--	@isRemindCMSReplenishment INT =NULL,
--	@month INT=NULL,
--	@beginDate DATETIME=NULL,
--	@endDate DATETIME=NULL,
--	@PageSize INT = 50 ,  --页大小                          
--    @PageIndex INT = 1    --当前页号   
--)
--AS
--BEGIN
--    DECLARE @SQL VARCHAR(MAX) ,  
--    @CountSql NVARCHAR(MAX) , --查询数量用    
--    @FromSQL NVARCHAR(MAX) , --查询表  
--	@FromSQL2 NVARCHAR(MAX),                                         
--    @Column NVARCHAR(MAX) , --查询字段                         
--    @Condition VARCHAR(MAX) , --条件                           
--    @RowCount INT ,  
--    @PageCount INT ,  
--    @start INT ,  
--    @end INT 

--	--设置查询主表      
--    SET @FromSQL = ' 
			
--		 SELECT DISTINCT cms2.cms_product_id,a2.await_replenishment  FROM dbo.shop_product_cms_info cms2 
--			inner join dbo.find_order_info_cms_product('+CAST(@month AS NVARCHAR(10))+','''+CONVERT(varchar(100), @beginDate, 21)+''','''+CONVERT(varchar(100), @endDate, 21)+''') a2
--			on a2.cms_product_code = cms2.cms_product_code
--					inner JOIN dbo.fba_shop_product fba2 
--						ON fba2.cms_product_id = cms2.cms_product_id 
--						inner join fba_shop_product_inventory inv2
--					on inv2.fba_shop_product_id=fba2.id 
					
--	 '  
--	 PRINT @FromSQL
--	SET @FromSQL2 =' FROM shop_product_cms_info cms
--		--inner join dbo.find_order_info_cms_product('+CAST(@month AS NVARCHAR(10))+','+CAST(@beginDate AS NVARCHAR(20))+','+CAST(@endDate AS NVARCHAR(10))+') a
--		--	on a.cms_product_code = cms.cms_product_code
--					inner JOIN dbo.fba_shop_product fba
--					ON fba.cms_product_id = cms.cms_product_id 
--					left join shop on shop.id=fba.shop_id 
--					inner join fba_shop_product_inventory inv
--					on inv.fba_shop_product_id=fba.id
--					'
--    SET @Condition = ' WHERE  1=1 '                


--	--设置查询条件  
     
--	 IF @isRemindCMSReplenishment IS NOT NULL   
--		BEGIN  
--			IF @isRemindCMSReplenishment =1
--			BEGIN
--			    SET @Condition = @Condition + ' AND a2.await_replenishment>0 '
--			END
--			ELSE 
--			BEGIN
--			     SET @Condition = @Condition + ' AND a2.await_replenishment<=0 '
--			END   
             
--		END   

--	IF @cmsProductCodes IS NOT NULL  
--		BEGIN  
--			SET @Condition = @Condition + ' AND cms2.cms_product_code in (''' + REPLACE(@cmsProductCodes,',',''',''') + ''')'     
--		END  

--	IF @cmsProductCode IS NOT NULL  
--		BEGIN  
--			SET @Condition = @Condition + ' AND  cms2.cms_product_code like ''' + @cmsProductCode + '%''';  
--		END 

--	--设置需要取的字段信息                          
--        SET @Column = ' 
--			shop.name as shopName ,
--		   cms.product_name as productName,
--		   cms.unit_quantity as unitQuantity,
--		   cms.available_stock as availableStock,
--		   cms.primary_picture_code as primaryPictureCode,
--		   cms.unit ,
--		   tmp2.await_replenishment cmsAwaitReplenishment,
--		   cms.the_replenishment cmsTheReplenishment,
--		   fba.id as fbaShopProductId,
--		   fba.shop_id as shopId,
--		   fba.sku ,
--		   fba.fba_barcode_name as fbaBarcodeName,
--		   fba.fba_barcode_sku as fbaBarcodeSku,
--		   fba.cms_product_id as cmsProductId,
--		   fba.cms_product_code as cmsProductCode,
--            inv.fba_security_line as fbaSecurityLine,
--            inv.sum_security_line as sumSecurityLine,
--            inv.fba_available_stock as fbaAvailableStock
--         '  
        

	
--	SET @FromSQL='from ( ' + @FromSQL + @Condition   +' ) tmp3 '     

--    --求符合条件的总数                        
--    SET @CountSql = ' SELECT @RowCount = count(cms_product_id) ' + @FromSQL                
--    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT              
                              
    
--    IF ISNULL(@PageSize, 0) < 1   
--        SET @PageSize = 50                                
--    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
--    IF ISNULL(@PageIndex, 0) < 1   
--        SET @PageIndex = 1                                
--    ELSE   
--        IF ISNULL(@PageIndex, 0) > @PageCount   
--            SET @PageIndex = @PageCount                                
--    SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                
--    SET @end = @PageIndex * @PageSize    

--	  SET @SQL = '
--	  select '+ @Column +@FromSQL2+'
--		INNER JOIN 
--		(
--		SELECT * FROM (
--		SELECT cms_product_id,await_replenishment, ROW_NUMBER() OVER( ORDER BY await_replenishment DESC) orderIndex  
--		'+@FromSQL+'
--		) tmp WHERE tmp.orderIndex BETWEEN ' + CAST(@start AS NVARCHAR(10)) + '
		
--		 AND '+CAST(@end AS NVARCHAR(10)) +' ) tmp2
--		ON tmp2.cms_product_id = cms.cms_product_id
--		ORDER BY tmp2.orderIndex asc
--	  '   
              
--        EXEC(@SQL);   
--        PRINT @SQL;              
--        SELECT  @RowCount 
--END
--GO



--EXEC dbo.p_cms_replenishment_product  
--    @month = 1, -- int
--    @beginDate = '2016-08-18 01:27:03', -- datetime
--    @endDate = '2017-08-18 01:27:03'




--	SELECT DISTINCT cms2.cms_product_id,a2.await_replenishment  FROM dbo.shop_product_cms_info cms2 

--	INNER JOIN dbo.find_order_info_cms_product(1,'2016-03-22 20:39:16.000','2017-03-22 20:39:16.000') a2
--	ON a2.cms_product_code = cms2.cms_product_code


--	SELECT * FROM dbo.find_order_info_cms_product(1,'2016-03-22 20:39:16.000','2017-03-22 20:39:16.000')


--	GO
    

	

--	  select  
--			shop.name as shopName ,
--		   cms.product_name as productName,
--		   cms.unit_quantity as unitQuantity,
--		   cms.available_stock as availableStock,
--		   cms.primary_picture_code as primaryPictureCode,
--		   cms.unit ,
--		   --tmp2.await_replenishment cmsAwaitReplenishment,
--		   cms.the_replenishment cmsTheReplenishment,
--		   fba.id as fbaShopProductId,
--		   fba.shop_id as shopId,
--		   fba.sku ,
--		   fba.fba_barcode_name as fbaBarcodeName,
--		   fba.fba_barcode_sku as fbaBarcodeSku,
--		   fba.cms_product_id as cmsProductId,
--		   fba.cms_product_code as cmsProductCode,
--            inv.fba_security_line as fbaSecurityLine,
--            inv.sum_security_line as sumSecurityLine,
--            inv.fba_available_stock as fbaAvailableStock
--          FROM shop_product_cms_info cms
--		--inner join dbo.find_order_info_cms_product(1,08 18 2016  1:27AM,08 18 2017) a
--		--	on a.cms_product_code = cms.cms_product_code
--					inner JOIN dbo.fba_shop_product fba
--					ON fba.cms_product_id = cms.cms_product_id 
--					left join shop on shop.id=fba.shop_id 
--					inner join fba_shop_product_inventory inv
--					on inv.fba_shop_product_id=fba.id
					
--		INNER JOIN 
--		(
--		SELECT * FROM (
--		SELECT cms_product_id,await_replenishment, ROW_NUMBER() OVER( ORDER BY await_replenishment DESC) orderIndex  
--		from (  
			
--		 SELECT DISTINCT cms2.cms_product_id,a2.await_replenishment 
--		  FROM dbo.shop_product_cms_info cms2 
--			inner join dbo.find_order_info_cms_product(1,'2016-08-18 01:27:03.000','2017-08-18 01:27:03.000') a2
--			on a2.cms_product_code = cms2.cms_product_code
--					inner JOIN dbo.fba_shop_product fba2 
--						ON fba2.cms_product_id = cms2.cms_product_id 
--						inner join fba_shop_product_inventory inv2
--					on inv2.fba_shop_product_id=fba2.id 
					
--	  WHERE  1=1  ) tmp3 
--		) tmp WHERE tmp.orderIndex BETWEEN 1
		
--		 AND 50 ) tmp2
--		ON tmp2.cms_product_id = cms.cms_product_id
--		ORDER BY tmp2.orderIndex asc
	  


	  
 CREATE PROC dbo.p_cms_replenishment_product
 (
 	
 	@cmsProductCode VARCHAR(100)=NULL,
 	@cmsProductCodes VARCHAR(max)=NULL,
 	@isRemindCMSReplenishment INT =NULL,
 	@PageSize INT = 50 ,  --页大小                          
     @PageIndex INT = 1    --当前页号   
 )
 AS
 BEGIN
     DECLARE @SQL VARCHAR(MAX) ,  
     @CountSql NVARCHAR(MAX) , --查询数量用    
     @FromSQL NVARCHAR(MAX) , --查询表  
 	@FromSQL2 NVARCHAR(MAX),                                         
     @Column NVARCHAR(MAX) , --查询字段                         
     @Condition VARCHAR(MAX) , --条件                           
     @RowCount INT ,  
     @PageCount INT ,  
     @start INT ,  
     @end INT 
 
 	--设置查询主表      
     SET @FromSQL = ' 
 			
 		 SELECT DISTINCT cms2.cms_product_id,cms2.await_replenishment  FROM dbo.shop_product_cms_info cms2 
 					inner JOIN dbo.fba_shop_product fba2 
 						ON fba2.cms_product_id = cms2.cms_product_id 
 						inner join fba_shop_product_inventory inv2
 					on inv2.fba_shop_product_id=fba2.id 
 					
 	 '  
 
 	SET @FromSQL2 =' FROM shop_product_cms_info cms
 					inner JOIN dbo.fba_shop_product fba
 					ON fba.cms_product_id = cms.cms_product_id 
 					left join shop on shop.id=fba.shop_id 
 					inner join fba_shop_product_inventory inv
 					on inv.fba_shop_product_id=fba.id
 					'
     SET @Condition = ' WHERE  1=1 '                
 
 	--设置查询条件  
      
 	 IF @isRemindCMSReplenishment IS NOT NULL   
 		BEGIN  
 			IF @isRemindCMSReplenishment =1
 			BEGIN
 			    SET @Condition = @Condition + ' AND cms2.await_replenishment>0 '
 			END
 			ELSE 
 			BEGIN
 			     SET @Condition = @Condition + ' AND cms2.await_replenishment<=0 '
 			END   
              
 		END   
 
 	IF @cmsProductCodes IS NOT NULL  
 		BEGIN  
 			SET @Condition = @Condition + ' AND cms2.cms_product_code in (''' + REPLACE(@cmsProductCodes,',',''',''') + ''')'     
 		END  
 
 	IF @cmsProductCode IS NOT NULL  
 		BEGIN  
 			SET @Condition = @Condition + ' AND  cms2.cms_product_code like ''' + @cmsProductCode + '%''';  
 		END 
 
 	--设置需要取的字段信息                          
         SET @Column = ' 
 			shop.name as shopName ,
 		   cms.product_name as productName,
 		   cms.unit_quantity as unitQuantity,
 		   cms.available_stock as availableStock,
 		   cms.primary_picture_code as primaryPictureCode,
 		   cms.unit ,
 		   cms.await_replenishment cmsAwaitReplenishment,
 		   cms.the_replenishment cmsTheReplenishment,
		   cms.sales,
 		   fba.id as fbaShopProductId,
 		   fba.shop_id as shopId,
 		   fba.sku ,
 		   fba.fba_barcode_name as fbaBarcodeName,
 		   fba.fba_barcode_sku as fbaBarcodeSku,
 		   fba.cms_product_id as cmsProductId,
 		   fba.cms_product_code as cmsProductCode,
             inv.fba_security_line as fbaSecurityLine,
             inv.sum_security_line as sumSecurityLine,
             inv.fba_available_stock as fbaAvailableStock
          '  
         
 
 	
 	SET @FromSQL='from ( ' + @FromSQL + @Condition   +' ) tmp3 '     
 
     --求符合条件的总数                        
     SET @CountSql = ' SELECT @RowCount = count(cms_product_id) ' + @FromSQL                
     EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT              
                               
     
     IF ISNULL(@PageSize, 0) < 1   
         SET @PageSize = 50                                
     SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
     IF ISNULL(@PageIndex, 0) < 1   
         SET @PageIndex = 1                                
     ELSE   
         IF ISNULL(@PageIndex, 0) > @PageCount   
             SET @PageIndex = @PageCount                                
     SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                
     SET @end = @PageIndex * @PageSize    
 
 	  SET @SQL = '
 	  select '+ @Column +@FromSQL2+'
 		INNER JOIN 
 		(
 		SELECT * FROM (
 		SELECT cms_product_id,ROW_NUMBER() OVER( ORDER BY await_replenishment DESC) orderIndex  
 		'+@FromSQL+'
 		) tmp WHERE tmp.orderIndex BETWEEN ' + CAST(@start AS NVARCHAR(10)) + '
 		
 		 AND '+CAST(@end AS NVARCHAR(10)) +' ) tmp2
 		ON tmp2.cms_product_id = cms.cms_product_id
 		ORDER BY tmp2.orderIndex asc
 	  '   
               
         EXEC(@SQL);   
         PRINT @SQL;              
         SELECT  @RowCount 
 END
go


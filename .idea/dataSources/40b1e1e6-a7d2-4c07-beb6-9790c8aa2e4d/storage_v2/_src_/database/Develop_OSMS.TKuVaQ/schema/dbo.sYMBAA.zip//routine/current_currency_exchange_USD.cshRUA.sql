
/**
	转美元
*/
CREATE FUNCTION current_currency_exchange_USD(
	@amount DECIMAL(18,3),
	@soucreCurrency INT
)RETURNS DECIMAL(18,3)
AS
BEGIN
	DECLARE @soucreRate DECIMAL(18,6),@usdRate DECIMAL(18,6)
    SELECT @soucreRate=rate FROM current_currency_exchange_rate WHERE currency=@soucreCurrency
	SELECT @usdRate=rate FROM current_currency_exchange_rate WHERE currency=2

	RETURN @amount*@soucreRate/@usdRate
END
go


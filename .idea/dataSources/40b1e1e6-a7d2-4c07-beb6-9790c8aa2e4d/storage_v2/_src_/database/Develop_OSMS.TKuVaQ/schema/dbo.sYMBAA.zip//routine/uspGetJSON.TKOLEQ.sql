create PROC uspGetJSON(
@TableName varchar(100),
@ColumnIn nvarchar(100)='',
@ColumnValues nvarchar(max),
@Condition NVARCHAR(max)='',
@Json varchar(max) OUTPUT,
@Limit int =NULL,
@ConvertColumns NVARCHAR(max)=null
--@SortColumn nvarchar(100)=null,
--@SortType nvarchar(10)='asc'
)
AS
--if(@SortColumn is null)
--	set @SortColumn='LastModifiedDate'
declare @query varchar(max),
@table_schema varchar(max) = null
if(charindex('.', @TableName) > 0 )
begin
set @table_schema = replace(replace( substring(@TableName, 0, charindex('.',@TableName)), '[', ''), ']', '')
set @TableName = replace(replace( substring(@TableName, charindex('.',@TableName) + 1,len(@TableName)), '[', ''), ']', '')
END
IF EXISTS ( SELECT 1 FROM tempdb..sysobjects WHERE id = OBJECT_ID('tempdb..#tmpJsonTable') ) 
DROP TABLE #tmpJsonTable
CREATE TABLE #tmpJsonTable
(
json NVARCHAR(max) NULL
)
--"dd"
set @query = 
'insert into #tmpJsonTable select ' + case when @Limit is not null then 'top ' + cast(@Limit as varchar(32)) + ' ' else '' end + '''{ '' + REVERSE(STUFF(REVERSE(''' +
CAST((SELECT ' "' + column_name + '" : ' + 
----处理为null的问题
case WHEN is_nullable = 'YES' then ''' + case when [' + column_name + '] is null then ''null'' else ' + 
--处理前缀"
case WHEN data_type='uniqueidentifier'or data_type like '%date%' or data_type like '%char%' or data_type like '%text%' then '''"'' + ' else '' end + 
/*类型转换*/
case WHEN data_type like '%date%' then 'convert(varchar(23),[' + column_name + '], 20)+ ''"''' 
else 'replace(replace(replace(replace(replace(cast([' + column_name + '] as varchar(max)),''\'',''\\''),''"'',''\"''),char(10),''\n''),char(13),''\n''),char(9),''\t'') ' end + 
--处理后缀"
case WHEN data_type='uniqueidentifier' or data_type like '%char%' or data_type like '%text%' then '+ ''"''' else '' end + ' end + '''
ELSE
--处理前缀" 
case WHEN data_type='uniqueidentifier' or data_type like '%date%' or data_type like '%char%' or data_type like '%text%' then '"' else '' end + ''' + ' +
/*类型转换*/
case WHEN data_type like '%date%' then 'convert(varchar(23),[' + column_name + '], 20)+ '''
else 'replace(replace(replace(replace(replace(cast([' + column_name + '] as varchar(max)),''\'',''\\''),''"'',''\"''),char(10),''\n''),char(13),''\n''),char(9),''\t'') + ''' end +
--处理后缀"
case WHEN data_type='uniqueidentifier'OR data_type LIKE 'date%' or data_type like '%char%' or data_type like '%text%' then '"' else '' end end + ','
AS [text()] 
from information_schema.columns 
where table_name = @TableName 
and (character_maximum_length IS NULL OR character_maximum_length!=-1)
AND(@ConvertColumns IS NULL OR COLUMN_NAME IN(SELECT MyValues FROM dbo.funSplitArray(@ConvertColumns,',')))
and (@table_schema is null or table_schema = @table_schema) FOR XML PATH('') ) as varchar(max)) +
'''),1,1,'''')) + '' }'' as json from ' + @TableName + ' with(nolock) where ('+@ColumnIn+' in (Select MyValues from dbo.funSplitArray('''+@ColumnValues+''','',''))) '+@Condition--+' ORDER BY '+@SortColumn+' '+@SortType
exec sp_sqlexec @query
--SELECT @query
set @Json = 
--'{' + char(10) + char(9) +
--'"recordCount" : ' + Cast((select count(*) from #tmpJsonTable) as varchar(32)) + ',' + char(10) + char(9) +
--'"records" : ' + char(10) + char(9) + char(9) + 
'[' + char(10)
+ REVERSE(STUFF(REVERSE(CAST((SELECT char(9) + char(9) + json + ',' + char(10) AS [text()] FROM #tmpJsonTable FOR XML PATH('')) AS varchar(max))),1,2,''))
+ char(10) + char(9) + char(9) + ']'
-- + char(10) + '}'
drop table #tmpJsonTable

 
 
--DECLARE @table_name varchar(100)='SalesOrder',
-- @ConvertColumns NVARCHAR(max)='SalesOrderNo,SalesOrderID',
-- @Condition NVARCHAR(max)='',
-- @json varchar(max)
 
--EXEC GetJSON @table_name=@table_name,@ConvertColumns=@ConvertColumns,@Condition=@Condition,@json=@json OUTPUT
--SELECT @json
go


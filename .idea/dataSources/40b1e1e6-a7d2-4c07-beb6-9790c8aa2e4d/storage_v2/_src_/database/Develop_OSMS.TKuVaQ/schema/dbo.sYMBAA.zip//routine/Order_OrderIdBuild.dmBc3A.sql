

/*  修改根据订单来源生成编号的规则  */    
CREATE PROC dbo.Order_OrderIdBuild  
(  
    --@OrderType INT, --订单业务类型: 1、amazon 2、ebay 3、smt 
	@shopType INT,
    @Code NVARCHAR(15) = NULL OUTPUT  
)  
AS  
DECLARE @a INT, @i INT,@prefix varchar(2);  
BEGIN  
    SET @prefix = ''  
 SET @i = 0;  
 SET @Code = CONVERT(nchar(6), GETDATE(), 12);  
 WHILE (@i < 1)  
 BEGIN  
  SET @a = CAST(RAND() * 899999 + 100000 AS INT);  
 
  IF NOT EXISTS (SELECT 1 FROM dbo.[order] 
                 WHERE LEN(code)<=14
           AND LEFT(RIGHT([code], 12), 4) =  LEFT(@Code, 4)   
        AND LEFT(RIGHT([code], 6), 6) = CONVERT(nchar(6), @a))   
  BEGIN 
   SET @Code = @Code + CONVERT(nchar(6), @a);  
  SET @i = @i + 1; 
  END  
 END  
  SELECT @prefix =
              CASE @shopType 
                 
					WHEN 1  THEN 'WA'    --wh-am订单 
                      WHEN 2  THEN 'WE'   --wh-ebay订单 
					  WHEN 3 THEN 'WT'   --wh-smt
					  WHEN 4 THEN 'BC'  --wh-bbc
                    ELSE 'M'            --PH或其他邮件订单  
              END   
            
     SET @Code = @prefix + @Code;  
END

go


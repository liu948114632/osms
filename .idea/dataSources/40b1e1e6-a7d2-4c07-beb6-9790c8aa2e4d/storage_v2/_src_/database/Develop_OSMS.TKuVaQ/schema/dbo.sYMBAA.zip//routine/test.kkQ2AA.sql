create function test(
@str varchar(50),
@str2 varchar(50)
)
returns varchar(100)
as 
begin 
RETURN @str+'|'+@str2
end
go



CREATE PROC p_fba_shop_product_inventory
(
	@shopId INT=NULL,
	@sku VARCHAR(100)=NULL,
	@skus VARCHAR(max)=NULL,
	@cmsProductCode VARCHAR(100)=NULL,
	@cmsProductCodes VARCHAR(max)=NULL,
	@isUpdateFbaSecurityLine INT =NULL,
	@isUpdateSumSecurityLine INT =NULL,
	@isRemindFbaReplenishment INT =NULL,
	@PageSize INT = 50 ,  --页大小                          
    @PageIndex INT = 1    --当前页号   
)
AS
BEGIN
    DECLARE @SQL VARCHAR(MAX) ,  
    @CountSql NVARCHAR(MAX) , --查询数量用    
    @FromSQL NVARCHAR(MAX) , --查询表                                           
    @Column NVARCHAR(MAX) , --查询字段                         
    @Condition VARCHAR(MAX) , --条件                           
    @RowCount INT ,  
    @PageCount INT ,  
    @start INT ,  
    @end INT 

	--设置查询主表      
    SET @FromSQL = ' FROM dbo.fba_shop_product_inventory i
						INNER JOIN dbo.fba_shop_product f
						ON f.id=i.fba_shop_product_id
						LEFT JOIN dbo.shop_product_cms_info cms
						ON cms.cms_product_id = f.cms_product_id '  
             
    SET @Condition = ' WHERE  1=1 '                

	--设置查询条件  
    IF @shopId IS NOT NULL   
		BEGIN  
			SET @Condition = @Condition + ' AND f.shop_id=' + CONVERT(VARCHAR(10), @shopId)   
             
		END    
	
	 IF @isUpdateFbaSecurityLine IS NOT NULL   
		BEGIN  
			SET @Condition = @Condition + ' AND i.is_update_fba_security_line=' + CONVERT(VARCHAR(10), @isUpdateFbaSecurityLine)   
             
		END   

	IF @isUpdateSumSecurityLine IS NOT NULL   
		BEGIN  
			SET @Condition = @Condition + ' AND i.is_update_sum_security_line=' + CONVERT(VARCHAR(10), @isUpdateSumSecurityLine)   
             
		END   
		
	IF @isRemindFbaReplenishment IS NOT NULL   
		BEGIN  
			SET @Condition = @Condition + ' AND i.is_remind_fba_replenishment=' + CONVERT(VARCHAR(10), @isRemindFbaReplenishment)   
             
		END   
	IF @cmsProductCodes IS NOT NULL  
		BEGIN  
			SET @Condition = @Condition + ' AND f.cms_product_code in (''' + REPLACE(@cmsProductCodes,',',''',''') + ''')'     
		END  

	IF @cmsProductCode IS NOT NULL  
		BEGIN  
			SET @Condition = @Condition + ' AND  f.cms_product_code like ''' + @cmsProductCode + '%''';  
		END 

	IF @skus IS NOT NULL  
		BEGIN  
			SET @Condition = @Condition + ' AND f.sku in (''' + REPLACE(@skus,',',''',''') + ''')'     
		END  

	IF @sku IS NOT NULL  
		BEGIN  
			SET @Condition = @Condition + ' AND  f.sku like ''' + @sku + '%''';  
		END 

	--设置需要取的字段信息                          
        SET @Column = '  
			i.id,
			f.id as fbaShopProductId,
           f.shop_id shopId,
           f.sku ,
           f.fba_barcode_name fbaBarcodeName ,
           f.fba_barcode_sku fbaBarcodeSku,
           f.cms_product_id cmsProductId,
           f.cms_product_code cmsProductCode,
           f.status ,
           cms.product_name as productName,
           cms.unit_quantity unitQuantity,
           cms.primary_picture_code primaryPictureCode,
           cms.unit ,
		   cms.cost_price as costPrice,
		   cms.available_stock as availableStock,
		   	i.fba_await_replenishment fbaAwaitReplenishment,
			i.fba_the_replenishment fbaTheReplenishment,
			i.fba_security_line fbaSecurityLine,
			i.sum_security_line sumSecurityLine,
			i.fba_available_stock as fbaAvailableStock,
			i.is_update_fba_security_line as updateFbaSecurityLine,
			i.is_update_sum_security_line as updateSumSecurityLine,
			i.is_remind_fba_replenishment as remindFbaReplenishment,
			i.days_sales_fba as daysSales
         '  
        

	
    --求符合条件的总数                        
    SET @CountSql = ' SELECT @RowCount = count(f.id) ' + @FromSQL + @Condition                   
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT              
                              
    
    IF ISNULL(@PageSize, 0) < 1   
        SET @PageSize = 50                                
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
    IF ISNULL(@PageIndex, 0) < 1   
        SET @PageIndex = 1                                
    ELSE   
        IF ISNULL(@PageIndex, 0) > @PageCount   
            SET @PageIndex = @PageCount                                
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                
    SET @end = @PageIndex * @PageSize    

	  SET @SQL = 'SELECT * from                        
       (                        
       SELECT *,ROW_NUMBER() OVER(ORDER BY temp.updateFbaSecurityLine desc,updateSumSecurityLine desc
		,remindFbaReplenishment desc, sku ASC) rowIndex                        
       from (SELECT ' +@Column + @FromSQL + @Condition  
            + ') temp                        
       ) temp2                             
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '  
            + CAST(@end AS NVARCHAR(10))      
              
        EXEC(@SQL);   
        PRINT @SQL;              
        SELECT  @RowCount 
END
go


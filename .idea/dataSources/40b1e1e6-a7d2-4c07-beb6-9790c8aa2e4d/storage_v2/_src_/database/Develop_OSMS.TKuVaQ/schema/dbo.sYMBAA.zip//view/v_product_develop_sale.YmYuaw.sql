CREATE VIEW dbo.v_product_develop_sale
 AS
 SELECT p.cms_product_code,SUM(dbo.current_currency_exchange_USD(c.shop_item_price,c.shop_item_curtype)) AS sales  FROM product_develop p WITH(NOLOCK)
 INNER JOIN dbo.order_product c WITH(NOLOCK) ON p.cms_product_code=c.cms_product_code AND c.is_cancel=0
 INNER JOIN dbo.[order] a WITH(NOLOCK) ON a.status<132 AND a.shop_type=1 AND a.id=c.order_id
 AND a.shop_order_date>=p.putaway_date
 GROUP BY p.cms_product_code
go


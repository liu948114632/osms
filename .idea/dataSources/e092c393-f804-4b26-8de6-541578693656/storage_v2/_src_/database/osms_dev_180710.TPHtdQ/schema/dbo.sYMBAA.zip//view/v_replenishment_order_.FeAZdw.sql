CREATE VIEW [dbo].[v_replenishment_order_]
AS
SELECT  
                      o.id, o.code, o.customer_name, o.is_send, o.status, o.shipping_method, o.shop_id, o.cost_freight, o.cost_price, 
                      o.send_group_id, o.tracking_code, o.remark, o.out_date, o.delivery_date,  o.order_item_num, 
                      o.order_item_prepare_num, o.shop_type, o.latest_delivery_date, o.earliest_delivery_date, o.latest_shipping_date,
                      o.earliest_shipping_date, o.add_order_date, o.country, o.CPF_code, o.Is_Quality_Inspection, 
                      o.reimburse_freight_percent, o.merchandiser_id, o.cpf_type, o.problem_status, o.problem_type, m.merchandiser_name,
                      o.delivery_customer_service,o.add_user,o.repository_id,o.is_modify_delivery_remark,
					  o.confirm_date,o.delivery_remark,o.recipients,
                      o.await_confirm_cancel,o.await_confirm_resend,o.awaite_putaway,o.shipping_list_status,o.shipment_ID,o.cms_prepare,o.copy,o.order_amazon_status
FROM         dbo.replenishment_order AS o LEFT OUTER JOIN
                      dbo.merchandiser AS m ON m.id = o.merchandiser_id
					  WHERE o.submit_status='1' OR o.submit_status IS NULL
go



 CREATE PROC dbo.p_cms_replenishment_product
 (
 	
 	@cmsProductCode VARCHAR(100)=NULL,
 	@cmsProductCodes VARCHAR(max)=NULL,
 	@isRemindCMSReplenishment INT =NULL,
 	@PageSize INT = 50 ,  --页大小                          
     @PageIndex INT = 1    --当前页号   
 )
 AS
 BEGIN
     DECLARE @SQL VARCHAR(MAX) ,  
     @CountSql NVARCHAR(MAX) , --查询数量用    
     @FromSQL NVARCHAR(MAX) , --查询表  
 	@FromSQL2 NVARCHAR(MAX),                                         
     @Column NVARCHAR(MAX) , --查询字段                         
     @Condition VARCHAR(MAX) , --条件                           
     @RowCount INT ,  
     @PageCount INT ,  
     @start INT ,  
     @end INT 
 
 	--设置查询主表      
     SET @FromSQL = ' 
 			
 		 SELECT DISTINCT cms2.cms_product_id,cms2.await_replenishment  FROM dbo.shop_product_cms_info cms2 
 					inner JOIN dbo.fba_shop_product fba2 
 						ON fba2.cms_product_id = cms2.cms_product_id 
 						inner join fba_shop_product_inventory inv2
 					on inv2.fba_shop_product_id=fba2.id 
 					
 	 '  
 
 	SET @FromSQL2 =' FROM shop_product_cms_info cms
 					inner JOIN dbo.fba_shop_product fba
 					ON fba.cms_product_id = cms.cms_product_id 
 					left join shop on shop.id=fba.shop_id 
 					inner join fba_shop_product_inventory inv
 					on inv.fba_shop_product_id=fba.id
 					'
     SET @Condition = ' WHERE  1=1 '                
 
 	--设置查询条件  
      
 	 IF @isRemindCMSReplenishment IS NOT NULL   
 		BEGIN  
 			IF @isRemindCMSReplenishment =1
 			BEGIN
 			    SET @Condition = @Condition + ' AND cms2.await_replenishment>0 '
 			END
 			ELSE 
 			BEGIN
 			     SET @Condition = @Condition + ' AND cms2.await_replenishment<=0 '
 			END   
              
 		END   
 
 	IF @cmsProductCodes IS NOT NULL  
 		BEGIN  
 			SET @Condition = @Condition + ' AND cms2.cms_product_code in (''' + REPLACE(@cmsProductCodes,',',''',''') + ''')'     
 		END  
 
 	IF @cmsProductCode IS NOT NULL  
 		BEGIN  
 			SET @Condition = @Condition + ' AND  cms2.cms_product_code like ''' + @cmsProductCode + '%''';  
 		END 
 
 	--设置需要取的字段信息                          
         SET @Column = ' 
 			shop.name as shopName ,
 		   cms.product_name as productName,
 		   cms.unit_quantity as unitQuantity,
 		   cms.available_stock as availableStock,
 		   cms.primary_picture_code as primaryPictureCode,
 		   cms.unit ,
 		   cms.await_replenishment cmsAwaitReplenishment,
 		   cms.the_replenishment cmsTheReplenishment,
		   cms.sales,
 		   fba.id as fbaShopProductId,
 		   fba.shop_id as shopId,
 		   fba.sku ,
 		   fba.fba_barcode_name as fbaBarcodeName,
 		   fba.fba_barcode_sku as fbaBarcodeSku,
 		   fba.cms_product_id as cmsProductId,
 		   fba.cms_product_code as cmsProductCode,
             inv.fba_security_line as fbaSecurityLine,
             inv.sum_security_line as sumSecurityLine,
             inv.fba_available_stock as fbaAvailableStock
          '  
         
 
 	
 	SET @FromSQL='from ( ' + @FromSQL + @Condition   +' ) tmp3 '     
 
     --求符合条件的总数                        
     SET @CountSql = ' SELECT @RowCount = count(cms_product_id) ' + @FromSQL                
     EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT              
                               
     
     IF ISNULL(@PageSize, 0) < 1   
         SET @PageSize = 50                                
     SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
     IF ISNULL(@PageIndex, 0) < 1   
         SET @PageIndex = 1                                
     ELSE   
         IF ISNULL(@PageIndex, 0) > @PageCount   
             SET @PageIndex = @PageCount                                
     SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                
     SET @end = @PageIndex * @PageSize    
 
 	  SET @SQL = '
 	  select '+ @Column +@FromSQL2+'
 		INNER JOIN 
 		(
 		SELECT * FROM (
 		SELECT cms_product_id,ROW_NUMBER() OVER( ORDER BY await_replenishment DESC) orderIndex  
 		'+@FromSQL+'
 		) tmp WHERE tmp.orderIndex BETWEEN ' + CAST(@start AS NVARCHAR(10)) + '
 		
 		 AND '+CAST(@end AS NVARCHAR(10)) +' ) tmp2
 		ON tmp2.cms_product_id = cms.cms_product_id
 		ORDER BY tmp2.orderIndex asc
 	  '   
               
         EXEC(@SQL);   
         PRINT @SQL;              
         SELECT  @RowCount 
 END
 go


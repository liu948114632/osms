CREATE PROCEDURE p_currency_change_history
AS 
BEGIN
    --TRUNCATE TABLE dbo.currency_change_history

    DECLARE @currency_id INT ,@count1 INT ,@index1 INT ,@count2 INT ,@index2 INT ,@last_version VARCHAR(10),@current_version VARCHAR(10),@current_operate_time datetime ,
	@rmb_rate DECIMAL(18,6),@usd_rate DECIMAL(18,6),@usd_currency_id INT 

	SELECT @usd_currency_id = id FROM dbo.currency WHERE code='USD'

    SELECT *  ,CONVERT( DATETIME,SUBSTRING([version],1,4) + '-'+ SUBSTRING([version],5,2) + '-1') AS operate_time, ROW_NUMBER() OVER(PARTITION BY currency ORDER BY id) AS rowIndex INTO #temp1
FROM dbo.currency_exchange_rate  

    SELECT DISTINCT currency,ROW_NUMBER() OVER(ORDER BY currency) AS rowIndex INTO #temp2
    FROM dbo.currency_exchange_rate  

    SELECT @count2 = COUNT(*) FROM #temp2
	SET @index2 = 0
	WHILE @index2 < @count2
	BEGIN
	   SET @index2= @index2 + 1
	   SELECT @currency_id = currency FROM #temp2 WHERE rowIndex= @index2

	    SET @last_version = NULL 
	    SELECT @count1 = COUNT(*) FROM #temp1 WHERE currency=@currency_id
		SELECT @last_version = MAX([version]) FROM currency_change_history WHERE currency_id=@currency_id 

		IF( @last_version IS NOT NULL )
		BEGIN
             SELECT @index1 = rowIndex FROM #temp1 WHERE currency=@currency_id AND [version] = @last_version
		END 
		ELSE
        BEGIN 
		    SET @index1 = 0
		END 

		WHILE @index1 < @count1
	    BEGIN
		    SET @index1 = @index1 +1 
			
			SELECT @current_operate_time = operate_time,@rmb_rate =rate FROM #temp1 WHERE currency=@currency_id AND rowIndex= @index1

			--更新上一个记录的最后时间为该记录的操作时间
			UPDATE currency_change_history SET end_time=@current_operate_time WHERE currency_id=@currency_id AND [version] = @last_version 

			SELECT @last_version = [version] FROM #temp1 WHERE currency=@currency_id AND rowIndex= @index1

			--取当时的美元汇率
			SELECT @usd_rate = CONVERT(DECIMAL(18,6),@rmb_rate / rate) FROM #temp1 WHERE currency=@usd_currency_id AND [version] = @last_version

			--插入本次记录
			INSERT INTO dbo.currency_change_history
			        ( currency_id ,
			          version ,
					  rmb_rate,
					  usd_rate,
			          start_time ,
			          end_time ,
			          order_index
			        )
			VALUES  ( @currency_id , -- currency_id - int
			          @last_version , -- version - varchar(50)
					  @rmb_rate,
					  @usd_rate,
			          @current_operate_time , -- start_time - datetime
			          NULL , -- end_time - datetime
			          @index1  -- order_index - int
			        )
		END 
	END 
    
	DROP TABLE #temp1
    DROP TABLE #temp2

END
go


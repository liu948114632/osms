CREATE VIEW dbo.v_product_develop
 AS
 SELECT a.id ,
        a.cms_product_code ,
        a.developer ,
        a.putaway_date ,
        a.add_date ,
        a.add_one,
		a.sales,
		a.brand,
		a.sale_qty FROM dbo.product_develop a
go


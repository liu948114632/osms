
CREATE FUNCTION[dbo].[fn_SerializeJSON](@SKU AS VARCHAR(MAX))  RETURNS VARCHAR(MAX)
AS
BEGIN
DECLARE @ss VARCHAR(max);
WITH t(SS) AS 
(
SELECT * FROM dbo.[temp_product] where item_sku=@SKU FOR XML RAW
)

SELECT @ss= '{' +REPLACE(REPLACE(REPLACE(REPLACE(SS,'=','":'),'" ','","'),'/>','}'),'<row ','"') FROM t

return @ss
END
go


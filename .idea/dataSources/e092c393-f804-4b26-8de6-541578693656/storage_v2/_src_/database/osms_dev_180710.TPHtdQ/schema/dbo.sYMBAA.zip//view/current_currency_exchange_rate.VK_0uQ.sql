/**
	当前汇率
*/
CREATE VIEW current_currency_exchange_rate
AS
SELECT * FROM dbo.currency_exchange_rate
	WHERE version =(SELECT TOP 1 version FROM dbo.currency_exchange_rate ORDER BY version DESC)


go


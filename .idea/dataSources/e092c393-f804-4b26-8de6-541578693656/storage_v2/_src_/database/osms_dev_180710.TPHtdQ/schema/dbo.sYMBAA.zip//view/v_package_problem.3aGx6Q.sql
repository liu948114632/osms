


CREATE VIEW dbo.v_package_problem AS
SELECT p.*,
	m.merchandiser_name,
	o.customer_account,
	o.customer_name,
	o.shipping_method,
	o.tracking_code,
	o.delivery_date,
	o.package_status,
	o.country_id,
	o.phone,
	o.shop_id,
	o.merchandiser_id,
	m.code AS merchandiser_code
	 FROM dbo.package_problem p WITH(NOLOCK)
INNER JOIN dbo.v_order_all_common o WITH(NOLOCK)
ON p.order_code=o.code
LEFT JOIN dbo.merchandiser m WITH(NOLOCK)
ON m.id=o.merchandiser_id
go



CREATE PROC dbo.searchReplenishmentTaskProducts   
  @productCode VARCHAR(500) =NULL,  
  @code VARCHAR(500) =NULL,  
  @productCodes VARCHAR(MAX) =NULL,  
  @orderCode VARCHAR(500) =NULL,  
  @type INT=NULL,
  @waitMoreBatchAudit INT=NULL,
  @partProductWaitMoreBatchAudit INT=NULL,
 
     @PageSize INT = 50 ,  --页大小                          
     @PageIndex INT = 1    --当前页号    
       
     AS  
     BEGIN  
    
         SET NOCOUNT ON;  
   
         DECLARE @SQL VARCHAR(MAX) ,  
             @CountSql NVARCHAR(MAX) , --查询数量用    
             @FromSQL NVARCHAR(MAX) , --查询表      
 			@FromSQL2 NVARCHAR(max),                                  
             @Column NVARCHAR(MAX) , --查询字段                         
             @Condition VARCHAR(MAX) , --条件                           
             @RowCount INT ,  
             @PageCount INT ,  
             @start INT ,  
             @end INT   
         --设置查询主表      
         SET @FromSQL = ' FROM dbo.replenishment_task_product a INNER JOIN
 						dbo.replenishment_task b ON a.replenishment_task_id=b.id   ' 
 						
 		
 		  SET @FromSQL2 = ' FROM dbo.replenishment_task_product a INNER JOIN
 						dbo.replenishment_task b ON a.replenishment_task_id=b.id   
 						left join shop_product_cms_info c on c.cms_product_id=a.cms_product_id
 						'  
              
         SET @Condition = ' WHERE  a.order_purchase=1 and a.main_task_id is null '                
        --设置查询条件  
     IF @type IS NOT NULL   
         BEGIN  
             SET @Condition = @Condition + ' AND a.type=' + CONVERT(VARCHAR(10), @type)   
              
         END    
         IF @orderCode IS NOT NULL  
 	   BEGIN  
 		SET @Condition = @Condition + ' AND  a.task_object_code like ''' + @orderCode + '%''';  
 	   END  
 	     IF @code IS NOT NULL  
 	   BEGIN  
 		SET @Condition = @Condition + ' AND  b.code like ''' + @code + '%''';  
 	   END       
 	  IF @productCode IS NOT NULL  
 	   BEGIN  
 		SET @Condition = @Condition + ' AND  (a.cms_product_code like ''' + @productCode + '%'' 
 			 or EXISTS(SELECT * FROM dbo.replenishment_task_product r WHERE r.main_task_id=a.id AND r.cms_product_code  like ''' + @productCode + '%'' ) )';  
 	   END  
 	  IF @productCodes IS NOT NULL  
 	   BEGIN  
 		SET @Condition = @Condition + ' AND (a.cms_product_code in (''' + REPLACE(@productCodes,',',''',''') + ''')
 		or EXISTS(SELECT * FROM dbo.replenishment_task_product r WHERE r.main_task_id=a.id AND r.cms_product_code  in (''' + REPLACE(@productCodes,',',''',''') + ''')))';  
 		 
 	   END   

	IF @waitMoreBatchAudit IS NOT NULL  
   
 	   BEGIN  
	 
	       SET @Condition = @Condition + ' AND a.more_batch_audit_status=1 ';  
 	   END  

	   IF @partProductWaitMoreBatchAudit IS NOT NULL  
   
 	   BEGIN  
	 
	       SET @Condition = @Condition + ' AND EXISTS(SELECT * FROM dbo.replenishment_task_product r WHERE r.main_task_id=a.id AND r.more_batch_audit_status =1  )';  
 	   END  
   
     --设置需要取的字段信息                          
         SET @Column = '   a.id ,
 						   a.replenishment_task_id replenishmentTaskId,
 						   a.cms_product_id cmsProductId,
 						   a.cms_product_code cmsProductCode,
 						   a.replenishment_num replenishmentNum,
 						   a.unit_quantity unitQty,
 						   a.unit ,
 						   a.task_quantity taskQty,
 						   a.task_pending_quantity taskPendingQty,
 						   a.task_status taskStatus, 
 						   a.task_strategy_department taskStrategyDepartment, 
 						   a.task_remark taskRemark, 
 						   a.status ,
 						   a.task_type taskType,
 						   a.main_task_id mainTaskId,
 						   a.task_object_code objectCode,
 						   a.task_object_item_id objectItemId,
 						   a.type ,
 						   a.more_batch_audit_status moreBatchAuditStatus,
 						   a.more_batch_audit_remark moreBatchAuditRemark,
 						   a.more_batch_quantity moreBatchQuantity,
 						   a.more_batch_feed_back moreBatchFeedBack,
 						   a.old_task_qty oldTaskQty,
 						   a.complated_qty as complatedQty,
 						   a.related_cms_task_ids ,
 						   a.cms_task_id ,
 						   a.is_part_product isPartProduct,
 						   b.code,
 						   b.complated_date complatedDate,
 						   b.create_date as createDate,
 						   c.product_name as productName,
 						   c.primary_picture_code as primaryPictureCode,
 						   c.color_card_picture_code colorCardPictureCode
          '  
         
        
         --求符合条件的总数                        
         SET @CountSql = ' SELECT @RowCount = count(a.id) ' + @FromSQL + @Condition                   
         EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT              
                               
     
         IF ISNULL(@PageSize, 0) < 1   
             SET @PageSize = 50                                
         SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
         IF ISNULL(@PageIndex, 0) < 1   
             SET @PageIndex = 1                                
         ELSE   
             IF ISNULL(@PageIndex, 0) > @PageCount   
                 SET @PageIndex = @PageCount                                
         SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                
         SET @end = @PageIndex * @PageSize   
 		
 
 		 SET @SQL = '
  	  select '+ @Column +@FromSQL2+'
  		INNER JOIN 
  		(
  		SELECT * FROM (
  		SELECT a.id,ROW_NUMBER() OVER( ORDER BY   CASE a.status WHEN 1 THEN 1 
 			WHEN 4 THEN 2
 			WHEN 5 THEN 3 
 			WHEN 2 THEN 4 
 			WHEN 3 THEN 5
			WHEN 6 THEN 6
			 END ,b.create_date desc) orderIndex  
  		'+@FromSQL+@Condition+'
  		) tmp WHERE tmp.orderIndex BETWEEN ' + CAST(@start AS NVARCHAR(10)) + '
  		
  		 AND '+CAST(@end AS NVARCHAR(10)) 
 		 +' ) tmp2
  		ON (tmp2.id = a.id or tmp2.id = a.main_task_id)
  		ORDER BY tmp2.orderIndex asc
  	  '     
       
         EXEC(@SQL);   
         PRINT @SQL;              
         SELECT  @RowCount                  
     END

go


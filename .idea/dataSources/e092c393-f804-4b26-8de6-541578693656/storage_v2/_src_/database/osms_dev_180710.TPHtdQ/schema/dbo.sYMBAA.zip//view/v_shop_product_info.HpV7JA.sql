
CREATE VIEW dbo.v_shop_product_info
AS
SELECT     dbo.am_shop_product.id, dbo.am_shop_product.product_id, dbo.am_shop_product.upc, dbo.am_shop_product.sku, dbo.am_shop_product.shop_id, 
                      dbo.am_shop_product.product_type, dbo.am_shop_product.browse_node, dbo.am_shop_product.price, dbo.am_shop_product.shelve_status, 
                      dbo.am_shop_product.content_status, dbo.am_shop_product.upload_status, dbo.am_shop_product.brand_name, dbo.product.department, dbo.product.picture_status, 
                      dbo.product.last_category_name, dbo.product.ph_price, dbo.product.unit_quantity, dbo.product.unit, dbo.product.weight, dbo.product.cost_price, 
                      dbo.product.primary_picture_code, dbo.am_shop_product.cms_product_code, ISNULL(dbo.product_freeze_stock.should_qty,0)AS should_qty , dbo.am_shop_product.sku_end, 
                      dbo.am_shop_product.product_content, dbo.am_shop_product.product_name, dbo.product.batch_id, dbo.am_shop_product.GROUP_id
FROM         dbo.am_shop_product LEFT JOIN
                      dbo.product_freeze_stock ON dbo.am_shop_product.product_id = dbo.product_freeze_stock.product_id LEFT OUTER JOIN
                      dbo.product ON dbo.am_shop_product.product_id = dbo.product.id

go


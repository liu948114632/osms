


/**      
 @author whw      
 @desc 报表统计2(系统下单时间为准)      
*/      
CREATE PROC [dbo].[proc_order_count_report2](      
 @begin VARCHAR(50)=NULL,      
 @end VARCHAR(50)=NULL,      
 @type INT =1,  
 @productCode VARCHAR(150)=NULL,
 @shopId VARCHAR(max)=NULL      
)      
AS      
BEGIN      
 DECLARE      
  @Condition varchar(MAX) --条件         
 SET @Condition='      
  WITH tmp AS (      
   SELECT *,CONVERT(VARCHAR(50),add_order_date,23) AS reportDate FROM dbo.[order] WITH(NOLOCK)      
   WHERE status<132  and shop_type=1     
 '        
       
       
 IF @begin IS NOT NULL      
  BEGIN      
   SET @Condition=@Condition+' and add_order_date>='''++ CONVERT(VARCHAR(50), @begin) + '''';       
  END      
        
 IF @end IS NOT NULL      
  BEGIN      
   SET @Condition=@Condition+'and add_order_date<='''++ CONVERT(VARCHAR(50), @end) + '''';       
  END       
        
 IF @shopId IS NOT NULL      
  BEGIN      
   SET @Condition=@Condition+'and shop_id in ('+@shopId + ')';       
  END       
       
 IF @type=9 -- FBA库存商品销量统计     
 BEGIN      
    
  SET @Condition=@Condition+'  
	 AND fulfillmentChannel=''AFN''     
    )      
       
   SELECT reportDate ,SUM(p.order_qty) AS totalUnit  
   ,min(t.shop_id) as shopId
   FROM dbo.order_prepare_product p WITH(NOLOCK)
	INNER JOIN tmp t
	ON t.id=p.order_id 
	WHERE p.cms_product_code='''+@productCode+'''
	GROUP BY t.reportDate      
        
  ';      
        
 END            
 SET @Condition= @Condition +' ORDER BY reportDate DESC'      
 PRINT @Condition      
 EXEC (@Condition)      
       
END
go


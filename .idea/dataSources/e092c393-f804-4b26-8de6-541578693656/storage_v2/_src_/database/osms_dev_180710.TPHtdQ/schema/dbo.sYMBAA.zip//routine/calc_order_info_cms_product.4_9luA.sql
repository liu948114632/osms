
/**
	@date 2017年8月17日16:01:10
	@desc 按商品统计订单销量

*/

CREATE FUNCTION calc_order_info_cms_product
(
	@beginDate DATETIME,
	@endDate DATETIME
)
RETURNS @tmp TABLE
(
	cms_product_code  VARCHAR(100),
	sales INT
)
AS
BEGIN
	INSERT @tmp
	        ( cms_product_code, sales )
	 SELECT p.cms_product_code,SUM(c.shop_quantity_Ordered) AS sales  FROM shop_product_cms_info p WITH(NOLOCK)
	 INNER JOIN dbo.order_prepare_product b WITH(NOLOCK) ON b.status<12 AND p.cms_product_code=b.cms_product_code
	 INNER JOIN dbo.order_product c WITH(NOLOCK) ON c.id=b.order_product_id AND c.is_cancel=0
	 INNER JOIN dbo.[order] a WITH(NOLOCK) ON a.status<132 AND a.shop_type=1 AND a.id=c.order_id
	 WHERE  a.shop_order_date>=@beginDate AND a.shop_order_date<@endDate
	GROUP BY p.cms_product_code
	RETURN
END


go


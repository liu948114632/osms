/**
	统计店铺fba订单以及自卖订单的商品月销量
*/
CREATE PROC dbo.p_statistic_fba_shop_product_month_sales
(
	@startDate DATETIME=NULL,
	@endDate DATETIME=NULL
)
AS 
BEGIN
    SELECT shop_seller_sku,o.shop_id,SUM(p.shop_quantity_Ordered) AS sum
	INTO #tmp 
	FROM dbo.[order] o
	INNER JOIN dbo.order_product p
	ON o.id=p.order_id AND (o.fulfillmentChannel='afn' OR o.fulfillmentChannel='mfn')
	WHERE o.status<>132 AND o.shop_type=1 AND p.shop_seller_sku IS NOT NULL
	AND o.shop_order_status<>'CANCELED'
	AND o.shop_order_date<=@endDate AND o.shop_order_date>=@startDate
	AND p.is_cancel=0
	GROUP BY p.shop_seller_sku,o.shop_id

	BEGIN
		UPDATE fba SET fba.month_sales=ISNULL(sum,0)
		FROM dbo.fba_shop_product fba 
		LEFT JOIN #tmp t ON  t.shop_seller_sku=fba.sku AND t.shop_id=fba.shop_id
	END

END

go


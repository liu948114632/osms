

/*------------------------------
[描述]
	处理字符串
--------------------------------*/
CREATE FUNCTION [dbo].[uf_Text]
(
	@Text NVARCHAR(4000)
)
RETURNS NVARCHAR(4000)
AS
BEGIN
	RETURN REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(@Text, ''))), '''', ''''''), '%', '\%'), '[', '\['), '_', '[_]')
END

go


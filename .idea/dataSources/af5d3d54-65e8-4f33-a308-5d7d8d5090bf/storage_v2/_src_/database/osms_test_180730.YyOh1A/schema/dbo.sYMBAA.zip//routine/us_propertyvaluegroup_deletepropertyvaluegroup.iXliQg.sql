CREATE PROCEDURE [dbo].[US_PropertyValueGroup_DeletePropertyValueGroup]
(
	@PropertyValueGroupId INT
)
AS
BEGIN 
	UPDATE dbo.T_PropertyValueGroup_US SET IsDeleted=1 WHERE PropertyValueGroupId=@PropertyValueGroupId
END
go


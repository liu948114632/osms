
CREATE VIEW V_CRM_ProductSetImages  
AS   
SELECT a.product_set_id AS ProductSetId,  
    a.picture_code AS pictureCode,  
    a.is_primary AS IsPrimary,  
    a.picture_name AS PictureName,  
    a.order_index AS OrderIndex  
FROM dbo.product_set_picture a WITH(NOLOCK)
go


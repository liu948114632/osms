/*--------------------------------------------------------    
[备注]    
视图：获取订单商品个数    
--------------------------------------------------------------*/    
CREATE VIEW [dbo].[V_CRM_OrderItemsCount] 
AS    
SELECT         
 [OrderId],    
 COUNT_BIG(*) AS Counts -- 订单商品总个数    
FROM dbo.T_OrderItem     
WHERE [Status] < 12  -- 非取消订单商品    
GROUP BY [OrderId]
go


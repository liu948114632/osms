

 
   
/*-------------------------------------  
[描述]获取指定上架时间范围的新商品订单销售情况
[作者]LXH  
[时间]2013-06-06  
----------------------------------*/  
CREATE FUNCTION [dbo].[uf_product_remaind_new_product_sale_info]  
(  
 @PublishMonth INT --上架多少月  
)  
RETURNS @Table TABLE(product_id                    INT NULL,   
                     order_number                  INT NULL,  
                     total_real_quantity           INT NULL,  
                     total_limited_quantity        INT NULL,  
                     total_real_unit_quantity      decimal(18,2),  
                     total_limited_unit_quantity   decimal(18,2),  
                     publish_time                  DATETIME  
                     )  
AS  
BEGIN       
   INSERT INTO @Table(product_id,  
                      order_number,  
                      total_real_quantity,  
                      total_limited_quantity,  
                      total_real_unit_quantity,  
                      total_limited_unit_quantity,  
                      publish_time  
                     )  
   SELECT product_id,  
          order_number,  
          total_real_quantity,  
          total_limited_quantity,  
          (temp2.total_real_quantity * 1.0 / product.unit_quantity) AS total_real_unit_quantity,  
          (temp2.total_limited_quantity * 1.0 / product.unit_quantity) AS total_limited_unit_quantity,  
          publish_time  
   FROM   
   (      
     SELECT product_id,  
         COUNT(DISTINCT order_code) AS order_number,  
      SUM(temp1.real_quantity) AS total_real_quantity,  
      SUM(temp1.limited_quantity) AS total_limited_quantity,  
      MIN(temp1.publish_time) AS publish_time  
     FROM   
    (  
      --1、统计订单任务  
     SELECT b.order_code, -- 订单号       
      b.product_id,      
      b.real_order_quantity AS real_quantity,    
      b.limited_order_quantity AS limited_quantity,  
      a.publish_time    
     FROM view_product_ph_new_product a  
     JOIN dbo.uf_product_remaind_order_sale_info(1) AS b ON a.id=b.product_id        
     WHERE  b.order_time <= DATEADD(Month,@PublishMonth,a.publish_time)  
      AND b.order_time >= a.publish_time
    ) temp1  
    GROUP BY temp1.product_id  
  ) temp2  
  JOIN product WITH(NOLOCK) ON temp2.product_id = product.id     
      
    RETURN  -- 返回结果  
END

go



-- =============================================          
-- Author:  <Author,,刘杨>          
-- Create date: <Create Date,,2010-12-07>          
-- Description: <Description,,增加拆分订单商品>          
          
-- 修改人：HYD          
-- 修改内容：将原先商品的转移，改为取消原始的订单中的，为新订单增加备货量为0的订单商品          
-- 修改时间:2011-08-05          
-- =============================================          
CREATE PROC dbo.CRM_Order_SplitOrderItemAdd          
    (          
      @OrderId VARCHAR(20) ,          
      @SplitOrderId VARCHAR(20) ,          
      @OrderItemIds VARCHAR(MAX)          
    )          
AS           
    BEGIN          
 -- SET NOCOUNT ON added to prevent extra result sets from          
 -- interfering with SELECT statements.          
        SET NOCOUNT ON ;          
                  
        DECLARE @TempTable TABLE          
            (          
              [Id] INT ,          
              [Value] VARCHAR(4000)          
            ) ;          
            
        INSERT  INTO @TempTable          
                SELECT  Id ,          
                        [Value]          
                FROM    dbo.uf_Split(@OrderItemIds, ',') ;          
          
  -- 增加拆分订单商品          
        INSERT  INTO dbo.T_OrderItem          
                ( OrderId ,          
                  ProductId ,        
                  CmsProductId,     
                  ProductSetId,         
                  [Type] ,          
                  Quantity ,          
                  ReadyQty ,          
                  Unit ,          
                  UnitQuantity ,   
                  CostPrice,      
                  ItemPrice ,          
                  SalePrice ,          
                  [Weight] ,          
                  Volume ,          
                  IsPromote ,          
                  IsProductPool ,          
                  Box ,          
                  [Status] ,          
                  XFreight,        
                  ColorCardName,        
                  SpecficationName,        
                  MinBatchQty,          
                  JoinDate ,          
                  UpdateTime ,          
                  CustomerRemark ,          
                  BranchRemark ,          
                  CSRemark,  
                  ProcessingStatus,  
                  PackageProductId,
                  PromoteId,
				  PackFee,
				  PurchaseHandlerRemark,
				     IsQualityInspection
            )          
                SELECT  @SplitOrderId ,          
                        ProductId ,         
                        CmsProductId,     
                        ProductSetId,        
                        Type ,          
                        Quantity ,          
                        ReadyQty ,          
                        Unit ,          
                        UnitQuantity ,      
                         CostPrice,        
                        ItemPrice ,          
                        SalePrice ,          
                        Weight ,          
                        Volume ,          
                        IsPromote ,          
                        IsProductPool ,          
                        Box ,          
                        [Status] ,          
                        XFreight,        
                        ColorCardName,        
                        SpecficationName,        
                        MinBatchQty,           
                        GETDATE() ,          
                        GETDATE() ,          
                        CustomerRemark ,          
                        BranchRemark ,          
                        CSRemark,  
                        ProcessingStatus,  
                        PackageProductId,
                        PromoteId,
						PackFee,
						PurchaseHandlerRemark,
						   IsQualityInspection
                FROM    dbo.T_OrderItem  
                WHERE   OrderItemId IN ( SELECT [Value] FROM @TempTable ) ;          
                                                   
   INSERT INTO T_OrderItemProduct          
   (          
     OrderItemId,          
     Name,          
     ItemCode,          
     Description,          
     ImageName,          
     Discount ,    
     ColorCode,    
     ColorImageName       
   )           
   SELECT c.OrderItemId,          
    b.Name,          
    b.ItemCode,          
    b.Description,          
    b.ImageName,          
    b.Discount,    
    b.ColorCode,    
          b.ColorImageName             
    FROM    dbo.T_OrderItem a          
    INNER JOIN dbo.T_OrderItemProduct b ON a.OrderItemId=b.OrderItemId          
    INNER JOIN T_OrderItem c ON a.ProductId = c.ProductId          
    WHERE   a.OrderItemId IN ( SELECT [Value] FROM   @TempTable )           
   AND c.OrderId = @SplitOrderId          
                                  
        -- 删除原始订单中的拆分订单项          
        UPDATE  dbo.T_OrderItem SET Status = 12           
        WHERE   OrderId = @OrderId          
                AND OrderItemId IN ( SELECT [Value]          
                                     FROM   @TempTable ) ;             
    END

go



/*  
*2012-08-08  
*加工报销单查询列表  
*2012-08-22
*先按状态升序再按申请时间倒序排序
*/  
CREATE PROCEDURE CMS_Processing_ExpenseList  
(  
 @DepartmentId INT = NULL, --部门ID  
 @Status INT = NULL, --状态  
 @SettlementWay INT = NULL, --结算方式  
 @PayWay INT = NULL, -- 付款方式  
 @CreatorId INT = NULL, -- 创建人ID  
 @CreateTimeBegin VARCHAR(20) = NULL,--创建时间起  
 @CreateTimeOver VARCHAR(20) = NULL,--创建时间止  
 @Code VARCHAR(MAX) = NULL,--报销单号  
 @ProcessingCode VARCHAR(MAX) = NULL,--加工单号  
 @PageSize INT = 50 ,  --页大小        
 @PageIndex INT = 1    --当前页号        
)  
AS  
BEGIN  
 SET NOCOUNT ON ;   
    DECLARE @SQL VARCHAR(max),        
            @CountSql NVARCHAR(MAX), --查询数量用        
            @FromSQL NVARCHAR(max), --查询表   
            @FromSQL2 NVARCHAR(MAX), --取字段关联表     
            @Condition varchar(MAX), --条件  
            @Column NVARCHAR(MAX), --字段         
            @RowCount INT , @PageCount INT , @start INT ,@end INT   
      
    SET @Condition = ' WHERE 1=1 '     
    IF @DepartmentId IS NOT NULL   
    BEGIN  
  SET @Condition = @Condition + ' AND A.department_id = ' + CONVERT(VARCHAR(10), @DepartmentId);  
 END  
 IF @Status IS NOT NULL   
 BEGIN  
  SET @Condition = @Condition + ' AND A.status = ' + CONVERT(VARCHAR(10), @Status);  
 END  
 IF @SettlementWay IS NOT NULL   
 BEGIN  
  SET @Condition = @Condition + ' AND A.settlement_way = ' + CONVERT(VARCHAR(10), @SettlementWay);  
 END  
 IF @PayWay IS NOT NULL   
 BEGIN  
  SET @Condition = @Condition + ' AND A.pay_way = ' + CONVERT(VARCHAR(10), @PayWay);  
 END  
 IF @CreatorId IS NOT NULL   
 BEGIN  
  SET @Condition = @Condition + ' AND A.creator_id = ' + CONVERT(VARCHAR(10), @CreatorId);  
 END  
 IF @CreateTimeBegin IS NOT NULL   
 BEGIN  
  SET @Condition = @Condition + ' AND A.create_time >=''' + @CreateTimeBegin + '''';   
 END  
 IF @CreateTimeOver IS NOT NULL   
 BEGIN  
  SET @Condition = @Condition + ' AND A.create_time <=''' + @CreateTimeOver + '''';  
 END  
 IF @Code IS NOT NULL   
 BEGIN  
  SET @Condition = @Condition + ' AND A.code like ''%' + @Code + '%''';  
 END  
 IF @ProcessingCode IS NOT NULL   
 BEGIN  
  SET @Condition = @Condition + ' AND EXISTS(select b.id from processing_expense_item b   
   WITH (NOLOCK) where b.processing_expense_id=a.id and b.processing_code like ''%' + @ProcessingCode +'%'')';  
 END  
   
 SET @FromSQL = ' processing_expense a WITH(NOLOCK) '  
 SET @FromSQL2 = ' LEFT JOIN processing_expense a WITH(NOLOCK) ON temp.id = a.id '  
   
 SET @CountSql = ' SELECT @RowCount = count(a.id) from ' + @FromSQL + @Condition         
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT      
    --PRINT @CountSql  
    IF ISNULL(@PageSize, 0) < 1                 
        SET @PageSize = 50  
                        
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize               
    IF ISNULL(@PageIndex, 0) < 1                 
        SET @PageIndex = 1                
    ELSE                 
    IF ISNULL(@PageIndex, 0) > @PageCount                 
        SET @PageIndex = @PageCount   
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1   
    SET @end = @PageIndex * @PageSize    
      
    SET @Column = ' a.id,   
     a.code,   
     a.department_id departmentId,  
     a.status,   
     a.total_amount totalAmount,  
     a.processing_count processingCount,  
     a.expense_amount expenseAmount,  
     a.settlement_way settlementWay,  
     a.pay_way payWay,  
     a.creator_id creatorId,  
     a.create_time createTime,  
     a.first_auditor_id firstAuditorId,  
     a.first_audit_time firstAuditTime,  
     a.last_auditor_id lastAuditorId,  
     a.last_audit_time lastAuditTime,  
     a.audit_remark auditRemark,  
     a.remark, 
     a.submit_time submitTime';  
 --组装查询语句      
  SET @SQL = 'SELECT a.id, ROW_NUMBER() OVER (ORDER BY a.status asc,a.create_time desc) RowIndex from '       
     + @FromSQL + @Condition;      
       
  SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp ' + @FromSQL2 + ' where RowIndex between '      
     + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';    
  --print @SQL        
  EXEC(@SQL);                  
  select @RowCount            
END


go





---获取客户的订单的平均评分
CREATE PROC dbo.CRM_Customer_GetCustomerOrderAvgComment
(
@CustomerId INT 
)
AS 
BEGIN
SELECT 
'综合得分' AS '综合得分/指标',
CAST((SUM(a.QualityScore)*1.0/COUNT(1)) AS DECIMAL(5,2)) AS 产品质量评价, 
CAST((SUM(a.ShipmentScore)*1.0/COUNT(1)) AS DECIMAL(5,2)) AS 物流评价,
 CAST((SUM(a.ServiceScore)*1.0/COUNT(1)) AS DECIMAL(5,2)) AS 客服评价 FROM dbo.T_OrderComment a WITH(NOLOCK)
INNER JOIN dbo.T_Order b WITH(NOLOCK) ON a.OrderId=b.OrderId
WHERE b.CustomerId=@CustomerId
GROUP BY b.CustomerId
END

go


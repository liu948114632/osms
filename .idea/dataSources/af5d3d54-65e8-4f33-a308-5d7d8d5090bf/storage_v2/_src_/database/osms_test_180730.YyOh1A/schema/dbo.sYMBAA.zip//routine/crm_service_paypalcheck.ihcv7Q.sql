

/*---------------------------------------------------
[备注] 
	检查PayPal的付款情况，从而找出可以自动录单的订单
-------------------------------------------------------*/
CREATE  PROCEDURE [dbo].[CRM_Service_PaypalCheck]
(
	@isHas				BIT OUT	-- 是否存在可以自动录入的订单
)
AS
DECLARE
	@paypal TABLE
	(
		Id				INT IDENTITY,
		paypalId		INT,
		address_country VARCHAR(50),
		payment_fee		MONEY,
		mc_currency		VARCHAR(50),
		item_number		VARCHAR(20)
	)
DECLARE
	@num				INT,
	@n					INT,
	@id					INT,
	@result				INT, -- 检查结果
	@orderId			VARCHAR(15),
	@payment_fee		MONEY,
	@mc_currency		VARCHAR(50),
	@address_country	VARCHAR(50)
BEGIN
	SET @isHas = 0;
	

	-- 将数据导入临时表等待处理
	INSERT INTO @paypal(paypalId,address_country,payment_fee,mc_currency,item_number)
	SELECT a.[Id],a.address_country,a.mc_gross,a.mc_currency,a.item_number
	FROM dbo.T_PaypalReturn a LEFT JOIN T_Order b on a.item_number = b.orderId
	WHERE a.[Status] = 0 And a.mc_gross > '' AND b.OrderId is not null;

	SELECT @num = COUNT(1) FROM @paypal;
	SET @n = 1;
	WHILE @n <= @num
	BEGIN
		-- get paypal info
		SELECT @id = paypalId,@address_country = address_country,@payment_fee = payment_fee,@mc_currency = mc_currency,@orderId = item_number
		FROM @paypal WHERE [Id] = @n;

		-- check payment
		EXEC CRM_Service_OrderPriceCheck @payment_fee,@mc_currency,@orderId,@result OUT;
		
		IF @result > 0
		BEGIN
			UPDATE dbo.T_PaypalReturn SET [Status] = @result WHERE [id] = @id;
		END
		ELSE
		begin
			-- check address
			EXEC CRM_Service_OrderAddressCheck @address_country,@orderId,@result OUT;
			IF @result > 0
			BEGIN
				UPDATE dbo.T_PaypalReturn SET [Status] = @result WHERE [id] = @id;
			END
			ELSE
			BEGIN
				-- 6:prepare order
				UPDATE dbo.T_PaypalReturn SET [Status] = 6 WHERE [id] = @id;
			END
		END
		SET	 @n = @n + 1;
	END	

	-- 存在可录的单
	IF EXISTS(SELECT * FROM	dbo.T_PaypalReturn WHERE [Status] = 6 )
		SET	@isHas = 1;

END
go


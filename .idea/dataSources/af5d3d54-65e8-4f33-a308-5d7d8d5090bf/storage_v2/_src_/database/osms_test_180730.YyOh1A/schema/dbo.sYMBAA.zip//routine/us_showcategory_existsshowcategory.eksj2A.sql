CREATE PROCEDURE [dbo].[US_ShowCategory_ExistsShowCategory]
(
	@ShowCategoryId INT
)
AS
BEGIN 
	IF EXISTS (SELECT 1 FROM dbo.T_ShowCategory_US WHERE ShowCategoryId=@ShowCategoryId AND IsDeleted=0)
		SELECT 1
    ELSE 
		SELECT 0 
END
go


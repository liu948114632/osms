
/*
* 2012-08-10
* 根据产品集ID获取产品集下产品的绑定属性值信息
*/
CREATE PROC [dbo].[CMS_Product_GetProductPropertyValueByProductSetID]       
(        
	@ProductSetId INT = NULL   --产品集ID  
)      
AS       
BEGIN                        
	SET NOCOUNT ON ;     
	SELECT 
		pv.id,
		pv.product_id productId,
		pv.property_id propertyId,
		pv.property_value propertyValue			
	FROM dbo.product p WITH(NOLOCK) LEFT JOIN product_property_value pv WITH(NOLOCK)
	ON p.id= pv.product_id WHERE p.product_set_id = @ProductSetId and p.is_delete=0
	ORDER BY p.id
    SET NOCOUNT OFF ;           
END
go




/***************************      
备注:获取单个处理人      
创建人: yxt      
创建日期:2012-10-19      
***************************/      
CREATE PROCEDURE dbo.CRM_Handler_GetHandlerByHandlerId
(
   @HandlerId INT 
)      
AS        
BEGIN        
	SELECT A.HandlerId AS UserId,    
	A.[Type],    
	A.[Desc],    
	A.BusinessType,      
	B.Code,      
	B.[Name],      
	B.EnglishName,    
	B.Email,    
	B.IsValid         
	FROM dbo.T_Handler AS A WITH(NOLOCK)    
	INNER JOIN dbo.V_CRM_UserInfo AS B ON A.HandlerId = B.Id   
	WHERE A.HandlerId = @HandlerId    
END
go


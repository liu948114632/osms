

/*----------------------------------------
备注:检查订单商品状态
创建人: FRH
创建日期:2009-12-30
------------------------------------------------------*/
CREATE PROC [dbo].[CRM_Order_OrderItemStatusCheck] 
(
	@OrderId 		VARCHAR(20)
)
AS
BEGIN
	-- 将不符合已备货的改成备货中
	UPDATE
		dbo.T_OrderItem
	SET	
		[Status] = 1
	WHERE	
		OrderId = @OrderId And Quantity > ReadyQty And [Status] = 6;
		
	-- 将符合已备货的改成已备货
	UPDATE
		dbo.T_OrderItem
	SET
		[Status] = 6
	WHERE	
		OrderId = @OrderId And Quantity = ReadyQty And [Status] < 6;
		
--	-- 自动调整备货系统的订单商品状态
--	EXEC SYS_CRM_CMS_OrderItemStatusCheck @OrderId = @OrderId;
END
go


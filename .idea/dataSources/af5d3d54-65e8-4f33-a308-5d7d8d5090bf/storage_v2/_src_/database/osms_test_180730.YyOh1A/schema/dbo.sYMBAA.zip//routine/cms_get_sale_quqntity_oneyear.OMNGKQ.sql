

CREATE FUNCTION CMS_Get_Sale_Quqntity_OneYear(@productId INT )
RETURNS DECIMAL(18,6)
AS
	BEGIN
		 DECLARE @Result DECIMAL(18,6)
		 SELECT @Result = SUM(A.order_quantity)  FROM order_item A WITH(NOLOCK) 
				WHERE A.product_id = @productId AND A.order_time >  DATEADD(YEAR,-1,GetDate())
				AND A.status <>12
		 RETURN @Result
	END
go


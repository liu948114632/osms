

/*-----------------------------------------------------
[描述]
	 修改订单是否可发货
-------------------------------------------------------*/
CREATE PROC [dbo].[CRM_Order_OrderSendStatusUpdate]
(
	@OrderId	VARCHAR(20),
	@IsSend		Bit
)
AS
Begin
	Update
		dbo.T_Order
	SEt
		IsSend = @IsSend
	Where
		OrderId = @OrderId;
--
--	Update
--		dbo.C_Order
--	SEt
--		IsSend = @IsSend
--	Where
--		OrderId = @OrderId;		
End
go


-- =============================================    
-- Author:  <Author,,Name>    
-- Create date: <Create Date,,>    
-- Description: <Description,,>    
-- =============================================  

-- department_storage
-- department_storage_detail  

CREATE PROCEDURE [dbo].[CMS_GetProcessingReplenishItemDetails] @ProcessingId INT
AS
    BEGIN    
    
        DECLARE @count INT = 0  
        DECLARE @status INT = 0
        DECLARE @storageDepartmentId INT
        SELECT  @storageDepartmentId = department_id
        FROM    dbo.processing
        WHERE   id = @ProcessingId
        IF @storageDepartmentId = 7
            OR @storageDepartmentId = 9
            BEGIN
                SET @storageDepartmentId = 41
            END
        SELECT  @count = id ,
                @status = status
        FROM    processing_apply_replenish
        WHERE   processing_id = @ProcessingId
                AND status IN ( 0, 1, 2 )
        IF @count > 0
            BEGIN  
                SELECT  d.id ,
                        c.id AS processingApplyReplenishId ,
                        b.id AS processingItemId ,
                        g.code ,
                        c.status AS status ,
                        ROUND(ISNULL(f.convert_rate, 1) * ( i.quantity
                                                            - ISNULL(i.lock_quantity,
                                                              0) ), 2) AS storageQuantity ,
                        ISNULL(d.qty, 0) AS qty ,
                        CASE WHEN f.id IS NOT NULL
                                  AND f.unit <> b.unit THEN 0
                             ELSE ISNULL(d.qty, 0) * ISNULL(f.new_unit_weight,
                                                            g.weight)
                        END AS applayWeight ,
                        d.cause ,
                        k.name AS position ,
                        ISNULL(f.new_unit_weight, g.weight) AS weight ,
                        CASE WHEN f.id IS NOT NULL
                                  AND f.unit <> b.unit THEN 1
                             ELSE 0
                        END isAddColor ,
                        g.primary_picture_code AS primaryPictureCode ,
                        CASE WHEN f.unit IS NULL
                                  AND a.department_id = 9 THEN g.unit
                             ELSE f.unit
                        END AS unit ,
                        g.unit_quantity AS unitQuantity ,
                        f.convert_rate AS convertRate ,
                        d.remark ,
                        g.id AS productId,
						d.responsible_department AS responsibleDepartment
                FROM    dbo.processing a WITH ( NOLOCK )
                        LEFT JOIN processing_apply_replenish c WITH ( NOLOCK ) ON c.processing_id = a.id
                                                              AND c.status IN (
                                                              0, 1, 2 )
                        LEFT JOIN dbo.processing_apply_replenish_item d WITH ( NOLOCK ) ON c.id = d.processing_apply_replenish_id
                        LEFT JOIN dbo.processing_item b WITH ( NOLOCK ) ON a.id = b.processing_id
                                                              AND b.status <> 4
                                                              AND d.processing_item_id = b.id
                        LEFT JOIN dbo.department_storage i ON i.product_id = d.product_id
                                                              AND i.department_id = @storageDepartmentId
                        LEFT JOIN dbo.department_storage_detail j WITH ( NOLOCK ) ON j.storage_id = i.id
                        LEFT JOIN dbo.storage_position k WITH ( NOLOCK ) ON k.id = j.position_id
                        LEFT JOIN dbo.product_unit_convert f WITH ( NOLOCK ) ON f.product_id = b.product_id
                                                              AND f.unit = b.unit
                                                              AND f.department_id = a.department_id
                        JOIN dbo.product g WITH ( NOLOCK ) ON g.id = d.product_id
                WHERE   a.id = @ProcessingId
                UNION
                SELECT  NULL ,
                        NULL AS processingApplyReplenishId ,
                        b.id AS processingItemId ,
                        g.code ,
                        0 AS status ,
                        ROUND(ISNULL(f.convert_rate, 1) * ( i.quantity
                                                            - ISNULL(i.lock_quantity,
                                                              0) ), 2) AS storageQuantity ,
                        0 AS qty ,
                        CASE WHEN f.id IS NOT NULL
                                  AND f.unit <> b.unit THEN 0
                             ELSE 0 * ISNULL(f.new_unit_weight, g.weight)
                        END AS applayWeight ,
                        NULL ,
                        k.name AS position ,
                        ISNULL(f.new_unit_weight, g.weight) AS weight ,
                        CASE WHEN f.id IS NOT NULL
                                  AND f.unit <> b.unit THEN 1
                             ELSE 0
                        END isAddColor ,
                        g.primary_picture_code AS primaryPictureCode ,
                        CASE WHEN f.unit IS NULL
                                  AND a.department_id = 9 THEN g.unit
                             ELSE f.unit
                        END AS unit ,
                        g.unit_quantity AS unitQuantity ,
                        f.convert_rate AS convertRate ,
                        NULL ,
                        g.id AS productId,NULL
                FROM    dbo.processing a WITH ( NOLOCK )
                        JOIN dbo.processing_item b WITH ( NOLOCK ) ON a.id = b.processing_id
                                                              AND b.status <> 4
                       
                        LEFT JOIN dbo.department_storage i ON i.product_id = b.product_id
                                                              AND i.department_id = @storageDepartmentId
                        LEFT JOIN dbo.department_storage_detail j WITH ( NOLOCK ) ON j.storage_id = i.id
                        LEFT JOIN dbo.storage_position k WITH ( NOLOCK ) ON k.id = j.position_id
                        LEFT JOIN dbo.product_unit_convert f WITH ( NOLOCK ) ON f.product_id = b.product_id
                                                              AND f.unit = b.unit
                                                              AND f.department_id = a.department_id
                        JOIN dbo.product g WITH ( NOLOCK ) ON g.id = b.product_id
                WHERE   a.id = @ProcessingId
                        AND  NOT EXISTS ( SELECT c.id  FROM processing_apply_replenish c WITH ( NOLOCK )
                        JOIN dbo.processing_apply_replenish_item d WITH ( NOLOCK ) ON c.id = d.processing_apply_replenish_id
                                                              AND d.processing_item_id = b.id  WHERE    c.processing_id = a.id
                                                              AND c.status IN (
                                                              0, 1, 2 ))
	   
            END  
        ELSE
            BEGIN  
                SELECT  NULL ,
                        NULL AS processingApplyReplenishId ,
                        b.id AS processingItemId ,
                        g.code ,
                        0 AS status ,
                        ROUND(ISNULL(f.convert_rate, 1) * ( i.quantity
                                                            - ISNULL(i.lock_quantity,
                                                              0) ), 2) AS storageQuantity ,
                        0 AS qty ,
                        CASE WHEN f.id IS NOT NULL
                                  AND f.unit <> b.unit THEN 0
                             ELSE 0 * ISNULL(f.new_unit_weight, g.weight)
                        END AS applayWeight ,
                        NULL ,
                        k.name AS position ,
                        ISNULL(f.new_unit_weight, g.weight) AS weight ,
                        CASE WHEN f.id IS NOT NULL
                                  AND f.unit <> b.unit THEN 1
                             ELSE 0
                        END isAddColor ,
                        g.primary_picture_code AS primaryPictureCode ,
                        CASE WHEN f.unit IS NULL
                                  AND a.department_id = 9 THEN g.unit
                             ELSE f.unit
                        END AS unit ,
                        g.unit_quantity AS unitQuantity ,
                        f.convert_rate AS convertRate ,
                        NULL ,
                        g.id AS productId,NULL
                FROM    dbo.processing a WITH ( NOLOCK )
                        JOIN dbo.processing_item b WITH ( NOLOCK ) ON a.id = b.processing_id
                                                              AND b.status <> 4    
	 --LEFT JOIN  processing_apply_replenish c WITH(NOLOCK)  ON c.processing_id =a.id AND c.status IN (0,1,2)    
	 --FULL OUTER JOIN dbo.processing_apply_replenish_item d WITH(NOLOCK) ON c.id = d.processing_apply_replenish_id AND d.processing_item_id=b.id    
                        LEFT JOIN dbo.department_storage i ON i.product_id = b.product_id
                                                              AND i.department_id = @storageDepartmentId
                        LEFT JOIN dbo.department_storage_detail j WITH ( NOLOCK ) ON j.storage_id = i.id
                        LEFT JOIN dbo.storage_position k WITH ( NOLOCK ) ON k.id = j.position_id
                        LEFT JOIN dbo.product_unit_convert f WITH ( NOLOCK ) ON f.product_id = b.product_id
                                                              AND f.unit = b.unit
                                                              AND f.department_id = a.department_id
                        JOIN dbo.product g WITH ( NOLOCK ) ON g.id = b.product_id
                WHERE   a.id = @ProcessingId    
            END   
    END
go


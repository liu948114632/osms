-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE CMS_FBA_Order_Retrieve
	@orderId INT ,
	@process INT,
	@subType INT = 0
AS
BEGIN
	 IF @process=1
	 BEGIN
		SELECT DISTINCT a.product_code AS productCode FROM dbo.order_item a  WITH(NOLOCK) JOIN dbo.storage_task b  WITH(NOLOCK) ON a.order_id=b.order_id AND a.id =b.order_item_id AND b.type IN(1,4,8)
		WHERE b.status =1 AND a.status<>12 AND a.order_id = @orderId
	 END
     ELSE IF @process = 2
	 BEGIN
		SELECT DISTINCT a.product_code AS productCode FROM dbo.order_item a  WITH(NOLOCK) JOIN dbo.storage_task b  WITH(NOLOCK) ON a.order_id=b.order_id AND a.id =b.order_item_id AND b.type IN(1,4,8)
		WHERE b.status =2 AND a.status<>12  AND a.order_id = @orderId
     END
	 ELSE IF @process = 3
	 BEGIN
		IF @subType=0
		begin
		SELECT DISTINCT a.product_code AS productCode FROM dbo.order_item a  WITH(NOLOCK) 
		JOIN dbo.view_all_storage_task b  WITH(NOLOCK) ON a.order_id=b.order_id AND a.id =b.order_item_id AND b.type IN(1,4,8)
		JOIN dbo.stock_out_ref_storage_task c WITH(NOLOCK) ON c.storage_task_id =b.id
		JOIN dbo.stock_out d ON d.id =c.stock_out_id AND d.is_received = 0
		WHERE  a.status<>12  AND a.order_id = @orderId
		END
        ELSE
        BEGIN
			SELECT DISTINCT d.code AS productCode FROM dbo.order_item a  WITH(NOLOCK) 
			JOIN dbo.view_all_storage_task b  WITH(NOLOCK) ON a.order_id=b.order_id AND a.id =b.order_item_id AND b.type IN(1,4,8)
			JOIN dbo.stock_out_ref_storage_task c WITH(NOLOCK) ON c.storage_task_id =b.id
			JOIN dbo.stock_out d ON d.id =c.stock_out_id AND d.is_received = 0
			WHERE  a.status<>12 AND a.order_id = @orderId
        END
        
	 END
	 ELSE IF @process = 4 
	 BEGIN
		SELECT DISTINCT a.product_code AS productCode FROM dbo.order_item a  WITH(NOLOCK) 
		JOIN dbo.assigment_stay_product b  WITH(NOLOCK) ON a.order_id=b.order_id AND a.id =b.order_item_id AND b.status=1
		WHERE  a.status<>12  AND a.order_id = @orderId
	 END
     
     ELSE IF @process = 5
	 BEGIN
	 IF @subType = 0
		 begin
			SELECT DISTINCT a.product_code AS productCode FROM dbo.order_item a  WITH(NOLOCK) 
			JOIN dbo.assignment_item b  WITH(NOLOCK) ON a.order_id=b.order_id AND a.id =b.order_item_id 
			JOIN dbo.assignment c WITH(NOLOCK) ON c.id= b.assignment_id AND c.status = 1
			WHERE  a.status<>12  AND a.order_id = @orderId
		END ELSE
        BEGIN
			SELECT DISTINCT c.code AS productCode FROM dbo.order_item a  WITH(NOLOCK) 
			JOIN dbo.assignment_item b  WITH(NOLOCK) ON a.order_id=b.order_id AND a.id =b.order_item_id 
			JOIN dbo.assignment c WITH(NOLOCK) ON c.id= b.assignment_id AND c.status = 1
			WHERE  a.status<>12  AND a.order_id = @orderId
        END
        
	 END
	 ELSE IF @process = 6
	 BEGIN
		SELECT DISTINCT a.product_code AS productCode FROM dbo.order_item a  WITH(NOLOCK) 
			JOIN dbo.check_product b  WITH(NOLOCK) ON a.order_id=b.order_id AND a.id =b.order_item_id 
			WHERE  a.status<>12 AND b.status=1  AND a.order_id = @orderId
	 END
     ELSE IF @process = 7
	 BEGIN
		SELECT DISTINCT a.product_code AS productCode FROM dbo.order_item a  WITH(NOLOCK) 
		JOIN dbo.fba_order_item_picking b WITH(NOLOCK)  ON b.order_item_id =a.id 
		WHERE a.status<>12 AND b.status =2  AND a.order_id = @orderId
	 END
      ELSE IF @process =8
	 BEGIN
		SELECT DISTINCT a.product_code AS productCode FROM dbo.order_item a  WITH(NOLOCK) 
		JOIN dbo.fba_order_item_picking b WITH(NOLOCK)  ON b.order_item_id =a.id 
		WHERE a.status<>12 AND b.status =3  AND a.order_id = @orderId
	 END
     
END
go


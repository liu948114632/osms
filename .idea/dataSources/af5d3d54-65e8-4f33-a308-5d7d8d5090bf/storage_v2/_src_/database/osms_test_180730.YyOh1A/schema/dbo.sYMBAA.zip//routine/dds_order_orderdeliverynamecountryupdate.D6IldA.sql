
/*------------------------------------------
备注:修改PW C_Order表订单的货运方式及国家
创建人: HJJ
创建日期:2010-05-08
------------------------------------------------------------------*/
CREATE  PROCEDURE [dbo].[DDS_Order_OrderDeliveryNameCountryUpdate]
(
	@OrderId VARCHAR(20),          ---订单编号
	@DeliveryName VARCHAR(50) ,    --货运方式名称，通过货运方式名称找到CRM库的货运方式ID
    @CountryName NVARCHAR(50)      --国家名称，通过国家名称找到CRM库的国家ID
)
AS 
BEGIN
	DECLARE @DeliveryId INT,@CountryId INT ;
	SET @DeliveryId = 0;
	SET @CountryId = 0 ;
    SELECT TOP 1 @DeliveryId = DeliveryId FROM dbo.T_Delivery WHERE IsDisplay = 1 AND [Name] LIKE '%'+ @DeliveryName + '%'
    SELECT @CountryId = CountryId FROM dbo.T_Country WHERE [Name] = @CountryName
	
	---更新PW Order表 订单表的货运方式 及 国家
	UPDATE dbo.[order] SET delivery_id = @DeliveryId , country_id = @CountryId WHERE code = @OrderId;
END
go




CREATE PROC CRM_Customer_ComplaintRepealProductItems
(
@ComplaintId VARCHAR(15),
@Id INT,
@ComplaintStatus INT=0 OUT
)
AS 
BEGIN
IF EXISTS(SELECT TOP 1 1 FROM dbo.T_Complaint WHERE Id=@ComplaintId AND Status=8)
BEGIN
   RAISERROR ('<info>该投诉已关闭！</info>' , 16, 1) WITH NOWAIT;      
   RETURN; 
END

UPDATE dbo.T_ComplaintProductItem SET Status=3  WHERE ComplaintId=@ComplaintId AND Id=@Id

SELECT @ComplaintStatus=status FROM dbo.T_Complaint WHERE Id=@ComplaintId;

--如果产品都是撤销状态，则关闭投诉
IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.T_ComplaintProductItem WHERE Status=3 AND ComplaintId=@ComplaintId)
BEGIN
	SET @ComplaintStatus=8
END
END


go


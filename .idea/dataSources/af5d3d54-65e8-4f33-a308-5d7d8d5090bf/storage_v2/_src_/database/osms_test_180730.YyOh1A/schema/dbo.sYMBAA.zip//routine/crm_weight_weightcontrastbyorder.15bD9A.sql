
/*----------------------------------------------------            
[备注]:判断订单是按订单重量还是发货重量算运费     
------------------------------------------------------*/            
CREATE PROCEDURE CRM_Weight_WeightContrastByOrder  
(  
  @OrderId  VARCHAR(20),  
  @WeightType  INT OUT -- 1：订单重量 2：发货重量    
)    
AS   
BEGIN  
   DECLARE @SendGroupId INT,@Weight INT,@OrderIds VARCHAR(MAX), @ReadyWeight INT,@ReadyWeightType INT     
     
   SET @OrderIds =  @OrderId  
   SELECT @SendGroupId=ISNULL(a.SendGroupId, 0)  
   FROM T_Order a WITH(NOLOCK) WHERE a.OrderID = @OrderId     
     
   --如果订单有同票订单，则取出所有同票的订单ID来计算订单重量  
   IF (@SendGroupId > 0)      
   BEGIN      
   SET @OrderIds = ''  
   SELECT @OrderIds = @OrderIds + OrderId + ','      
   FROM T_Order a  
   WHERE SendGroupID = @SendGroupId AND OrderStatus < 132;     
     
   IF (LEN(@OrderIds) > LEN(@OrderId))   
   BEGIN      
          SET @OrderIds=LEFT(@OrderIds,LEN(@OrderIds)-1)    
      END  
   END   
     
      EXEC CRM_Weight_OrderWeightOrPostWeightGet @OrderIds=@OrderIds, @Weight=@Weight OUT, @WeightType=@WeightType OUT, @ReadyWeight=@ReadyWeight OUT, @ReadyWeightType=@ReadyWeightType OUT;        
END
go




/**
	@desc 电子业务备货商品补货
	@date 2016-05-18
	@author whw	
*/ 
CREATE VIEW [dbo].[view_dz_product_pool_replenish]
AS
SELECT id,product_id,MAX(prepare_quantity) AS prepare_quantity  FROM (
    SELECT  id ,
            product_id ,
            prepare_quantity
    FROM    ( SELECT    a.* ,
                        ISNULL(b.quantity, 0)+ISNULL(c.quantity,0) AS storage_count
              FROM      dbo.dz_product_pool AS a
                        INNER JOIN dbo.product p ON p.id = a.product_id
                        LEFT JOIN view_product_generalized_storage b ON a.product_id = b.product_id
						LEFT JOIN dbo.business_department_storage c ON c.product_id =a.product_id AND c.business_department_id =3 AND c.type =2
              WHERE     NOT EXISTS ( SELECT pmt.id
                                     FROM   view_all_purchasing_management_task
                                            AS pmt
                                     WHERE  pmt.[type] = 3
                                            AND pmt.sub_type = 12
                                            AND ( pmt.[status] < 6
                                                  OR ( pmt.[status] = 6
                                                       AND DATEDIFF(DAY,
                                                              pmt.completion_time,
                                                              GETDATE()) <= 1
                                                     )
                                                )
                                            AND pmt.product_id = a.product_id )
                        AND NOT EXISTS ( SELECT TOP 1
                                                id
                                         FROM   dbo.stay_shield_product WITH ( NOLOCK )
                                         WHERE  product_id = a.product_id
                                                AND status = 1 )
                        AND p.offline_status < 2
            ) AS temp
    WHERE   temp.storage_count < ( temp.sale_quantity * 1.0
                                   * temp.refresh_param * temp.limit_rate )
            AND temp.prepare_quantity > 0
    UNION
    SELECT  dz_product_pool.id ,
            dz_product_pool.product_id ,
            CEILING(( x1.waitPlanQty + sale_quantity * refresh_param
                      * limit_rate - ISNULL(b.quantity, 0)-ISNULL(c.quantity,0) - ISNULL(x2.uncompleteQty, 0) )
                    * 1.00 / p.unit_quantity) * p.unit_quantity
    FROM    dbo.dz_product_pool
            JOIN ( SELECT   a.id ,
                            SUM(c.plan_quantity * ( d.unit_quantity
                                                    - ISNULL(b.remaind_qty, 0) )
                                / b.convert_rate) AS waitPlanQty
                   FROM     dbo.dz_product_pool AS a
                            INNER JOIN dbo.storage_product_processing_accessories b ON a.product_id = b.original_product_id
                            INNER JOIN dbo.purchasing_management_task c ON c.product_id = b.processing_product_id
                                                              AND c.status = 8
                            JOIN dbo.product d ON d.id = a.product_id
                   GROUP BY a.id
                 ) x1 ON x1.id = dz_product_pool.id
            LEFT JOIN ( SELECT  a.id ,
                                SUM(pmt.wait_quantity) AS uncompleteQty
                        FROM    dz_product_pool AS a
                                JOIN purchasing_management_task AS pmt ON pmt.[type] = 3
                                                              AND pmt.sub_type = 12
                                                              AND pmt.[status] < 6
                                                              AND pmt.product_id = a.product_id
                        GROUP BY a.id
                      ) x2 ON x2.id = dz_product_pool.id
            LEFT JOIN view_product_generalized_storage b ON dz_product_pool.product_id = b.product_id
			LEFT JOIN dbo.business_department_storage c ON c.product_id =dz_product_pool.product_id AND c.business_department_id =3 AND c.type =2
            JOIN dbo.product p ON p.id = dz_product_pool.product_id
    WHERE   ISNULL(b.quantity, 0)+ISNULL(c.quantity,0) + ISNULL(x2.uncompleteQty, 0) - ISNULL(x1.waitPlanQty,
                                                              0) < sale_quantity
            * refresh_param * limit_rate
			) z GROUP BY  id,z.product_id
go


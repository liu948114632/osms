



-- =============================================
-- Author:		HYD
-- Create date: 2010-06-10
-- Description:	增加订单的附加费
-- Version：CRM 5.1.0
-- =============================================
CREATE PROCEDURE [dbo].[CRM_Order_OrderSurchargeAdd]
(
	@OrderId VARCHAR(20),
	@CategoryId	INT,
	@Surcharge DECIMAL(9,2),
	@Remark VARCHAR(500)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO dbo.T_OrderSurcharge
	        ( OrderId ,
	          CategoryId ,
	          Surcharge ,
	          Remark
	        )
	VALUES  ( @OrderId, -- OrderId - varchar(15)
	          @CategoryId , -- CategoryId - tinyint
	          @Surcharge , -- Surcharge - decimal
	          @Remark  -- Remark - varchar(500)
	        )
END

go


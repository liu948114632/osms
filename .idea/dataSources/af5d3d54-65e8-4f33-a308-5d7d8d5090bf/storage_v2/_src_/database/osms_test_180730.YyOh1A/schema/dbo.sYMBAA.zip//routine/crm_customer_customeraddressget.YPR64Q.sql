
  
/*---------------------------------------------------  
[描述]  
 通过邮件来获取客户的地址  
type 1--shipAddress;2:billAddress  
-----------------------------------------------------*/  
CREATE PROCEDURE [dbo].[CRM_Customer_CustomerAddressGet] 
( @type INT,-- 地址类型  
 @userId INT,
@IsEnlisthAddress BIT=0
    )  
AS   
    BEGIN  
        DECLARE @returnType INT = 0;  
        DECLARE @addressId INT;  
          
        IF ( @userId > 0 )   
            BEGIN  
            IF(@IsEnlisthAddress=0)
            begin
    -- 取地址编号  
                SELECT TOP 1  
                        @addressId = [AddressId] ,  
                        @returnType = [Type]  
                FROM    dbo.T_CustomerAddresses  
                WHERE   [UserId] = @UserId  
                        AND ( [Type] = @type  
                              OR [Type] = 3  
                            );  
         END
    ELSE
    BEGIN
          SELECT TOP 1  
                        @addressId =  ISNULL(EnglishAddressId,0) ,  
                        @returnType = [Type]  
                FROM    dbo.T_CustomerAddresses  
                WHERE   [UserId] = @UserId  
                        AND  ISNULL(EnglishAddressId,0) >0
                        
            
    END
                        END  
                IF ( @addressId > 0 )   
                    BEGIN  
                        SELECT  a.* ,  
                                b.[Name] AS CountryName  
                        FROM    ( SELECT    *  
                                  FROM      dbo.T_Addresses  
                                  WHERE     [AddressId] = @AddressId  
                                ) a  
                                LEFT  JOIN dbo.T_Country b ON a.Country = b.CountryId;  

            END  
              
        RETURN @returnType;  
    END

go


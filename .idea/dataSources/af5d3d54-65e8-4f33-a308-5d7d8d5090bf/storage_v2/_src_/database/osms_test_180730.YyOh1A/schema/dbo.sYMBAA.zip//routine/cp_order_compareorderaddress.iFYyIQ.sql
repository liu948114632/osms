
CREATE PROCEDURE [dbo].[CP_Order_CompareOrderAddress]
(
  @OrderIds VARCHAR(MAX),
  @Result INT = 0 OUT  --返回不同的地址条数
)
AS
BEGIN
	SELECT b.OrderId,b.DeliveryId,LTRIM(RTRIM(ISNULL(c.Firstname,''))) AS Firstname,LTRIM(RTRIM(ISNULL(c.Lastname,''))) AS Lastname,
		   LTRIM(RTRIM(ISNULL(c.Address1,''))) AS Address1,LTRIM(RTRIM(ISNULL(c.Address2,''))) AS Address2,LTRIM(RTRIM(ISNULL(c.Country,''))) AS Country,
		   LTRIM(RTRIM(ISNULL(c.City,''))) AS City,LTRIM(RTRIM(ISNULL(c.Fax,''))) AS Fax,LTRIM(RTRIM(ISNULL(c.Phone,''))) AS Phone,
		   LTRIM(RTRIM(ISNULL(c.Zip,''))) AS Zip,LTRIM(RTRIM(ISNULL(c.State,''))) AS State,LTRIM(RTRIM(ISNULL(c.Port,''))) AS Port,
		   LTRIM(RTRIM(ISNULL(c.CompanyName,''))) AS CompanyName  
	INTO #Temp_OrderInfo  
	FROM dbo.uf_Split(@OrderIds,',') a  
	INNER JOIN dbo.T_Order b WITH(NOLOCK) ON a.[Value] = b.OrderId  
	INNER JOIN dbo.T_OrderAddresses c WITH(NOLOCK) ON b.ShipAddressId = c.AddressId  

    IF (@@ROWCOUNT < 2)  
    BEGIN  
       SET @Result = 0
       RETURN 
    END

	SELECT DISTINCT DeliveryId,Firstname,Lastname,Address1,Address2,Country,City,Fax,Phone,Zip,State,Port,CompanyName  
	FROM #Temp_OrderInfo  
   
    IF(@@ROWCOUNT = 1)  
    BEGIN   
        SET @Result = 1
    END 
    ELSE
    BEGIN
        SET @Result = 2
    END

    DROP TABLE #Temp_OrderInfo
END
go


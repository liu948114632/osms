
CREATE PROC CRM_Order_ShopOrderExists
(
    @ShopTradeNo VARCHAR(100),
    @BusinessType INT
)
AS
BEGIN
    SELECT COUNT(1) FROM dbo.T_ShopCustomer t1 INNER JOIN dbo.T_Order t2 ON t1.OrderId=t2.OrderId 
    WHERE t1.ShopTradeNo=@ShopTradeNo AND t2.OrderStatus < 132 AND t2.OrderIndustryType=@BusinessType
END
go


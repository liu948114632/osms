/*  
*招标历史查询  
*/ 
CREATE PROCEDURE [dbo].[CMS_ProviderInvitedBidsHistoryList]      
(      
 @productId INT = NULL, --一产品ID 
 @PageSize INT = 50 ,  --页大小                
 @PageIndex INT = 1    --当前页号        
)      
AS          
BEGIN          
 SET NOCOUNT ON          
 DECLARE      
  @SQL NVARCHAR(MAX),        
  @tempSQL NVARCHAR(MAX),        
  @FromSQL NVARCHAR(MAX),         
  @FromSQL2 NVARCHAR(MAX),        
  @Column NVARCHAR(MAX),          
  @Condition NVARCHAR(MAX),   
  @CountSQL NVARCHAR(MAX),              
  @RowCount INT , @PageCount INT , @start INT ,@end INT;       
 --组装查询条件     
 SET @Condition = ' WHERE tib.task_invited_bids_result !=1 ';  
 
 IF @productId IS NOT NULL       
 BEGIN      
  SET @Condition = @Condition + ' AND pdt.product_id ='+CONVERT(VARCHAR(20),@productId);   
 END 
 
--JOIN dbo.view_all_purchasing_department_task pdt WITH (NOLOCK) ON pdt.id = tib.purchase_task_id
 --设置查询主表      
 SET @FromSQL = ' FROM task_invited_bids_detail tibd WITH (NOLOCK)  
		LEFT JOIN task_invited_bids tib WITH (NOLOCK) ON tibd.task_bid_id = tib.id 
		JOIN task_relate_invited_bids trib WITH(NOLOCK) ON  tib.id = trib.invited_bids_id 
		JOIN dbo.view_all_purchasing_department_task pdt WITH (NOLOCK) ON pdt.id = trib.task_id
		JOIN dbo.view_all_purchasing_management_task  pmt WITH (NOLOCK) ON pmt.id = pdt.purchasing_management_task_id
		LEFT JOIN  product p WITH (NOLOCK) ON pdt.product_id = p.id
		'         
   
       
 --设置取字段表      
 SET @FromSQL2 = ' JOIN task_invited_bids_detail tibd WITH (NOLOCK) ON tibd.id = temp.id
		JOIN task_invited_bids tib WITH (NOLOCK) ON tibd.task_bid_id = tib.id 
		JOIN task_relate_invited_bids trib WITH(NOLOCK) ON  tib.id = trib.invited_bids_id 
		JOIN dbo.view_all_purchasing_department_task pdt WITH (NOLOCK) ON pdt.id = trib.task_id
		JOIN dbo.view_all_purchasing_management_task  pmt WITH (NOLOCK) ON pmt.id = pdt.purchasing_management_task_id
		LEFT JOIN  product p WITH (NOLOCK) ON pdt.product_id = p.id
		LEFT JOIN provider pv WITH (NOLOCK) ON pv.id = tibd.provider_id
		LEFT JOIN department dm WITH (NOLOCK) on dm.id = pv.department_id
		'
      
 --获取符合条件的总记录数      
 SET @CountSQL = ' SELECT @RowCount = count(tibd.id) ' + @FromSQL + @Condition            
    EXEC sp_executesql @CountSQL, N'@RowCount INT OUT', @RowCount OUT       
          
    --设置分页参数(一定要放在取记录数的后面)      
    IF ISNULL(@PageSize, 0) < 1                       
        SET @PageSize = 50                      
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                      
    IF ISNULL(@PageIndex, 0) < 1                       
        SET @PageIndex = 1                      
    ELSE                       
    IF ISNULL(@PageIndex, 0) > @PageCount                       
        SET @PageIndex = @PageCount                   
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1                      
    SET @end = @PageIndex * @PageSize      
          
    --设置取字段信息    
    SET @Column = ' pdt.id AS taskId,
	pdt.transmit_time AS taskTime,
	p.code AS productCode,
	pdt.plan_quantity AS planQuantity,
	pdt.type AS taskType,
	pdt.sub_type AS taskSubType,
	tib.cost_price AS costPrice,
	tib.invited_bid_time AS invitedBidTime,
	dm.name AS department,
	pv.code AS providerCode,
	tibd.bid_price AS bidPrice,
	pmt.transmit_time AS transmitTime,
	tibd.provider_bids_result AS invitedBidsResult,
	tibd.remark AS invitedBidRemark';     
             
 --组装基本查询语句           
 SET @SQL = 'select  distinct tibd.id' + @FromSQL + @Condition;      
 SET @SQL = 'SELECT ' + @Column + ', ROW_NUMBER() OVER(ORDER BY tibd.id desc,pdt.transmit_time DESC,tibd.provider_bids_result DESC,pv.code DESC) rowIndex  FROM (' + @SQL + ') temp ' + @FromSQL2 
  SET @SQL = 'SELECT  * FROM (' + @SQL + ') temp ' + ' WHERE rowIndex between ' 
	+ CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) 
 PRINT @SQL
 EXEC(@SQL)  
    SELECT @RowCount       
END






----------中心仓库指定仓库中  排除 PW类型的订单
go




CREATE PROC dbo.CMS_LogisticsCenter_CheckOrderList  
    (  
	  @DepartmentId INT = NULL , --部门
      @OrderCode VARCHAR(20) = NULL , --订单编号     
      @OrderTimeBegin DATETIME = NULL , --查询下单时间的开始时间                            
      @OrderTimeEnd DATETIME = NULL , --查询下单时间的结束时间 
      @CompleteTimeBegin DATETIME = NULL , --查询质检完成时间的开始   v3.9.0 add                        
      @CompleteTimeEnd DATETIME = NULL , --查询质检完成时间的结束     v3.9.0 add  
      @OrderStatus INT = NULL ,  --订单状态                            
      @Status INT = NULL ,  --质检状态                            
      @IsStockUp BIT = NULL,
	  @IsVip INT = NULL,
	  @NewNeedCheck INT = NULL,
      @MerchandiserId INT = NULL, -- 3.9.31 跟单员
      @PageSize INT = 50 ,  --页大小                            
      @PageIndex INT = 1    --当前页号                            
    )  
AS   
    BEGIN                                  
        SET NOCOUNT ON ;                                  
                                    
        DECLARE @SQL VARCHAR(MAX) ,  
            @CountSql NVARCHAR(MAX) , --查询数量用                            
            @FromSQL NVARCHAR(MAX) , --查询表                          
            @Condition VARCHAR(MAX) , --条件                             
            @RowCount INT ,  
            @PageCount INT ,  
            @BarCount INT, --条码总数  
            @BarCountSql NVARCHAR(MAX),  
            @start INT ,  
            @end INT ,  
            @DistinctCode VARCHAR(10) ,  
            @OrderSQL VARCHAR(MAX)                          
                                    
        SET @FromSQL = ' FROM check_order as x WITH (NOLOCK) inner join  [order] a WITH (NOLOCK) on x.order_id=a.id 
						 LEFT JOIN T_CustomerSpecial as tx WITH (NOLOCK) on a.customer_id = tx.CustomerId   
                         AND (CASE  a.type WHEN 2 THEN 16 when 5 then 17 ELSE 1 END) = tx.BusinessType '                             
                                
        SET @Condition = ' WHERE 1=1 '                            
        SET @DistinctCode = ''
		IF @IsVip IS NOT NULL
        BEGIN
			 SET @Condition = @Condition + ' AND a.is_vip='  
                    + CONVERT(VARCHAR(10), @IsVip)  
        END
		IF @NewNeedCheck IS NOT NULL AND @NewNeedCheck>=0
        BEGIN
			 SET @Condition = @Condition + ' AND x.new_need_check=' + CONVERT(VARCHAR(10), @NewNeedCheck)  
        END
        IF @Status IS NOT NULL   
            BEGIN                             
                SET @Condition = @Condition + ' AND x.status='  
                    + CONVERT(VARCHAR(10), @Status)                            
            END         
        IF @OrderCode IS NOT NULL   
            BEGIN                             
                SET @Condition = @Condition + ' AND a.code like ''%'  
                    + @OrderCode + '%'''                          
            END                              
        IF @OrderStatus IS NOT NULL   
            BEGIN                             
                SET @Condition = @Condition + ' AND a.status='  
                    + CONVERT(VARCHAR(10), @OrderStatus)                            
            END                              
                      
        IF @DepartmentId IS NOT NULL   
            BEGIN             
                SET @Condition = @Condition + ' AND a.department_id='  
                    + CONVERT(VARCHAR(10), @DepartmentId)            
            END    
        IF @OrderTimeBegin IS NOT NULL   
            BEGIN                             
                SET @Condition = @Condition + ' AND a.order_time >='''  
                    + CONVERT(VARCHAR(20), @OrderTimeBegin) + ''''                            
            END                             
        IF @OrderTimeEnd IS NOT NULL   
            BEGIN                             
                SET @Condition = @Condition + ' AND a.order_time <='''  
                    + CONVERT(VARCHAR(20), @OrderTimeEnd) + ''''                             
            END
        --v3.9.0 add
        IF @CompleteTimeBegin IS NOT NULL
			BEGIN
				SET @Condition =@Condition + ' AND x.complete_time >='''
					+ CONVERT(VARCHAR(20), @CompleteTimeBegin) + ''''
			END
		IF @CompleteTimeEnd IS NOT NULL
			BEGIN
				SET @Condition =@Condition + ' AND x.complete_time <='''
					+ CONVERT(VARCHAR(20), @CompleteTimeEnd) + ''''
			END
        IF @IsStockUp IS NOT NULL
            IF @IsStockUp = 1
				BEGIN                             
					SET @Condition = @Condition + ' AND NOT EXISTS ( SELECT TOP 1 ix.id from order_item ix WITH (NOLOCK) 
					WHERE  ix.order_id = a.id AND ix.status NOT IN(12,4) AND isnull(ix.zcq_department_received_qty,0)<ix.order_quantity AND ix.is_check=1 )'                             
				END
			ELSE
			   BEGIN                             
					SET @Condition = @Condition + ' AND EXISTS( SELECT TOP 1 ix.id from order_item ix WITH (NOLOCK) 
					WHERE  ix.order_id = a.id AND ix.status NOT IN(12,4) AND isnull(ix.zcq_department_received_qty,0)<ix.order_quantity AND ix.is_check=1 )'                            
				END
--------------------------------------------------------------------------------------				
		IF @MerchandiserId IS NOT NULL
			BEGIN
				SET @Condition = @Condition + ' and a.merchandiser_id=' + CONVERT(VARCHAR(10), @MerchandiserId) ;    
			END			
--------------------------------------------------------------------------------------            
					             
        SET @CountSql = ' SELECT @RowCount = count(' + @DistinctCode  
            + ' a.id) ' + @FromSQL + @Condition                            
        --总数量                      
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT;           
        -- SELECT @CountSql    
                            
        IF ISNULL(@PageSize, 0) < 1   
            SET @PageSize = 50                                  
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                  
        IF ISNULL(@PageIndex, 0) < 1   
            SET @PageIndex = 1                                  
        ELSE   
            IF ISNULL(@PageIndex, 0) > @PageCount   
                SET @PageIndex = @PageCount                                  
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                  
        SET @end = @PageIndex * @PageSize                           
                              
        SET @SQL = 'SELECT * from (                            
   SELECT temp.*,ROW_NUMBER() OVER(ORDER BY temp.id ) rowIndex,
			CASE WHEN  ISNULL((SELECT TOP 1 ix.id from order_item ix WITH (NOLOCK) 
					WHERE ix.order_id = temp.orderId AND ix.status NOT IN(12,4) AND isnull(ix.zcq_department_received_qty,0)<ix.order_quantity AND ix.is_check=1 ),0) = 0 
			THEN 1 ELSE 0 END AS isQualityInspection                         
   from (                           
	   SELECT ' + @DistinctCode  + ' x.id, 
	   x.status,
	   a.is_vip as isVip,
	   x.order_id AS orderId,
	   x.wait_check_time AS waitCheckTime,
	   x.wait_confirm_time AS waitConfirmTime,
	   x.complete_time AS completeTime,       
	   x.new_need_check AS newNeedCheck,                   
	   a.code as orderCode,                            
	   a.status as orderStatus,                           
	   a.merchandiser_id AS merchandiserId,                           
	   a.order_time AS orderDate,                               
	   a.valid_order_count AS validOrderCount,                           
	   a.prepared_count AS preparedCount,                 
	   tx.Special AS customerRemark,                           
	   a.customer_service_remark AS customerServiceRemark,           
	   a.branch_remark AS branchRemark,          
	   a.stock_out_branch_remark AS stockOutBranchRemark,x.check_remark as checkRemark '                           
       
        SET @SQL = @SQL + @FromSQL + @Condition  
            + ') temp ) temp2 where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '  
            + CAST(@end AS NVARCHAR(10))                            
          
		--SELECT @SQL      
			print @SQL
        EXEC(@SQL) ;                                      
                                
        SELECT  @RowCount;   
                                   
    END
go


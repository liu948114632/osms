
/*
条件：
办事处采购任务列表，
1.任务状态是已经分配的并且没有结束
2.任务类型为PHW订单任务
3.对应任务的商品在所有订单中都已经备好货

那么自动做以下处理：
1.办事处采购任务设置为待取消
2.采购部任务设置为取消
3.采管部设置为取消

1.办事处采购任务设置为待取消
------------ 这里有个疑问，为什么不设置为取消，而是待取消
P3的任务是不会到办事处的
P3任务都是去中心仓库
*/

CREATE PROCEDURE CMS_Service_GetPurchaseMange_Data
AS 
BEGIN
WITH    cte_order_product
          AS -- 还没有备好货的所有商品
( SELECT DISTINCT
            product_id
  FROM      dbo.order_item WITH ( NOLOCK )
  WHERE     [status] = 1
)
    SELECT DISTINCT c.id,c.order_id AS orderId,c.order_item_id AS orderItemId
            
    FROM    dbo.department_purchase_task a WITH ( NOLOCK )
            INNER JOIN dbo.view_all_purchasing_department_task AS b WITH ( NOLOCK ) ON a.purchasing_department_task_id = b.id
            INNER JOIN dbo.view_all_purchasing_management_task AS c WITH ( NOLOCK ) ON b.purchasing_management_task_id = c.id        
           
            LEFT JOIN cte_order_product AS s ON a.product_id = s.product_id
    WHERE   a.[status] > 10
            AND a.[status] < 70-- 已分配、采购中、加工中、无法处理状态
            AND c.[type] = 1
            AND a.is_cancled = 0
            AND s.product_id IS NULL ;
 
END

go



/**
检查订单是否符合当前的运费折扣
*/
CREATE PROC CRM_Order_IsQualifiedFreightDiscount
(
   @OrderId VARCHAR(20),
   @Result BIT OUT 
)
AS 
BEGIN
     DECLARE @CrmCustomerId INT,--CRM客户ID
             @WebCustomerId INT,--网站的客户ID
             @ShipCountryId INT ,--货运地址国家ID
             @ShipCity VARCHAR(500), --货运地址城市
             @ShipZip VARCHAR(200), --货运地址邮编
             @CustomerRatingId INT, --客户等级ID
             @CustomerType  INT, --客户类型
             @DeliveryID  INT, --货运方式ID
             @ProductPrice DECIMAL(18,2) , --商品折前总价
             @OrderWeight DECIMAL(18,2),--订单重量
             @PromoteActivityId int --运费促销活动ID
             
    SET @Result = CONVERT(BIT,0) --默认是符合要求的
           
     --1、取订单基本信息
     SELECT @CrmCustomerId = CustomerId,
            @ShipCountryId = Country,
            @ShipCity = City,
            @ShipZip = Zip,
            @DeliveryID = DeliveryId,
            @PromoteActivityId = DeliveryPromoteActivityId
     FROM dbo.T_Order a
     JOIN dbo.T_OrderAddresses b ON a.ShipAddressId=b.AddressId
     WHERE OrderId =@OrderId
     
     --如果订单没有享受活动折扣，则表示符合要求
     IF( @PromoteActivityId IS NULL OR @PromoteActivityId<=0)
     begin
        SET @Result = CONVERT(BIT,1) --符合要求的
        RETURN;
     END 
     
     --2、取客户信息
     SELECT @CustomerRatingId = RatingId,
            @CustomerType = ISNULL(PHActivityLevel,0),
            @WebCustomerId = BussinessCustomerId
     FROM dbo.T_Customer
     LEFT JOIN dbo.T_CustomerActivityLevel ON UserID=CustomerId
     WHERE UserID=@CrmCustomerId
     
     --商品折前总价
     EXEC CRM_Order_GetOrderOriginalProductPrice @OrderId=@OrderId,@OriginalProductPrice = @ProductPrice OUT ;
     
     --获取订单重量                                
     DECLARE @ReadyWeight DECIMAL(18,2)
     EXEC CRM_Price_OrderValidWeightGet @OrderId=@OrderId, @Weight=@OrderWeight OUT,@ReadyWeight=@ReadyWeight OUT ; 
    

     --检查是否满足活动要求
     IF EXISTS(
     SELECT 1
        FROM    dbo.ph_freight_promote_activity a WITH(NOLOCK)  
                INNER JOIN ph_promote_activity b WITH(NOLOCK) ON a.promote_activity_id = b.id 
                INNER JOIN ph_promote_activity_range c1 WITH(NOLOCK) ON b.id = c1.promote_activity_id AND c1.range_type = 1  --国家限制
                INNER JOIN ph_promote_activity_range c2 WITH(NOLOCK) ON b.id = c2.promote_activity_id AND c2.range_type = 2  --客户限制
                INNER JOIN ph_promote_activity_range c3 WITH(NOLOCK) ON b.id = c3.promote_activity_id AND c3.range_type = 3  --客户等级限制
                INNER JOIN ph_promote_activity_range c4 WITH(NOLOCK) ON b.id = c4.promote_activity_id AND c4.range_type = 4  --客户类型限制
                INNER JOIN ph_promote_activity_range c5 WITH(NOLOCK) ON b.id = c5.promote_activity_id AND c5.range_type = 5  --货运方式限制
        WHERE   b.is_delete = 0 AND b.is_activity_start = 1  
                AND a.promote_activity_id = @PromoteActivityId --判断当前订单活动
                AND DATEADD(hh,-15,GETDATE())>=b.begin_time AND DATEADD(hh,-15,GETDATE())<=b.end_time --转成美国时间再比较
                AND (--判断是否满足活动的客户范围
                        c2.ids LIKE ('%,' + CONVERT(VARCHAR(10), @WebCustomerId) + ',%')  --1、如果促销针对特定的客户则其他条件不限  
                        OR (
                             ( c1.ids = '-1'  
                               OR c1.ids = '-11'  
                               OR c1.ids LIKE ('%,' + CONVERT(VARCHAR(10), @ShipCountryId) + ',%')  
                             )  --2.1、判断货运国家是否满足限制要求
                             AND ( c3.ids = '-1'  
                                   OR c3.ids = '-11'  
                                   OR c3.ids LIKE ('%,'  + CONVERT(VARCHAR(10), @CustomerRatingId) + ',%')  
                                 ) --2.2、判断客户等级是否满足限制要求 
                             AND ( c4.ids = '-1'  
                                   OR c4.ids = '-11'  
                                   OR c4.ids LIKE ('%,' + CONVERT(VARCHAR(10), @customerType) + ',%')  
                                 ) --2.3、判断客户类型是否满足限制要求 
                           )          
                    )
                 AND ( c5.ids = '-1'  
                       OR c5.ids = '-11'  
                       OR c5.ids LIKE ('%,' + CONVERT(VARCHAR(10), @DeliveryID) + ',%')  
                     ) --3、判断货运方式是否满足要求
               AND  a.order_product_price <= @ProductPrice --判断商品金额是否达到要求
         )
      BEGIN   --按照当前活动条件查询，能查出记录表示还满足要求
           SET @Result = CONVERT(BIT,1) --符合要求的
           RETURN;
      END 
      ELSE 
      BEGIN
           SET @Result = CONVERT(BIT,0) --不符合要求的
           RETURN;
      END 
END
go


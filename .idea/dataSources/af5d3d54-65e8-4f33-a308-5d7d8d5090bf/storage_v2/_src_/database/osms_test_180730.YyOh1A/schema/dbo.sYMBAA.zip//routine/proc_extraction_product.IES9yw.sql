
/**
	@author whw
	@date 2016-8-5
	@desc 提取商品
*/
CREATE PROC proc_extraction_product
AS
BEGIN
	
SELECT *,ROW_NUMBER() OVER(ORDER BY id) AS no INTO #log FROM dbo.ph_show_category_relate_product_update_operator_log
WHERE status<>1

DECLARE @start INT=1
DECLARE @total INT=NULL
DECLARE @object_id INT =NULL
DECLARE @object_type TINYINT=NULL

DECLARE @tb_result TABLE
(
	object_id INT,
	object_type INT
)

SELECT @total=COUNT(*) FROM #log

WHILE @start<=@total
BEGIN
	SELECT @object_id=object_id,@object_type=object_type FROM #log WHERE no=@start
	IF NOT EXISTS(SELECT * FROM @tb_result WHERE object_id=@object_id AND object_type=@object_type)
	BEGIN TRY
	    IF @object_type=1
		BEGIN
		    EXEC dbo.proc_extraction_product_1 @phShowCategoryId = @object_id
		END
		IF @object_type=2
		BEGIN
		    EXEC dbo.proc_extraction_product_2 @ph_product_id = @object_id -- int
		END
		INSERT INTO @tb_result
		        ( object_id, object_type )
		VALUES  ( @object_id, -- object_id - int
		          @object_type  -- object_type - int
		          )
	END TRY
	BEGIN CATCH
		--运行失败
	END CATCH
    SET @start=@start+1
END


UPDATE l SET l.status=CASE WHEN r.object_id IS NULL THEN 2 ELSE 1 END --1、成功 2、失败
FROM dbo.ph_show_category_relate_product_update_operator_log l
INNER JOIN #log t ON t.id=l.id
LEFT JOIN @tb_result r ON r.object_id=t.object_id AND r.object_type=t.object_type

DROP TABLE #log
END

go


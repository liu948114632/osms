CREATE FUNCTION fn_getProoductIdByProviderCode(@ProviderCode nvarchar(30)) 
RETURNS TABLE
AS
  RETURN SELECT pp.product_id FROM product_provider pp WITH(NOLOCK)
  INNER JOIN provider p  WITH(NOLOCK) on pp.provider_id = p.id AND p.code LIKE + @ProviderCode +'%'

go


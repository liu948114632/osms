  
  
/**      
获取不能走海外仓的商品在国内的运费      
*/      
CREATE PROC CRM_Order_GetDomesticFreightByOverseasWarehouse  
(      
  @OrderId VARCHAR(20),      
  @GoDomesticItemIds VARCHAR(max),--走国内的订单项ID,多个用逗号隔开      
  @Freight  DECIMAL(18,2) OUT -- 返回运费  
)      
AS      
BEGIN   
    DECLARE @OrderItems TABLE(OrderItemId INT ); 
    DECLARE @IsFreeShipping BIT,@OrderIndustryType INT ,@FreeShipSurcharge DECIMAL(18,2)
    
    SELECT @IsFreeShipping = IsFreeShipping,@OrderIndustryType = OrderIndustryType,@FreeShipSurcharge = FreeShipSurcharge
    FROM dbo.T_Order 
    WHERE OrderId = @OrderId 

    INSERT INTO @OrderItems(OrderItemId)            
	 SELECT [Value]             
	 FROM dbo.uf_Split(@GoDomesticItemIds,',');   
   
 --1.获取走国内商品的订单重量  
 DECLARE @Weight INT ,@VolumeWeight INT  
 SET @VolumeWeight = 0;  
   
 --1.1 获取物理重量  
 SELECT @Weight = CEILING(SUM(Quantity*1.0*[Weight]/UnitQuantity))  
 FROM dbo.T_OrderItem a with(nolock)  
 JOIN @OrderItems b ON a.OrderItemId=b.OrderItemId  
 WHERE a.Status < 12 AND OrderId=@OrderId; --排除取消商品     
   
 --1.2 获取体积重量  
 -- 获取体积系数  
 DECLARE @VolumeWeightRate Decimal(18,2); -- 体积重量换算率   
 EXEC CRM_Settings_VolumeWeightRateByOrder @OrderId, @VolumeWeightRate OUT;  
 If @VolumeWeightRate > 0  
 BEGIN   
  SELECT @VolumeWeight = CEILING( SUM( (Quantity*1.0*[Volume]/@VolumeWeightRate)/UnitQuantity ) )   
  FROM dbo.T_OrderItem a with(nolock)  
  JOIN @OrderItems b ON a.OrderItemId=b.OrderItemId  
  WHERE a.Status < 12 AND OrderId=@OrderId; --排除取消商品    
 END   
   
 --SELECT @Weight,@VolumeWeight  
   
 --1.3 获取订单重量 = 物理重量和体积重量取最大值  
 IF @VolumeWeight > @Weight 
 SET @Weight = @VolumeWeight;  
   
 --2.根据国内的重量计算运费,免运费的排除，算实时运费
  --IF( @IsFreeShipping = 1 )
  -- BEGIN
  --      if(@OrderIndustryType = 17)  
		--begin --JL订单免运费为0  
		--	 SET @Freight = 0    
		--end  
		--ELSE
		--BEGIN
		--    SET @Freight = CEILING(ISNULL(@Weight,0) * 1.0 / 1000) * @FreeShipSurcharge   
		--END 
  -- END  
  -- ELSE 
  -- BEGIN
          EXEC CRM_Order_CalculateOrderFreightBySnapshot @OrderId=@OrderId,@Weight = @Weight,@Freight=@Freight OUT ;  
 --  END  
END

go


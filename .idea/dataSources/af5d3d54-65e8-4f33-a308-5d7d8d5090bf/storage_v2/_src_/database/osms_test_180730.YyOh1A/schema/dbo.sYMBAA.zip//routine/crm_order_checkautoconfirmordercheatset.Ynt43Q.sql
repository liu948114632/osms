--检查用户订单是否存在欺诈，如果有不自动录单
CREATE PROC CRM_Order_CheckAutoConfirmOrderCheatSet
(
@CountryId INT=-1,
@CustomerId INT=-1
)
AS 
BEGIN
	SELECT TOP 1 Remark FROM dbo.T_AutoConfirmOrderCheatSet WHERE CountryId=@CountryId OR CustomerId=@CustomerId
END
go


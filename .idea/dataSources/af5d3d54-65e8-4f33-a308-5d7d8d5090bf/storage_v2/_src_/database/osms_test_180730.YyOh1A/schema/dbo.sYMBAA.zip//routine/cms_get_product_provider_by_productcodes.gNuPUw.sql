CREATE PROCEDURE CMS_Get_product_provider_by_productCodes
(
 @ProductCodes NVARCHAR(max) =null
)
AS 
BEGIN
 SET NOCOUNT ON;
	DECLARE  @SQL varchar(MAX)
	SET @SQL ='select pp.product_id AS productId,
			pp.id,
			pp.provider_id AS providerId,
			pp.department_id AS departmentId
	 from product_provider pp WITH(NOLOCK) 
	inner join product_strategy  ps WITH(NOLOCK) on ps.product_id = pp.product_id and ps.department_id = pp.department_id
	inner join product p WITH(NOLOCK)  on ps.product_id = p.id and  p.is_delete = 0 and ';
	SET @SQL = @SQL + ' P.code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')'  
	SET @SQL = @SQL + ' AND p.is_delete = 0'  
	EXEC(@SQL)
END
go


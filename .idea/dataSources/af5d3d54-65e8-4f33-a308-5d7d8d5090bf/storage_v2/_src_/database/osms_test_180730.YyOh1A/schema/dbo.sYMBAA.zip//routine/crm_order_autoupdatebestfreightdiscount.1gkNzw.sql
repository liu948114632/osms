/**    
根据订单情况，自动获取当前最优惠的运费折扣，并更新运费和订单信息    
*/    
CREATE PROC CRM_Order_AutoUpdateBestFreightDiscount    
(      
  @OrderId VARCHAR(20) , --订单ID    
  @IsDhlRemote BIT = 0, --货运地址在DHL是否偏远    
  @OperatorId INT =0 , --操作人ID     
  @PromoteActivityId INT OUT --返回最优的活动ID    
)      
AS       
BEGIN      
   DECLARE @ProcedureCost DECIMAL(18,2) , --返回免运费的手续费     
           @FreightDiscount DECIMAL(18,2) , --返回运费折扣    
           @BestDeliveryId INT ,--返回最优的货运方式    
           @DeliveryRange VARCHAR(500) --返回免运费货运方式的范围    
               
  EXEC CRM_Order_GetCurrentBestFreightPromoteActivityByOrder @OrderId= @OrderId,@IsDhlRemote =@IsDhlRemote,@PromoteActivityId = @PromoteActivityId OUT,    
  @ProcedureCost = @ProcedureCost OUT,@FreightDiscount = @FreightDiscount OUT,@BestDeliveryId = @BestDeliveryId OUT ,@DeliveryRange = @DeliveryRange OUT     
      
     --如果没有最优的运费获得，则直接返回    
     IF( @PromoteActivityId <1)     
     BEGIN    
        RETURN;    
     END     
         
     --更新订单信息    
   UPDATE dbo.T_Order SET FreightDiscount = @FreightDiscount,    
                          FreeShipSurcharge = @ProcedureCost,    
                          DeliveryId = (CASE WHEN @FreightDiscount = 1 THEN @BestDeliveryId ELSE DeliveryId END),--如果是免运费活动，则更新为最优货运方式   
                          FreeShipDeliveryRange = (CASE WHEN @FreightDiscount = 1 THEN @DeliveryRange ELSE '' END),    
                          DeliveryPromoteActivityId = @PromoteActivityId,    
                          IsFreeShipping = (CASE WHEN @FreightDiscount = 1 THEN 1 ELSE 0 END) --判断当前是否为免运费活动    
   FROM T_Order    
   WHERE OrderId = @OrderId    
        
   --更新运费    
   DECLARE @Freight  DECIMAL(18,2)    
   EXEC CRM_Order_OrderFreightUpdate @OrderId=@OrderId,@Freight=@Freight OUT    
       
   --插入日志    
   DECLARE @Remark VARCHAR(500)    
   SET @Remark = N'自动获取订单最优运费折扣为' + CONVERT(VARCHAR(10),@FreightDiscount) + ' off,更新后运费为：'  + CONVERT(VARCHAR(20),@Freight)    
   EXEC CRM_Order_OrderHistoryAdd  @UserId=@OperatorId,@OrderId=@OrderId,@Remark=@Remark;    
END
go


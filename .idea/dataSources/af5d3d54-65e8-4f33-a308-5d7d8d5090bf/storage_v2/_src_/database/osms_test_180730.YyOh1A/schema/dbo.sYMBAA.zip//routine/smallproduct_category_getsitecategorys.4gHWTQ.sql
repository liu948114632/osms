


-- =============================================
-- Author:		<yangzk>
-- Create date: <2008-07-15>
-- Description:	<小商品城-获得类别信息>
-- ==========================================================
CREATE PROCEDURE [dbo].[SmallProduct_Category_GetSiteCategorys]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT
		CategoryId,
		[Name],
		'' AS [Code], 
		[Description],
		[ParentId],
		CAST((CASE WHEN IsDisplay = 1 THEN 0 ELSE 1 END) AS BIT) AS [Disabled],
		[OrderIndex] AS [Order],
		[Name] AS [Title],
		[Description] AS [Alias],
		[ImageUrl]
	FROM
		dbo.T_Category
	ORDER BY 
		[Name];
END


go


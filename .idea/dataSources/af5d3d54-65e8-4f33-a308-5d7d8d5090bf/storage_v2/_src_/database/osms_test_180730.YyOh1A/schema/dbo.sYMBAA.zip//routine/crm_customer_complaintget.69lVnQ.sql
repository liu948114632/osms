
/*----------------------------------------------  
备注:获取某个投诉信息  
创建人: FRH  
创建日期:2010-01-06  

 修改人:HYD  
 修改时间：2010-06-17  
 修改版本：CRM V5.1  
 修改内容：或者单个投诉时候增加获取责任人  

 crm5.2.0 2010-07-13 OrderId,ItemCode改为从关联表获取  
-------------------------------------------------*/  
CREATE PROC dbo.CRM_Customer_ComplaintGet  
(  
 @Id  VARCHAR(13)  
)  
AS  

BEGIN  
 SELECT   
  [Id],  
  Status,  
  UserId,  
  CustomerId,  
  Tracer,  
  EmailId,  
  Subject,  
  Body,   
  (SELECT OrderId + ','   
   FROM dbo.T_ComplaintRelatedOrder  
    WHERE ComplaintId = dbo.T_Complaint.Id  
     FOR XML PATH('')) AS OrderId,  
  TicketId,    
  CreateDate,
  [Type] 
 FROM dbo.T_Complaint  
 WHERE Id = @Id;  
END
go


CREATE PROC dbo.CMS_Get_InventoryDetail 
	@inventoryTaskItemId INT = NULL  
AS   
    BEGIN  
SELECT a.[id]
      ,a.[inventory_task_item_id] AS inventoryTaskItemId
      ,a.[product_id] AS productId
      ,a.[quantity]
      ,[actual_quantity] AS actualQuantity
      ,a.[cost_price] AS costPrice
      ,a.[remark]
      ,[bar_code] AS barCode
      ,[new_unit] AS newUnit
      ,[convert_rate] AS convertRate
      ,[new_unit_weight] AS newUnitWeight
      ,[new_unit_actual_weight] AS newUnitActualWeight
      ,[new_unit_actual_quantity] AS newUnitActualQuantity 
      ,b.code AS productCode,
      b.name AS productName,
      b.original_name AS productOriginalName,
      b.primary_picture_code AS primaryPictureCode,
      b.color_card_picture_code AS colorCardPictureCode,
      CASE WHEN c.status=3 THEN NULL ELSE b.cost_price END AS checkComputationPrice,
	  ISNULL(e.available_qty,0) AS availableQty,
	  ISNULL(d.freeze_type_17,0) AS ebayFreezeQty,--网店冻结数
	  ISNULL(d.freeze_type_11,0)+ISNULL(d.freeze_type_14,0)+ISNULL(d.freeze_type_15,0) AS orderFreezeQty --订单冻结数=需求冻结+订单预约冻结+自定义出库申请冻结数
      FROM  dbo.storage_inventory_detail  a WITH(NOLOCK)
	  JOIN dbo.product b WITH(NOLOCK) ON a.product_id =b.id  AND b.is_delete=0
	  JOIN dbo.storage_inventory_task_item c WITH(NOLOCK) ON c.id =a.inventory_task_item_id
	  LEFT JOIN dbo.cms_getInventoryDetailQuantity(@inventoryTaskItemId) d ON d.product_id=a.product_id AND d.position_id=c.position_id
	  LEFT JOIN view_storage_position e ON e.product_id=a.product_id AND e.position_id=c.position_id
	WHERE inventory_task_item_id = @inventoryTaskItemId
    END


go


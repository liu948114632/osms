
 CREATE VIEW view_storage_detail
AS
   SELECT a.*,ISNULL(c.warehouse_area_id,0) AS warehouse_area_id,ISNULL(c.layer_id,0 ) AS layerId
   FROM storage_detail a  
   LEFT JOIN dbo.storage_position b ON a.position_id=b.id
   LEFT JOIN dbo.storage_position_area c ON c.position_area=LEFT(b.name,1)  AND c.department_id=b.department_id
   --LEFT JOIN storage_layer s ON s.layer =c.layer AND s.department_id = c.department_id
 go



CREATE  PROC CRM_Delivery_GetDeliveryList
(
@DeliveryType INT=1
)
AS
BEGIN
PRINT @DeliveryType;
IF(@DeliveryType=1)
BEGIN
	SELECT DeliveryId,Name FROM T_Delivery WHERE [IsDisplay] = 1 AND DeliveryType=@DeliveryType
	order by name
END
IF(@DeliveryType=2)--独立英国仓货运方式有else 和pick up goods myself
BEGIN
		SELECT DeliveryId,Name FROM T_Delivery WHERE [IsDisplay] = 1 AND (DeliveryType=@DeliveryType OR DeliveryId=17)
		order by name
END
IF(@DeliveryType=3)  ----独立美国仓货运方式
BEGIN
		SELECT DeliveryId,Name FROM T_Delivery WHERE [IsDisplay] = 1 AND DeliveryType=@DeliveryType
		order by name
END
END
go


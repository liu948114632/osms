/*-----------------------------------------
	函数:获取商品的采购价格
type:1为最近价格;2为最低价格
注意价格都要取报销过的采购单
------------------------------------------*/
CREATE FUNCTION [dbo].[uf_GetPurchasePrice]
(
	@ProductDataId	int,
	@Type			int
)
RETURNS decimal(18,6)
AS
BEGIN
	declare @price decimal(18,6)

	if @type = 1
	begin
		SELECT TOP 1 @price = a.TotalPrice from
		(
			select purchaseId,TotalPrice from dbo.C_PurchaseItem where ProductDataId = @ProductDataId 
				and [PurchasePrice] > 0 and DueQty > 0 AND [Status] = 2 -- 已完成
		)a left join dbo.C_Purchase b on a.PurchaseId = b.PurchaseId
		where b.[Status] = 8 -- 已报销的采购单
		order by b.FinishTime DESC;
	end
	else if (@type = 2)
	begin
		SELECT @price = MIN(a.TotalPrice) from
		(
			select purchaseId,[TotalPrice] from dbo.C_PurchaseItem where ProductDataId = @ProductDataId 
				and [PurchasePrice] > 0 and DueQty > 0 AND [Status] = 2 -- 已完成
		)a left join dbo.C_Purchase b on a.PurchaseId = b.PurchaseId
		where b.[Status] = 8; -- 已报销的采购单
	end
	return isnull(@price,0);
END
go


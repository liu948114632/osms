CREATE PROCEDURE [dbo].[US_PropertyValue_ExistsPropertyValue]
(
	@PropertyValueId INT
)
AS
BEGIN 
	IF EXISTS (SELECT 1 FROM dbo.T_PropertyValue_US WHERE PropertyValueId=@PropertyValueId AND IsDeleted=0)
		SELECT 1
    ELSE 
		SELECT 0 
END
go


/*------------------------------------------------------
报表统计-考核-统计当月采购工作量
frh 创建
up_Report_Assess_PurchaseQtyCount '2008-01-01','2010-01-01','GZ'
------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Assess_PurchaseQtyCount]
(
	@StartTime		DateTime,
	@EndTime		DateTime,
	@Stock			NVARCHAR(10)
)
As
Begin
	Declare @StockId INT
	
	SET @StockId  = (SELECT ISNULL(Id,0) FROM dbo.C_Stock WHERE Short = @Stock);
	If (@StockId > 0)
	Begin
		Select b.FirstName,a.PurchaseQty 
		From (
				Select b.CreatorId,COUNT(1) AS PurchaseQty
				From dbo.C_PurchaseItem a 
				JOIN dbo.C_Purchase b on a.PurchaseId = b.PurchaseId
				WHERE b.[type] <> 3 -- 计划外采购排除
					AND b.CreateTime > @StartTime AND b.CreateTime < @EndTime 
						AND b.StockId = @StockId AND b.[Status] >= 4 -- 已完成状态后的
				GROUP BY b.CreatorId 
		) a
		LEFT JOIN dbo.B_User b on a.CreatorId = b.Id
		Order By b.FirstName
	End
End


go


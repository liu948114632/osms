CREATE PROCEDURE [dbo].[US_Product_DeleteProduct]
(
    @ProductId INT
)
AS
BEGIN 
	UPDATE T_Product_US SET IsDeleted=1 ,LastUpdateDate=GETDATE() 
	WHERE ProductId=@ProductId
END
go


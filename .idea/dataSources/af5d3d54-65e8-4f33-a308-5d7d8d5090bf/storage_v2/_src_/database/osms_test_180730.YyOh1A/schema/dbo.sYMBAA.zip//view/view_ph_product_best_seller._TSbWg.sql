CREATE VIEW view_ph_product_best_seller 
AS 
SELECT TOP 500 MAX(d.id) AS product_id,
CEILING(SUM(b.order_quantity*1.0/b.unit_quantity)) AS  sale_quantity-- 销售批量
FROM dbo.[order] AS a WITH(NOLOCK) 
JOIN dbo.order_item  AS b WITH(NOLOCK) ON a.id = b.order_id
JOIN dbo.product AS c WITH(NOLOCK) ON c.id = b.product_id
JOIN dbo.ph_product AS d WITH(NOLOCK) ON b.product_id= d.product_id AND d.is_on_shelf = 1 --已上架
--AND c.is_gift = 0
WHERE a.status < 132 -- 排除取消订单
AND b.status <>12
AND a.order_time > DATEADD(MONTH,-1,CONVERT(VARCHAR(7),GETDATE(),25) + '-01') -- 录单时间
AND a.order_time < CONVERT(VARCHAR(7),GETDATE(),25) + '-01'
AND c.is_display_ph=1 
AND c.is_cleaning <> 1
GROUP BY b.product_id ORDER BY sale_quantity DESC

go


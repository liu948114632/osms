

 
 

/*----------------------------------------------------
备注:更新未决订单X商品的运费
创建人: FRH
创建日期:2009-12-30
----------------------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_PendingOrderXFreightUpdate]
(
	@OrderId   		VARCHAR(20),
	@Freight		DECIMAL(9,2) -- 运费差要平摊到每个X商品
)
AS
Declare
	@OrderItemId	Int,
	@No				Int,
	@Count			Int,
	@Weight			Int,
	@xWeight		Int,
	@addFreight		DECIMAL(9,2),-- 以有商品分配到的x运费总和
	@xFreight		DECIMAL(9,2) -- X商品运费
Begin

	-- 不记录行的变化 
	Set Nocount ON;

	Set @Weight = 0;
	Select @Weight = Ceiling(Sum(Quantity*WEIGHT*1.0/UnitQuantity))
	From dbo.T_OrderItem Where OrderId = @OrderId ;

	If @Weight > 0 And @Freight > 0
	Begin
		-- 定义表变量，用来记录要转移的订单商品
		Declare 
			@OrderItems 
		table
		(
			id			Int identity,
			OrderItemId Int,  -- 订单商品项Id
			Weight		Int  -- 订单商品的重量
		);

		-- 插入数据
		Insert Into 
			@OrderItems
		Select 
			[OrderItemID],
			Weight*Quantity*1.0/UnitQuantity
		From
			dbo.T_OrderItem
		Where
			OrderId = @OrderId;
	  
		Set @Count = @@ROWCOUNT;
		Set @No = 1;
		Set @addFreight = 0;

		-- 依次将当前订单的未到货商品转称到未决订单
		While(@No <= @Count)
		Begin
			
			SET @xWeight = 0;
			SET @OrderItemId = 0;

			-- 获取当前转移商品及X运费
			Select @OrderItemId = OrderItemId,@xWeight = Weight From @OrderItems Where Id = @No;

			-- 最后一个X商品取剩余的费用
			if (@No = @Count)
			Begin
				Set @xFreight = @Freight - @addFreight;
			End
			Else
			Begin
				Set @xFreight = Round(@Freight*@xWeight/@Weight,2);
			End

			Update 
				dbo.T_OrderItem
			Set
				XFreight = @xFreight,
				[Type] = 2 -- 2：X商品
			Where
				OrderItemId = @OrderItemId;

			Set @No = @No + 1;
			Set @addFreight = @addFreight + @xFreight;
		End

	END
	ELSE
	BEGIN
		UPDATE dbo.T_OrderItem
		SET	XFreight = 0,[Type] = 2 -- 2：X商品
		WHERE OrderId = @OrderId;
	END
End

go



CREATE FUNCTION [dbo].[uf_Report_ComleteRateByDay2]
(
	@OrderId		VARCHAR(20),
	@RequireQty		INT,
	@FirstReadyTime	DATETIME
	
)
RETURNS DECIMAL(18,4)
AS
BEGIN
	DECLARE @Qty INT;
	DECLARE @Rate DECIMAL(18,4);
	
	WITH cteAssignment AS( 
		SELECT b.OrderItemDataId,SUM(b.AssignQty) AS qty
	FROM
		dbo.C_Assignment a
	JOIN dbo.C_AssignmentItem b
	ON a.AssignmentId = b.AssignmentId
	AND a.[Status] > 1
	AND a.AssignTime < CONVERT(VARCHAR(10),@FirstReadyTime,25) 
	GROUP BY b.OrderItemDataId
	)
	
	SELECT @Qty = COUNT(*) FROM cteAssignment a
	JOIN dbo.C_OrderItem c 
	ON a.OrderItemDataId = c.OrderItemDataId
	WHERE c.Orderid = @OrderId AND c.[Status] < 12
	AND a.qty >= c.quantity;
	


	IF @Qty IS NULL OR @Qty = 0
		SET @Rate = 0;
	ELSE
		SET @Rate = @Qty*1.0/@RequireQty;

	RETURN @Rate;
END
go


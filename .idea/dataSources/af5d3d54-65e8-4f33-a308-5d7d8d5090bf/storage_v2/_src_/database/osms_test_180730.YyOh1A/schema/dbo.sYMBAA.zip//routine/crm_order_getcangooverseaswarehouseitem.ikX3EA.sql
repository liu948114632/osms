
/**          
获取订单可以走海外仓的商品          
*/          
CREATE PROC dbo.CRM_Order_GetCanGoOverseasWarehouseItem          
(          
  @OrderId VARCHAR(20),      
  @WarehouseId INT --准备走的仓库      
)          
AS          
begin          
      --是否只检查需要走海外仓的商品项
      DECLARE @IsCheckGoOverseasWarehouseProduct BIT
	  SET @IsCheckGoOverseasWarehouseProduct = 0
	  --目前UK独立仓订单只需要检查要求走海外仓的商品
	  SELECT @IsCheckGoOverseasWarehouseProduct = (CASE OrderIndustryType WHEN 5 THEN 1 ELSE 0 END ) 
	  FROM dbo.T_Order WHERE OrderId=@OrderId
      
      SELECT a.OrderItemId,          
             a.OrderId,          
             a.CmsProductId,          
             a.ProductId,          
             a.Quantity,          
             a.UnitQuantity,          
             a.Unit,          
             a.ReadyQty,         
             c.[Length],        
             c.[Width],          
             c.[Height],        
             c.[Weight],        
             a.Volume,          
             a.ItemPrice,          
             a.SalePrice,          
             a.CostPrice,          
             d.code AS ProductCode,          
             d.category_id_1 AS categoryId1,          
             d.category_id_2 AS categoryId2,          
             d.category_id_3 AS categoryId3,          
             ISNULL(d.category_id_3,ISNULL(d.category_id_2,d.category_id_1)) AS categoryId,          
             c.CK1StorageNo AS StorageNo,
			 c.IsContainBattery
      FROM dbo.T_OrderItem a WITH(NOLOCK)              
      JOIN T_OverseasWarehouseProduct c WITH(NOLOCK) ON a.CmsProductId=c.CMSProductId AND c.WarehouseId = @WarehouseId    
      JOIN dbo.product d WITH(NOLOCK) ON c.CMSProductId = d.id          
      WHERE a.OrderId=@OrderId AND a.Status < 12 AND c.IsDelete=0
	  AND (@IsCheckGoOverseasWarehouseProduct = 0 OR (@IsCheckGoOverseasWarehouseProduct=1 AND a.IsGoOverseasWarehouse=1))
      ORDER BY d.category_id_1,d.category_id_2,d.category_id_3        
END
go


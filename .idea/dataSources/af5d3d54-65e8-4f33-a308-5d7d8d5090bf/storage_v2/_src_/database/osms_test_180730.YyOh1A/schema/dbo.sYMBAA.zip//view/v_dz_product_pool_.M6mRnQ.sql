/**
	@desc 电子业务备货商品列表
	@date 2016-05-17
	@author whw
 */
 CREATE VIEW dbo.v_dz_product_pool_
 AS 
 SELECT d.id ,
        d.product_id ,
        d.sale_quantity ,
        d.prepare_quantity ,
        d.pool_type,
        d.plan_day,
        d.limit_rate,
        d.refresh_param,
        d.is_forever_exit,
        d.is_update_prepare_quantity,
        d.create_time,
        p.code AS productCode,
        p.cost_price AS costPrice,
        p.unit_quantity ,
        p.unit,
        p.primary_picture_code AS primaryPictureCode,
        t.name AS strategyDepartment,
        p.category_id_1,
        p.category_id_2,
        p.category_id_3,
        t.id AS strategyId,
		ISNULL(ps.quantity,0) AS generalizedQty,
		CEILING(CONVERT(DECIMAL(18,6),limit_rate*refresh_param*sale_quantity)) AS limit
         FROM dbo.dz_product_pool d 
        JOIN dbo.product_strategy s ON d.product_id=s.product_id
        JOIN dbo.product p ON p.id=s.product_id
        JOIN dbo.department  t ON s.department_id=t.id
        LEFT JOIN dbo.view_product_generalized_storage ps ON ps.product_id = d.product_id


go


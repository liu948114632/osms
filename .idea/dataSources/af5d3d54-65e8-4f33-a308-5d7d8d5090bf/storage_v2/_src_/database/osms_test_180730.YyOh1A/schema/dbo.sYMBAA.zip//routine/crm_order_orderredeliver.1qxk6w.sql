
/*------------------------------------------              
备注:订单重新发货      
创建人: LXH              
创建日期:2012-10-10              
------------------------------------------------------*/              
CREATE PROC dbo.CRM_Order_OrderReDeliver              
(              
  @OrderId VARCHAR(20),
  @SendWeight DECIMAL(18,2)      
)              
AS               
BEGIN           
    DECLARE @OrderStatus INT       
  
    SELECT @OrderStatus = dbo.T_Order.OrderStatus      
    FROM dbo.T_Order      
    WHERE dbo.T_Order.OrderId = @OrderId      
  
    IF( @OrderStatus != 64)      
    BEGIN      
        RAISERROR ('订单状态不是已发货状态，不允许重新发货!' , 16, 1) WITH NOWAIT;      
        RETURN;      
    END       
  
    UPDATE dbo.T_Order SET PostWeight = @SendWeight,
                           LastModifyTime = GETDATE()      
    WHERE dbo.T_Order.OrderId = @OrderId   

	
UPDATE T_OrderExtend SET DeliveryTimes=ISNULL(DeliveryTimes,0)+1 WHERE OrderId=@OrderId

END
go


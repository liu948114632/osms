
/**
*读取PW商品售价低于成本的数据  
*基准成本价*批量数量>=售价*实际汇率，则加入售价报警
*批量售价=(基准成本价×批量数量) ÷ 汇率 × 利润系数
*/
CREATE PROC [dbo].[CMS_Product_GetPWPriceBelowCostAlarm]
    (
      @ExchangeRate DECIMAL(18, 6) --实际汇率/网站汇率
    )
AS 
    BEGIN        
        SET NOCOUNT ON ;  
		SELECT 
			a.id, a.product_id AS productId,
			a.is_on_shelf isOnShelf,
			a.current_cost_price currentCostPrice,
			a.reference_cost_price referenceCostPrice,
			a.first_profit_coefficient firstProfitCoefficient
		 FROM dbo.pw_product a WITH(NOLOCK)
		INNER JOIN dbo.product b WITH(NOLOCK) ON a.product_id=b.id
		INNER JOIN dbo.product_promote_pw c WITH(NOLOCK) ON c.product_set_id=b.product_set_id
		WHERE b.is_display_pw = 1 AND c.is_promote=1
		AND a.is_on_shelf = 1 
		AND a.first_profit_coefficient * @ExchangeRate <=1
END
go


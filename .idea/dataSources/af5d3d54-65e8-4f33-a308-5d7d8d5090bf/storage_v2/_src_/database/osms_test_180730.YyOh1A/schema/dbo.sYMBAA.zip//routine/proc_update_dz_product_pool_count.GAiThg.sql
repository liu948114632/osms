
/**
	@desc 电子业务备货商品更新月均销量、备货量
	@date 2016-05-18
	@author whw	
*/ 
CREATE PROC proc_update_dz_product_pool_count(
	@EndDate DATETIME --统计的结束日期
)
AS 
BEGIN
	IF NOT EXISTS( SELECT * FROM dbo.dz_product_pool )
	BEGIN
		RETURN;
	END;
	
  --  WITH thirty_days AS (
		--SELECT * FROM dbo.dz_count_order_product_sale_info(@EndDate, 30) 
  --  ),
   WITH ninety_days AS (
		SELECT * FROM dbo.dz_count_order_product_sale_info(@EndDate, 90) 
    ),
    temp AS
   (
				SELECT    d.product_id ,
                            ISNULL(t1.saleQuantity*1.0/3, 0) * d.refresh_param AS original_product_preprae_qty ,
                            CASE d.pool_type
                              WHEN 1 THEN  --热销品
                                   0
                              WHEN 2
                              THEN   --原膜（+子膜销量）
                                   ISNULL(t2.saleQuantity*1.0/3, 0) * d.refresh_param
                                   * ( p.unit_quantity*1.0 / s.convert_rate )
                            END AS processing_product_preprae_qty ,
                            p.unit_quantity ,	
                            s.convert_rate ,
                            ISNULL(t3.saleQuantity,0) AS  avg_sale_qty,
                            CASE d.pool_type
                              WHEN 1 THEN  --热销品
                                   0
                              WHEN 2
                              THEN   --原膜（+子膜销量）
                                  ISNULL(t4.saleQuantity, 0)
                                   * ( p.unit_quantity*1.0 / s.convert_rate )
                             END AS child_avg_sale_qty 
                  FROM      dbo.dz_product_pool d WITH ( NOLOCK )
                            INNER JOIN dbo.product p WITH ( NOLOCK ) ON p.id = d.product_id
                            LEFT JOIN dbo.storage_product_processing_accessories s
                            WITH ( NOLOCK ) ON s.original_product_id = p.id
                            LEFT JOIN ninety_days
                            t1 ON t1.product_id = p.id    --销量
                            LEFT JOIN ninety_days 
                            t2 ON t2.product_id = s.processing_product_id --子膜销量
                            LEFT JOIN ninety_days
                            t3 ON t3.product_id = d.product_id --月均销量
							LEFT JOIN ninety_days
                            t4 ON t4.product_id = s.processing_product_id --子膜月均销量
                   --WHERE d.is_update_prepare_quantity=0 
                
   )
   
   
    
   
        
          
    UPDATE dbo.dz_product_pool 
    SET   sale_quantity= tmp.saleQuantity,
    prepare_quantity=CASE is_update_prepare_quantity WHEN 0 THEN tmp.prepareQuantity ELSE prepare_quantity END
    FROM dbo.dz_product_pool,
    (
		  SELECT  product_id AS productId ,
                dbo.dz_product_pool_calc_original_product_preprae_qty(MIN(original_product_preprae_qty),
                                                              SUM(processing_product_preprae_qty),
                                                              MIN(unit_quantity)) AS prepareQuantity,
                FLOOR(MIN(avg_sale_qty*1.0/3)+SUM(a.child_avg_sale_qty*1.0/3)) AS saleQuantity
        FROM   temp AS a
      GROUP BY product_id 
    
    ) AS tmp
    WHERE tmp.productId=dz_product_pool.product_id

END

go


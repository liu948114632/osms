 
CREATE FUNCTION dbo.CMS_storage_order_department
(
	@storageOrderId INT
)
RETURNS INT
AS 
BEGIN
	DECLARE @department INT
    SELECT TOP 1 @department=b.department_id FROM dbo.storage_order_item a
	INNER JOIN dbo.view_all_storage_task b
	ON a.task_id=b.id AND a.is_deleted=0
	WHERE a.storage_order_id=@storageOrderId
	RETURN @department
END

go


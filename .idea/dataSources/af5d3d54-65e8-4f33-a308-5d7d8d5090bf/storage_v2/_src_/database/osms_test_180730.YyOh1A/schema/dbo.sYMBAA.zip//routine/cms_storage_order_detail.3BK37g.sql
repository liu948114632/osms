
CREATE PROC dbo.CMS_storage_order_detail
(
	@storageOrderId INT
)
AS
BEGIN
    SELECT soi.id ,
           soi.storage_order_id AS storageOrderId,
           soi.task_id AS taskId,
           oi.customer_remark as remark,
           soi.reason ,
		   p.code AS productCode,	
		   p.primary_picture_code AS primaryPictureCode,
		   p.color_card_picture_code AS colorCardPictureCode,
		   st.product_unit AS productUnit,
		   p.name AS productName,
		   st.position AS position,
		   st.actual_quantity,
		   CASE WHEN st.status IN (4,5) THEN 0 ELSE st.wait_quantity END  AS blockingQuantity,
		   st.plan_quantity AS taskQuantity,
		   p.id AS productId,
		   soi.status,
		   oi.status AS orderItemStatus,
		   v.available_qty AS availableQty,
		   oi.id AS orderItemId
		   FROM dbo.storage_order_item soi
	LEFT JOIN dbo.view_all_storage_task st ON st.id = soi.task_id
	LEFT JOIN dbo.order_item oi WITH(NOLOCK) ON  oi.id=st.order_item_id
	LEFT JOIN dbo.product p WITH(NOLOCK) ON p.id=st.product_id
	LEFT JOIN dbo.view_product_all_storage_quantity_info v ON v.product_id =oi.product_id
	WHERE soi.storage_order_id=@storageOrderId AND soi.is_deleted=0
	ORDER BY soi.id ASC
END
go




CREATE PROCEDURE CMS_CheckProduct_BlacklistProduct
    (
      @ProductCode VARCHAR(22) = NULL , --产品编号    
      @ProductCodes VARCHAR(MAX) = NULL , --产品编号列表   
      @SDepartmentId INT = NULL , --策略部门ID  
      @ProviderCode VARCHAR(MAX) = NULL , --供应商   
      @CategoryId1 INT = NULL ,--一级类别ID    
      @CategoryId2 INT = NULL ,--二级类别ID    
      @CategoryId3 INT = NULL ,--三级类别ID         
      @PageSize INT = 50 ,  --页大小                            
      @PageIndex INT = 1    --当前页号  
    )
AS 
    BEGIN  
        DECLARE @SQL NVARCHAR(MAX) ,
            @FromSQL NVARCHAR(MAX) , 
            @Column NVARCHAR(MAX) ,
            @Condition NVARCHAR(MAX) ,
            @CountSQL NVARCHAR(MAX) , 
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ;           
     
		--组装查询条件          
        SET @Condition = ' WHERE 1=1 ' ;    
        IF @ProductCode IS NOT NULL 
            BEGIN  
                SET @Condition = @Condition + ' and product.code like '''
                    + @ProductCode + '%''' ;  
            END  
        IF @ProductCodes IS NOT NULL 
            BEGIN  
                SET @Condition = @Condition + ' and product.code in ('''
                    + REPLACE(@ProductCodes, ',', ''',''') + ''')' ;        
            END 
        IF @CategoryId1 IS NOT NULL 
            BEGIN        
                SET @Condition = @Condition + ' AND product.category_id_1='
                    + CONVERT(VARCHAR(10), @CategoryId1)      
            END       
        IF @CategoryId2 IS NOT NULL 
            BEGIN        
                SET @Condition = @Condition + ' AND product.category_id_2='
                    + CONVERT(VARCHAR(10), @CategoryId2)      
            END       
        IF @CategoryId3 IS NOT NULL 
            BEGIN         
                SET @Condition = @Condition + ' AND product.category_id_3='
                    + CONVERT(VARCHAR(10), @CategoryId3)      
            END 
        IF @SDepartmentId IS NOT NULL 
            BEGIN  
                SET @Condition = @Condition + ' and ps.department_id='
                    + CONVERT(VARCHAR(10), @SDepartmentId) ;  
            END  
        IF @ProviderCode IS NOT NULL 
            BEGIN  
                SET @Condition = @Condition + ' and pr.code=''' + @ProviderCode + '''' ;  
            END       
                
        SET @FromSQL = ' FROM dbo.blacklist_product AS a WITH(NOLOCK) 
						 INNER JOIN product AS product WITH(NOLOCK) ON a.product_id =product.id 
						 INNER JOIN product_strategy as ps WITH(NOLOCK) on ps.product_id = product.id
						 INNER JOIN product_provider as x WITH(NOLOCK)  on x.product_id = product.id and x.department_id = ps.department_id
						 INNER JOIN provider AS pr WITH(NOLOCK) ON pr.id=x.provider_id ' ;
        
  --获取符合条件的总记录数          
        SET @CountSQL = ' SELECT @RowCount = count(a.id) ' + @FromSQL
            + @Condition                    
        EXEC sp_executesql @CountSQL, N'@RowCount INT OUT', @RowCount OUT           
  
  --设置分页参数(一定要放在取记录数的后面)          
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                          
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                          
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                          
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                       
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                          
        SET @end = @PageIndex * @PageSize     
     
        SET @Column = 'a.id,
     a.create_user_id as createUserId,  
     a.create_time as createTime,
     a.qc_remark as qcRemark,
     product.id   productId, 
     product.primary_picture_code primaryPictureCode,  
     product.color_card_picture_code colorCardPictureCode,       
     product.code productCode,  
     product.name productName,  
     CONVERT(VARCHAR(10), product.unit_quantity) + '' '' + product.unit unitQuantity,  
     pr.id providerId,  
     pr.code providerCode,  
     ps.department_id as strategyDepartmentId
     ' ;         
  
    
  --组装查询语句              
        SET @SQL = 'SELECT ' + @Column + ', ROW_NUMBER() OVER (ORDER BY a.id desc) RowIndex '
            + @FromSQL + @Condition ;              
    
        SET @SQL = 'SELECT  * FROM (' + @SQL + ') temp  WHERE RowIndex between '
            + CONVERT(VARCHAR(10), @Start) + ' AND '
            + CONVERT(VARCHAR(10), @End) + ' order by RowIndex' ;    
                    
		--SELECT @SQL  
        EXEC(@SQL) ;                                      
        SELECT  @RowCount    
        SET NOCOUNT OFF ;  
    END


go


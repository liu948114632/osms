/**  
获得订单项商品最新售价信息(促销信息采用新增时的促销信息）
*/  
CREATE PROC dbo.CRM_Product_GetPhProductSalePriceByOrderItem
(    
  @OrderItemId INT   --订单项ID  
)    
AS     
BEGIN    
  --获取商品的新增到订单时的售价信息  
  SELECT             
  b.CmsProductId,            
  a.id AS WebProductId,            
  CAST(ISNULL(c.is_promote,0) AS BIT) AS IsPromote,     
  (100 - ISNULL(c.Discount,0)) AS Discount, --注意：product_promote表中的Discount是降的折扣      
  ISNULL(c.[type],0) AS PromoteType,  --促销类型     
  CAST(ISNULL(c.is_bind_storage,0) AS BIT) AS IsBindStorage,  --是否绑定库存促销      
  b.LastCostPrice AS CostPrice,            
  b.UnitQuantity,            
  8.2 AS ExchangeRate,            
  a.first_profit_coefficient AS Profit1,        
  a.first_quantity_from AS QuantityFrom1,        
  a.first_quantity_to AS QuantityTo1,        
  a.second_profit_coefficient AS Profit2,        
  a.second_quantity_from AS QuantityFrom2,        
  a.second_quantity_to AS QuantityTo2,        
  a.third_profit_coefficient AS Profit3,        
  a.third_quantity_from AS QuantityFrom3,        
  a.third_quantity_to AS QuantityTo3,   
  --商品如有促销，各段价格都按第一段利润算   
   ISNULL(CAST((LastCostPrice *   b.UnitQuantity) / 8.2 * first_profit_coefficient AS Decimal(18,2)),0) AS OriginalSalePrice,            
  ISNULL(CAST((LastCostPrice *   b.UnitQuantity) / 8.2 * (CASE WHEN Discount > 0 THEN first_profit_coefficient ELSE second_profit_coefficient END ) AS Decimal(18,2)),0) AS OriginalSalePrice2,           
  ISNULL(CAST((LastCostPrice *   b.UnitQuantity) / 8.2 * (CASE WHEN Discount > 0 THEN first_profit_coefficient ELSE third_profit_coefficient END ) AS Decimal(18,2)),0) AS OriginalSalePrice3,     
  CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice *   b.UnitQuantity) / 8.2 * first_profit_coefficient AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice,  
  CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice *   b.UnitQuantity) / 8.2 *   
  (CASE WHEN Discount > 0 THEN first_profit_coefficient ELSE  second_profit_coefficient END ) AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice2,       
  CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice *   b.UnitQuantity) / 8.2 *   
  (CASE WHEN Discount > 0 THEN first_profit_coefficient ELSE  third_profit_coefficient END ) AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice3,  
  promote_activity_id,
  c.id AS PromoteId                 
  FROM dbo.T_OrderItem d WITH(NOLOCK) 
  JOIN dbo.ph_product a WITH(NOLOCK) ON d.CmsProductId=a.product_id         
  JOIN dbo.V_CRM_Base_Product b WITH(NOLOCK) ON a.product_id = b.CmsProductId            
  LEFT JOIN dbo.product_promote c  ON (d.PromoteId>0 AND d.PromoteId=c.id) AND c.is_promote = 1    
                AND DATEADD(hh,-15,GETDATE())>=c.start_time AND DATEADD(hh,-15,GETDATE())<=c.end_time --转成美国时间再比较  
  WHERE d.OrderItemId=@OrderItemId 
END


go


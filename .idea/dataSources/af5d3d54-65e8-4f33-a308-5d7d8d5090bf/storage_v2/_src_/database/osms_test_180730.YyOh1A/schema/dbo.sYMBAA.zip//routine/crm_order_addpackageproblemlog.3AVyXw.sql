CREATE PROC CRM_Order_AddPackageProblemLog
(
@OrderId VARCHAR(15),
@Remark VARCHAR(200),
@OperatorName VARCHAR(50)
)
AS 
BEGIN

DECLARE @PackageProblemId INT;

SELECT TOP 1 @PackageProblemId=id FROM dbo.T_PackageProblem WHERE OrderId=@OrderId
IF(@PackageProblemId>0)
	INSERT INTO dbo.T_PackageProblemLog( PackageProblemId,Remark ,OperatorName , CreateDate )VALUES  (@PackageProblemId,@Remark,@OperatorName ,GETDATE())
END
go


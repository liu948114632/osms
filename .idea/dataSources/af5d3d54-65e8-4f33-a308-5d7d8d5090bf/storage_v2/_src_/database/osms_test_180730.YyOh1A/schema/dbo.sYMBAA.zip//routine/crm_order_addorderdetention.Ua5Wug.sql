


---添加订单扣件
CREATE PROC dbo.CRM_Order_AddOrderDetention
(
@OrderId VARCHAR(15)='',
@OrderCodes VARCHAR(200),
@CreaterUser VARCHAR(20)='' ,
@Reason NVARCHAR(500),
@CreateTime VARCHAR(25),
@DMSDetainOrderId  INT ,
@IsDetention BIT
)
AS
BEGIN

IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.T_OrderDetention WHERE OrderId=@OrderId)
BEGIN
	INSERT INTO dbo.T_OrderDetention
	        ( IsDetention ,
	          OrderId ,
	          OrderCodes ,
	          Reason ,
	          CreatorUserName ,
	          CreateTime ,
	          DMSDetainOrderId
	        )
	VALUES  (@IsDetention , -- IsDetention - bit
	          @OrderId, -- OrderId - varchar(15)
	          @OrderCodes , -- OrderCodes - varchar(200)
	          @Reason, -- Reason - nvarchar(500)
	          @CreaterUser, -- CreatorUserName - varchar(20)
	          @CreateTime , -- CreateTime - datetime
	          @DMSDetainOrderId  -- DMSDetainOrderId - int
	        )			
END
ELSE
	BEGIN
	UPDATE dbo.T_OrderDetention
	SET IsDetention=@IsDetention,
			Reason=CASE WHEN @IsDetention=1 THEN @Reason ELSE Reason END,
	        CreatorUserName=@CreaterUser,
			LastUpdateTime=@CreateTime
	WHERE OrderId=@OrderId
	END

	IF @IsDetention=1
	BEGIN
					EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int
			    @OrderId =@OrderId, -- varchar(20)
			    @Remark = '订单已扣件' -- varchar(5000)
	END
	ELSE
	BEGIN
			EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int
			    @OrderId =@OrderId, -- varchar(20)
			    @Remark = '订单取消扣件，变为可正常发货订单' -- varchar(5000)
	END

END
go


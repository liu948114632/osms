---获取客服在线咨询列表
CREATE PROC CRM_Customer_GetOnlineServicerConsultList
(
@StartDate VARCHAR(30)='',        
@EndDate VARCHAR(30)='',     
@HandlerId INT=-1,
@Status INT=-1,
@DealUserName VARCHAR(50)='',  
@IsSolve INT=-1,
@IsPriority INT=-1,
@EmailId INT =-1,
@PageSize INT=50,        
@PageIndex INT=1  
)
AS        
BEGIN        
 SET NOCOUNT ON;        
 DECLARE @sql NVARCHAR(max)        
 DECLARE @countSql NVARCHAR(max)        
 DECLARE @rowCount int,@pageCount int, @startPageIndex int, @endPageIndex int        
         
 SET  @sql = N'SELECT T_OnlineServiceConsult.*,
 CASE WHEN IsSolve=1 THEN ''是'' ELSE ''否'' END AS ''Is_Solve'',
 CASE WHEN IsPriority=1 THEN ''是'' ELSE ''否'' END AS ''Is_Priority'',
 CASE WHEN CustomerSource=0 THEN ''MESSAGE'' ELSE ''电话'' END AS ''Customer_Source'' , 
u.name as DealUserName,
 ROW_NUMBER() OVER(ORDER BY Status asc,DealTime desc ) AS RowNo 
 FROM  dbo.T_OnlineServiceConsult WITH(NOLOCK)   
 LEFT  JOIN dbo.[user] u
 ON T_OnlineServiceConsult.DealUserId=u.id
 WHERE 1 = 1 '        
         
   IF(@StartDate<>'')        
 BEGIN         
    SET @sql = @sql + ' AND DealTime>='''+ @StartDate+''''        
 END         
         
 IF(@EndDate<>'')        
 BEGIN         
    SET @sql = @sql + ' AND DealTime<='''+ @EndDate+''''        
 END         
  
 IF(@HandlerId>-1)        
 BEGIN        
     SET @sql = @sql + ' AND HandlerId='+ ltrim(str(@HandlerId))        
 END        
  
  IF(@Status>-1)  
     BEGIN         
    SET @sql = @sql + ' AND Status='+ltrim(str(@Status))        
    END   
    
   IF(@DealUserName<>'')        
 BEGIN        
  SET @sql = @sql + ' AND DealUserId in (SELECT id FROM dbo.[user] WHERE name like ''%'+@DealUserName+'%'')'        
 END       
         
  IF(@IsSolve>-1)  
     BEGIN         
    SET @sql = @sql + ' AND IsSolve='+ltrim(str(@IsSolve))        
    END   
    
      IF(@IsPriority>-1)  
     BEGIN         
    SET @sql = @sql + ' AND IsPriority='+ltrim(str(@IsPriority))        
    END   
    IF(@EmailId>-1)
   BEGIN
   	SET @sql=@sql+' And EmailId='+ltrim(str(@EmailId))        
   END 
     
 --得到记录条数          
    SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql + ') AS Items'          
    EXEC sp_executesql  @countSql, N'@rowCount INT OUT', @rowCount OUT           
         
 IF(@PageIndex<1) SET @PageIndex=1        
    SET @pageCount = (@RowCount + @PageSize - 1) / @PageSize          
    IF ISNULL(@PageIndex, 0) < 1 SET @PageIndex = 1          
    ELSE IF @PageIndex > @pageCount  SET @PageIndex = @pageCount          
    SET @startPageIndex = (@PageIndex - 1) * @PageSize + 1          
    SET @endPageIndex = @PageIndex * @PageSize         
              
 SET @sql = 'SELECT * FROM ('+@sql+') AS Items WHERE RowNo BETWEEN ' + ltrim(STR(@startPageIndex)) + ' AND ' + ltrim(STR(@endPageIndex))+' ORDER BY Status asc,DealTime desc'        
         
    PRINT @sql        
    EXEC(@sql)         
         
    SELECT @rowCount   AS 'RowCount',@pageCount AS 'PageCount'  
END

go


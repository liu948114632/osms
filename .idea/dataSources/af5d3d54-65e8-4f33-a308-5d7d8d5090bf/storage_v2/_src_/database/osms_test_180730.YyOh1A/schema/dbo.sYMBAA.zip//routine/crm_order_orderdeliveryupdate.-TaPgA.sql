



/*-----------------------------------------------------------      
备注:修改订单的货运方式,并更新是否偏远地址标志      
创建人: FRH      
创建日期:2010-01-08      
       
-------------------------------------------------------------*/      
CREATE PROC [dbo].[CRM_Order_OrderDeliveryUpdate]       
(      
 @OrderId  NVARCHAR(20),      
 @DeliveryId  Int,      
 @IsRemote  BIT,        
 @Port   NVARCHAR(100) ,    
 @City  NVARCHAR(100),
 @IsFreeShipping  BIT,  
 @FreeShipSurcharge DECIMAL(18,2),--免运费的附加费
 @FreeShipDeliveryRange  VARCHAR(500)--免运费的货运方式范围  
)      
AS      
BEGIN      
      
 -- 要将修改后的货运方式的是否偏远地区标志通讯到PH      
 -- 改货运方式      
 UPDATE dbo.T_Order       
 SET       
  DeliveryId  = @DeliveryId,      
  IsRemote  = @IsRemote ,     
  IsFreeShipping = @IsFreeShipping,
  FreeShipDeliveryRange =@FreeShipDeliveryRange ,--这个值在免运费时设置
  FreeShipSurcharge = (CASE WHEN @IsFreeShipping = 1 THEN @FreeShipSurcharge ELSE FreeShipSurcharge END) ,--这个值在免运费时设置
  --免运费的折扣设为1，非免运费的时候原先有折扣就继续有折扣，否则为0
  FreightDiscount = (CASE WHEN @IsFreeShipping = 1 THEN 1 ELSE (CASE WHEN FreightDiscount>0 AND FreightDiscount <1 THEN FreightDiscount ELSE 0 END) END),
  DeliveryPromoteActivityId  = (CASE WHEN @IsFreeShipping = 1 THEN NULL ELSE DeliveryPromoteActivityId END) --如果设为了免运费，只能清掉原先的活动ID
 WHERE OrderId  = @OrderId;      
       
 -- 不是修改为Port to Port的清除订单地址中的Port      
 IF(@DeliveryId <> 22)      
 BEGIN      
  UPDATE dbo.T_OrderAddresses SET Port = ''  ,City = @City     
   WHERE AddressId IN       
    (SELECT ShipAddressId FROM dbo.T_Order WHERE OrderId = @OrderId);      
 END      
 ELSE      
 BEGIN      
  UPDATE dbo.T_OrderAddresses SET [Port] = @Port ,City = @City     
   WHERE AddressId IN       
    (SELECT ShipAddressId FROM dbo.T_Order WHERE OrderId = @OrderId);      
 END      
       
-- -- 非Pending状态的订单要同步到备货系统      
-- IF EXISTS(SELECT * FROM dbo.T_Order WHERE OrderId = @OrderId AND OrderStatus > 0)      
-- BEGIN      
--  -- 更改货运订单的货运方式      
--  EXEC SYS_CRM_CMS_OrderDeliveryUpdate @OrderId,@DeliveryId;      
-- END       
       
END
go


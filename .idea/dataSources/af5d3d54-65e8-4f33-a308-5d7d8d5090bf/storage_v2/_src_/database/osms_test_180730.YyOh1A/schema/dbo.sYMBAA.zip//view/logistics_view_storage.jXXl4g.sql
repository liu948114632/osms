CREATE  VIEW  logistics_view_storage AS (
SELECT b.*,c.remark,c.quality_remark 
FROM(
SELECT  a.[id]
      ,[department_id]
      ,[product_id]
      ,a.[quantity],
       d.position_id AS [position_id]
      ,a.[lock_quantity]
      ,[update_time]
     FROM logistics_storage a WITH(NOLOCK) 
     join logistics_storage_detail d WITH(NOLOCK) on  d.storage_id = a.id
     JOIN department c WITH(NOLOCK) ON a.department_id= c.id
) b 
LEFT JOIN storage_position_remark c WITH(NOLOCK) ON b.department_id =c.department_id AND b.product_id = c.product_id AND b.position_id = c.position_id AND c.position_id>0
)

go


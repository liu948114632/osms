
/*---------------------------------------------
[函数:
	每天下单数量,包括网站订单和邮件订单
------------------------------------------------*/
CREATE FUNCTION [dbo].[uf_promo_count_GetDayOrders]
(
	@Date		VARCHAR(8) -- 20071004
)
RETURNS Int
AS
BEGIN
	DECLARE @c INT;

	-- 获取网站订单(下单时间)
	SELECT @c = COUNT(1) FROM dbo.T_Order 
	WHERE OrderStatus > 0 AND OrderStatus < 132 -- 准备货物后非取消的都算处理的订单
		AND OrderType IN(1,2) -- 网站订单和邮件订单且不包含P单 
			AND CONVERT(VARCHAR(8),OrderDate,112) = @Date;
	
	IF @c IS NULL SET @c = 0;
	
	RETURN @c;
END

go


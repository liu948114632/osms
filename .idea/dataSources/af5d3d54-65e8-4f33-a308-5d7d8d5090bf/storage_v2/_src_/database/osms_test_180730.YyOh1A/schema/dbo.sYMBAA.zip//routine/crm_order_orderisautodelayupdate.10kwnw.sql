
-- =============================================          
-- Author:  HYD          
-- Create date: 2010-04-21          
-- Description: 更新订单是否自动跟踪          
------------------------------------------------          
-- 修改人: 刘杨          
-- 修改时间: 2010-10-13          
-- 描述: 取消自动发货标识时，清空预计发货时间          
-- =============================================          
CREATE PROC dbo.CRM_Order_OrderIsAutoDelayUpdate          
    (          
      @OrderId VARCHAR(20) ,          
      @IsAutoDelay BIT          
    )          
AS           
BEGIN          
    SET NOCOUNT ON ;          
        
    UPDATE  dbo.T_Order         
    SET     IsAutoDelay = @IsAutoDelay          
    WHERE   OrderId = @OrderId          
        
    --下面记录取消时间，报表系统要用    
    IF @IsAutoDelay = 0           
    BEGIN                    
        IF EXISTS(SELECT 1 FROM dbo.T_CancelRegularShipment WHERE OrderId = @OrderId)        
            UPDATE dbo.T_CancelRegularShipment SET CancelTime = GETDATE() WHERE OrderId = @OrderId         
        ELSE         
           INSERT INTO dbo.T_CancelRegularShipment(OrderId, CancelTime) VALUES(@OrderId, GETDATE())                
    END
	ELSE
	BEGIN
		UPDATE dbo.T_OrderExtend SET CustomerFollowUp=0 WHERE OrderId=@OrderId
	END          
END

go


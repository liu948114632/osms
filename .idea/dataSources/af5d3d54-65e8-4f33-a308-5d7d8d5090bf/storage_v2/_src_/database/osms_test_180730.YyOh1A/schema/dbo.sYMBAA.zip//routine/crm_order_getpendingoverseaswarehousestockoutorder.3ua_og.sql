

/* 获取待出口易处理的出库单  */    
CREATE PROC CRM_Order_GetPendingOverseasWarehouseStockOutOrder    
AS    
begin    
      SELECT o.OrderId,    
             StockOutCode,    
             Warehouse,    
             CASE WHEN LOWER(ExpressService)='none'
                THEN 
             (SELECT TOP 1 d.LogisticsCarriersCode FROM dbo.T_Order o LEFT JOIN dbo.T_Delivery d ON d.DeliveryId=o.DeliveryId WHERE o.OrderId=T_OverseasWarehouseStockOutOrder.OrderId)          
             else             
             ExpressService
             END AS ExpressService,    
             CreateTime,    
             Status    
      FROM dbo.T_OverseasWarehouseStockOutOrder  INNER JOIN dbo.T_Order o
      ON o.OrderId = T_OverseasWarehouseStockOutOrder.OrderId
      WHERE o.OrderStatus<>132 AND  Status >=10 AND Status <= 30 --只查询提审中和审核通过的出库单,排除取消的单
      --AND Warehouse = 'UK'   --目前只取英国仓库  
END

go


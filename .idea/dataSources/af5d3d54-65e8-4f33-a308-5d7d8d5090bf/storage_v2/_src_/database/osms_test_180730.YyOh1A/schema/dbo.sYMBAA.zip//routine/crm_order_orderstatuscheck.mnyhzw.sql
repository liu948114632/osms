
/*--------------------------------------------------              
备注:检查订单状态              
创建人: FRH              
创建日期:2009-12-30              
----------------------------------------------------*/              
CREATE PROC dbo.CRM_Order_OrderStatusCheck               
(              
 @OrderId  VARCHAR(20),              
 @UpdatedStatus INT OUT -- 更改后的订单状态              
)              
AS              
DECLARE              
 @Status   INT,              
 @HistoryInfo    VARCHAR(max),  
 @ProcessingStatusNum INT,
 @IsSend BIT ,             
@OrderIndustryType INT
BEGIN              

 SET @UpdatedStatus = -1; -- 获取修改后的订单状态              
 SET @Status = 0;   -- 订单原始状态 
 SET @IsSend = 0;   -- 是否发货             
 SELECT @Status = [OrderStatus],@OrderIndustryType=OrderIndustryType,@IsSend = [IsSend] FROM dbo.T_Order WHERE OrderId = @OrderId;              

 -- 检查订单商品项是否全部取消               
 IF EXISTS(SELECT * FROM dbo.T_OrderItem WHERE OrderId = @OrderId And [Status] < 12)              
 BEGIN              
  PRINT('');              
 END              
 ELSE               
 BEGIN              
  -- 订单设置为取消状态               
  UPDATE dbo.T_Order SET OrderStatus = 132,LastModifyTime = GETDATE(),SendGroupID=null --取消时移除同票关系          
  WHERE OrderId = @OrderId;              
 END              

 -- 检查订单商品项是否全部备货              
 IF EXISTS(SELECT * FROM dbo.T_OrderItem WHERE OrderId = @OrderId AND [Status] < 6)              
 BEGIN   --如果没有全部备货，则改为准备货物      
    Update dbo.T_Order               
    Set OrderStatus = 1,LastModifyTime = GETDATE()               
    Where OrderId = @OrderId  And OrderStatus > 1;               
 END              
 ELSE IF @Status = 1 --如果全部备完货，但订单状态还是准备货物，则根据以下情况改变订单状态
      AND EXISTS(SELECT * FROM dbo.T_OrderItem WHERE OrderId = @OrderId AND [Status] = 6)              
 BEGIN              
   --  DECLARE @IsQC BIT, --是否需要质检
   --          @IsProcessing BIT,--是否需要加工
			-- @IsNoRelecture BIT=0 --是否没有待校对状态，直接改成已备货
     
   --  --检查是否需要质检
   --  select @IsQC = (CASE WHEN EXISTS( SELECT TOP 1 1 FROM check_order a WITH(NOLOCK)
   --             JOIN dbo.[order] b  WITH(NOLOCK) ON a.order_id=b.id 
   --             WHERE b.code = @OrderId AND a.status < 20 ) 
   --             THEN CONVERT(BIT,1) ELSE CONVERT(BIT,0) END )
   --  --检查是否需要加工         
   --  select @IsProcessing = (CASE WHEN EXISTS( SELECT TOP 1 1 FROM dbo.T_OrderItem WITH(NOLOCK)
   --                          WHERE OrderId = @OrderId AND ProcessingStatus = 20 And [Status] < 12 ) 
   --                          THEN CONVERT(BIT,1) ELSE CONVERT(BIT,0) END )
			----订单来源为CN、WH-FBA，没重发或打回的订单，c3备货完后走清点校对流程，走清点校对流程的，订单状态就没有待校对，满足待校对条件的，直接是已备货
			--IF EXISTS(SELECT TOP 1 1 FROM dbo.T_Order WHERE OrderId=@OrderId AND (OrderIndustryType=3 OR OrderIndustryType=51)) AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.T_OrderResendRecord WHERE OrderId=@OrderId)
			--BEGIN
			--	SET @IsNoRelecture=1
			--END

      --如果订单不需要质检，不需要加工，且允许发货，且不是英国独立仓的订单，则改为待校对，否则只能是已备货，英国独立仓订单编程已备货
    --  IF @IsQC = 0 AND @IsProcessing=0 AND @IsSend = 1  AND @OrderIndustryType<>5 AND @OrderIndustryType<>6  AND  @IsNoRelecture=0
    --  BEGIN
    --      Update dbo.T_Order               
		  --Set OrderStatus = 40,LastModifyTime = GETDATE()               
		  --Where OrderId = @OrderId;  
    --  END
    --  ELSE
    --  BEGIN
          UPDATE dbo.T_Order               
		  SET OrderStatus = 31,LastModifyTime = GETDATE()               
		  WHERE OrderId = @OrderId;  
      --END           
 END 
 ELSE IF( EXISTS(SELECT TOP 1 1 FROM dbo.T_OrderItem WHERE OrderId = @OrderId AND [Status] = 8) 
        AND NOT EXISTS (SELECT TOP 1 1 FROM dbo.T_OrderItem WHERE OrderId = @OrderId AND [Status] NOT IN (8,12)) )--如果订单已全部发货
 BEGIN
      UPDATE dbo.T_Order               
	  SET OrderStatus = 64,LastModifyTime = GETDATE()               
	  WHERE OrderId = @OrderId;  
 END    

 -- 返回修改后的订单状态              
 SELECT @UpdatedStatus = OrderStatus               
  FROM dbo.T_Order               
   WHERE OrderId = @OrderId               
    AND (OrderStatus > @Status OR OrderStatus < @Status) -- 订单变化才返回状态值;              

 --增加订单变更历史              
 IF( @UpdatedStatus > 0 AND @UpdatedStatus != @Status AND @UpdatedStatus<=31)              
 BEGIN                        
  INSERT INTO dbo.order_history              
    ( order_code ,              
      operator_id ,              
      operator_time ,              
      process              
    )              
  VALUES  ( @OrderId , -- order_code - varchar(50)              
      0 , -- operator_id - int              
      GETDATE() , -- operator_time - smalldatetime              
      '订单状态变为：' +               
      (CASE @UpdatedStatus WHEN 1 THEN '准备货物'              
                           WHEN 31 THEN '已备货'              
                           WHEN 40 THEN '待校对'              
                           WHEN 45 THEN '校对中'              
                           WHEN 50 THEN '打包中'          
                           WHEN 55 THEN '已打包'           
                           WHEN 60 THEN '已出库'               
                           WHEN 64 THEN '已发货'              
                           WHEN 128 THEN '已完成'              
                           WHEN 132 THEN '取消'              
                           ELSE ''              
        END )              
    )              
 END                
END


go


--当设置了的客户在设置了的行业下，某订单达到要监控的订单状态（注意，有些情况下可能会跳状态，正常跳过也算啊），就发邮件给指定的接收邮箱。
CREATE PROC CRM_Order_CustomerOrderControl
AS
BEGIN
			SELECT a.CustomerId,a.OrderId,b.BusinessType,b.Emails,a.OrderStatus,a.OrderDate,c.EmailId,c.FullName FROM dbo.T_Order a WITH(NOLOCK)
		INNER JOIN dbo.T_CustomerOrderControl b WITH(NOLOCK) ON a.CustomerId=b.CustomerId AND a.OrderIndustryType=b.BusinessType
		INNER JOIN dbo.T_Customer c WITH(NOLOCK) ON c.UserID=b.CustomerId
		WHERE a.OrderStatus>=b.OrderStatus AND (a.OrderStatus<132 OR b.OrderStatus=132)
		AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.T_CustomerOrderSendEmail e WITH(NOLOCK) WHERE e.OrderId=a.OrderId AND a.CustomerId=e.CustomerId)
		AND a.OrderDate>=b.CheckDate
		ORDER BY a.OrderDate ASC        
END

go


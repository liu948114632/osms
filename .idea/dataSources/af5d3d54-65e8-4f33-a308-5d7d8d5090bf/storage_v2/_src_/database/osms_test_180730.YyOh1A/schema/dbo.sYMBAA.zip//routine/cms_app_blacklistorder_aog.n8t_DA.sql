/*
*2014-07-04
*APP,黑名单产品订单列表---到货订单列表
*/
CREATE PROCEDURE [dbo].[CMS_APP_BlackListOrder_AOG]
    @id INT = NULL ,
    @PageSize INT = 50 ,  --页大小                        
    @PageIndex INT = 1    --当前页号   
AS 
    BEGIN
	
        SET NOCOUNT ON;

        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用  
            @FromSQL NVARCHAR(MAX) , --查询表                                         
            @Column NVARCHAR(MAX) , --查询字段                       
            @Condition VARCHAR(MAX) , --条件                         
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT 
            
        SET @FromSQL = ' FROM  dbo.blacklist_product a
					JOIN dbo.order_item b WITH (NOLOCK) ON a.product_id = b.product_id
					JOIN dbo.[order] c WITH (NOLOCK) ON c.id = b.order_id
					JOIN order_item_group d WITH (NOLOCK) ON d.order_id = c.id AND d.id=b.order_item_group_id 
					JOIN dbo.department dt WITH (NOLOCK) ON c.department_id=dt.id '
        SET @Condition = ' WHERE  c.status < 60 AND b.status = 6 '              
        IF @id IS NOT NULL 
            BEGIN
                SET @Condition = @Condition + ' AND a.product_id=' + CONVERT(VARCHAR(20), @id) 
           
            END 
    --设置需要取的字段信息                        
        SET @Column = ' c.code as code,
		c.id as id,
        c.status as status,
        c.department_id  as departmentId,
        d.position as position,
        dt.name as departmentName,
        b.prepared_quantity as preparedQty,
        b.order_quantity as orderQty'
						
				
		   			
        --求符合条件的总数                      
        SET @CountSql = ' SELECT @RowCount = count(c.id) ' + @FromSQL + @Condition                 
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
                            
		
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                              
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                              
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                              
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                              
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                              
        SET @end = @PageIndex * @PageSize   
    
        SET @SQL = 'SELECT * from                      
       (                      
       SELECT *,ROW_NUMBER() OVER(ORDER BY temp.id ASC) rowIndex                      
       from (SELECT ' +@Column + @FromSQL + @Condition
            + ') temp                      
       ) temp2                           
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))    
            
        EXEC(@SQL);             
        SELECT  @RowCount                
    END
go


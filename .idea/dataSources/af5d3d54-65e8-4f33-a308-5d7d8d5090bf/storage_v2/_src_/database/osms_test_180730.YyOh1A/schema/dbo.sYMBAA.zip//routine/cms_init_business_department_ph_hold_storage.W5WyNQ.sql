

CREATE PROC cms_init_business_department_ph_hold_storage 
AS
BEGIN
	 
	 DELETE FROM  business_department_ph_hold_storage

	 ;WITH holdProduct AS (
	 SELECT product_id FROM  dbo.product_pool
	 UNION
     SELECT product_id FROM   dbo.product_inventory WHERE status = 1
	 ),saleInfo AS
	 (  
	 SELECT product_id, CEILING(ISNULL(sale_quantity,0)/3.0) AS sale_quantity FROM  (
	 SELECT  -- 订单号 
       b.product_id,          
        SUM(CASE WHEN b.order_quantity > 10 * c.unit_quantity THEN 10 * c.unit_quantity ELSE b.order_quantity END) AS sale_quantity--有限的量        
		 FROM dbo.[order] AS a WITH(NOLOCK)              
		 JOIN dbo.order_item  AS b WITH(NOLOCK) ON a.id = b.order_id         
		 JOIN product c WITH(NOLOCK) ON c.id =b.product_id          
		 JOIN holdProduct z ON z.product_id =b.product_id        
		 WHERE (a.type IN (1,3))  -- 3.9.11 加入 WH-AM、WH-EBAY        
           AND ( b.is_promote=0 OR a.type=3 ) AND  b.status<>12 and  DATEDIFF(dd,b.order_time,GETDATE())<=90   GROUP BY b.product_id) z
		   )

	 --DECLARE @rate DECIMAL(18,2) = 0;
	 --SELECT @rate=CONVERT(DECIMAL(18,2),g.value) FROM dbo.common_sys_config g WHERE [_key]='PH_POOL_STORAGE_RATE'
	 INSERT INTO business_department_ph_hold_storage(qty,product_id)
	 SELECT ISNULL(phHoldStorageQuantity,0),product_id FROM  (
	 SELECT CASE WHEN  CEILING(k.sale_quantity* CONVERT(DECIMAL(18,2),g.value)/c.unit_quantity)*c.unit_quantity > =quantity-lock_quantity 
	 THEN FLOOR((quantity-lock_quantity)/c.unit_quantity) *c.unit_quantity
	 ELSE CEILING(k.sale_quantity* CONVERT(DECIMAL(18,2),g.value)/c.unit_quantity)*c.unit_quantity end  AS phHoldStorageQuantity,a.product_id   FROM  dbo.business_department_storage a
	 JOIN holdProduct b ON a.product_id =b.product_id
	 JOIN dbo.product c ON c.id =b.product_id AND c.is_display_ph = 1 
	 JOIN saleInfo k ON k.product_id =b.product_id
	 LEFT JOIN forbidden_product_hold_storage f ON f.product_id =b.product_id AND f.is_delete = 0
	 JOIN dbo.common_sys_config g ON [_key]='PH_POOL_STORAGE_RATE'
	  WHERE business_department_id=4 AND type=4  AND f.id IS NULL 
	  )z
END
go


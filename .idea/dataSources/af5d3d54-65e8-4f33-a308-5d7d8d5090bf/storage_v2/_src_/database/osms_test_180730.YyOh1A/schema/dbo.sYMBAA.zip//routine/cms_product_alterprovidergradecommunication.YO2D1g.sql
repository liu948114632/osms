create PROCEDURE [dbo].[CMS_Product_AlterProviderGradeCommunication](
	@providerId INT=NULL 
)
AS

DECLARE @i  INT = 1;
DECLARE @rowCount  INT =0;
SELECT @rowCount = COUNT(*)  FROM  dbo.product_strategy a  WITH(NOLOCK) JOIN dbo.product_provider b  WITH(NOLOCK) ON  a.product_id =b.product_id AND a.department_id =b.department_id AND b.provider_id =@providerId
DECLARE  @PageSize INT = 1000   
DECLARE @pageCount  INT = ( @rowCount + @PageSize - 1 ) / @PageSize     
WHILE @i<=@pageCount
BEGIN
INSERT INTO dbo.communication_log
        ( command ,
          object_id ,
          status ,
          create_time ,
          operator ,
          model_type 
        )   select 'UPDATE_PROVIDER_GRADE',(SELECT CONVERT(VARCHAR(50),product_id)+',' FROM (

SELECT a.product_id,ROW_NUMBER() OVER(ORDER BY a.product_id asc) AS rowindex  FROM  dbo.product_strategy a 
WITH(NOLOCK) JOIN dbo.product_provider b WITH(NOLOCK) ON  a.product_id =b.product_id AND a.department_id =b.department_id
 AND b.provider_id =@providerId)  z WHERE rowindex BETWEEN (@i-1)*@PageSize+1 AND (@i)*@PageSize  FOR XML PATH('')  ),1,GETDATE(),0,'PRODUCT' 

SET @i =@i+1
END
go


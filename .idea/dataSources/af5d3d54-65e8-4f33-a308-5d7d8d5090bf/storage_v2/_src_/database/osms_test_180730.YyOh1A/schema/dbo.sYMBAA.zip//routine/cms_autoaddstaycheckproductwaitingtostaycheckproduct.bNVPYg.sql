CREATE PROCEDURE CMS_AutoAddStayCheckProductWaitingToStayCheckProduct
AS 
    BEGIN
        SET NOCOUNT ON ;
        SELECT  *
        INTO    #TEMP_StayCheckProductWaiting
        FROM    ( SELECT    a.id AS stayCheckProductWaitingId,
							a.product_id AS productId ,
                            b.id AS orderId ,
                            c.id AS orderItemId ,
                            CAST(ISNULL(c.volume, 0) / c.unit_quantity / 1.3 AS DECIMAL(18,6)) AS orderVolume ,
                            CAST(ISNULL(c.weight, 0) / c.unit_quantity / 1.15 AS DECIMAL(18,6)) AS orderWeight ,
                            ( SELECT    COUNT(*)
                              FROM      dbo.stay_check_product
                              WHERE     product_id = a.product_id
                                        AND create_time > DATEADD(month, -6,GETDATE())
                            ) AS isHalfNoExists ,
                            NULL AS departmentId,
                            b.is_check AS isCheck,
                            b.status AS orderStatus
                  FROM      dbo.stay_check_product_waiting AS a WITH ( NOLOCK )
                            JOIN dbo.[order] AS b WITH ( NOLOCK ) ON b.id = a.order_id
                            JOIN dbo.order_item AS c WITH ( NOLOCK ) ON c.id = a.order_item_id AND c.product_id = a.product_id AND c.order_id = b.id 
                  WHERE     a.status = 0
                            AND b.is_check = 0
                            AND b.status <> 132
                            AND b.status >= 55
                            AND ISNULL(b.deliver_weight, 0) > ISNULL(b.website_weight,0) * 1.15
                            AND c.status <> 12
                ) AS t
		--更新待测产品部门为可用存数最多的仓库部门
        UPDATE  #TEMP_StayCheckProductWaiting
        SET     departmentId = t1.department_id
        FROM    ( SELECT    t.department_id ,
                            t.product_id
                  FROM      ( SELECT    v.product_id ,
                                        v.department_id ,
                                        ROW_NUMBER() OVER ( PARTITION BY v.product_id ORDER BY v.available_qty DESC ) rn
                              FROM      ( SELECT    a.product_id ,
                                                    a.department_id ,
                                                    SUM(ISNULL(quantity, 0)- ISNULL(lock_quantity,0)) AS available_qty
                                          FROM      storage a WITH ( NOLOCK )
                                                    JOIN department b WITH ( NOLOCK ) ON a.department_id = b.id
                                          WHERE     b.type = 3
                                                    AND ISNULL(quantity, 0) - ISNULL(lock_quantity, 0) > 0
                                          GROUP BY  a.product_id ,a.department_id
                                        ) AS v
                                        JOIN #TEMP_StayCheckProductWaiting AS b ON v.product_id = b.productId
                              WHERE     (b.isHalfNoExists IS NULL OR b.isHalfNoExists = 0)--半年内不存在于待测产品
                            ) AS t
                  WHERE     t.rn = 1
                ) AS t1
        WHERE   t1.product_id = #TEMP_StayCheckProductWaiting.productId
        
        --加入待测订单商品
        INSERT  INTO dbo.stay_check_product
                ( product_id ,
                  status ,
                  order_id ,
                  order_item_id ,
                  operate_user_id ,
                  create_time ,
                  is_red ,
                  is_volumeCargo ,
                  order_volume ,
                  order_weight ,
                  department_id
                )
        SELECT  productId ,
                1 AS status ,
                orderId ,
                orderItemId ,
                0 AS operateUserId ,
                GETDATE() AS createTime ,
                ( SELECT    CASE WHEN COUNT(*) > 0 THEN 1
                                 ELSE 0
                            END
                  FROM      dbo.stay_check_product WITH(NOLOCK)
                  WHERE     product_id = productId
                            AND (status = 2 OR status = 4 )
                ) AS isRed ,
                0 AS isVolumeCargo ,
                orderVolume ,
                orderWeight ,
                departmentId
        FROM    #TEMP_StayCheckProductWaiting
        WHERE   departmentId IS NOT NULL          
        --设置订单已检测
        UPDATE  a
        SET     is_check = 1
        FROM    dbo.[order] AS a WITH(NOLOCK)
                JOIN #TEMP_StayCheckProductWaiting AS b ON a.id = b.orderId
        WHERE   a.is_check = 0
                AND b.departmentId IS NOT NULL  
        --待测等待商品状态更新为"已处理"
        UPDATE  a
        SET     status = 1
        FROM    dbo.stay_check_product_waiting AS a  WITH(NOLOCK)
                JOIN #TEMP_StayCheckProductWaiting AS b ON a.product_id = b.productId AND a.order_id = b.orderId AND a.order_item_id = b.orderItemId
        WHERE   b.departmentId IS NOT NULL
        
        --商品在半年内不存在待测列表,且 可用库存  < 单位批量(包括库存为0) 加入等待
        INSERT  INTO dbo.stay_check_product_waiting
                ( product_id ,
                  order_id ,
                  order_item_id ,
                  create_time ,
                  status
                )
        SELECT  t.productId ,
                t.orderId ,
                t.orderItemId ,
                GETDATE() ,
                0
        FROM    #TEMP_StayCheckProductWaiting AS t
        WHERE   NOT EXISTS ( SELECT 1
                             FROM   dbo.stay_check_product_waiting  WITH(NOLOCK)
                             WHERE  product_id = t.productId
                                    AND status = 0 )
                AND t.departmentId IS NULL 
		
		--商品在半年内存在于待测列表,继续加入等待                        
        INSERT  INTO dbo.stay_check_product_waiting
                ( product_id ,
                  order_id ,
                  order_item_id ,
                  create_time ,
                  status
                )
        SELECT  t.productId ,
                t.orderId ,
                t.orderItemId ,
                GETDATE() AS createTime,
                0 AS status
        FROM    #TEMP_StayCheckProductWaiting AS t
        WHERE   t.departmentId IS NULL
        AND isHalfNoExists IS NOT NULL                   
        AND isHalfNoExists > 0
        AND  NOT EXISTS ( SELECT 1 FROM  dbo.stay_check_product_waiting  WITH(NOLOCK)
                         WHERE  product_id = t.productId
                                AND status = 0 )
		--订单质检标识为true且订单状态>55清除待测等待数据                                    
		DELETE a FROM dbo.stay_check_product_waiting as a  WITH(NOLOCK) 
		JOIN #TEMP_StayCheckProductWaiting AS b ON a.id = b.stayCheckProductWaitingId
		WHERE b.isCheck = 1 AND b.orderStatus >55
		
		DROP TABLE #TEMP_StayCheckProductWaiting
    END
go


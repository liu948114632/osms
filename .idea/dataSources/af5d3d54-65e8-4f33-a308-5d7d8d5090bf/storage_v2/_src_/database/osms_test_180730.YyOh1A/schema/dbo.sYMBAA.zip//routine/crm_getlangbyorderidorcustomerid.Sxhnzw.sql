
--通过订单或者客户Id获取客户语种
CREATE PROC CRM_GetLangByOrderIdOrCustomerId
(
@OrderId varchar(20)='',
@CustomerId INT,
@Lang INT=0 OUT
)
AS 
BEGIN
IF(@OrderId<>'')
BEGIN
 SELECT @Lang=Lang FROM dbo.T_Order WHERE OrderId=@OrderId
END
ELSE 
BEGIN
  IF EXISTS(SELECT TOP 1 Lang FROM dbo.T_Order WHERE CustomerId=@CustomerId ORDER BY OrderDate DESC)
 SELECT TOP 1 @Lang=Lang FROM dbo.T_Order WHERE CustomerId=@CustomerId ORDER BY OrderDate DESC
ELSE
SELECT TOP 1 @lang= CASE  RegFrom WHEN 'en' THEN 0 WHEN 'de' THEN 1 WHEN 'fr' THEN 2 WHEN 'ru'  THEN 3 WHEN 'es' THEN 4 WHEN 'jp' THEN 5 WHEN 'it' THEN 6 ELSE 0 END FROM dbo.T_Customer
WHERE UserID=@CustomerId
END 
END
go






/*------------------------------------------------------
[推广]
	统计某段时间各个国家的注册客户情况
返回国家名、注册客户数和注册客户中下单的客户数
up_Report_Market_NewCustomersGet '2008-01-01','2008-11-01'
----------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Market_NewCustomersGet]
(
	@StartTime		DateTime, 
	@EndTime		DateTime
)
AS
BEGIN
	SET NOCOUNT ON;
	
	/*
	Select 
		d.Country As CountryName, -- 注册国家
		Count(1) As Customers, -- 注册客户数
		Sum(IsNull(e.OrderUser,0)) As OrderCustomers -- 注册客户下单的客户数
	From
		T_Customer a
		Left Join T_CustomerAddresses b On a.UserId = b.UserId And b.[Type] In (1,3) 
		Left Join T_Addresses  c On b.AddressId = c.AddressId
		Left Join T_Country d On c.Country = d.Id
		Left Join (
			Select UserId,1 as OrderUser From B_Order
			Where Status < 132 And OrderDate > @StartTime And OrderDate < @EndTime
			Group By UserId
		) e On a.UserId = e.UserId
	Where
		a.RegFrom Is Null And a.RegTime > @StartTime And a.RegTime < @EndTime
		And b.UserId > 0 And c.AddressId > 0 And d.Id > 0
	Group by 
		d.Country
	Order by
		Count(1) Desc
	*/
	
	WITH cteCustomers AS 
	(
		SELECT
			a.UserId,  
			d.[Name] AS CountryName -- 注册国家
		FROM t_customer a 
		JOIN dbo.T_CustomerAddresses b 
			ON a.UserId = b.UserId AND b.[TYPE] IN(1,3)
		JOIN dbo.T_Addresses c 
			ON b.AddressId = c.AddressId
		JOIN dbo.T_Country d 
			ON c.Country = d.CountryId	
		WHERE a.RegTime > @StartTime And a.RegTime < @EndTime AND a.RegFrom = '' --PH客户		
	),cteCountryCustomers AS -- 各个国家注册客户数
	(
		SELECT
			CountryName,-- 注册国家
			COUNT(1) AS Customers -- 注册客户数 
		FROM cteCustomers
		GROUP BY [CountryName]	
	),cteOrdersCustomers AS -- 下单客户数
	(
		SELECT
			CountryName,-- 注册国家
			COUNT(1) AS Customers -- 注册客户数 
		FROM cteCustomers WHERE UserId IN(
			SELECT CustomerId
			FROM dbo.T_Order
			WHERE OrderType IN(1,2) AND OrderStatus > 0 AND OrderStatus < 132
				AND OrderDate > @StartTime And OrderDate < @EndTime
		)
		GROUP BY [CountryName]	
	)
	
	
	SELECT 
		a.CountryName,
		a.Customers,-- 注册客户数
		ISNULL(b.Customers,0) As OrderCustomers -- 下单的客户数
	FROM cteCountryCustomers a 
		LEFT JOIN cteOrdersCustomers b 
			ON a.CountryName = b.CountryName
	ORDER BY a.Customers DESC;

END


go


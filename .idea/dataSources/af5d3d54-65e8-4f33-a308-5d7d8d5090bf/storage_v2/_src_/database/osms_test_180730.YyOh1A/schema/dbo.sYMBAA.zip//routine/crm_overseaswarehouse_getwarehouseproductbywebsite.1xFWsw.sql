CREATE PROC CRM_OverseasWarehouse_GetWarehouseProductByWebSite
(
@CmsProductId INT,
--@OverseasWebSiteId INT
@WarehouseId INT
)
AS
BEGIN
	SELECT a.CK1StorageNo AS StorageNo,a.CMSProductId,a.Width,a.Length,a.Height,a.Weight FROM dbo.T_OverseasWarehouseProduct a WITH(NOLOCK)
--INNER JOIN dbo.T_OverseasWarehouse b WITH(NOLOCK) ON a.WarehouseId=b.ID
 WHERE IsDelete=0 AND CMSProductId=@CmsProductId 
 --AND b.OverseasWebSite=@OverseasWebSiteId
 AND a.WarehouseId=@WarehouseId
END
go


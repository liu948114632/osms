
/**
保存海外仓包裹项
*/
CREATE PROC CRM_Order_AddOverseasWarehousePackageItem
(  
  @OrderId VARCHAR(20), --订单号
  @PackageCode VARCHAR(30), --包裹号
  @ProductCode VARCHAR(30), --商品编号
  @StorageNo VARCHAR(30),   --出口易库存编码
  @SendQty   INT --是批量的数
)
AS
BEGIN
      --SELECT @ProductCode = b.code
      --FROM dbo.T_OverseasWarehouseProduct a
      --JOIN dbo.V_CRM_All_Product b ON a.CMSProductId = b.CmsProductId
      --WHERE a.CK1StorageNo = @StorageNo
      
      DECLARE @OrderItemId INT 
      SET @OrderItemId = 0
      
      SELECT @OrderItemId = a.OrderItemId
      FROM dbo.T_OrderItem a 
      JOIN dbo.T_OrderItemProduct b ON a.OrderItemId=b.OrderItemId
      WHERE a.OrderId = @OrderId AND b.ItemCode = @ProductCode
      
      INSERT INTO dbo.T_OverseasWarehousePackageItem
              ( PackageCode ,
                ProductCode ,
                StorageNo ,
                OrderItemId,
                OrderId,
                SendQty
              )
      VALUES  ( @PackageCode , -- PackageCode - varchar(30)
                @ProductCode , -- ProductCode - varchar(30)
                @StorageNo , -- StorageNo - varchar(30)
                @OrderItemId , -- OrderItemId - int
                @OrderId,
                @SendQty
              )
END
go


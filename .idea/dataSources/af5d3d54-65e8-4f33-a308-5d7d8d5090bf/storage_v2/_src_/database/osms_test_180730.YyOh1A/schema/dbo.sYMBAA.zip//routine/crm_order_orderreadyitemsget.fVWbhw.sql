

/*----------------------------------------      
备注：获取订单到货商品装箱数据      
创建人: FRH      
创建日期:2010-02-23      
      
修改人：HYD      
修改日期：2011-08-10      
修改内容：增加产品长度，直径，Material 属性值的获取      
-----------------------------------------------*/      
CREATE PROC [dbo].[CRM_Order_OrderReadyItemsGet]       
(      
 @OrderIds  VARCHAR(MAX)-- 多个订单号      
)      
AS      
BEGIN      
 SET NOCOUNT ON;      
      
 Declare @tOrder Table (OrderId VARCHAR(20));      
      
 INSERT INTO @tOrder(OrderId)      
 SELECT [Value] FROM dbo.uf_Split(@OrderIds,',');      
       
 Select       
  ISNULL(d.Name,'') AS CategoryName,-- 原来的三级类别名称      
  a.box,-- 子箱号      
  b.Code,-- 商品编号      
  a.WEIGHT AS UnitWeight,-- 商品一个批量的重量      
  a.UnitQuantity,      
  a.Unit, -- 商品批量单位      
  a.ReadyQty, -- 实际到货数量      
  CAST(a.weight*(a.readyqty*1.0/a.UnitQuantity) AS DECIMAL(18,2)) AS ReadyWeight,-- 到货重量      
  b.CmsProductId AS ProductId,      
  (SELECT top 1 ISNULL(SpecValue,0.0) FROM dbo.V_CRM_ProductRelatedSpec WHERE SpecId = 3 AND CmsProductId = b.CmsProductId) AS Length, -- 长度      
  (SELECT top 1 ISNULL(SpecValue,0.0) FROM dbo.V_CRM_ProductRelatedSpec WHERE SpecId = 2 AND CmsProductId = b.CmsProductId) AS Diameter, -- 直径      
  (SELECT top 1 ISNULL(pv.Name,'') FROM dbo.V_CRM_ProductRelatedProperty py JOIN dbo.property_value pv ON py.PropertyValueId = pv.id WHERE pv.property_id = 2 AND py.CmsProductId = b.CmsProductId) AS Material,
  d.hs_code AS HSCode       
 From dbo.T_OrderItem a       
 INNER JOIN dbo.V_CRM_All_Product b      
  ON a.CmsProductId = b.CmsProductId AND a.OrderId IN(SELECT OrderId FROM @tOrder)        
 LEFT JOIN dbo.category d ON b.CategoryId2 = d.id -- 只获取2级类别      
 /* 已经在备货的商品 */      
 WHERE a.ReadyQty > 0       
 /* 非取消状态的商品 */      
 AND a.[Status] < 12      
 ORDER BY CategoryName,b.Code;--a.box      
       
END
go


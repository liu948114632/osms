CREATE PROC  [CMS_Product_PictureCode]
( 
	@PictureName VARCHAR(200) = NULL --图片名称
)
AS 
BEGIN 
    DECLARE @pictureCode NVARCHAR(200) = NULL ;           
    SET NOCOUNT ON ;        
		SELECT @pictureCode = picture_code FROM (
			SELECT picture_code,picture_name   FROM dbo.product_picture_collection WITH(NOLOCK) WHERE type IN (1,2,10)
			UNION ALL
			SELECT picture_code,picture_name   FROM dbo.product_set_color_card WITH(NOLOCK) 
		) temp WHERE temp.picture_name=@PictureName
	IF @pictureCode  IS  NULL 
	BEGIN
		SELECT @pictureCode =picture_code FROM  dbo.common_picture_store WITH(NOLOCK)  WHERE [filename] =@PictureName
	END
	SELECT @pictureCode
	SET NOCOUNT OFF ;     
END

go


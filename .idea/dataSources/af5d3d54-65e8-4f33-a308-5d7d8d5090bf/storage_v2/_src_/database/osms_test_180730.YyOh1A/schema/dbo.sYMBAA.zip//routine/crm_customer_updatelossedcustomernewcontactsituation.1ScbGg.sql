    
	

	
---修改挽回客户的联系情况
CREATE PROC CRM_Customer_UpdateLossedCustomerNewContactSituation 
( 
@CustomerId INT,
@OperatorId INT=0
 )
AS
    BEGIN

	DECLARE @IsContactCustomer BIT =0;    

	SELECT @IsContactCustomer=ISNULL(IsContactCustomer,0) FROM dbo.T_LossedCustomerNew WHERE CustomerId=@CustomerId

        UPDATE  dbo.T_LossedCustomerNew
        SET     ContactNum = ISNULL(ContactNum,0) + 1 ,
                LastContactTime = GETDATE() ,
			  IsContactCustomer=1,
                FirstContactTime = CASE WHEN ISDATE(FirstContactTime) = 1
                                        THEN FirstContactTime
                                        ELSE GETDATE()
                                   END								   		
        WHERE   CustomerId = @CustomerId;

		IF @IsContactCustomer=0
		BEGIN
			EXEC dbo.CRM_Customer_AddLossedCustomerNewLog @CustomerId = @CustomerId, -- int
			    @OperatorId =@OperatorId, -- int
			    @log = N'发邮件自动设置联系客户为是', -- nvarchar(2000)
			    @EmailContent = N'' -- nvarchar(max)
			
		END

    END

go


---修改挽回客户的联系情况
  CREATE PROC dbo.CRM_Customer_UpdateDigCustomerContactResultByCustomerEmail
   ( 
   @EmailId INT
   )
  AS
 BEGIN

   UPDATE a SET  ContactResult=1 FROM  dbo.T_DigCustomerDetail a WITH(NOLOCK)
  INNER JOIN dbo.T_DigCustomer b WITH(NOLOCK) ON a.DigCustomerId=b.DigCustomerId
  AND b.EmailID=@EmailId

END

go


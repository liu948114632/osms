

--取消畅销品标记
CREATE PROC [dbo].CMS_ProviderStorageProduct_MarkNotHot AS 
BEGIN
UPDATE a SET a.is_hot = 0   --前180天的销量 
   FROM dbo.provider_storage_product a WITH(NOLOCK)
   LEFT JOIN dbo.uf_product_remaind_sale_info(GETDATE() - 60 ,GETDATE(),1,1) b ON a.product_id = b.product_id 
   JOIN dbo.product c ON c.id =a.product_id
   WHERE a.is_hot = 1 AND (b.product_id IS NULL OR c.offline_status = 2 OR EXISTS(SELECT TOP 1 product_id FROM stay_shield_product ssp
			WHERE operate_type = 1 AND ssp.product_id = a.product_id))
END


go


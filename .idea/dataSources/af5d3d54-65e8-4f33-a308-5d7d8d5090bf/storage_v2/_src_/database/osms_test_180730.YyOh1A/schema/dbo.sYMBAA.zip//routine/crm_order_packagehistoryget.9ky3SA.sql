


/*---------------------------------------------------
备注:获取某个Package的历史操作
创建人: FRH
创建日期:2009-12-30	
-----------------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_PackageHistoryGet] 
(
	@UserId				INT = 0,
	@OrderId			VARCHAR(20) = ''
)
AS
BEGIN
	if @UserId > 0
	BEGIN
		SELECT 
			a.*,
			(CASE WHEN a.userId = 0 THEN N'网站客户' ELSE b.[name] END) AS UserName 
		FROM 
			T_OrderPackagehistory a LEFT JOIN [user] b 
				ON a.userId = b.Id
		WHERE a.OrderId = @OrderId AND (a.userId = @userId OR a.UserId = 0)
		ORDER BY a.Id DESC ;
	END
	ELSE
	BEGIN
		SELECT 
			a.*,
			(CASE WHEN a.userId = 0 THEN N'网站客户' ELSE b.[name] END) AS UserName 
		FROM 
			T_OrderPackagehistory a LEFT JOIN dbo.[user] b
				ON a.userId = b.Id
		WHERE a.OrderId = @OrderId -- and a.userId > 0
		ORDER BY a.Id DESC ;
	END
END
go


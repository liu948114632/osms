CREATE PROC CRM_Customer_GetCustomerInfoShareByHandler
(
@HandlerId INT
)
AS 
BEGIN
	;WITH cte AS
(
SELECT a.id,a.ShareByHandlerId,b.HandlerId AS ShareToHandler,a.ShareWay,b.BusinessType FROM dbo.T_CustomerInfoShare a WITH(NOLOCK)
INNER JOIN dbo.T_CustomerInfoShareHandler b WITH(NOLOCK) ON a.Id=b.ShareId
WHERE b.HandlerId=@HandlerId--单向共享
UNION ALL
SELECT a.id,b.HandlerId AS ShareByHandlerId,a.ShareByHandlerId AS  ShareToHandler,a.ShareWay,b.BusinessType FROM dbo.T_CustomerInfoShare a WITH(NOLOCK)
INNER JOIN dbo.T_CustomerInfoShareHandler b WITH(NOLOCK) ON a.Id=b.ShareId
WHERE a.ShareByHandlerId=@HandlerId AND a.ShareWay=2--双向共享
),result AS 
(
SELECT a.*,b.ShareMode,b.ShareTimeQuantum,CONVERT(CHAR(10),GETDATE(),25) AS CurrDate,CAST(DATEPART(WEEKDAY,GETDATE())-1  AS VARCHAR(2))AS CurrWeekDay FROM cte  a
INNER JOIN dbo.T_CustomerInfoShareTimeQuantum b ON a.Id=b.ShareId
)
SELECT * FROM result a 
WHERE (a.ShareMode=1 AND ShareTimeQuantum=a.CurrDate) OR (a.ShareMode=2 AND ShareTimeQuantum=CurrWeekDay)
END
go


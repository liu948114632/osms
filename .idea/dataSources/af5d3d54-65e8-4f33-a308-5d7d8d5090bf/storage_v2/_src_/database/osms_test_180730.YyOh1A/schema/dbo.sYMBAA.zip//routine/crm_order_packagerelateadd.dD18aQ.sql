

/*-------------------------------------------
备注:添加问题包裹历史
创建人: FRH
创建日期:2009-12-30
--------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_PackageRelateAdd] 
(
	@OrderId		NVARCHAR(20),
	@Subject 	    NVARCHAR(500),
	@Content		NVARCHAR(2000),
	@Agent			NVARCHAR(200),
	@QuestionStatus INT,
	@UserId			INT
)
AS
BEGIN 
	INSERT INTO	dbo.T_OrderPackageRelate (
		OrderId,
		Subject,
		[Content],
		Agent,
		AddTime,
		UserId
	)  
	VALUES
	( 
		@OrderId,
		@Subject,
		@Content,
		@Agent,
		GETDATE(),
		@UserId );

	-- 标志处理完成
	UPDATE dbo.T_OrderPackage 
	SET	QuestionStatus = @QuestionStatus,DealStatus = 2 -- 处理状态2:已解决
	WHERE OrderId = @OrderId
END

go


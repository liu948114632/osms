CREATE VIEW V_ProductInventory
AS 

SELECT id ,product_id,ISNULL(x1,0) + ISNULL(x2,0) + ISNULL(x3,0) AS not_finish_prepare_qty,ISNULL(x4,0) AS required_wait_qty
FROM (
SELECT a.id,a.product_id,(SELECT SUM(wait_quantity) FROM dbo.purchasing_management_task b1  WITH (NOLOCK)  WHERE b1.product_id = a.product_id AND status IN (1,4) AND type=3) AS x1
,(SELECT SUM(wait_quantity) FROM dbo.purchasing_department_task b2  WITH (NOLOCK) WHERE b2.product_id = a.product_id AND status IN (4,7,8,9) AND type=3) AS x2
,(SELECT SUM(wait_quantity) FROM dbo.department_purchase_task b3   WITH (NOLOCK) WHERE b3.product_id = a.product_id AND status<70 AND type=3) AS x3,
(SELECT SUM(plan_quantity) FROM dbo.purchasing_management_task b1  WITH (NOLOCK)  WHERE b1.product_id = a.product_id AND status = 8 AND is_ready_sell=0 AND purchasing_management_remark='因小批量等待采购') AS x4
FROM product_inventory a
) b

go


CREATE PROCEDURE [dbo].[US_Property_ExistsProperty]
(
    @PropertyId INT
)
AS
BEGIN 
	IF EXISTS (SELECT 1 FROM dbo.T_Property_US WHERE PropertyId = @PropertyId AND IsDeleted=0)
		SELECT 1
    ELSE 
		SELECT 0 
END
go


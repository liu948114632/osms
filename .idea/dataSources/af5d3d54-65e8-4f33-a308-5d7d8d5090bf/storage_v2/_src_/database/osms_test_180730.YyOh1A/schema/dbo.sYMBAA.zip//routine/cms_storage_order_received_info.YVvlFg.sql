
CREATE PROC CMS_Storage_order_received_info
(
	@orderId INT,
	@productId INT
)
AS
BEGIN
    SELECT  so.id ,
        so.code ,
        ( SELECT    COUNT(DISTINCT st2.product_id)
          FROM      dbo.storage_order_item st1 WITH ( NOLOCK )
                    JOIN dbo.view_all_storage_task st2 WITH ( NOLOCK ) ON st1.task_id = st2.id
          WHERE     st1.storage_order_id = so.id
                    AND st1.is_deleted = 0
                    AND st1.status != 5
        ) AS productCount ,
		t.plan_quantity AS planQuantity,
		s.collect_user_id AS collectUserId,
		s.department_id AS departmentId,
		s.collect_date AS collectDate
   FROM dbo.storage_order so WITH ( NOLOCK )
		INNER JOIN dbo.storage_order_item soi WITH(NOLOCK) ON soi.storage_order_id=so.id
		INNER JOIN view_all_storage_task t ON t.id=soi.task_id
		INNER JOIN dbo.sub_order_inventory_item si WITH(NOLOCK) ON si.sub_order_id=so.id
		INNER JOIN dbo.sub_order_inventory s WITH(NOLOCK) ON s.id=si.inventory_id
	WHERE so.order_id=@orderId AND t.product_id=@productId AND so.is_received=1
	ORDER BY s.collect_date ASC 
END


go


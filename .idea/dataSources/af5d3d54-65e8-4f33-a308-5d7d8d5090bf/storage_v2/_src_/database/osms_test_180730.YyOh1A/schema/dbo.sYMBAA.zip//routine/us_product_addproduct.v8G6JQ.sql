CREATE PROCEDURE [dbo].[US_Product_AddProduct]  
(  
  @ProductId INT,
  @IsDisplay BIT   
)  
AS  
BEGIN   
 IF NOT EXISTS (SELECT 1 FROM T_Product_US WHERE ProductId=@ProductId)  
 BEGIN  
  INSERT INTO T_Product_US(ProductId,IsDeleted,CreateDate,LastUpdateDate,Is_Display)  
  VALUES(@ProductId,0,GETDATE(),GETDATE(),@IsDisplay)  
 END  
 ELSE  
 BEGIN  
  UPDATE T_Product_US SET IsDeleted=0,LastUpdateDate=GETDATE(),Is_Display=@IsDisplay
  WHERE ProductId=@ProductId  
 END  
END
go


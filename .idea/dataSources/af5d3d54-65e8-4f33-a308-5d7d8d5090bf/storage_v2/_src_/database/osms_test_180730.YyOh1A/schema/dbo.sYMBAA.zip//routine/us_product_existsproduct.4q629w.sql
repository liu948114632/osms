CREATE PROCEDURE [dbo].[US_Product_ExistsProduct]
(
    @ProductId INT
)
AS
BEGIN 
	IF EXISTS (SELECT 1 FROM T_Product_US WHERE ProductId=@ProductId AND IsDeleted=0)
		SELECT 1
    ELSE 
		SELECT 0 
END
go


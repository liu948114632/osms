


/*-----------------------------------------
[备注] 
	检查paypal的付款地址是否一致，只检查国家
--------------------------------------------------------*/
CREATE   PROCEDURE [dbo].[CRM_Service_OrderAddressCheck]
(
	@address_country		VARCHAR(100),		
	@orderId				VARCHAR(20),
	@result					INT	OUT -- 返回结果
)
AS
DECLARE
	@country				VARCHAR(150),
	@addressId				INT
BEGIN
	SET	@result = 0;         -- 返回0代表通过

		IF @address_country IS NULL OR @address_country = ''
	BEGIN
		SET @result =0; -- 如果返回的国家是空的，直接通过
		RETURN;
	END
	
	--法国进行特殊处理(因为法国改成了France Métropolitaine）
	IF( @address_country = 'France' )
	BEGIN
	    SELECT @address_country = Name FROM dbo.T_Country WHERE CountryId=34
	END 

	-- 获取相应的地址Id
	SELECT @addressId = [ShipAddressId] FROM dbo.T_Order WHERE OrderId = @orderId;
	IF @addressId IS NULL	
	BEGIN
		SET	@result = 5;-- 信息不全，匹配失败
		RETURN;
	END	
	
	-- 获取寄货地址里面的国家
	SELECT @country = (SELECT [Name] FROM dbo.T_Country WHERE [CountryId] = dbo.T_OrderAddresses.Country)
	FROM dbo.T_OrderAddresses WHERE	AddressId =  @addressId;

	IF @country IS NULL OR @country = ''
	BEGIN
		SET @result = 5; -- 信息不全，匹配失败
		RETURN;
	END
	ELSE IF(@address_country <> @country) 
	BEGIN
		SET @result = 2; -- 地址匹配失败
	END
END

go


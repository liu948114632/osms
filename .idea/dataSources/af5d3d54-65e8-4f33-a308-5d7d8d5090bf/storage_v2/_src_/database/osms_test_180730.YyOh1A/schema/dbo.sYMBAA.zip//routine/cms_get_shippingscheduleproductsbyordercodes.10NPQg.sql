 
CREATE PROCEDURE CMS_GET_ShippingScheduleProductsByOrderCodes
	 @OrderCodes NVARCHAR(MAX),
	 @shippingScheduleId INT
AS
BEGIN

	WITH productLot AS ( SELECT c.product_id,SUM(c.lot_quantity) AS lotqty FROM  dbo.shipping_schedule_order a 
	 JOIN dbo.[order] b ON a.order_id =b.id  
	 JOIN dbo.shipping_schedule_order_item c ON c.order_id = b.id AND c.shipping_schedule_id = a.shipping_schedule_id
	 WHERE a.shipping_schedule_id = @shippingScheduleId AND b.code IN (SELECT Value FROM  dbo.uf_Split(@OrderCodes,',')) GROUP BY c.product_id
	 )

	 SELECT 
	      b.id,
		  shipping_schedule_id  AS shippingScheduleId,
          b.product_id AS productId ,
          product_code AS productCode ,
          a.lotqty AS lotQuantity ,
          unit_taxes AS unitTaxes,
          unit_shipping_cost AS unitShippingCost ,
          unit_other_cost AS unitOtherCost ,
          unit_declared_value AS unitDeclaredvalue ,
          voulme  AS volume,
          weight ,
          first_way_cost AS firstWayCost FROM  productLot a  JOIN dbo.shipping_schedule_product  b ON a.product_id =b.product_id
	 WHERE b.shipping_schedule_id =@shippingScheduleId

	  
END
go


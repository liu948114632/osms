 
/**                  
 2012-03-27                
 获取订单待分配数量                  
*/                  
CREATE PROC [dbo].[CMS_Logistics_GetAssignmentByRequire]  
    (  
      @StockOutItemId INT = NULL ,  
      @ProductId INT = NULL ,--产品Id                
      @Qty INT = NULL , --数量      
      @DepartmentId INT = NULL ,--接货部门
      @StockOutId INT = null               
    )  
AS   
    BEGIN                        
        SET NOCOUNT ON ;                  
                        
        DECLARE @OrderItemId INT  
                --@receive_department_id INT,
            
        IF OBJECT_ID('#temp_assignment_product') IS NOT NULL   
            DROP TABLE #temp_assignment_product ;                
                        
        SELECT  @OrderItemId = a.order_item_id  
        FROM    dbo.view_all_purchasing_management_task AS a WITH ( NOLOCK )  
                INNER JOIN dbo.view_all_storage_task AS b WITH ( NOLOCK ) ON a.id = b.purchasing_management_task_id  
                INNER JOIN dbo.stock_out_ref_storage_task AS c WITH ( NOLOCK ) ON c.storage_task_id = b.id  
        WHERE   c.stock_out_item_id = @StockOutItemId           
                
        --SELECT  @receive_department_id = b.receive_department_id,
        --        @StockOutId = b.id  
        --FROM    dbo.stock_out_item AS a WITH ( NOLOCK )  
        --        INNER JOIN dbo.stock_out AS b WITH ( NOLOCK ) ON a.stock_out_id = b.id  
        --WHERE   a.id = @StockOutItemId              
        
        SELECT  temp.id AS orderItemId ,  
                temp.order_id AS orderId ,  
                temp.department_id AS departmentId ,  
                temp.code AS orderCode ,  
                temp.product_id AS productId ,  
                temp.quantity - temp.prepareLockQty1 - temp.prepareLockQty2 AS assignQuantity ,  
                temp.quantity - temp.prepareLockQty1 - temp.prepareLockQty2 AS orderAssignQuantity ,  
                CONVERT(VARCHAR(100), temp.unit_quantity) + ' ' + temp.unit AS productUnit,  
                CASE WHEN t.position='' THEN NULL ELSE t.position end AS position  ,  
                temp.order_item_group_id AS orderItemGroupId  
                INTO #temp_assignment_product  
        FROM    ( SELECT    i.id ,  
       i.order_item_group_id,  
                            ( i.order_quantity - ISNULL(i.zcq_department_received_qty,0) ) AS quantity ,  
                            ISNULL(( SELECT SUM(a.assign_quantity)  
                                     FROM   dbo.assignment_item a  
                                            INNER JOIN dbo.assignment b ON a.assignment_id = b.id  
                                                              AND a.order_item_id = i.id  
                                                              AND b.status IN (  
                                                              0, 1 )  
                                   ), 0) AS prepareLockQty1 ,  
                            ISNULL(( SELECT SUM(sp.assign_quantity)  
                                     FROM   dbo.assigment_stay_product AS sp  
                                     WHERE  sp.order_item_id = i.id  
                                            AND sp.status IN ( 0, 1 )  AND sp.department_id =@DepartmentId 
                                   ), 0) AS prepareLockQty2 
                                    ,   
                            i.product_id ,  
                            i.unit_quantity ,  
                            i.unit ,  
                            i.order_id ,  
                            o.code ,  
                            o.department_id ,  
                            o.valid_Order_Count ,  
                            o.prepared_Count ,  
                            o.priority_Level ,  
                            o.order_Time ,  
                            CASE WHEN @OrderItemId = i.id THEN 1  
                                 ELSE 0  
                            END stockOutSort 
                             --f.assign_position_time 
                  FROM      Order_Item AS i  
                            INNER JOIN [Order] AS o ON o.id = i.order_Id  
                            --LEFT JOIN dbo.small_lot_order f ON o.id=f.order_id AND f.is_deleted=1
                  WHERE     i.product_id = @ProductId  AND i.processing_status<>30 and i.status<>12 AND o.status<40
                            AND o.department_id = @DepartmentId  
                            AND ISNULL(i.zcq_department_received_qty,0)<i.order_quantity
                ) temp  
                INNER JOIN dbo.order_item_group AS t WITH(NOLOCK) ON t.id = temp.order_item_group_id  
        WHERE   temp.quantity > ( temp.prepareLockQty1 + temp.prepareLockQty2 )  
       ORDER BY temp.stockOutSort DESC ,  
                ( temp.valid_Order_Count - temp.prepared_Count ) ,  
                CASE WHEN temp.quantity <= @Qty THEN 0  
                     ELSE 1  
                END ,  
                temp.priority_Level DESC ,  
                temp.order_Time ASC      
              
                
              SELECT * FROM #temp_assignment_product;  
          
        INSERT INTO dbo.temp_logistics_assignment_product_log  
                ( orderItemId ,  
                  orderId ,  
                  departmentId ,  
                  orderCode ,  
                  productId ,  
                  assignQuantity ,  
                  orderAssignQuantity ,  
                  productUnit ,  
                  position ,  
                  orderItemGroupId,  
                  stockOutId  ,  
                  createTime  
                )  
         SELECT orderItemId ,  
                  orderId ,  
                  departmentId ,  
                  orderCode ,  
                  productId ,  
                  assignQuantity ,  
                  orderAssignQuantity ,  
                  productUnit ,  
                  position ,  
                  orderItemGroupId,  
                  @StockOutId,  
                  GETDATE()  
        FROM #temp_assignment_product;  
                    
        DROP TABLE #temp_assignment_product;  
    END


go


-- =============================================      
-- Author:  <dk>      
-- Description: <统计客户购买金额>    
-- =============================================     
CREATE PROC dbo.CRM_Customer_CustomerBuyAmount           
AS        
BEGIN    

 UPDATE a SET     
 a.PurchaseAmountPh = ISNULL(b.PhOrderPrice,0) + ISNULL(c.Total,0),    
 a.PurchaseAmountPw = ISNULL(b.PwOrderPrice,0) + ISNULL(d.Total,0),
 a.PurchaseAmountJl = ISNULL(b.JlOrderPrice,0) + ISNULL(e.Total,0),
Type=CASE 
WHEN a.Type=0 AND (SELECT SUM(b.OrderCount) FROM dbo.T_CustomerTrading b WITH(NOLOCK) WHERE  a.UserID=b.CustomerId)>3 THEN 1 
WHEN a.Type=1 AND (SELECT SUM(b.OrderCount) FROM dbo.T_CustomerTrading b WITH(NOLOCK) WHERE  a.UserID=b.CustomerId)<=3 THEN 0
ELSE a.Type END
 FROM dbo.T_Customer a  WITH(NOLOCK)    
 LEFT JOIN dbo.V_CustomerOrderPrice b WITH(NOLOCK)    ON b.CustomerId = a.UserID    
 LEFT JOIN dbo.T_CustomerConsumption c WITH(NOLOCK)    ON a.UserID=c.UserId AND c.OrderIndustryType=1
 LEFT JOIN dbo.T_CustomerConsumption d WITH(NOLOCK)    ON a.UserID=d.UserId AND d.OrderIndustryType=16
 LEFT JOIN dbo.T_CustomerConsumption e WITH(NOLOCK)    ON a.UserID=e.UserId AND e.OrderIndustryType=17
 
END

go


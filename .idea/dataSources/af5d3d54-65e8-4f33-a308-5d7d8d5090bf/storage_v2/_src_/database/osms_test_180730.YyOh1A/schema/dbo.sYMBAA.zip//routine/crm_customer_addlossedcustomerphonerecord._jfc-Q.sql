
---添加挽回客户的电话记录
CREATE PROC CRM_Customer_AddLossedCustomerPhoneRecord
(
@CustomerId INT,
@ContactSituation INT,
@Remark NVARCHAR(500),
@CreatorId INT 
)
AS 
BEGIN
INSERT INTO dbo.T_LossedCustomerPhoneRecord
        ( CustomerId ,
          CreateTime ,
          Content ,
          Status ,
          CreatorId
        )
VALUES  (@CustomerId, -- CustomerId - int
          GETDATE() , -- CreateTime - smalldatetime
          @Remark , -- Content - nvarchar(500)
           @ContactSituation, -- Status - int
          @CreatorId -- Creator - int
        )
    ---修改最后一次联系方式    
  UPDATE dbo.T_LossedCustomer SET LastContactTime=GETDATE() WHERE CustomerId=@CustomerId
  --如果首次联系方式为空，则修改首次联系方式为电话
IF (SELECT ISNULL(FirstRespondWay,0) FROM  T_LossedCustomer WHERE CustomerId=@CustomerId)<1 AND @ContactSituation=1
BEGIN
  UPDATE dbo.T_LossedCustomer SET FirstRespondWay=1,ContactSituation=1 WHERE CustomerId=@CustomerId
END
        
END

go


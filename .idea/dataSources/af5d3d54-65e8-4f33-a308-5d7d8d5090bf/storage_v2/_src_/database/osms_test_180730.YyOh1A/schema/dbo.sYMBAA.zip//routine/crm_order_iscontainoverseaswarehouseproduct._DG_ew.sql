/**  
检查订单是否包含有海外仓商品  
*/  
CREATE PROC CRM_Order_IsContainOverseasWarehouseProduct  
(  
  @OrderId VARCHAR(20),  
  @Result   BIT Out   
)  
AS  
begin  
     IF EXISTS(SELECT TOP 1 1  
     FROM T_OrderItem a  
     WHERE OrderId = @OrderId AND STATUS < 12     
       AND CmsProductId IN (SELECT CmsProductId FROM T_OverseasWarehouseProduct WHERE IsDelete=0))  
     begin  
        SET @Result = 1  
     END   
     ELSE   
     begin  
        SET @Result = 0  
     END        
END

go


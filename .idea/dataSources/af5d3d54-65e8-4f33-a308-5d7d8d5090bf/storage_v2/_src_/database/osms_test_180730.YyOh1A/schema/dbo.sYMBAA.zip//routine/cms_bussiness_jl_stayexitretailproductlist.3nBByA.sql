

CREATE PROC [dbo].[CMS_Bussiness_JL_StayExitRetailProductList]
    (
      @CategoryId1 INT = NULL , --一级类别ID              
      @CategoryId2 INT = NULL , --二级类别ID              
      @CategoryId3 INT = NULL , --三级类别ID                        
      @ProductCode VARCHAR(MAX) = NULL ,--商品编号              
      @ProductCodes VARCHAR(MAX) = NULL ,--商品编号集合              
      @ProductName VARCHAR(MAX) = NULL ,--产品名称
      @PageSize INT = 50 ,  --页大小              
      @PageIndex INT = 1    --当前页号            
    )
AS 
    BEGIN                    
        SET NOCOUNT ON ;                    
                      
        DECLARE @SQL VARCHAR(MAX) ,
            @TempSQL NVARCHAR(MAX) ,
            @BaseSQL VARCHAR(MAX) ,   --基本查询用          
            @CountSql NVARCHAR(MAX) , --查询数量用              
            @FromSQL1 NVARCHAR(MAX) , --内查询用              
            @FromSQL2 NVARCHAR(MAX) , --外查询用              
            @Condition VARCHAR(MAX) , --条件              
            @Column VARCHAR(MAX) ,--用于查询出来的列              
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT                
    --获得查询条件          
        SET @Condition = ' WHERE 1=1 AND p.status=4 AND p.is_delete = 0'              
        IF @CategoryId1 IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND p.category_id_1='
                    + CONVERT(VARCHAR(20), @CategoryId1)              
            END               
        IF @CategoryId2 IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND p.category_id_2='
                    + CONVERT(VARCHAR(20), @CategoryId2)              
            END               
        IF @CategoryId3 IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND p.category_id_3='
                    + CONVERT(VARCHAR(20), @CategoryId3)              
            END                             
        IF @ProductCode IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND p.code like '''
                    + @ProductCode + '%'''              
            END              
        IF @ProductCodes IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND p.code in ('''
                    + REPLACE(@ProductCodes, ',', ''',''') + ''')'              
            END              
        IF @ProductName IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND p.name like ''%'
                    + @ProductName + '%'''              
            END                
    --设置条件查询必须关联的表          
        SET @FromSQL1 = 'FROM product as p '
        SET @FromSQL1 = @FromSQL1 + 'INNER JOIN dbo.jl_product AS j WITH ( NOLOCK ) ON p.id = j.product_id '
        SET @FromSQL1 = @FromSQL1 + 'INNER JOIN dbo.stay_exit_retail_product p2 WITH ( NOLOCK ) ON j.id = p2.product_id '        
    --求符合条件的总数          
        SET @CountSql = ' SELECT @RowCount = count(p.id) ' + @FromSQL1
            + @Condition              
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                    
                  
--     SELECT @CountSql              
                   
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                    
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                    
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                    
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                 
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                    
        SET @end = @PageIndex * @PageSize            
              
    --设置取字段信息必须关联的表          
        SET @FromSQL2 = 'INNER JOIN dbo.product a WITH (NOLOCK) ON temp.id = a.id' 
           
    --设置需要取的字段信息            
        SET @Column = ' a.id as productId, 
						a.code,
						a.category_id_1 as categoryId1,
						a.category_id_2 as categoryId2,
						a.category_id_3 as categoryId3,
						a.primary_picture_code as primaryPictureCode,           
						a.name,         
						a.cost_price AS costPrice,
						temp.join_time as joinTime 
					  '
	--组装基本查询的SQL      
	SET @BaseSQL = 'SELECT * from (              
         SELECT  p.id,
		 p2.join_time,
         ROW_NUMBER() OVER ( ORDER BY p2.join_time DESC ) rowIndex '              
                SET @BaseSQL = @BaseSQL + @FromSQL1 + @Condition
                    + ') temp2               
    where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
                    + CAST(@end AS NVARCHAR(10))   					        
    --组装最终取数的SQL          
         SET @SQL = 'select ' + @Column + ' from (' + @BaseSQL + ') temp '
            + @FromSQL2 + ' ORDER BY rowIndex'     
        print @SQL                
        EXEC(@SQL) ;            
        SELECT  @RowCount                  
    END


go


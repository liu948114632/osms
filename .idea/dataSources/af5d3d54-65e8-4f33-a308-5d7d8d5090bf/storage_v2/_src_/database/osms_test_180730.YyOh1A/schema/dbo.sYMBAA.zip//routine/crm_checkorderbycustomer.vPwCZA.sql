
--======================================      
--update Author:  <ll>      
-- Create date: <2014-09-11>      
-- Description: <检查客户订单>      
-- =============================================      
CREATE PROC dbo.CRM_CheckOrderByCustomer 
(
@OrderId VARCHAR(20),
@CustomerId INT,
@BuessId INT,
  @Result BIT OUT
)
AS      
BEGIN      
    SET @Result = CONVERT(BIT,0)
  IF EXISTS (SELECT TOP 1 1 FROM dbo.T_Order WHERE OrderId=@OrderId AND CustomerId=@CustomerId)
  BEGIN
  	           SET @Result = CONVERT(BIT,1)
  END
END

go


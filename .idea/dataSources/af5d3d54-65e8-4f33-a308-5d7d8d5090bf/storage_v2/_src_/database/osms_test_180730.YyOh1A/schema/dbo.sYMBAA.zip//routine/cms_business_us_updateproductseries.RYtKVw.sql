CREATE   PROC [dbo].[CMS_Business_US_UpdateProductSeries]
(
      @CategorySeriesId INT = NULL , --类别系列Id        
      @FirstProfitCoefficient DECIMAL(10, 6) = NULL , --第一段系数        
      @SecondProfitCoefficient DECIMAL(10, 6) = NULL , --第二段系数        
      @ThirdProfitCoefficient DECIMAL(10, 6) = NULL --第三段系数        
 )
AS 
    BEGIN                  
        SET NOCOUNT ON ;                
        DECLARE @ProductStr VARCHAR(MAX) ;  
        SET @ProductStr = '' ;  
        UPDATE  dbo.us_product
        SET     first_profit_coefficient = @FirstProfitCoefficient ,
                second_profit_coefficient = @SecondProfitCoefficient ,
                third_profit_coefficient = @ThirdProfitCoefficient
        WHERE   category_series_id = @CategorySeriesId         
     
        SELECT  @ProductStr = @ProductStr + ',' + CAST(product_id AS VARCHAR)
        FROM    ( SELECT    product_id
                  FROM      dbo.us_product
                  WHERE     category_series_id = @CategorySeriesId
                ) temp  
        IF @ProductStr !=''
        BEGIN
        SET @ProductStr = RIGHT(@ProductStr, LEN(@ProductStr) - 1)
        INSERT  INTO dbo.communication_log
                ( command ,
                  object_id ,
                  status ,
                  create_time ,
                  operator ,
                  model_type ,
                  execute_time    
                )
        VALUES  ( 'UPDATE_US_SALE_PRICE' ,
                  @ProductStr ,
                  1 ,
                  GETDATE() ,
                  0 ,
                  'PRODUCT' ,
                  NULL 
                )  
         END 
		--DECLARE @ProductStr2 VARCHAR(MAX) ;  
  --      SET @ProductStr2 = '' ;  
  --      UPDATE   dbo.us_domestic_product
  --      SET      profit_coefficient = @FirstProfitCoefficient 
                 
  --      WHERE   category_series_id = @CategorySeriesId         
     
  --      SELECT  @ProductStr2 = @ProductStr2 + ',' + CAST(product_id AS VARCHAR)
  --      FROM    ( SELECT    product_id
  --                FROM      dbo.uk_product a
		--		   JOIN uk_domestic_product b ON a.id =b.id
  --                WHERE     b.category_series_id = @CategorySeriesId
  --              ) temp  
  --      IF @ProductStr2 !=''
  --      BEGIN
  --      SET @ProductStr2 = RIGHT(@ProductStr, LEN(@ProductStr2) - 1)
  --      INSERT  INTO dbo.communication_log
  --              ( command ,
  --                object_id ,
  --                status ,
  --                create_time ,
  --                operator ,
  --                model_type ,
  --                execute_time    
  --              )
  --      VALUES  ( 'UPDATE_UK_DOMESTIC_SALE_PRICE' ,
  --                @ProductStr2 ,
  --                1 ,
  --                GETDATE() ,
  --                0 ,
  --                'PRODUCT' ,
  --                NULL 
  --              )  
  --       END  
		          
        SET NOCOUNT OFF ;             
    END
go



 
 CREATE PROC [dbo].[CRM_Order_IsOrderItemWritable]  
    (  
      @orderId VARCHAR(100) ,  
      @productId VARCHAR(100) ,  
      @errorMsg VARCHAR(200) OUTPUT ,  
      @returnValue INT OUTPUT  
    )  
AS   
    BEGIN     
        SET NOCOUNT ON    
    
  /*1.获取订单基本信息的限制条件*/  
        DECLARE @countryId INT = NULL;  
        DECLARE @deliveryId INT = NULL;  
        SELECT  @countryId = t3.CountryId ,  
                @deliveryId = t2.DeliveryId  
        FROM    dbo.T_OrderAddresses t1  
                INNER JOIN T_Order t2 ON t1.AddressId = t2.ShipAddressId  
                                         AND t2.OrderId = @OrderId  
                INNER JOIN dbo.T_Country t3 ON t1.Country = t3.CountryId;  
                
        PRINT '参数: '  
        PRINT '@countryId :' + CONVERT(VARCHAR(3), @countryId);  
        PRINT '@deliveryId:' + CONVERT(VARCHAR(3), @deliveryId);  
        PRINT ''  
        IF ( @countryId IS NULL  
             AND @deliveryId IS NULL  
           )   
            RAISERROR  ('参数异常:没有指定订单的出口国家和货运方式。' , 16, 1) WITH NOWAIT;              

               --自提订单不要任何限制
   IF(@DeliveryId=17)
   RETURN 

   EXEC CRM_Order_IsOrderInfoWritable @CMSProductIds=@productId,@CountryId=@countryId,@DeliveryId=@deliveryId,@ReturnValue=@returnValue OUT,@ErrorMsg=@errorMsg OUT
    END

 go


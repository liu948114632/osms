CREATE PROC dbo.CRM_Order_Detention_GetDMSUsers
AS
BEGIN
	SELECT  a.CreatorUserName,ROW_NUMBER() OVER(ORDER BY a.CreatorUserName) AS RowIndex  FROM dbo.T_OrderDetention a
	GROUP BY a.CreatorUserName
END

go


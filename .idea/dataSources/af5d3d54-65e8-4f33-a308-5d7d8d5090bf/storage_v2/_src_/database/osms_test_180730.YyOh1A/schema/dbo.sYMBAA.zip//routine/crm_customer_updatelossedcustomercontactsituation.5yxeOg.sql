

---修改挽回客户的联系情况
CREATE PROC CRM_Customer_UpdateLossedCustomerContactSituation ( @CustomerId INT )
AS
    BEGIN
        UPDATE  dbo.T_LossedCustomer
        SET     ContactNum = ISNULL(ContactNum,0) + 1 ,
                LastContactTime = GETDATE()
        WHERE   CustomerId = @CustomerId;

--UPDATE dbo.T_LossedCustomerNew SET ContactNum=ISNULL(ContactNum,0)+1,LastContactTime=GETDATE(),FirstContactTime=CASE WHEN ISDATE(FirstContactTime)=1 THEN FirstContactTime ELSE GETDATE() END   WHERE CustomerId=@CustomerId;

    END;

go


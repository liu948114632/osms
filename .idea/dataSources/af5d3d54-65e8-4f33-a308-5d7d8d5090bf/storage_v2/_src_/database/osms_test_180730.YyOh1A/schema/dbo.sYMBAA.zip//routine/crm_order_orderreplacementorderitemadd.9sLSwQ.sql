
-- =============================================    
-- Author:  HYD    
-- Create date: 2011-06-17    
-- Description: 确认替代增加订单商品    
-- =============================================    
CREATE PROCEDURE [dbo].[CRM_Order_OrderReplacementOrderItemAdd]    
 @OrderId VARCHAR(20) ,    
 @ProductId INT ,    
 @ItemPrice MONEY ,    
 @Quantity INT ,    
 @Unit NVARCHAR(20) ,    
 @UnitQuantity INT ,    
 @Weight INT ,    
 @SalePrice MONEY ,    
 @Volume DECIMAL(9, 3) ,    
 @IsProductPool BIT ,    
 @ISPROMOTE BIT,    
 @OrderItemId INT OUT    
AS    
BEGIN    
 -- SET NOCOUNT ON added to prevent extra result sets from    
 -- interfering with SELECT statements.    
 SET NOCOUNT ON;    
    
 INSERT  INTO dbo.T_OrderItem    
                ( OrderId ,    
                  ProductId ,    
                  ItemPrice ,    
                  Quantity ,    
                  ReadyQty ,    
                  Unit ,    
                  UnitQuantity ,    
                  Weight ,    
                  JoinDate ,    
                  [Type] ,    
                  CustomerRemark ,    
                  CSRemark ,    
                  UpdateTime ,    
                  Box ,    
                  [Status] ,    
                  SalePrice ,    
                  Volume ,    
                  ISPROMOTE ,    
                  IsProductPool,
                  IsPHReplaceProduct   
           )    
        VALUES  ( @OrderId ,    
                  @ProductId ,    
                  CAST(@ItemPrice AS DECIMAL(18, 2)) ,    
                  @Quantity ,    
                  0 ,--ReadyQty    
                  @Unit ,    
                  @UnitQuantity ,    
                  @Weight ,    
                  GETDATE() ,--JoinDate    
                  1 ,-- Type  --新增的替代品为3  
                  '',-- 商品备注    
                  '',-- 客服备注    
                  GETDATE() ,--UpdateTime    
                  1 ,--Box    
                  1 , -- Status    
                  @SalePrice ,    
                  @Volume ,    
                  @ISPROMOTE ,    
                  @IsProductPool,
                  1     
           ) ;    
     
        SET @OrderItemId = @@IDENTITY ;    
END
go


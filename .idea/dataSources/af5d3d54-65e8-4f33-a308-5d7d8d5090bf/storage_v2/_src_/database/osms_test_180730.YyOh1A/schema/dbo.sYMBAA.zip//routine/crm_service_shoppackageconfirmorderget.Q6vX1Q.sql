/*------------------------------------------      
备注:获得需要发包裹确认邮件的网店订单  
SMT,EBAY,TA-DZ-SMT,TA-DZ-EBAY,DZ-SMT,DZ-EBAY
创建日期:2012-06-20      
------------------------------------------------------*/      
CREATE PROC [dbo].[CRM_Service_ShopPackageConfirmOrderGet]        
AS       
BEGIN   
    SELECT o.OrderId,   
           T_OrderPackage.DueDate,
           o.OrderIndustryType
    FROM dbo.T_Order  o
    INNER JOIN T_OrderPackage ON o.OrderId = dbo.T_OrderPackage.OrderId  
   INNER JOIN dbo.T_ShopCustomer s ON s.OrderId=o.OrderId
    WHERE o.OrderStatus>60 AND DATEDIFF(DAY,DueDate,GETDATE())>25
   AND s.IsAutoSendConfirmArrivalEmail=1 AND s.IsAlreadySendConfirmArrivalEmail=0 AND o.OrderIndustryType IN (18,21,24,25,33,35) 
   AND s.ShopCustomerEmail>''
END
go


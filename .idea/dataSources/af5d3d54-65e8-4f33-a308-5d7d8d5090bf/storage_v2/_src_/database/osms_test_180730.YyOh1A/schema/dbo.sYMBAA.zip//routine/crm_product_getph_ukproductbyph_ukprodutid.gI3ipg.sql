-- =============================================    
-- Description: <根据C3商品ID获得PH-UK商品信息>  
-- =============================================   
CREATE PROC [dbo].[CRM_Product_GetPH_UKProductByPH_UKProdutId]      
(      
 @PH_UKProductId INT   
)      
AS      
BEGIN  
 SELECT  *
 FROM dbo.V_CRM_PH_UK_Product   
 WHERE WebProductId = @PH_UKProductId;  
END

go


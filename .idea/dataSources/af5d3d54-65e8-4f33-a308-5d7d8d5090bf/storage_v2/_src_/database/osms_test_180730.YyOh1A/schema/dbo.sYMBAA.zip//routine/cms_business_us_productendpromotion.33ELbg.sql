CREATE PROCEDURE [dbo].[CMS_Business_US_ProductEndPromotion]  
    (  
      @ProductIds VARCHAR(MAX) = NULL  
    )  
AS   
    BEGIN  
        DECLARE @ProductStr VARCHAR(MAX) ;   
        DECLARE @SQL VARCHAR(MAX) ;   
        SET @SQL = '';  
        SET @ProductStr = '';  
        IF @ProductIds IS NOT NULL AND @ProductIds != ''   
            BEGIN   
                SET @SQL = '                  
                INSERT INTO dbo.product_promote_us_history  
                        ( product_id ,  
                          discount ,  
                          start_time ,  
                          end_time ,  
                          Type ,  
                          is_bind_storage ,  
                          begin_storage ,  
                          join_user_id ,  
                          join_time ,  
                          is_promote ,
                          promote_type
                        )   
                  SELECT product_id,discount,start_time,  
                          end_time ,  
                          Type ,  
                          is_bind_storage ,  
                          begin_storage ,  
                          join_user_id ,  
                          join_time ,  
                          is_promote ,
                          promote_type FROM us_product_promote WHERE   product_id IN ('+ @ProductIds +' ) and type <> 3 and promote_activity_id IS NULL AND promote_area_id IS NULL and promote_type =0' ;   
                EXEC (@SQL);  
                
                SELECT  @ProductStr = STUFF(( SELECT ','
                                                + CONVERT(VARCHAR(50),a.id) 
                                                  FROM  us_product_promote AS a
                                                 INNER JOIN  dbo.uf_Split(@ProductIds,',') AS b ON a.product_id = b.Value
                                                    where a.type <> 3 and promote_type =0
                                     FOR XML PATH('')), 1, 1, '');   
                
                INSERT  INTO dbo.communication_log  
                        ( command ,  
                          object_id ,  
                          status ,  
                          create_time ,  
                          operator ,  
                          model_type ,  
                          execute_time,
                          promote_type    
						 )  
                VALUES  ( 'US_END_PROMOTE' ,  
                          @ProductStr ,  
                          1 ,  
                          GETDATE() ,  
                          0 ,  
                          'PROMOTE' ,  
                          NULL,
                          0   
                        )   
                SET @SQL ='DELETE FROM  us_product_promote WHERE   product_id IN (' + @ProductIds + ')  and type <> 3 and promote_activity_id IS NULL AND promote_area_id IS NULL and promote_type =0';    
                EXEC (@SQL);                         
            END  
        ELSE   
            BEGIN    
                INSERT INTO dbo.product_promote_us_history  
                        ( product_id ,  
                          discount ,  
                          start_time ,  
                          end_time ,  
                          Type ,  
                          is_bind_storage ,  
                          begin_storage ,  
                          join_user_id ,  
                          join_time ,  
                          is_promote ,
                          promote_type
                        )   
                  SELECT product_id,  
						  discount,  
						  start_time,  
                          end_time ,  
                          type ,  
                          is_bind_storage ,  
                          begin_storage ,  
                          join_user_id ,  
                          join_time ,  
                          is_promote ,
                          promote_type FROM  us_product_promote  WHERE  type <> 3 AND promote_activity_id IS NULL AND promote_area_id IS NULL     and promote_type =0       
                                     
				if object_id('tempdb..#tempUSEndPromote') is not null Begin DROP TABLE #tempUSEndPromote End
				CREATE TABLE #tempUSEndPromote(
					id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
					pid INT null
				)
				INSERT INTO #tempUSEndPromote(pid) SELECT id FROM dbo.us_product_promote WHERE type<>3 and promote_type =0

				DECLARE @Count INT, @Index INT
				SELECT @Count = COUNT(1) FROM #tempUSEndPromote;
				SET @Index = 0;
				 
				WHILE @Index < @Count
				BEGIN
				SELECT  @ProductStr = STUFF(( SELECT ',' + CONVERT(VARCHAR(50),pid) FROM #tempUSEndPromote WHERE id BETWEEN @Index+1 AND @Index + 2000  FOR XML PATH('')), 1, 1, '');
				                    
					--鎻掑叆閫氳鏃ュ織   
					INSERT  INTO dbo.communication_log  
							( command ,  
							  object_id ,  
							  status ,  
							  create_time ,  
							  operator ,  
							  model_type ,  
							  execute_time ,
							  promote_type   
				   )  
					VALUES  ( 'US_END_PROMOTE' ,  
							  @ProductStr ,  
							  1 ,  
							  GETDATE() ,  
							  0 ,  
							  'PROMOTE' ,  
							  NULL ,
							  0  
							) 
					SET @Index = @Index + 2000;
				END  
				DELETE FROM  us_product_promote  WHERE  type <> 3 and promote_activity_id IS NULL AND promote_area_id IS NULL and promote_type =0
            END  
    END

go


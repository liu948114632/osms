-- =============================================    
--获取商品装箱批体，批重和货运部批体，批重，CRM查看查看商品信息要2个都要显示
-- =============================================    
CREATE PROCEDURE [dbo].[CRM_Product_GetBoxDeliveryWeightAndBoxVolume]      
(    
 @CmsProductId  INT,  --CMS商品ID  
 @IsJl INT,--1：jL 0：不是JL  
 @BoxWeight  DECIMAL(18,3) OUT, -- 批量装箱重量  
 @BoxVolume  DECIMAL(18,3) OUT, -- 批量装箱体积    
  @DeliveryBoxWeight  DECIMAL(18,3) OUT, -- 货运部批重 
 @DeliveryBoxVolume  DECIMAL(18,3) OUT -- 货运部批体   
)    
AS    
BEGIN    

 DECLARE @categoryId  INT,-- 商品所在的最后一级类别    
         @SingleWeight DECIMAL(18,6) , -- 单重  
         @SingleVolume DECIMAL(18,6),  -- 单体  
         @UnitQuantity INT,             -- 批量单件数  
         @CategoryVolumeRate DECIMAL(9,2),-- 类别所在的重量体积转换系数    
         @WeightBoxRate DECIMAL(9,2),     -- 重量装箱系数   
         @VolumeBoxRate DECIMAL(9,2)    -- 体积装箱系数    
  
 SET @CategoryId = 0;    
 SET @CategoryVolumeRate = 0;    
 SET @SingleWeight = 0;    
 SET @SingleVolume = 0;   
 SET @UnitQuantity = 1;   
 SET @WeightBoxRate = 1.15 --默认值  
 SET @VolumeBoxRate = 1.3  --默认值  
  
 --1、获取该商品基本信息  
 SELECT @CategoryId = dbo.V_CRM_Base_Product.CategoryId,  
        @SingleWeight = ISNULL(dbo.V_CRM_Base_Product.weight,0),  
        @SingleVolume = ISNULL(dbo.V_CRM_Base_Product.volume,0),  
        --@UnitQuantity = ISNULL(dbo.V_CRM_Base_Product.UnitQuantity,0),    
        @UnitQuantity = CASE WHEN @IsJl = 1 THEN 1 ELSE ISNULL(dbo.V_CRM_Base_Product.UnitQuantity,0) END,
        @DeliveryBoxWeight=ProductWeight,
        @DeliveryBoxVolume=ProductVolume 
 FROM V_CRM_Base_Product  
 WHERE dbo.V_CRM_Base_Product.CmsProductId = @CmsProductId    

----如果C3已经设置了商品的批重，批体，则直接用C3 的，否则，按原逻辑算
--IF @IsJl=0 AND  @BoxWeight>0 AND @BoxVolume>0
-- RETURN;
  
 --2.1、取重量装箱系数  
 SET @WeightBoxRate = ISNULL((SELECT WeightRate FROM T_Category WITH(NOLOCK) WHERE CategoryId = @CategoryId),1.15)    
 IF @WeightBoxRate <= 0    
 BEGIN    
     SET @WeightBoxRate = 1.15    
 END   
  
 --2.2、取体积装箱系数  
  SELECT @VolumeBoxRate = ISNULL((CASE WHEN a.PackVolumeRate > 0 THEN a.PackVolumeRate  
          WHEN b.PackVolumeRate > 0 THEN b.PackVolumeRate  
          ELSE c.PackVolumeRate  
          END),1.3)  
  FROM dbo.T_Category a WITH(NOLOCK)   
  LEFT JOIN T_Category b WITH(NOLOCK) ON a.ParentId=b.CategoryId  
  LEFT JOIN T_Category c WITH(NOLOCK) ON b.ParentId=c.CategoryId  
    WHERE a.CategoryId=@CategoryId    
   
    IF @VolumeBoxRate <= 0    
 BEGIN    
     SET @VolumeBoxRate = 1.3; 
 END   
   
  
 --3、计算装箱重量  
 IF @IsJl = 1
 BEGIN
	SET @BoxWeight = ISNULL(@SingleWeight,0) * ISNULL(@UnitQuantity,0) * ISNULL(@WeightBoxRate,0)
 END 
 ELSE 
 BEGIN
	SET @BoxWeight = CEILING(ISNULL(@SingleWeight,0) * ISNULL(@UnitQuantity,0) * ISNULL(@WeightBoxRate,0))   	
 END 
  
 --4、计算装箱体积  
 --4.1、如果自身有体积，则按自身体积计算  
 IF @SingleVolume > 0  
 BEGIN  
     SET @BoxVolume = CONVERT(DECIMAL(18,3),ISNULL(@SingleVolume,0) * ISNULL(@UnitQuantity,0) * ISNULL(@VolumeBoxRate,0))  
 END   
 ELSE   
 BEGIN  
     --4.2、如果自身没有体积，则按重量转换  
     --4.2.1、先取出重量转体积系数  
  SELECT @CategoryVolumeRate = ISNULL((CASE WHEN a.VolumeRate > 0 THEN a.VolumeRate  
          WHEN b.VolumeRate > 0 THEN b.VolumeRate  
          ELSE c.VolumeRate  
          END),0)  
  FROM dbo.T_Category a WITH(NOLOCK)   
  LEFT JOIN T_Category b WITH(NOLOCK) ON a.ParentId=b.CategoryId  
  LEFT JOIN T_Category c WITH(NOLOCK) ON b.ParentId=c.CategoryId  
  WHERE a.CategoryId=@CategoryId    
  
  --4.2.2、如果没有重量转体积系数，则体积为0  
  IF @CategoryVolumeRate <= 0  
  BEGIN  
     SET @BoxVolume = 0  
  END   
  ELSE  
  BEGIN  
     SET @BoxVolume = CONVERT(DECIMAL(18,3),ISNULL(@SingleWeight,0) * ISNULL(@UnitQuantity,0) * ISNULL(@CategoryVolumeRate,0) * ISNULL(@VolumeBoxRate,0))  
  END   
 END   
 
END

go


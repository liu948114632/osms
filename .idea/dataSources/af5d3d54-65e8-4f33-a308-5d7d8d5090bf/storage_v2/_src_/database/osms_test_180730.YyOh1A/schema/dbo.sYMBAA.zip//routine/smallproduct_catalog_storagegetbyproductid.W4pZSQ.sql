






/*------------------------------------------------
[描述]
	小商品城根据商品的编号得到库存所有信息
----------------------------------------------*/
CREATE Procedure [dbo].[SmallProduct_Catalog_StorageGetByProductId] 
(
	@productId			INT
)
AS
BEGIN
--	SELECT 
--		ISNULL(B.[Id], 0) AS [Id],
--		A.[Id] AS [StockId],
--		ISNULL(B.[StorageQty], 0) AS [Quantity]
--	FROM B_Stock A LEFT JOIN B_Storage B ON A.[Id] = B.[StockId] AND B.[ProductId] = @productId
--	WHERE A.[Id] > 1 -- 深圳仓库没库存
	
	DECLARE @ProductDataId INT;
	SELECT @ProductDataId = ProductDataId
	FROM dbo.D_ProductRelation
	WHERE ProductId = @productId AND [TYPE] = 1;-- PH商品
	
	DECLARE @StorageQty	INT;
	SET @StorageQty = 0;
	EXEC [dbo].[CMS_Stock_ProductStorageGet] @ProductDataId,@StorageQty OUT;
	
	DECLARE @Unit VARCHAR(20),@UnitQuantity INT;
	SET @UnitQuantity = 1;
	SET @Unit = '';
	SELECT @Unit = Unit,@UnitQuantity = UnitQuantity FROM dbo.D_Product WHERE ProductDataId = @ProductDataId;
	IF @UnitQuantity <= 0 SET @UnitQuantity = 1;
	
	-- 只显示中心仓库库存
	SELECT 0 AS [Id],4 AS StockId,@StorageQty AS [Quantity],CAST(@StorageQty*1.0/@UnitQuantity AS DECIMAL(9,3)) AS ReqQuantity,@Unit AS Unit;  
	
		
END


go


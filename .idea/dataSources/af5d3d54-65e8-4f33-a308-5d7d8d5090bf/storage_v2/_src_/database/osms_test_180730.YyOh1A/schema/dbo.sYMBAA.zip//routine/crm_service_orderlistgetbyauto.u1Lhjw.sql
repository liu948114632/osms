

CREATE PROC dbo.CRM_Service_OrderListGetByAuto            
AS            
BEGIN            
 SET NOCOUNT ON;        
  WITH cte AS    
(      
 SELECT  a.OrderId ,-- 订单号            
        b.OrderIndustryType, --订单行业        
        b.CustomerId    
 FROM dbo.T_OrderPrepareImport a  WITH(NOLOCK)         
 INNER JOIN dbo.T_Order b   WITH(NOLOCK) ON a.OrderId=b.OrderId     
 INNER JOIN dbo.T_BusinessType c   WITH(NOLOCK) ON c.BusinessTypeValue=b.OrderIndustryType
 WHERE a.Status=1 AND (OrderIndustryType IN(1,5,6,16)  OR c.IsPHClone=1)AND b.OrderType=1 AND b.IsCanAutoImportOrder=1    
 UNION ALL       
 SELECT o.OrderId,       
        o.OrderIndustryType ,    
        o.CustomerId    
 FROM dbo.T_Order o      
 WHERE o.OrderStatus = 0 AND o.OrderType = 4 AND o.IsCanAutoImportOrder=1     
)   
SELECT o.*  
FROM cte o  
INNER JOIN dbo.T_Customer c ON c.UserID=o.CustomerId     
WHERE c.SuspicionMarking != 1--嫌疑客户的订单不自动录单    
END

go


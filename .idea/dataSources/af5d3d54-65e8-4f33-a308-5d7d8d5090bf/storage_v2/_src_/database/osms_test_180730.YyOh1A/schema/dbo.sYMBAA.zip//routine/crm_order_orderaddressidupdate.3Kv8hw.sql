
/*--------------------------------------------------
[备注]保存订单地址
------------------------------------------------------*/
CREATE PROC [dbo].[CRM_Order_OrderAddressIdUpdate]
(
  @OrderId		VARCHAR(20),
  @AddressId	INT,	-- 地址Id
  @Type			INT		-- 1：货运地址	2：账单地址
)
AS 
BEGIN
	IF @Type = 1
	BEGIN
		UPDATE dbo.T_Order SET ShipAddressId = @AddressId WHERE OrderId = @OrderId;
	END 
	ELSE 
	BEGIN
		UPDATE dbo.T_Order SET BillAddressId = @AddressId WHERE OrderId = @OrderId;
	END 
END
go


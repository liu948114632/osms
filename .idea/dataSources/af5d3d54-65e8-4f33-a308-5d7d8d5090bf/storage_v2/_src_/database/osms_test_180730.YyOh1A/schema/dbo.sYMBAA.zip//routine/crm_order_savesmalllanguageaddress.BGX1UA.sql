
CREATE PROC [dbo].[CRM_Order_SaveSmallLanguageAddress]
    (
      @OrderId VARCHAR(20) ,
      @Firstname NVARCHAR(50) ,
      @Lastname NVARCHAR(50) ,
      @Phone NVARCHAR(50) ,
      @Fax NVARCHAR(50) ,
      @Street1 NVARCHAR(200) ,
      @Street2 NVARCHAR(200) ,
      @City NVARCHAR(50) ,
      @Country INT ,
      @State NVARCHAR(50) ,
      @Zip NVARCHAR(50) ,
      @CompanyName VARCHAR(100) ,
      @AddressID INT
    )
AS 
    BEGIN
	
        EXEC SYS_PH_CRM_CustomerAddressAdd @Firstname, @Lastname, @Phone, @Fax,
            @Street1, @Street2, @City, @Country, @State, @Zip, @CompanyName,
            @AddressID OUT;
        
        
        DECLARE @Count INT;
        SELECT  @Count = COUNT(1)
        FROM    [T_SmllLanguageOrder]
        WHERE   [OrderId] = @OrderId;
        
        IF @Count = 0 
            BEGIN
                INSERT  INTO [dbo].[T_SmllLanguageOrder]
                        ( [OrderId], [EnglishAddressId] )
                VALUES  ( @OrderId, @AddressID );

            END
        ELSE 
            BEGIN
                UPDATE  [dbo].[T_SmllLanguageOrder]
                SET     [OrderId] = @OrderId ,
                        [EnglishAddressId] = @AddressID
                WHERE   [OrderId] = @OrderId;
            END
        
    END
go


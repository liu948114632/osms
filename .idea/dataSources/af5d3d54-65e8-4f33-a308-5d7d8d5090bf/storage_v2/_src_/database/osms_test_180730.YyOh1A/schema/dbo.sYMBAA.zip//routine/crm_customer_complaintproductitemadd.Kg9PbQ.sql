/**  
 新增投诉产品  
*/  
CREATE PROC CRM_Customer_ComplaintProductItemAdd  
(  
 @ComplaintId CHAR(13),  
 @CmsProductId INT,  
 @Content VARCHAR(max),  
 @Result VARCHAR(500),  
 @Expense DECIMAL(9,2),  
 @Tracer INT,  
 @DutyUser INT,  
 @Type INT,  
 @Status INT,  
 @Cause VARCHAR(2000),  
 @Mend VARCHAR(2000)  
)  
AS  
BEGIN  
 INSERT INTO dbo.T_ComplaintProductItem  
         ( ComplaintId ,  
           CmsProductId ,  
           [Content] ,  
           Result ,  
           Expense,  
           Tracer ,  
           DutyUser ,  
           [Type] ,  
           Status ,  
           Cause ,  
           Mend ,  
           CreateTime  
         )  
 VALUES  ( @ComplaintId , -- ComplaintId - char(13)  
           @CmsProductId , -- ProductId - int  
           @Content , -- Content - varchar(max)  
           @Result , -- Result - varchar(500)  
           @Expense,  
           @Tracer , -- Tracer - int  
           @DutyUser , -- DutyUser - int  
           @Type , -- Type - int  
           @Status , -- Stauts - int  
           @Cause , -- Cause - varchar(2000)  
           @Mend , -- Mend - varchar(2000)  
           GETDATE()  -- CreateTime - smalldatetime  
         ) SELECT @@IDENTITY;  
END
go



CREATE PROC dbo.CRM_Order_CancelOrderItemsForOrderModifyRecord        
 @OrderId varchar(20),      
 @OperatorId int ,--操作人      
 @OrderItemIds  VARCHAR(8000),  --订单项ID，多个之间用逗号隔开      
 @CancelReasons  VARCHAR(8000) --取消原因，多个之间用逗号隔开,原因应与取消项为1对1的关系      
AS        
BEGIN        
 -- SET NOCOUNT ON added to prevent extra result sets from        
 -- interfering with SELECT statements.        
 SET NOCOUNT ON;        
  
  --1、先判断是否能取消      
  DECLARE @OrderStatus INT       
  SELECT @OrderStatus = a.OrderStatus      
  From dbo.T_Order a        
  WHERE a.OrderId=@OrderId      
  
  If (@OrderStatus >45)        
  Begin        
                RAISERROR ('<info>订单校对中之后的状态不能修改订购量！</info>' , 16, 1) WITH NOWAIT;                
   RETURN;        
  End        
  
  --2、创建表变量,将多项转为多条行数据      
  Declare @TempOrderItems Table(OrderItemId Int,OrderIndex int);      
  Declare @TempCancelReason Table(Reason varchar(100),OrderIndex int);      
  
  -- 往@TempOrderItems插入订单商品Id        
  INSERT @TempOrderItems(OrderItemId,OrderIndex)        
  SELECT [value],ID      
  From dbo.uf_Split(@OrderItemIds,',');        
  
  -- 往@TempCancelReason插入各取消原因      
  INSERT @TempCancelReason(Reason,OrderIndex)        
  SELECT [value],ID      
  From dbo.uf_Split(@CancelReasons,',');        
  
 --3、取消商品        
 UPDATE b        
 SET b.[Status] = 12        
 FROM @TempOrderItems a         
 INNER JOIN dbo.T_OrderItem b ON a.OrderItemId = b.OrderItemId        
 WHERE b.OrderId = @OrderId      
  
 --4、记录订单项历史记录      
 --组装修改订单的历史记录      
 DECLARE @Remark VARCHAR(max),@ProductCodes VARCHAR(max)      
 SET @Remark = ''      
 SET @ProductCodes = ''      
 --组装取消的商品Code      
 SELECT @ProductCodes = @ProductCodes + ',' + c.code       
 FROM @TempOrderItems a         
 INNER JOIN dbo.T_OrderItem b ON a.OrderItemId = b.OrderItemId      
 INNER JOIN dbo.V_CRM_Base_Product c ON b.CmsProductId = c.CmsProductId      
 WHERE b.OrderId = @OrderId      
  
 --增加订单历史:取消商品Code      
 IF LEN(@ProductCodes) > 0      
 BEGIN      
    SET @ProductCodes = SUBSTRING(@ProductCodes,2,LEN(@ProductCodes) - 1)      
 END       
  
 SET @Remark = '取消商品:' + @ProductCodes      
 EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = @OperatorId,  @OrderId = @OrderId, @Remark = @Remark       
  
 --5、记录订单项取消记录(报表系统用)      
 INSERT  INTO dbo.T_OrderItemCancelRecord        
 ( OrderItemId ,        
   ProductCode ,        
   Operator ,        
   OperateTime ,        
   Reason        
   )        
 SELECT a.OrderItemId,b.ItemCode,@OperatorId,GETDATE(),c.Reason      
 FROM @TempOrderItems a      
 INNER JOIN dbo.T_OrderItemProduct b ON a.OrderItemId=b.OrderItemId      
 LEFT JOIN @TempCancelReason c ON a.OrderIndex = c.OrderIndex      
  
END
go


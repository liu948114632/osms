/* 获取订单对象 */  
CREATE PROC [dbo].[CRM_Order_UpdateOrderGet]                                          
(                                          
  @OrderId VARCHAR(20) = ''                                          
)                                          
AS                                           
DECLARE @Weight INT ,                                          
@ReadyWeight INT ,                                          
@Price DECIMAL(18, 2) ,                                          
@ReadyPrice DECIMAL(18, 2) ,                                          
@Freight DECIMAL(18, 2) ,                                          
@ReadyFreight DECIMAL(18, 2) ,
  @ExcludeOverseaPrice DECIMAL(18, 2) ,                                          
@ExcludeOverseaReadyPrice DECIMAL(18, 2)                                           
BEGIN                                          
	-- 获取该订单有效的重量与到货重量(考虑体积)                                          
    EXEC CRM_Price_OrderValidWeightGet @OrderId, @Weight OUT,@ReadyWeight OUT ;                                          
                              
	-- 获取该订单商品和到货商品的价值                                          
    EXEC CRM_Price_OrderPriceGet @OrderId, @Price OUT, @ReadyPrice OUT ;     
   
             --排除海外仓商品的货物价值
       EXEC CRM_Price_OrderPriceExcludeOverseaProductGet  @OrderId,@ExcludeOverseaPrice OUT,@ExcludeOverseaReadyPrice OUT;                                      
                              
	-- 获取订单运费以及到货商品运费                                          
    --EXEC [dbo].[CRM_Price_OrderFreightGet] @OrderId, @Freight OUT, @ReadyFreight OUT ;                                          
    /* 2014-12-20 mzc 取运费快照 */
    EXEC dbo.CRM_Order_CalculateOrderFreightWithDiscountBySnapshot @OrderId, @Freight OUT, @ReadyFreight OUT ;   
                              
    SELECT  a.OrderId ,                                          
            a.CustomerId ,                                          
            a.OrderType ,                                          
            a.ShipAddressId ,                                          
            a.BillAddressId ,                                          
            a.OrderDiscount ,                                          
            a.OrderStatus ,                                          
            @Price AS Price , -- 订单商品价值                                           
            @ReadyPrice AS ActualPrice , -- 到货商品价值
          @ExcludeOverseaPrice AS    ExcludeOverseaPrice,--排除海外仓商品价值                           
            @Weight AS Weight , -- 订单重量                                          
            @ReadyWeight AS ActualWeight , -- 订单到货商品重量                                          
            a.Freight , -- 订单运费(维护的)                                          
            @ReadyFreight AS ActualFreight , -- 统计订单实际运费                                          
            a.DeliveryId ,              
            a.IsFreeShipping,--是否免运费                                        
            a.PayStatus ,                                          
            a.OrderDate ,                                          
            c.OrderRemark ,                                          
            a.DelayStatus , -- 订单延迟状态                                          
            a.Priority , -- 订单优先级                                          
            ISNULL(a.IsRemote, 0) AS IsRemote ,                                          
            a.LastModifyTime ,                                          
            c.PrintRemark ,                                          
            ISNULL(a.PostWeight, 0) AS PostWeight ,                                          
            a.IsActualInvoice ,                                          
            a.IsSend ,                                          
            a.DelayUpdateDate ,                                          
		   a.IsAutoOrder ,       
            a.IsAutoDelay,                                         
            a.IsInvoice , -- 是否已做发票                                          
            c.PendingRemark ,                           
            c.[BranchRemark] ,                                          
            a.HandlerId ,                                          
            a.IsBalance , -- 是否已经结算                                         
            ISNULL(a.CollateStatus, 0) AS CollateStatus ,                                          
            ISNULL(a.CollateUser, 0) AS CollateUser ,                     
            a.CPFCode , --巴西税号                                          
            a.IsNeedProcessing , --需加工                                          
            a.IsIncludeShippingFee ,--是否包含运费                     
            a.SubTotalPercent , --发票金额百分比                           
            a.IsPartPayment ,--是否开启部分付款             
            a.OrderIndustryType,                                      
            a.AutoDelayDate, --自动发货时间              
            a.CollateDate,                          
            a.IsModifyFreight,                          
            a.IsConfirmReplace,                        
            a.TaxCodeType ,               
            a.IsQualityInspection ,              
            A.SubType,                  
            a.lang,          
            a.IsOverseasWarehouseOrder,          
            a.OverseasWarehouseStatus,          
            a.IsCommunicationCMS,
            a.ResendStatus,
			a.OrderCheckStatus,
   CASE WHEN a.Currency is NULL         
   THEN (SELECT b.currency FROM dbo.T_Currency b WHERE b.id=1)        
   ELSE (SELECT b.currency FROM dbo.T_Currency b WHERE b.id=a.currency)        
   END  AS Currency,        
           ISNULL(a.Rate,(SELECT b.rate FROM dbo.T_Currency b WHERE b.id=1)) AS Rate,        
           a.Currency AS CurrencyId,    
           a.IsSendLeaflet,  
           ISNULL(a.FreightDiscount,0) AS FreightDiscount,
           a.FreeShipSurcharge,  
           a.FreeShipDeliveryRange,
           ISNULL(a.DeliveryPromoteActivityId ,0) AS DeliveryPromoteActivityId,
           
		a.CustomsClearanceProportion,
		a.DischargeTaskStatus,
		a.RateVersion,
		a.ForceGoOverseas,
		a.IsNotRegisteredCustomerOrder,
		a.IsAutoBalance,
		a.SendGroupID,
		a.DmsInvoiceRemark,
		a.DeliveryDate,
		a.DeliveryUserName,
		d.TraceNo,
		d.IsCashOrder,
		ISNULL(d.OrderPayIsCommunicationCMS,0) AS OrderPayIsCommunicationCMS,
		c.ServiceRemark,
		c.DMSOrderShippingRemark
    FROM    dbo.T_Order a  with(UPDLOCK)        
            JOIN dbo.T_OrderRemark c with(UPDLOCK) ON a.OrderId = c.OrderId     
			LEFT JOIN dbo.T_OrderExtend d WITH(UPDLOCK) ON a.OrderId=d.OrderId
    WHERE a.OrderId=@OrderId                                       
END

go


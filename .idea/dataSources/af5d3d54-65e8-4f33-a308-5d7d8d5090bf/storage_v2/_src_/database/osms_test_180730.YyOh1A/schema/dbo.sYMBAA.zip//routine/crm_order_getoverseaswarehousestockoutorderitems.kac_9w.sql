

    
/**    
获取订单的海外仓出库单项    
*/    
CREATE PROC CRM_Order_GetOverseasWarehouseStockOutOrderItems    
(    
  @OrderId VARCHAR(20),    
  @StockOutCode VARCHAR(30),    
  @PageNo INT = 0 ,                                                          
  @PageSize INT = 20            
)    
AS    
BEGIN    
       DECLARE @Sql NVARCHAR(MAX) ,                                                          
        @CountSql NVARCHAR(MAX) ,                                                          
        @Where NVARCHAR(MAX) ,                                                          
        @Parameters NVARCHAR(1000) , -- 动态参数      
        @From NVARCHAR(MAX) ,                                                        
        @PageCount INT ,                                                          
        @RowCount INT ,                                                          
        @Start INT , --每页的起始位置                                                          
        @End INT  --每页的终止位置        
                                                                                                                  
        SET NOCOUNT ON ;       
            
     --查询的表    
     SET @From = ' FROM  dbo.T_OrderItem a WITH(NOLOCK)    
        INNER JOIN dbo.T_OrderItemProduct b WITH(NOLOCK) ON a.OrderItemId=b.OrderItemId    
        INNER JOIN T_OverseasWarehouseStockOutOrderItem d  WITH(NOLOCK) ON a.OrderItemId=d.OrderItemId    
        LEFT JOIN T_OverseasWarehouseProduct c WITH(NOLOCK) ON d.StorageNo=c.CK1StorageNo  
        WHERE 1=1 '    
            
     --条件    
     SET @Where = ' AND a.OrderId=''' + @OrderId + ''' AND d.StockOutCode=''' + @StockOutCode + '''' ;       
      
     -- 组合查询语句                                                          
     SET @CountSql = ' Select @pRowCount = Count(1) '  +  @From + @Where    
     SET @Parameters = N'@pRowCount INT OUT' ;        
            
     -- 获取总记录数                                                          
     EXEC sp_executesql @CountSql, @Parameters, @pRowCount = @RowCount OUT    
     -- 分页参数设置，并最终返回页数和总记录数    
     EXEC [dbo].[CRM_PageCountGet] @PageNo, @PageSize, @RowCount, @Start OUT, @End OUT ;     
         
     SET @Sql = 'SELECT a.OrderItemId,    
             a.OrderId,    
             a.CmsProductId,    
             a.ProductId,    
             a.Quantity,    
             a.UnitQuantity,    
             a.Unit,    
             a.ReadyQty,                 
             a.Weight,    
             a.Volume,    
             a.ItemPrice,    
             a.SalePrice,    
             a.CostPrice,    
             b.ItemCode AS ProductCode,    
             c.CK1StorageNo,    
             ROW_NUMBER() OVER(ORDER BY a.OrderItemId) AS RowNumber'    
                 
    SET @Sql = 'SELECT * FROM (' + @Sql + @From + @Where + ') temp     
              Where RowNumber BETWEEN @pStart AND @pEnd '    
                  
    SET @Parameters = N'@pStart INT,@pEnd INT' ;      
                  
    EXEC sp_executesql @Sql, @Parameters, @pStart = @Start, @pEnd = @End    
END
go



CREATE VIEW view_ph_product_hot 
AS 
SELECT a.product_id,
  (CASE WHEN MAX(ISNULL(c.category_id_3,0))<>0 THEN MAX(c.category_id_3)	
	   WHEN MAX(ISNULL(c.category_id_2,0)) <> 0 THEN MAX(c.category_id_2)
	   ELSE MAX(ISNULL(c.category_id_1,0)) END 
  )AS category_id,
 COUNT(DISTINCT a.order_id) AS order_count, --订单数量
 CEILING(SUM(a.order_quantity*1.0/a.unit_quantity)/3)*2 AS  batch_quantity-- 销售批量
 ,CEILING(SUM(a.order_quantity*1.0/a.unit_quantity)/3)* MAX(c.unit_quantity)*2 AS  sale_quantity-- 销售数量
 ,MAX(d.id) AS ph_product_id
FROM dbo.order_item AS a
JOIN dbo.[order] AS b ON a.order_id = b.id
JOIN dbo.product AS c ON a.product_id  = c.id --AND c.is_gift = 0 
JOIN dbo.ph_product AS d ON d.product_id = c.id 
WHERE b.status < 132 -- 排除取消订单
AND a.status <>12
AND b.order_time > DATEADD(MONTH,-3,CONVERT(VARCHAR(7),GETDATE(),25) + '-01') -- 录单时间
AND b.order_time < CONVERT(VARCHAR(7),GETDATE(),25) + '-01'
GROUP BY a.product_id HAVING COUNT(DISTINCT a.order_id) >=3 AND CEILING(SUM(a.order_quantity*1.0/a.unit_quantity))>=9

go


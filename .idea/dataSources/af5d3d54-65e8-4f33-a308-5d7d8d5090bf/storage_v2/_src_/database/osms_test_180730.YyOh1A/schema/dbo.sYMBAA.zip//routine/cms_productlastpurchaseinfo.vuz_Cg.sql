CREATE PROCEDURE [dbo].[CMS_ProductLastPurchaseInfo]

AS
BEGIN
	SET NOCOUNT ON;
	--最近采购成本价
		UPDATE a SET a.last_purchase_price =purchase_price,a.last_purchase_discount = discount,a.last_purchase_provider_id=provider_id,							last_purchase_time=create_time from
		 dbo.product a JOIN (
			SELECT z.*,ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY create_time DESC )AS rowindex  FROM (
			SELECT a.purchase_price,a.discount,a.provider_id,b.create_time,a.product_id FROM purchase_item a,dbo.purchase b
			WHERE a.purchase_id = b.id
			AND b.status = 80 AND a.is_deleted =0
			AND a.completion_quantity > 0 AND a.purchase_price > 0 
			UNION
			SELECT processing_cost_price AS purchase_price,0 AS discount ,c.provider_id,a.completion_time AS create_time,a.product_id
			 FROM dbo.processing a
			 JOIN dbo.product_provider c ON c.product_id =a.product_id AND c.department_id =a.department_id
	 		WHERE a.status = 50 
			AND actual_processing_quantity > 0
			) z 
			) z1 on z1.product_id =a.id AND rowindex = 1  
			
			
			
	
	----最近采购成本价
	--UPDATE dbo.product SET last_purchase_price =
	--(
	--SELECT TOP 1 purchase_price
	--	FROM (
	--	SELECT * FROM (
	--		SELECT TOP 1 a.purchase_price,b.create_time,a.product_id FROM purchase_item a,dbo.purchase b
	--		WHERE a.purchase_id = b.id
	--		AND a.product_id = dbo.product.id
	--		AND b.status = 80 AND a.is_deleted =0
	--		AND a.completion_quantity > 0 AND a.purchase_price > 0
	--		ORDER BY b.id DESC) a
	--		UNION
	--		SELECT purchase_price,create_time,product_id FROM (
	--		SELECT TOP 1 (itemPurchasePrice + ISNULL(dbo.processing.processing_cost,0))/processing.actual_processing_quantity AS purchase_price,processing.product_id,processing.completion_time AS create_time
	--		 FROM dbo.processing join
	--		(SELECT SUM(ISNULL(p.cost_price,0) * ISNULL(item.used_quantity,0))AS itemPurchasePrice,item.processing_id  
	--		FROM dbo.processing_item AS item JOIN dbo.product AS p
	--		ON p.id = item.product_id
	--		WHERE item.status <> 4
	--		GROUP BY item.processing_id)AS a
	--		ON dbo.processing.id = a.processing_id
	--		WHERE dbo.processing.status = 50 
	--		AND actual_processing_quantity > 0
	--		AND dbo.processing.product_id = dbo.product.id
	--		ORDER BY processing.id DESC
	--	)b
	--) AS temp
	--ORDER BY temp.create_time DESC
	--)
	--WHERE dbo.product.status = 4 AND dbo.product.is_delete = 0
	
  -- UPDATE dbo.product SET last_purchase_discount =(SELECT TOP 1	discount FROM (
		--select 
		--	a.discount AS discount,b.create_time AS createTime	
		--	 from dbo.purchase_item AS a,dbo.purchase AS b where a.purchase_Id = b.id 
		--	and b.status = 80
		--	and a.is_deleted = 0
		--	and a.completion_quantity > 0 
		--	and a.purchase_price > 0 
		--	and a.product_id = product.id
		--	UNION 
		--	SELECT 
		--	0 AS discount,b.completion_time AS createTime
		--	FROM    dbo.processing_item AS a
		--			JOIN dbo.processing AS b WITH ( NOLOCK ) ON a.processing_id = b.id
		--			LEFT JOIN dbo.product_provider AS pp WITH ( NOLOCK ) ON pp.product_id = a.product_id AND pp.department_id = b.department_id
		--			JOIN dbo.product AS pjProduct WITH(NOLOCK) ON a.product_id = pjProduct.id
		--	WHERE b.status = 50 --财务确认完成加工单
		--		AND b.product_id = product.id
		--	)z ORDER BY createTime DESC) WHERE dbo.product.status = 4 AND dbo.product.is_delete = 0
			
	
		 --UPDATE dbo.product SET last_purchase_provider_id =(SELECT TOP 1	lastPurchaseProvider  from (select 
			--	a.provider_id AS lastPurchaseProvider,b.create_time AS createTime	
			--	 from dbo.purchase_item AS a JOIN dbo.purchase AS b on a.purchase_Id = b.id 	
			--	--LEFT JOIN dbo.provider WITH ( NOLOCK ) ON provider.id =a.provider_id
			--	WHERE 
			--	 b.status = 80
			--	and a.is_deleted = 0
			--	and a.completion_quantity > 0 
			--	and a.purchase_price > 0 
			--	and a.product_id = product.id
			--	UNION 
			--	SELECT 
			--	ISNULL(pp.provider_id,'''') AS lastPurchaseProvider,
		 --      b.completion_time AS createTime
			--	FROM    dbo.processing_item AS a
			--			JOIN dbo.processing AS b WITH ( NOLOCK ) ON a.processing_id = b.id
			--			LEFT JOIN dbo.product_provider AS pp WITH ( NOLOCK ) ON pp.product_id = a.product_id AND pp.department_id = b.department_id
			--			--LEFT JOIN dbo.provider WITH ( NOLOCK ) ON provider.id =pp.provider_id
			--	WHERE b.status = 50 --财务确认完成加工单
			--	AND b.product_id = product.id) z ORDER BY createTime DESC)   WHERE dbo.product.status = 4 AND dbo.product.is_delete = 0
				
	
	--上次采购时间
	--UPDATE dbo.product SET last_purchase_time =
	--(SELECT TOP 1 b.create_time FROM purchase_item a,dbo.purchase b
	--WHERE a.purchase_id = b.id
	--AND dbo.product.id = a.product_id 
	--AND b.status = 80 AND a.is_deleted =0
	--AND a.completion_quantity > 0 AND a.purchase_price > 0
	--ORDER BY b.id desc)
	--WHERE dbo.product.status = 4 AND dbo.product.is_delete = 0
	----AND dbo.product.id = 680532
	--;
	--UPDATE dbo.product SET last_purchase_time =
	--(
	--SELECT TOP 1 create_time
	--	FROM (
	--	SELECT * FROM (
	--		SELECT TOP 1 a.purchase_price,b.create_time,a.product_id FROM purchase_item a,dbo.purchase b
	--		WHERE a.purchase_id = b.id
	--		AND a.product_id = dbo.product.id
	--		AND b.status = 80 AND a.is_deleted =0
	--		AND a.completion_quantity > 0 AND a.purchase_price > 0
	--		ORDER BY b.id DESC) a
	--		UNION
	--		SELECT purchase_price,create_time,product_id FROM (
	--		SELECT TOP 1 (itemPurchasePrice + ISNULL(dbo.processing.processing_cost,0))/processing.actual_processing_quantity AS purchase_price,processing.product_id,processing.completion_time AS create_time
	--		 FROM dbo.processing join
	--		(SELECT SUM(ISNULL(p.cost_price,0) * ISNULL(item.used_quantity,0))AS itemPurchasePrice,item.processing_id  
	--		FROM dbo.processing_item AS item JOIN dbo.product AS p
	--		ON p.id = item.product_id
	--		GROUP BY item.processing_id)AS a
	--		ON dbo.processing.id = a.processing_id
	--		WHERE dbo.processing.status = 50 
	--		AND actual_processing_quantity > 0
	--		AND dbo.processing.product_id = dbo.product.id
	--		ORDER BY processing.id DESC
	--	)b
	--) AS temp
	--ORDER BY temp.create_time DESC
	--)
	--WHERE dbo.product.status = 4 AND dbo.product.is_delete = 0
	
	
	--AND dbo.product.id = 680532
	;
	--最低采购成本价
	--UPDATE dbo.product SET lowest_purchase_price =
	--(SELECT MIN(a.purchase_price) FROM dbo.purchase_item a , dbo.purchase b 
	--	WHERE a.purchase_id = b.id AND a.completion_quantity > 0 AND a.purchase_price > 0
	--	AND a.is_deleted = 0 AND dbo.product.id = a.product_id AND b.status = 80
	--)
	--WHERE dbo.product.status = 4 AND dbo.product.is_delete = 0
	----AND dbo.product.id = 765563
	--;
	
	UPDATE dbo.product SET lowest_purchase_price =
	(
	SELECT ISNULL(MIN(purchase_price),0.000000) FROM
	(
	SELECT MIN(a.purchase_price) AS purchase_price 
		FROM dbo.purchase_item a , dbo.purchase b 
		WHERE a.purchase_id = b.id AND a.completion_quantity > 0 AND a.purchase_price > 0
		AND a.is_deleted = 0 AND a.product_id = dbo.product.id  AND b.status = 80
	UNION
 	SELECT MIN(processing_cost_price) AS purchase_price 
		 FROM dbo.processing 
		WHERE dbo.processing.status = 50 
		AND actual_processing_quantity > 0
		AND dbo.processing.product_id = dbo.product.id
	)AS a
	)
	WHERE dbo.product.status = 4 AND dbo.product.is_delete = 0	
END
go


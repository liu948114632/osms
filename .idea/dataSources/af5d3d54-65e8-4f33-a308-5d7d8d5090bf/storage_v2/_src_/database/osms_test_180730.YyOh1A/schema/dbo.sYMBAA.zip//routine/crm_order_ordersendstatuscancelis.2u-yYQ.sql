


/*----------------------------------------------------
[备注] 
	判断订单是否取消可发货状态
--------------------------------------------------------*/
CREATE PROC [dbo].[CRM_Order_OrderSendStatusCancelIs]
(
	@OrderId			VARCHAR(20),
	@IsCancel			BIT OUT
)

AS
DECLARE
	@IsSend				BIT,
	@Price				DECIMAL(9,2),
	@ReadyPrice			DECIMAL(9,2),
	@Freight			DECIMAL(9,2),
	@OrderPrice			DECIMAL(9,2),
	@Pay				DECIMAL(9,2)
BEGIN
	SET @IsSend = 0;
	SET @Price = 0;
	SET @Pay = 0;
	
	-- 获取订单可发货状态和应付款
	SELECT @IsSend = IsSend,@Freight = [Freight] FROM dbo.T_Order WHERE OrderId = @OrderId;
	
	-- 获取订单的商品价值
	EXEC dbo.CRM_Price_OrderPriceGet @OrderId,@Price OUTPUT,@ReadyPrice OUTPUT;
	


	SET @OrderPrice = @Price + @Freight;

	IF @IsSend = 1 -- 当前订单处于可发货
	BEGIN
		-- 获取订单已付款
		EXEC CRM_Order_OrderPaymentGet @OrderId,@Pay OUT;

		-- 未完全付款,可以取消可发货标志
		IF @OrderPrice > @Pay
			SET  @IsCancel = 1;
	END
	ELSE
	BEGIN
		SET @IsCancel = 0;
	END
END
go


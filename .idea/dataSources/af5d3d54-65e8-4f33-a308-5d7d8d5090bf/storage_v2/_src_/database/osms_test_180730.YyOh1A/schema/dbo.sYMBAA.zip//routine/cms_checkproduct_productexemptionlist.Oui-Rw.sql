



CREATE PROC dbo.CMS_CheckProduct_ProductExemptionList(
	@CategoryId1 INT = NULL,--一级类别
	@CategoryId2 INT = NULL,--二级类别
	@CategoryId3 INT = NULL,--三级类别
	@IsExemption INT = NULL,--是否免检
	@JoinBeginDate NVARCHAR(100) = NULL,--属性1
	@JoinEndDate NVARCHAR(100) = NULL,--属性2
	@ProductCode VARCHAR(22) = NULL,--产品编号
	@ProductCodes VARCHAR(MAX) = NULL,--产品编号
	@ProductName VARCHAR(MAX) = NULL,--产品名称
	@ProviderCode NVARCHAR(50)=NULL,
	@ProviderCodes NVARCHAR(MAX)=NULL,
	@Level INT= NULL,
	@StrategyDepartmentId INT = NULL,--部门Id
	@exemptionLevel VARCHAR(20)=NULL,
	@PageSize INT = 50 ,  --页大小              
	@PageIndex INT = 1    --当前页号    
)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE
		@SQL VARCHAR(max),              
        @CountSql NVARCHAR(MAX), --查询数量用              
        @FromSQL NVARCHAR(max), --查询内表            
        @Column NVARCHAR(max), --取的字段            
        @Condition varchar(MAX), --条件               
        @RowCount INT , 
        @PageCount INT , 
        @start INT ,
        @end INT
      
		--设置查询主表
		SET @FromSQL = ' FROM  
						  product P WITH(NOLOCK)
						 left JOIN exemption_product PH WITH(NOLOCK) ON PH.product_id = P.id 
						left join dbo.product_strategy  a WITH(NOLOCK) ON a.product_id =p.id 
						left join dbo.product_provider c WITH(NOLOCK) ON c.product_id =p.id AND c.department_id =a.department_id 
						left join dbo.provider d WITH(NOLOCK) ON d.id = c.provider_id
						left join product_description e  WITH(NOLOCK) on e.product_id = p.id
						LEFT JOIN dbo.complaint_product_level_ratio f WITH(NOLOCK)  ON f.product_id =p.id ';			 
		--设置查询条件
		SET @Condition = ' WHERE 1=1 AND p.is_delete = 0 and p.status=4 '
		IF @CategoryId1 IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND P.category_id_1=' + CONVERT(VARCHAR(10), @CategoryId1)
		END
		IF @CategoryId2 IS NOT NULL 
		BEGIN
			SET @Condition = @Condition + ' AND P.category_id_2=' + CONVERT(VARCHAR(10), @CategoryId2)
		END
		IF @CategoryId3 IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND P.category_id_3=' + CONVERT(VARCHAR(10), @CategoryId3)
		END
		IF @JoinBeginDate IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND p.upload_time>=''' + CONVERT(VARCHAR(100), @JoinBeginDate)+''''
		END
		IF @JoinEndDate IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND p.upload_time<=''' + CONVERT(VARCHAR(100), @JoinEndDate)+''''
		END
		IF @ProductCode IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND P.code like ''' + @ProductCode + '%''';
		END
		IF @ProductCodes IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND P.code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')'   
		END
		IF @ProductName IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND P.name like ''%' + @ProductName + '%''';
		END
		IF @ProviderCode IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND d.code like ''' + @ProviderCode + '%''';
		END
		IF @ProviderCodes IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND d.code in (''' + REPLACE(@ProviderCodes,',',''',''') + ''')'   
		END
		IF @StrategyDepartmentId  IS NOT NULL
		BEGIN
			SET @Condition = @Condition + ' AND a.department_id  =' + CONVERT(VARCHAR(10), @StrategyDepartmentId)  
		END
		IF @Level IS NOT NULL 
		BEGIN
			SET @Condition = @Condition + ' AND f.level  =' + CONVERT(VARCHAR(10), @Level)  
		END
		IF @ProductName IS NOT NULL 
		BEGIN
			SET @Condition = @Condition + ' AND P.name like ''%' + @ProductName + '%''';
		END	
		IF @exemptionLevel IS NOT NULL
		BEGIN
		    SET @Condition = @Condition + ' AND isNUll(PH.exemption_level,''C级'') = ''' + @exemptionLevel + '''';
		END
	
	--设置查询列
	SET @Column = ' 
					p.id AS productId ,
					PH.join_user as joinUser,
					p.upload_time as joinDate,
					isNUll(PH.exemption_level,''C级'') as exemptionLevel,
					PH.last_operater_id as lastOperaterId,
					PH.last_operater_date as lastOperaterDate,
					P.code as productCode ,
					P.name as productName ,
					P.unit_quantity AS unitQuantity ,
					P.unit ,
					d.code as providerCode,
					a.department_id as strategyDepartmentId,
					f.level,
					e.chinese_description as productDescription,
					P.primary_picture_code AS primaryPictureCode ,
					P.color_card_picture_code as colorCardPictureCode,
					ROW_NUMBER() OVER ( ORDER BY p.id DESC ) RowIndex ';
				   
	--查询记录数
	SET @CountSQL = '';
	SET @CountSQL = 'SELECT @RowCountOUT=count(P.id) ' + @FromSQL + @Condition;
	--print @CountSQL;
	EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;	

   	--查询的分页条件
	IF ISNULL(@PageSize, 0) < 1                       
		SET @PageSize = 50                      
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                      
    IF ISNULL(@PageIndex, 0) < 1                       
        SET @PageIndex = 1                      
    ELSE                       
    IF ISNULL(@PageIndex, 0) > @PageCount                       
        SET @PageIndex = @PageCount                      
    SET @Start = ( @PageIndex - 1 ) * @PageSize + 1                      
    SET @End = @PageIndex * @PageSize  
    			   
	--组装查询语句
		SET @SQL = 'SELECT  ' + @Column + @FromSQL + @Condition+') z';
	
		SET @SQL = 'SELECT * FROM (' + @SQL + ' WHERE RowIndex between '
				 + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';
	PRINT @SQL
	EXEC(@SQL);                        
    select @RowCount  					   
END

go


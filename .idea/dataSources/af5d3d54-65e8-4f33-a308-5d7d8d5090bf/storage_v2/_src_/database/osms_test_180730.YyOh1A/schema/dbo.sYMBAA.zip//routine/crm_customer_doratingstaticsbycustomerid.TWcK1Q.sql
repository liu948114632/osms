
CREATE PROC dbo.CRM_Customer_DoRatingStaticsByCustomerId
(
@CustomerId INT 
)
AS
    BEGIN

        SET NOCOUNT ON;
        IF OBJECT_ID('tempdb..#UpdateInfo') IS NOT NULL
            BEGIN
                DROP TABLE #tempTable
            END
		
        CREATE TABLE #UpdateInfo
            (
              CustomerId INT ,
              [EmailId] VARCHAR(50) ,
              Price1 DECIMAL ,
              Price2 DECIMAL ,
              Price DECIMAL ,
              [Name] VARCHAR(50) ,
              [NextRate] INT ,
              [LEVEL] VARCHAR(50) ,
              [Percent] DECIMAL ,
              CustomerName NVARCHAR(101) ,
              IsVip INT ,
              GroupType VARCHAR(10) ,
              LastOrderLanguage INT,
              CurrentRate INT,
              isChangeLevel BIT
            );
            WITH    cte
                      AS (
                           SELECT   a.CustomerId ,
                                    SUM(b.Quantity * b.ItemPrice * 1.0
                                        / b.UnitQuantity) AS OrderPrice ,
                                    c.GroupId AS GroupType
                           FROM     dbo.T_Order a  WITH(NOLOCK)
                                    INNER JOIN dbo.T_OrderItem b WITH(NOLOCK) ON a.OrderId = b.OrderId
									INNER JOIN dbo.T_Customer c WITH(NOLOCK) ON c.UserID=a.CustomerId
									INNER JOIN dbo.T_BusinessType d WITH(NOLOCK) ON d.BusinessTypeValue=a.OrderIndustryType
                           WHERE a.OrderStatus IN ( 64, 128 )
                             AND a.CustomerId NOT IN ( 80, 21651, 720,  
                                                              1196, 2513, 2515,  
                                                              2516, 4504 )-- 排除特殊客户        
                                     AND    b.[Status] < 12
                                    AND (a.OrderIndustryType = 1 OR a.OrderIndustryType=5 OR a.OrderIndustryType=6 OR d.IsPHClone=1)
                                    AND a.CustomerId=@CustomerId
                                            GROUP BY a.CustomerId,c.GroupId
                         )
            INSERT  INTO #UpdateInfo                   
                    SELECT  b.UserId ,
                            b.EmailId ,
                            ISNULL(d.Total, 0) AS Price1 ,-- 初始值        
                            CAST(a.OrderPrice AS DECIMAL(18, 2)) AS Price2 , --订单金额,        
                            CAST(ISNULL(d.Total, 0) + a.OrderPrice AS DECIMAL(18,
                                                              2)) AS Price ,-- 总消费金额        
                            c.[Name] ,
                            c.RatingId AS [NextRate] ,
                            c.[LevelPrice] AS [LEVEL] ,
                            c.Discount AS [Percent] ,
                            b.FullName AS CustomerName ,
                            CAST(ISNULL(v.UserId, 0) AS BIT) AS IsVip ,
                            a.GroupType ,
                            (
                              SELECT TOP 1
                                        Lang
                              FROM      dbo.T_Order
                              WHERE     CustomerId = a.CustomerId
                              ORDER BY  OrderDate DESC
                            ) AS LastOrderLanguage,
                            b.RatingId,
                            CASE WHEN c.LevelPrice > 0 AND (ISNULL(d.Total, 0) + a.OrderPrice > c.[LevelPrice])
                            THEN 1
                            ELSE 0
                            end
                    FROM    cte AS a
                            INNER JOIN dbo.T_Customer b ON a.CustomerId = b.UserId
                            LEFT JOIN dbo.T_CustomerRating c ON b.RatingId
                                                              + 1 = c.RatingId -- b.RatingId = c.RatingId - 1
                                                              AND c.LevelPrice > 0
                            LEFT JOIN dbo.T_CustomerConsumption d ON b.UserId = d.UserId AND d.OrderIndustryType=1
                            LEFT JOIN dbo.T_CustomerVip v ON v.UserId = b.UserId
                    
             
                
        UPDATE  dbo.T_Customer
        SET     dbo.T_Customer.RatingId = t.NextRate
              --      dbo.T_Customer.PurchaseAmountPh=t.Price
        FROM    T_Customer INNER JOIN #UpdateInfo t 
        ON		dbo.T_Customer.UserID = t.CustomerId
        WHERE t.isChangeLevel=1;
        
         UPDATE a SET     
 a.PurchaseAmountPh =ISNULL(b.PhOrderPrice,0) + ISNULL(c.Total,0)
 FROM dbo.T_Customer a  WITH(NOLOCK)    
 LEFT JOIN dbo.V_CustomerOrderPrice b ON b.CustomerId = a.UserID    
 LEFT JOIN dbo.T_CustomerConsumption c ON a.UserID=c.UserId AND c.OrderIndustryType=1
WHERE a.UserID=@CustomerId; 
        
        SELECT  *
        FROM    #UpdateInfo;
        
    END

go


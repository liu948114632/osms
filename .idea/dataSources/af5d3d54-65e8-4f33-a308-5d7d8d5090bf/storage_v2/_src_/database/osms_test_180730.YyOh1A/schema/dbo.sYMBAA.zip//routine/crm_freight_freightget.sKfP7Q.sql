/*----------------------------------------------------    
[备注] 计算运费：根据重量、发货地址、是否偏远   
------------------------------------------------------*/    
CREATE PROCEDURE [dbo].[CRM_Freight_FreightGet]     
(    
 @CountryId INT,
 @DeliveryId INT,
 @IsRemote BIT,
 @Weight INT,   
 @Freight DECIMAL(18,2) OUT   
)    
AS    
BEGIN
	DECLARE @AddedFreight DECIMAL(18,2) -- 附加费用
	
	-- 判断是否海运PortToPort    
	IF @DeliveryId = 22    
	BEGIN    
		EXEC CRM_Price_FreightGetByPortToPort @CountryId, @Freight OUT;    
	END    
	ELSE IF @Weight > 0    
	BEGIN    
		-- 获取基本运费    
		EXEC CRM_Price_FreightGet @DeliveryId, @CountryId, @Weight, @Freight OUT;    

		-- 偏远地区运费    
		IF @IsRemote = 1    
		BEGIN
			EXEC CRM_Price_AddedFreightGet @DeliveryId, @Weight, @AddedFreight OUT;    

			IF @AddedFreight > 0    
			BEGIN    
				SET @Freight = @Freight + @AddedFreight;    
			END    
		END    
	END        
END
go


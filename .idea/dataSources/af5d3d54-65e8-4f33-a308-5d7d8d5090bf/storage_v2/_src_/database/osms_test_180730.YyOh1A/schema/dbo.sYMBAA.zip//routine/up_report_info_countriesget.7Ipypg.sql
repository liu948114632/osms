



/**************************************************************
[公共信息]
	获取国家列表
**************************************************************/
CREATE PROCEDURE [dbo].[up_Report_Info_CountriesGet] 
(
	@CountryName	Nvarchar(50) = ''
)
AS
BEGIN
	SET NOCOUNT ON
	If @CountryName > ''
	Begin
		Select [Name] AS Country From T_Country 
		Where [Name] Like '%' + @CountryName +  '%'  
		Order By [Name];
	End
	Else
	Begin
		Select [Name] AS Country 
		From T_Country 
		Order By [Name];
	End
END


go


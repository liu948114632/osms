
CREATE VIEW V_CRM_UserBussinessType  
AS   
SELECT b.user_id AS UserId,  
       b.user_type_id AS BussinessTypeId,  
       a.name AS BussinessTypeName,  
       b.is_default_user_type AS IsDefaultBussinessType  
FROM dbo.user_type a WITH(NOLOCK)  
INNER JOIN dbo.user_bind_type b WITH(NOLOCK) ON b.user_type_id=a.id
go


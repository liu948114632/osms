CREATE PROC CRM_User_FindUserPageList
(
@userCode VARCHAR(50)='',
@userName VARCHAR(50)='',
@pageIndex INT=1,
@pageSize INT=50
)
AS
	BEGIN        
 SET NOCOUNT ON;        
 DECLARE @sql NVARCHAR(max)=''      
 DECLARE @countSql NVARCHAR(max) =''
 DECLARE @rowCount int,@pageCount int, @startPageIndex int, @endPageIndex int 

 
  
         
 SET  @sql = N' 
 SELECT *,ROW_NUMBER() OVER(ORDER BY code ASC ) as RowNo FROM dbo.T_User where 1=1
     '    

	   IF(@userCode>'')        
 BEGIN        
     SET @sql = @sql + ' AND code  like ''%'+@userCode+'%'''
 END        
  
  IF(@userName>'')        
 BEGIN        
     SET @sql = @sql + ' AND name  like ''%'+@userName+'%'''
 END 

 --得到记录条数          
    SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql + ') AS Items'          

	PRINT @countSql

    EXEC sp_executesql  @countSql, N'@rowCount INT OUT', @rowCount OUT         
	
 IF(@PageIndex<1) SET @PageIndex=1        
    SET @pageCount = (@RowCount + @PageSize - 1) / @PageSize          
    IF ISNULL(@PageIndex, 0) < 1 SET @PageIndex = 1          
    ELSE IF @PageIndex > @pageCount  SET @PageIndex = @pageCount          
    SET @startPageIndex = (@PageIndex - 1) * @PageSize + 1          
    SET @endPageIndex = @PageIndex * @PageSize         
              
 SET @sql = 'SELECT * FROM ('+@sql+') AS Items WHERE RowNo BETWEEN ' + ltrim(STR(@startPageIndex)) + ' AND ' + ltrim(STR(@endPageIndex))+' ORDER BY RowNo '        
         
    PRINT @sql        
    EXEC(@sql)         

  SELECT @rowCount   AS 'RowCount',@pageCount AS 'PageCount'   
         
END
go


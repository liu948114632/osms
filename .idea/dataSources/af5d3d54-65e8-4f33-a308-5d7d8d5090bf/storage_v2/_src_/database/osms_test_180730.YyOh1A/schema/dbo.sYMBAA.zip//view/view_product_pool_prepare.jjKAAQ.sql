
  
      
CREATE VIEW [dbo].[view_product_pool_prepare] AS       
with one_month_sale AS   
(  
 --新产品上架一个月  
 SELECT temp1.product_id,   
     (temp1.total_limited_unit_quantity / 3) AS month_sale_quantity, --月平均销量  
     temp1.order_number,     
     1 AS sale_type    --新品热销  
    FROM   
    (  
       SELECT *   
     FROM dbo.uf_new_product_sale_info(1) --获取新品上架一个月内的销售信息和加工信息  
     WHERE order_number >=3 AND total_limited_unit_quantity >=3 --找出上架后一个月内满足条件的商品：下单次数≥3　且　销售总批数≥3  
     ) temp1   
     JOIN dbo.uf_new_product_sale_info(3) temp2 ON temp1.product_id = temp2.product_id  
),  
two_month_sale AS   
(  
      --新产品上架2个月  
      SELECT temp1.product_id,   
       (temp1.total_limited_unit_quantity / 3) AS month_sale_quantity, --月平均销量  
       temp1.order_number,     
       2 AS sale_type    --新品热销  
      FROM   
      (  
         SELECT *   
       FROM dbo.uf_new_product_sale_info(2) --获取新品上架两个月内的销售信息和加工信息  
       WHERE order_number >=4 AND total_limited_unit_quantity >=4 --找出上架后两个月内满足条件的商品：下单次数≥4　且　销售总批数≥4  
         AND publish_time < DATEADD(MONTH,-1,GETDATE())  --排除仅上架一个月的    
       ) temp1   
       JOIN dbo.uf_new_product_sale_info(3) temp2 ON temp1.product_id = temp2.product_id  
)  
,other_sale AS   
(  
      --普通产品  
      SELECT temp1.product_id,   
       (temp1.total_limited_unit_quantity / 3) AS month_sale_quantity, --月平均销量  
       temp1.order_number,  
       3 AS sale_type    --PH热销  
      FROM   
      (  
         SELECT *   
       FROM dbo.uf_product_sale_info(DATEADD(MONTH,-3,GETDATE()),GETDATE(),0,1,1)  --获取所有商品的3个月内销量  
        --找出三个月内满足条件的商品：总下单数≥3，总销售批数≥9 OR 过去三个月总下单数≥6，总销售批数≥6   
       WHERE ((order_number >=3 AND total_limited_unit_quantity >=9) OR (order_number >=6 AND total_limited_unit_quantity >=6))  
         AND publish_time < DATEADD(MONTH,-2,GETDATE())  --排除仅上架两个月的    
       ) temp1   
)  
  
--其它策略下 一般商品池商品 备货量为 2倍 月均销量。  
--佛山策略下 一般商品池商品 备货量调整为 3倍 月均销量；  
--所有策略下 大采购/阿尔迪商品 备货量为 4倍 月均销量；  
--所有策略下 特殊材料商品 备货量为1倍 月均销量  
SELECT temp.product_id,  
       temp.month_sale_quantity as sale_quantity,  
       temp.order_number,  
       CEILING(temp.month_sale_quantity) *   
             (CASE WHEN smp.product_pool_multiple > 0 THEN smp.product_pool_multiple WHEN ( aldi = 1 OR is_big_purchase = 1 ) THEN 4 WHEN e.department_id = 6 THEN 3 ELSE 2 END)*p.unit_quantity AS prepare_quantity,  
       (CASE WHEN sale_type = 1 OR sale_type =2 THEN 3 ELSE 1 END)  AS Type  
FROM   
(          
   SELECT product_id,month_sale_quantity,order_number,sale_type,ROW_NUMBER() OVER ( PARTITION BY product_id ORDER BY sale_type) AS row_index  
   FROM   
   (  
    SELECT * FROM one_month_sale       
    UNION      
    SELECT * FROM two_month_sale  
    UNION   
    SELECT * FROM other_sale  
   ) temp2      
) temp    
INNER JOIN product p WITH(NOLOCK)  ON  p.id = temp.product_id  
INNER JOIN dbo.product_strategy AS e WITH(NOLOCK)  ON e.product_id = temp.product_id  
INNER JOIN dbo.product_provider AS f WITH(NOLOCK) ON f.product_id = temp.product_id AND f.department_id = e.department_id  
LEFT JOIN dbo.product_pool AS pp WITH(NOLOCK) ON pp.product_id=temp.product_id  
LEFT JOIN special_material_product AS smp WITH(NOLOCK) ON smp.product_id = temp.product_id AND smp.begin_time <= GETDATE() AND smp.end_time >= GETDATE()  
LEFT JOIN stay_shield_product ssp WITH(NOLOCK)  on operate_type = 1 AND ssp.product_id = temp.product_id  
LEFT JOIN  dbo.product_promote pp1 WITH(NOLOCK)  on pp1.type=3 AND pp1.product_id=temp.product_id
LEFT JOIN  product_inventory  as pin WITH(NOLOCK)   ON   pin.product_id =  temp.product_id   
WHERE p.is_delete=0 AND pp.id IS null AND temp.row_index = 1   AND ssp.id IS NULL  AND pp1.id IS NULL   AND pin.id IS NULL 
    AND (  
     (p.is_display_ph = 1 AND p.is_roughcast=0    
   AND NOT EXISTS( SELECT TOP 1 id FROM dbo.stay_shield_product WITH(NOLOCK)   
                   WHERE product_id=temp.product_id AND dbo.stay_shield_product.status=1 AND shield_type=1 AND operate_type = 0)   
        ) --非毛坯商品要求必须在PH显示，且没有待屏蔽  
       OR p.is_roughcast=1 --毛坯商品只要符合要求就可以进入  
       )   
AND f.provider_id NOT IN (3329,3227) AND p.is_cleaning = 0 --排除清货商品  
AND p.is_provider_stock != 1 --排除供应商库存商品  
  
--排除待下架或永久下架的商品(v3.9.10)  
AND p.offline_status =0  
--AND NOT EXISTS (  
--   SELECT TOP 1 product_id FROM stay_shield_product ssp  
--   WHERE operate_type = 1 AND ssp.product_id = temp.product_id  
--)   
  
  
  
  
----排除清仓商品  
--AND NOT EXISTS (  
--      SELECT TOP 1 product_id  
--      FROM dbo.product_promote pp  
--      WHERE type=3 AND pp.product_id=temp.product_id  
--       )  
--AND NOT EXISTS (  
----排除备货销售商品  
--     SELECT  TOP 1 rs.id  FROM dbo.product_ready_sell AS rs WITH(NOLOCK) WHERE rs.product_id = temp.product_id  
--        AND rs.is_ready_sell = 1  
--    )  
--AND NOT EXISTS (  
----排除备货商品  
--    SELECT TOP 1  * FROM product_inventory  as pin WITH(NOLOCK)  WHERE  pin.product_id =  temp.product_id   
-- )  


go


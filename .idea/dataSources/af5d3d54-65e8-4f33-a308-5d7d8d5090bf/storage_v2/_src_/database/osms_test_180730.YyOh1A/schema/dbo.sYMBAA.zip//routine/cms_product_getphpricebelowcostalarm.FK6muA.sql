




/**
*读取PH商品售价低于成本的数据  
*基准成本价*批量数量>=售价*实际汇率，则加入售价报警
*批量售价=(基准成本价×批量数量) ÷ 汇率 × 利润系数
*/
CREATE PROC [dbo].[CMS_Product_GetPHPriceBelowCostAlarm]
    (
      @ExchangeRate DECIMAL(18, 6) --实际汇率/网站汇率
    )
AS 
    BEGIN        
        SET NOCOUNT ON ;    
        SELECT    a.id ,
                            a.product_id AS productId ,
                            a.is_on_shelf AS isOnShelf ,
                            a.is_best_sellers AS isBestSellers ,
                            a.current_cost_price AS currentCostPrice ,
                            a.reference_cost_price AS referenceCostPrice ,
                            a.first_profit_coefficient AS firstProfitCoefficient
                  FROM      dbo.ph_product a WITH ( NOLOCK )
                            INNER JOIN dbo.product b WITH ( NOLOCK ) ON a.product_id = b.id
                            INNER JOIN dbo.product_promote c WITH(NOLOCK) ON a.product_id=c.product_id
                  WHERE     c.is_promote=1 AND b.is_display_ph = 1
                            AND a.is_on_shelf = 1
                            AND a.first_profit_coefficient * @ExchangeRate <= 1
    END
go


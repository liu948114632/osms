

/*------------------------------------------------------
报表统计-考核-投诉率
统计当月投诉数量以及前一个月的采购数量
up_Report_Assess_ComplaintRate '2009-01-01','2010-01-01','JS'
------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Assess_ComplaintRate]
(
	@StartTime		DateTime,
	@EndTime		DateTime,
	@Stock			VARCHAR(10)
)
As
Begin
	Declare @StockId INT,@PurchaseStartTime DateTime,@PurchaseEndTime DATETIME;
	
	-- 前一个月的采购数量
	Set @PurchaseStartTime = DATEADD(Month,-1,@StartTime);
	Set @PurchaseEndTime = DATEADD(Month,-1,@EndTime);
	
	Set @StockId  = (SELECT ISNULL(Id,0) FROM dbo.C_Stock WHERE Short = @Stock);
	If (@StockId > 0)
	Begin
		
		DECLARE @t TABLE (ItemCode NVARCHAR(100));
		
		-- 收集投诉商品编号 
		DECLARE @allItemCode VARCHAR(MAX);
		SET @allItemCode = '';
		SELECT @allItemCode = @allItemCode + ',' + b.[Code]
		FROM dbo.T_Complaint a 
			JOIN dbo.T_ComplaintRelatedProduct b 
				ON a.Id = b.ComplaintId
		WHERE a.CreateDate > @StartTime AND a.CreateDate < @EndTime;

		SET @allItemCode =  SUBSTRING(@allItemCode,2,LEN(@allItemCode) -1);
		
		-- 拆开成商品存储
		INSERT INTO @t(ItemCode)
		SELECT RTRIM(LTRIM([value])) FROM dbo.uf_Split(@allItemCode,',') WHERE [Value] > '';

		-- 前一个月的采购
		WITH Purchase (UserId,PurchaseCount) AS 
		(
			SELECT b.CreatorId,COUNT(1) AS PurchaseCount
			FROM dbo.C_PurchaseItem a 
			JOIN dbo.C_Purchase b 
				ON a.PurchaseId = b.PurchaseId
			AND b.CreateTime > @PurchaseStartTime AND b.CreateTime < @PurchaseEndTime AND b.StockId = @StockId AND b.[Status] > 3 AND b.[Status] < 16 -- 已完成的
			GROUP BY b.CreatorId 
		)
		,

		-- 投诉情况
		Complaint (UserId,ComplaintCount) AS
		(

			SELECT a.CreatorId,COUNT(1)
			FROM (
				SELECT b.CreatorId,a.ProductDataId 
				FROM dbo.C_PurchaseItem a 
				JOIN dbo.C_Purchase b ON a.PurchaseId = b.PurchaseId
				AND b.CreateTime > @StartTime AND b.CreateTime < @EndTime AND b.StockId = @StockId AND b.[Status] > 3 AND b.[Status] < 16 -- 已完成的
				GROUP BY a.ProductDataId,b.CreatorId
			) a
			JOIN dbo.D_Product b ON a.ProductDataId = b.ProductDataId
			AND b.Code IN(SELECT itemCode FROM @t)
			GROUP BY a.CreatorId
		)
		

		SELECT  
			c.FirstName AS UserName, 
			a.PurchaseCount,-- 采购数量
			IsNull(b.ComplaintCount,0) as ComplaintCount, -- 投诉数量
			LTRIM(CAST((CAST(ISNULL(b.ComplaintCount,0) as decimal(18,2))/a.PurchaseCount) * 100 as decimal(18,2))) + '%' As ComplaintRate -- 投诉率
		FROM Purchase a 
			LEFT JOIN Complaint b on a.UserId  = b.UserId
			INNER JOIN dbo.B_User c ON a.UserId = c.Id
		ORDER BY c.FirstName;
		

		
		/*
		declare
			@ItemCode varchar(200),
			@Code	varchar(100)

		declare myCursor cursor for select ItemCode from dbo.C_Complaint 
		where itemCode > '' AND CreateDate >= @StartTime AND CreateDate <= @EndTime
		open myCursor
			fetch next from myCursor into @ItemCode
			while @@fetch_status = 0
				begin   
				if @@error <> 0 break
				begin			
						declare myCursor2 cursor for select value from dbo.uf_Split(@ItemCode,',')
						open myCursor2
							fetch next from myCursor2 into @Code
							while @@fetch_status = 0
								begin   
								if @@error <> 0 break
								begin			
									
								INSERT INTO @t Values(rtrim(ltrim(@Code)))

								end
							fetch next from myCursor2 into @Code
						end
						close myCursor2
						deallocate myCursor2
				end
			fetch next from myCursor into @ItemCode
		end
		close myCursor;
		deallocate myCursor;
		
		With Purchase (UserId,PurchaseCount) as 
		(
			select b.UserId,COUNT(1) as PurchaseCount
			from b_PurchaseItem a join b_purchase b on a.purchaseId = b.Id
			AND b.CreateDate >= @PurchaseStartTime AND b.CreateDate <= @PurchaseEndTime AND b.StockId = @StockId AND Status > 3
			GROUP BY b.UserId 
		)
		,

		Complaint (UserId,ComplaintCount) as
		(

			Select a.userId,Count(1) 
			From (
				Select b.UserId,a.ProductId from b_PurchaseItem a 
				join b_purchase b on a.purchaseId = b.Id
				AND b.CreateDate >= @StartTime AND b.CreateDate <= @EndTime AND b.StockId = @StockId AND Status > 3
				Group by a.ProductId,b.UserId
			) a
			Left join t_item b on a.ProductId = b.ItemKeyId
			Where b.ItemCode IN(select ItemCode from @t)
			Group by a.UserId
		)

		Select  
			c.FirstName as UserName, 
			a.PurchaseCount,-- 采购数量
			IsNull(b.ComplaintCount,0) as ComplaintCount, -- 投诉数量
			LTRIM(CAST((CAST(ISNULL(b.ComplaintCount,0) as decimal(18,2))/a.PurchaseCount) * 100 as decimal(18,2))) + '%' As ComplaintRate -- 投诉率
		From Purchase a 
			Left join Complaint b on a.UserId  = b.UserId
			Left Join b_User c ON a.UserId = c.Id
		Order by c.FirstName

		
		*/
	End
End


go


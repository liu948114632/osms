  
CREATE FUNCTION [Get_CheckCode]  
    (  
      @BarCode VARCHAR(12)  
    )  
RETURNS VARCHAR(13)  
AS  
    BEGIN  
        DECLARE @codelength INT  
        SET @codelength = LEN(@BarCode)  
        DECLARE @curnum INT;  
            SET @curnum = 0  
        DECLARE @temp1 INT;  
            SET @temp1 = 0  
        DECLARE @temp2 INT;  
            SET @temp2 = 0  
        DECLARE @locatnum INT;  
            SET @locatnum = 0  
        DECLARE @code13 INT  
        DECLARE @i INT;  
            SET @i = 0  
        WHILE ( @i < @codelength )  
            BEGIN  
                SET @locatnum = @i + 2;  
                    SET @curnum = FLOOR(SUBSTRING(@BarCode,  
                                                  @codelength - @i, 1))  
                IF ( @locatnum % 2 = 0 )  
                    SET @temp1 = @temp1 + @curnum  
                ELSE  
                    SET @temp2 = @temp2 + @curnum  
                SET @i = @i + 1  
            END  
        SET @code13 = 10 - ( @temp1 * 3 + @temp2 ) % 10;  
            IF ( @code13 = 10 )  
            SET @code13 = 0  
        RETURN @BarCode+CAST(@code13 AS VARCHAR(1));  
    END
go


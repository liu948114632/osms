
CREATE PROC dbo.CMS_ProductStorage_ConvertUnitList
    (
      @CategoryId1 INT = NULL , --一级类别ID                
      @CategoryId2 INT = NULL , --二级类别ID                
      @CategoryId3 INT = NULL , --三级类别ID                
      @PublishStatus INT = NULL ,  --上传类型                
      @PropertyValueId1 INT = NULL ,--属性值ID1                
      @PropertyValueId2 INT = NULL ,--属性值ID1                
      @PropertyValueId3 INT = NULL ,--属性值ID1              
      @JlIsDisplay BIT = NULL , --jl是否显示  
      @PhIsDisplay BIT = NULL , --ph是否显示                  
      @PwIsDisplay BIT = NULL , --pw是否显示             
      @ProductCode VARCHAR(MAX) = NULL ,--商品编号                
      @ProductCodeList VARCHAR(MAX) = NULL ,--商品编号集合，多个编号用逗号隔开                
      @ProductName VARCHAR(MAX) = NULL ,--商品名称                
      @ProductSetCode VARCHAR(MAX) = NULL ,--商品集编号     
      @IsBindUnit BIT = NULL ,--是否绑定新单位  
      @IsBindProcessingItem BIT = NULL ,--是否绑定配件  
      @AuditTimeBegin VARCHAR(20) = NULL ,--复审时间，开始  
      @AuditTimeEnd VARCHAR(20) = NULL ,--复审时间，结束  
      @ProcessingItemCode VARCHAR(20) = NULL ,--配件产品编号  
      @ProcessingItemCodes VARCHAR(MAX) = NULL ,--配件产品编号，多个  
      @StrategyDepartmentId INT = NULL ,
      @OfflineStatus INT = NULL ,
      @BindType INT = NULL , -- 配件绑定类型  
      @ProviderCode VARCHAR(20) = NULL ,-- 供应商编号  
      @ProviderCodeList VARCHAR(MAX) = NULL , --供应商编号集合，多个编号用都好隔开 
      @DepartmentId INT = 0 ,
      @hasBindProblem INT = NULL ,
      @PageSize INT = 50 ,  --页大小                
      @PageIndex INT = 1    --当前页号                
    )
AS
    BEGIN                      
        SET NOCOUNT ON;                      
                        
        DECLARE @SQL VARCHAR(MAX) ,
            @TempSQL NVARCHAR(MAX) ,
            @BaseSQL VARCHAR(MAX) ,   --基本查询用            
            @CountSql NVARCHAR(MAX) , --查询数量用                
            @FromSQL1 NVARCHAR(MAX) , --内查询用                
            @FromSQL2 NVARCHAR(MAX) , --外查询用                
            @Condition VARCHAR(MAX) , --条件                
            @Column VARCHAR(MAX) ,--用于查询出来的列                
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ,
            @IsQueryProductSet BIT ,
            @IsQueryUnit BIT ,
            @IsQueryProcessingItem BIT     
 
        IF OBJECT_ID('#temp_product_processing_item') IS NOT NULL
            DROP TABLE #temp_product_processing_item;
        SELECT  product_id ,
                processing_product_id ,
                unit ,
                department_id
        INTO    #temp_product_processing_item
        FROM    product_processing_item
        WHERE   department_id = @DepartmentId
                        
        SET @IsQueryProductSet = 0    
        SET @IsQueryUnit = 0;  
        SET @IsQueryProcessingItem = 0
         
     --设置条件查询必须关联的表            
        SET @FromSQL1 = ' FROM dbo.product AS p WITH (NOLOCK)   
      LEFT JOIN dbo.product_strategy as stacey WITH (NOLOCK) ON p.id =stacey.product_id '                     
    --获得查询条件            
        SET @Condition = ' WHERE 1=1 AND p.status=4 AND p.is_delete = 0'                
        IF @ProcessingItemCode IS NOT NULL
            OR @ProcessingItemCodes IS NOT NULL
            OR @ProviderCode IS NOT NULL
            OR @ProviderCodeList IS NOT NULL
            BEGIN  
                SET @IsQueryProcessingItem = 1  
            END 
        IF @hasBindProblem IS NOT NULL
            BEGIN
                IF @hasBindProblem = 0
                    BEGIN
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND not  EXISTS (SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) 
				join product_unit_convert puc WITH ( NOLOCK ) on puc.product_id = item.processing_product_id and puc.department_id =item.department_id
				WHERE item.product_id = p2.id  and puc.unit<>item.unit) ' 
                            END 
                        ELSE
                            BEGIN
                                SET @Condition = @Condition
                                    + ' AND not  EXISTS (SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) 
				join product_unit_convert puc WITH ( NOLOCK ) on puc.product_id = item.processing_product_id and puc.department_id =item.department_id
				WHERE item.product_id = p.id  and puc.unit<>item.unit) ' 
                            END 
                    END
                ELSE
                    BEGIN
                        IF @IsQueryProcessingItem = 1
                            BEGIN
                                SET @Condition = @Condition
                                    + ' AND   EXISTS (SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) 
				join product_unit_convert puc WITH ( NOLOCK ) on puc.product_id = item.processing_product_id and puc.department_id =item.department_id
				WHERE item.product_id = p2.id  and puc.unit<>item.unit) '
                            END
                        ELSE
                            BEGIN
                                SET @Condition = @Condition
                                    + ' AND   EXISTS (SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) 
				join product_unit_convert puc WITH ( NOLOCK ) on puc.product_id = item.processing_product_id and puc.department_id =item.department_id
				WHERE item.product_id = p.id  and puc.unit<>item.unit) '
                            END
				


                    END
            END 
        IF @StrategyDepartmentId IS NOT NULL
            BEGIN  
                SET @Condition = @Condition + ' AND stacey.department_id ='
                    + CONVERT(VARCHAR(20), @StrategyDepartmentId)      
            END  
    ----配件产品编号    
        IF @ProcessingItemCode IS NOT NULL
            BEGIN  
                SET @Condition = @Condition + ' AND p.code = '''
                    + @ProcessingItemCode + ''''          
            END  
        IF @ProcessingItemCodes IS NOT NULL
            BEGIN  
                SET @Condition = @Condition + ' AND p.code in ('''
                    + REPLACE(@ProcessingItemCodes, ',', ''',''') + ''')'                 
            END  
        IF @IsQueryProcessingItem = 1
            BEGIN  
                SET @Condition = @Condition
                    + ' AND p2.status=4 AND p2.is_delete = 0'          
            END  
        IF @OfflineStatus IS NOT NULL
            BEGIN  
                IF @IsQueryProcessingItem = 1
                    BEGIN  
                        SET @Condition = @Condition
                            + ' AND EXISTS ( SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) WHERE  item.product_id = p2.id ) '  
                    END  
                ELSE
                    BEGIN  
                        SET @Condition = @Condition
                            + ' AND EXISTS (SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) WHERE item.product_id = p.id) '  
                    END
   
   
                IF @OfflineStatus = 0
                    BEGIN   
                        SET @Condition = @Condition
                            + ' AND  not EXISTS ( SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK )   
  join  product wp  WITH ( NOLOCK ) on wp.id=item.processing_product_id WHERE  item.product_id = p.id   AND wp.offline_status=2 AND wp.is_delete = 0)'     
                    END  
                ELSE
                    BEGIN  
                        SET @Condition = @Condition
                            + ' AND  EXISTS ( SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK )   
  join  product wp WITH ( NOLOCK )  on wp.id=item.processing_product_id WHERE  item.product_id = p.id   AND wp.offline_status=2 AND wp.is_delete = 0)'   
                    END  
            END  
        IF @IsBindProcessingItem IS NOT NULL
            BEGIN  
                IF @IsBindProcessingItem = 1
                    BEGIN  
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND EXISTS ( SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) WHERE  item.product_id = p2.id ) '  
                            END  
                        ELSE
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND EXISTS (SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) WHERE item.product_id = p.id) '  
                            END      
                    END  
                IF @IsBindProcessingItem = 0
                    BEGIN  
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND NOT EXISTS ( SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) WHERE  item.product_id = p2.id ) '  
                            END  
                        ELSE
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND NOT EXISTS (SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK ) WHERE item.product_id = p.id)'            
                            END  
                    END       
            END   
      
     -------------------------------配件绑定类型--------------------------------------  
  --   IF @BindType IS NOT NULL  
  --  BEGIN  
  --IF @BindType =1   
  --BEGIN  
  -- IF @IsQueryProcessingItem = 1  
  -- BEGIN  
  --  SET @Condition = @Condition + ' AND  not exists  (SELECT   product_id FROM  product_processing_item it  WHERE  p2.id =it.product_id and type =2 ) '  
  -- END  
  -- ELSE   
  -- BEGIN  
  --  SET @Condition = @Condition + ' AND  not exists  (SELECT DISTINCT product_id FROM  product_processing_item it   WHERE p.id =it.product_id  and type =2 ) '  
  -- END   
  --END  
    
  --IF @BindType =2  
  --BEGIN  
  -- IF @IsQueryProcessingItem = 1  
  -- BEGIN  
  --  SET @Condition = @Condition + ' AND  not exists  (SELECT   product_id FROM  product_processing_item it  WHERE  p2.id =it.product_id and type =1 ) '  
  -- END  
  -- ELSE   
  -- BEGIN  
  --  SET @Condition = @Condition + ' AND  not exists  (SELECT DISTINCT product_id FROM  product_processing_item it   WHERE p.id =it.product_id and type =1 ) '  
  -- END   
    
  --END  
    
  --  END     
      
      
        IF @CategoryId1 IS NOT NULL
            BEGIN               
                IF @IsQueryProcessingItem = 1
                    BEGIN   
                        SET @Condition = @Condition + ' AND p2.category_id_1='
                            + CONVERT(VARCHAR(20), @CategoryId1)   
                    END  
                ELSE
                    BEGIN      
                        SET @Condition = @Condition + ' AND p.category_id_1='
                            + CONVERT(VARCHAR(20), @CategoryId1)                
                    END  
            END                 
        IF @CategoryId2 IS NOT NULL
            BEGIN   
                IF @IsQueryProcessingItem = 1
                    BEGIN  
                        SET @Condition = @Condition + ' AND p2.category_id_2='
                            + CONVERT(VARCHAR(20), @CategoryId2)    
                    END  
                ELSE
                    BEGIN   
                        SET @Condition = @Condition + ' AND p.category_id_2='
                            + CONVERT(VARCHAR(20), @CategoryId2)      
                    END                       
            END                 
        IF @CategoryId3 IS NOT NULL
            BEGIN  
                IF @IsQueryProcessingItem = 1
                    BEGIN  
                        SET @Condition = @Condition + ' AND p2.category_id_3='
                            + CONVERT(VARCHAR(20), @CategoryId3)    
                    END   
                ELSE
                    BEGIN  
                        SET @Condition = @Condition + ' AND p.category_id_3='
                            + CONVERT(VARCHAR(20), @CategoryId3)      
                    END                    
            END                    
        IF @JlIsDisplay IS NOT NULL
            BEGIN                 
                IF @JlIsDisplay = 1
                    BEGIN    
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p2.is_display_jl=1'  
                            END  
                        ELSE
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p.is_display_jl=1'        
                            END            
                    END                 
                ELSE
                    BEGIN                 
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p2.is_display_jl=0'  
                            END  
                        ELSE
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p.is_display_jl=0'        
                            END                 
                    END                 
            END                
        IF @PhIsDisplay IS NOT NULL
            BEGIN                 
                IF @PhIsDisplay = 1
                    BEGIN  
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p2.is_display_ph=1'  
                            END  
                        ELSE
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p.is_display_ph=1'        
                            END              
                    END                 
                ELSE
                    BEGIN                 
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p2.is_display_ph=0'  
                            END  
                        ELSE
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p.is_display_ph=0'        
                            END                
                    END                 
            END  
        IF @PwIsDisplay IS NOT NULL
            BEGIN                 
                IF @PwIsDisplay = 1
                    BEGIN              
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p2.is_display_pw=1'  
                            END  
                        ELSE
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p.is_display_pw=1'        
                            END              
                    END                 
                ELSE
                    BEGIN                 
                        IF @IsQueryProcessingItem = 1
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p2.is_display_pw=0'  
                            END  
                        ELSE
                            BEGIN  
                                SET @Condition = @Condition
                                    + ' AND p.is_display_pw=0'        
                            END    
                    END                 
            END                      
        IF @ProductCode IS NOT NULL
            BEGIN   
                IF @IsQueryProcessingItem = 1
                    BEGIN    
                        SET @Condition = @Condition + ' AND p2.code like '''
                            + @ProductCode + '%'''  
                    END  
                ELSE
                    BEGIN  
                        SET @Condition = @Condition + ' AND p.code like '''
                            + @ProductCode + '%'''   
                    END           
            END                
        IF @ProductCodeList IS NOT NULL
            BEGIN  
                IF @IsQueryProcessingItem = 1
                    BEGIN    
                        SET @Condition = @Condition + ' AND p2.code in ('''
                            + REPLACE(@ProductCodeList, ',', ''',''') + ''')'  
                    END                 
                BEGIN  
                    SET @Condition = @Condition + ' AND p.code in ('''
                        + REPLACE(@ProductCodeList, ',', ''',''') + ''')'  
                END  
            END        
  
        IF @ProductName IS NOT NULL
            BEGIN  
                IF @IsQueryProcessingItem = 1
                    BEGIN    
                        SET @Condition = @Condition + ' AND p2.name like ''%'
                            + @ProductName + '%'''           
                    END                 
                BEGIN  
                    SET @Condition = @Condition + ' AND p.name like ''%'
                        + @ProductName + '%'''           
                END              
            END                  
        IF @PropertyValueId1 IS NOT NULL
            BEGIN  
                IF @IsQueryProcessingItem = 1
                    BEGIN    
                        SET @Condition = @Condition
                            + ' AND p2.id in ( select o.product_id from product_property_value AS o where o.property_value='
                            + CONVERT(VARCHAR(20), @PropertyValueId1) + ')'                
                    END                 
                BEGIN  
                    SET @Condition = @Condition
                        + ' AND p.id in ( select o.product_id from product_property_value AS o where o.property_value='
                        + CONVERT(VARCHAR(20), @PropertyValueId1) + ')'                
                END             
            END                 
        IF @PropertyValueId2 IS NOT NULL
            BEGIN                
                IF @IsQueryProcessingItem = 1
                    BEGIN    
                        SET @Condition = @Condition
                            + ' AND p2.id in ( select o.product_id from product_property_value AS o where o.property_value='
                            + CONVERT(VARCHAR(20), @PropertyValueId2) + ')'                
                    END                 
                BEGIN  
                    SET @Condition = @Condition
                        + ' AND p.id in ( select o.product_id from product_property_value AS o where o.property_value='
                        + CONVERT(VARCHAR(20), @PropertyValueId2) + ')'                
                END  
            END                 
        IF @PropertyValueId3 IS NOT NULL
            BEGIN                
                IF @IsQueryProcessingItem = 1
                    BEGIN    
                        SET @Condition = @Condition
                            + ' AND p2.id in ( select o.product_id from product_property_value AS o where o.property_value='
                            + CONVERT(VARCHAR(20), @PropertyValueId3) + ')'                
                    END                 
                BEGIN  
                    SET @Condition = @Condition
                        + ' AND p.id in ( select o.product_id from product_property_value AS o where o.property_value='
                        + CONVERT(VARCHAR(20), @PropertyValueId3) + ')'                
                END  
            END                              
        IF @AuditTimeBegin IS NOT NULL
            BEGIN   
                IF @IsQueryProcessingItem = 1
                    BEGIN    
                        SET @Condition = @Condition
                            + ' AND p2.audit_time >='''
                            + CONVERT(VARCHAR(20), @AuditTimeBegin) + ''''    
                    END                 
                BEGIN  
                    SET @Condition = @Condition + ' AND p.audit_time >='''
                        + CONVERT(VARCHAR(20), @AuditTimeBegin) + ''''    
                END           
            END                 
        IF @AuditTimeEnd IS NOT NULL
            BEGIN  
                IF @IsQueryProcessingItem = 1
                    BEGIN    
                        SET @Condition = @Condition
                            + ' AND p2.audit_time <='''
                            + CONVERT(VARCHAR(20), @AuditTimeEnd) + ''''         
                    END                 
                ELSE
                    BEGIN  
                        SET @Condition = @Condition + ' AND p.audit_time <='''
                            + CONVERT(VARCHAR(20), @AuditTimeEnd) + ''''         
                    END          
            END  
      
        IF @ProductSetCode IS NOT NULL
            BEGIN                
                SET @IsQueryProductSet = 1                
                SET @Condition = @Condition + ' AND ps.code like ''%'
                    + @ProductSetCode + '%'''                
            END  
        IF @IsBindUnit IS NOT NULL
            BEGIN  
                SET @IsQueryUnit = 1                
                IF @IsBindUnit = 1
                    BEGIN                
                        SET @Condition = @Condition + ' AND s.id is not null'              
                    END                 
                ELSE
                    BEGIN                 
                        SET @Condition = @Condition + ' AND s.id is null'                
                    END              
            END  
      
        
        IF @IsQueryProcessingItem = 1
            BEGIN   
                SET @FromSQL1 = @FromSQL1
                    + ' INNER JOIN #temp_product_processing_item AS ppi WITH(NOLOCK) ON ppi.processing_product_id = p.id '   
                SET @FromSQL1 = @FromSQL1
                    + ' INNER JOIN dbo.product AS p2 WITH(NOLOCK) ON p2.id = ppi.product_id '   
            END            
        IF @IsQueryProductSet = 1
            BEGIN        
                IF @IsQueryProcessingItem = 1
                    BEGIN  
                        SET @FromSQL1 = @FromSQL1
                            + ' INNER JOIN dbo.product_set AS ps WITH (NOLOCK) on p2.product_set_id = ps.id'   
                    END   
                ELSE
                    BEGIN          
                        SET @FromSQL1 = @FromSQL1
                            + ' INNER JOIN dbo.product_set AS ps WITH (NOLOCK) on p.product_set_id = ps.id'    
                    END              
            END    
        IF @IsQueryUnit = 1
            BEGIN  
                IF @IsQueryProcessingItem = 1
                    BEGIN  
                        SET @FromSQL1 = @FromSQL1
                            + ' Left JOIN dbo.product_unit_convert AS s WITH (NOLOCK) on s.product_id = p2.id and s.department_id='
                            + CONVERT(VARCHAR(20), @DepartmentId)  
                    END   
                ELSE
                    BEGIN          
                        SET @FromSQL1 = @FromSQL1
                            + ' Left JOIN dbo.product_unit_convert AS s WITH (NOLOCK) on s.product_id = p.id and s.department_id='
                            + CONVERT(VARCHAR(20), @DepartmentId)     
                    END                
            END   
        IF @ProviderCode IS NOT NULL
            BEGIN  
                SET @FromSQL1 = @FromSQL1
                    + ' left join  product_strategy ps  WITH (NOLOCK) on ps.product_id =p.id   LEFT JOIN product_provider AS pp  WITH (NOLOCK) ON pp.product_id = ps.product_id AND pp.department_id = ps.department_id   
				 LEFT JOIN provider AS pr WITH (NOLOCK) ON pr.id = pp.provider_id'  
                SET @Condition = @Condition + ' AND pr.code LIKE ''%'
                    + @ProviderCode + '%'''   
            END  
        IF @ProviderCodeList IS NOT NULL
            BEGIN  
                SET @FromSQL1 = @FromSQL1
                    + '  left join  product_strategy ps  WITH (NOLOCK) on ps.product_id =p.id  LEFT JOIN product_provider AS pp  WITH (NOLOCK) ON pp.product_id = ps.product_id AND pp.department_id = ps.department_id   
             LEFT JOIN provider AS pr WITH (NOLOCK) ON pr.id = pp.provider_id'  
                SET @Condition = @Condition + ' AND pr.code in ('''
                    + REPLACE(@ProviderCodeList, ',', ''',''') + ''')'  
            END    
    --求符合条件的总数  
        IF @IsQueryProcessingItem = 1
            BEGIN   
                SET @CountSql = ' SELECT @RowCount = count(p2.id) '
                    + @FromSQL1 + @Condition                
                EXEC sp_executesql @CountSql, N'@RowCount INT OUT',
                    @RowCount OUT  
            END   
        ELSE
            BEGIN  
                SET @CountSql = ' SELECT @RowCount = count(p.id) ' + @FromSQL1
                    + @Condition                
                EXEC sp_executesql @CountSql, N'@RowCount INT OUT',
                    @RowCount OUT  
            END                       
--     SELECT @CountSql                
                     
        IF ISNULL(@PageSize, 0) < 1
            SET @PageSize = 50                      
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                      
        IF ISNULL(@PageIndex, 0) < 1
            SET @PageIndex = 1                      
        ELSE
            IF ISNULL(@PageIndex, 0) > @PageCount
                SET @PageIndex = @PageCount                   
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                      
        SET @end = @PageIndex * @PageSize              
                
    --设置取字段信息必须关联的表            
        SET @FromSQL2 = ' INNER JOIN dbo.product AS a WITH (NOLOCK) ON temp.id = a.id'            
        IF @IsQueryProductSet = 1
            BEGIN                
                SET @FromSQL2 = @FromSQL2
                    + ' INNER JOIN product_set AS b WITH (NOLOCK) on temp.product_set_id = b.id'                
            END              
        ELSE
            BEGIN            
                SET @FromSQL2 = @FromSQL2
                    + ' LEFT JOIN dbo.product_set AS b WITH (NOLOCK) ON temp.product_set_id = b.id'            
            END   
               
                  
        SET @FromSQL2 = @FromSQL2
            + ' LEFT JOIN dbo.product_unit_convert AS s WITH(NOLOCK) ON s.product_id = temp.id and s.department_id='
            + CONVERT(VARCHAR(20), @DepartmentId)        
              
    --设置需要取的字段信息              
        SET @Column = ' a.id as productId,            
        a.code as productCode,                
        a.name productName,      
        a.original_name as productOriginalName, 
        a.unit as productUnit,                    
        a.unit_quantity AS unitQuantity,              
        a.is_display AS isDisplay,                
        a.is_display_ph AS isDisplayPh,                
        a.is_display_pw AS isDisplayPw,                
        a.is_display_jl AS isDisplayJl,           
        a.primary_picture_code AS primaryPictureCode,              
        a.color_card_picture_code AS colorCardPictureCode,     
        b.code AS productSetCode,  
        s.id as id,  
        s.department_id as departmentId,  
        s.convert_rate as convertRate,  
        s.original_unit as originalUnit,  
        s.unit as unit,  
        s.create_time as createTime,  
        s.new_unit_weight as newUnitWeight,  
        a.weight as productWeight,  
        a.audit_time AS auditTime,  
        temp.isBindProcessingItem '   
                          
            
    --组装基本查询的SQL         
        IF @IsQueryProcessingItem = 1
            BEGIN   
                SET @BaseSQL = 'SELECT * from (                
         SELECT  p2.id,              
           p2.product_set_id,                 
           ( CASE WHEN EXISTS ( SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK )  
        WHERE item.product_id = p2.id ) THEN 1  
      ELSE 0  
    END ) AS isBindProcessingItem,       
         ROW_NUMBER() OVER(ORDER BY p2.code asc) rowIndex'   
            END   
        ELSE
            BEGIN  
                SET @BaseSQL = 'SELECT * from (                
         SELECT  p.id,              
           p.product_set_id,                 
           ( CASE WHEN EXISTS ( SELECT 1 FROM #temp_product_processing_item AS item WITH ( NOLOCK )  
        WHERE item.product_id = p.id ) THEN 1  
      ELSE 0  
    END ) AS isBindProcessingItem,  
         ROW_NUMBER() OVER(ORDER BY p.code asc) rowIndex'   
            END    
                 
        SET @BaseSQL = @BaseSQL + @FromSQL1 + @Condition
            + ') temp2                 
    where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))                
      
    --组装最终取数的SQL            
        SET @SQL = 'select ' + @Column + ' from (' + @BaseSQL + ') temp '
            + @FromSQL2 + ' ORDER BY rowIndex'                     
        EXEC(@SQL);         
        PRINT @SQL          
        SELECT  @RowCount                    
    END


go


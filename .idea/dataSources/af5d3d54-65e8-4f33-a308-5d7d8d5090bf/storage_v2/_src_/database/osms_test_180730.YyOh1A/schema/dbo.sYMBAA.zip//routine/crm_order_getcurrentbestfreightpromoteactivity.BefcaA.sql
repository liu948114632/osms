/**  
根据客户信息和货运方式，获取可以享受的最合适的运费促销活动  
优先获取免运费活动  
*/  
CREATE PROC CRM_Order_GetCurrentBestFreightPromoteActivity  
(    
  @CrmCustomerId INT = -1 ,--CRM客户ID  
  @ShipCountryId INT = -1, --货运地址国家ID  
  @ShipCity VARCHAR(500) = '', --货运地址城市  
  @ShipZip VARCHAR(200) = '', --货运地址邮编  
  @IsDhlRemote BIT = 0, --货运地址在DHL是否偏远  
  @CustomerRatingId INT = -1, --客户等级ID  
  @CustomerType  INT = -1, --客户类型  
  @DeliveryID  INT = -1, --货运方式ID  
  @ProductPrice DECIMAL(18,2) = 0, --商品折前总价  
  @OrderWeight DECIMAL(18,2) = 0, --订单重量  
  @PromoteActivityId INT OUT, --返回最优的活动ID  
  @ProcedureCost DECIMAL(18,2) OUT, --返回运费折扣  
  @FreightDiscount DECIMAL(18,2) OUT, --返回免运费的手续费  
  @BestDeliveryId INT OUT,--返回最优的货运方式  
  @DeliveryRange VARCHAR(500) OUT--返回免运费货运方式的范围  
)    
AS     
BEGIN    
  DECLARE @ActivityCount INT ,@Index INT  
  DECLARE @WebCustomerId int --网站的客户ID  
    
  --默认没有满足的活动  
  SET @PromoteActivityId = -1;  
    
  SET  @WebCustomerId = -1  
  IF (@CrmCustomerId >0 )  
  BEGIN  
      --获取网站的客户ID    
   SELECT @WebCustomerId = BussinessCustomerId  
   FROM dbo.T_Customer  
   WHERE UserID=@CrmCustomerId  
  END   
    
  IF (@WebCustomerId = -1 OR @CustomerRatingId = -1 OR @CustomerType = -1 OR @ShipCountryId = -1  OR @DeliveryID = -1)    
  BEGIN        
    RETURN;    
  END    
    
  --1、先判断客户是否满足免运费的活动  
  EXEC CRM_Order_GetCurrentFreeShippingActivity @CrmCustomerId=@CrmCustomerId,@ShipCountryId=@ShipCountryId,@ShipCity=@ShipCity,@ShipZip=@ShipZip,  
  @IsDhlRemote=@IsDhlRemote,@CustomerRatingId=@CustomerRatingId,@CustomerType=@CustomerType,@ProductPrice=@ProductPrice,@OrderWeight=@OrderWeight,  
  @PromoteActivityId = @PromoteActivityId OUT,@ProcedureCost = @ProcedureCost OUT, @BestDeliveryId = @BestDeliveryId OUT,@DeliveryRange=@DeliveryRange OUT   
  --如果有免运费的活动，则直接返回  
  IF( @PromoteActivityId > 0)  
  BEGIN  
     SET @FreightDiscount = 1;--赋予免运费的折扣  
     RETURN;  
  END   
    
  --2、再获取客户所有满足要求的运费折扣活动（取折扣最优惠的)  
    SELECT @PromoteActivityId = PromoteActivityId,  
           @ProcedureCost = ProcedureCost,  
           @BestDeliveryId = @DeliveryID,  
           @FreightDiscount = FreightDiscount,  
           @DeliveryRange = DeliveryRange  
    FROM (  
    SELECT TOP 1 a.promote_activity_id AS PromoteActivityId,  
           a.freight_discount AS FreightDiscount,  
           a.procedure_cost AS ProcedureCost,  
           a.order_product_price AS OrderProductPrice,  
           c5.ids AS DeliveryRange  
        FROM    dbo.ph_freight_promote_activity a WITH(NOLOCK)    
                INNER JOIN ph_promote_activity b WITH(NOLOCK) ON a.promote_activity_id = b.id   
                INNER JOIN ph_promote_activity_range c1 WITH(NOLOCK) ON b.id = c1.promote_activity_id AND c1.range_type = 1  --国家限制  
                INNER JOIN ph_promote_activity_range c2 WITH(NOLOCK) ON b.id = c2.promote_activity_id AND c2.range_type = 2  --客户限制  
                INNER JOIN ph_promote_activity_range c3 WITH(NOLOCK) ON b.id = c3.promote_activity_id AND c3.range_type = 3  --客户等级限制  
                INNER JOIN ph_promote_activity_range c4 WITH(NOLOCK) ON b.id = c4.promote_activity_id AND c4.range_type = 4  --客户类型限制  
                INNER JOIN ph_promote_activity_range c5 WITH(NOLOCK) ON b.id = c5.promote_activity_id AND c5.range_type = 5  --货运方式限制  
        WHERE   b.is_delete = 0 AND b.is_activity_start = 1    
                AND a.freight_discount < 1 --排除免运费的活动  
                AND DATEADD(hh,-15,GETDATE())>=b.begin_time AND DATEADD(hh,-15,GETDATE())<=b.end_time --转成美国时间再比较  
                AND (--判断是否满足活动的客户范围  
                        c2.ids LIKE ('%,' + CONVERT(VARCHAR(10), @WebCustomerId) + ',%')  --1、如果促销针对特定的客户则其他条件不限    
                        OR (  
                             ( c1.ids = '-1'    
                               OR c1.ids = '-11'    
                               OR c1.ids LIKE ('%,' + CONVERT(VARCHAR(10), @ShipCountryId) + ',%')    
                             )  --2.1、判断货运国家是否满足限制要求  
                             AND ( c3.ids = '-1'    
                                   OR c3.ids = '-11'    
                                   OR c3.ids LIKE ('%,'  + CONVERT(VARCHAR(10), @CustomerRatingId) + ',%')    
                                 ) --2.2、判断客户等级是否满足限制要求   
                             AND ( c4.ids = '-1'    
                                   OR c4.ids = '-11'    
                                   OR c4.ids LIKE ('%,' + CONVERT(VARCHAR(10), @customerType) + ',%')    
                                 ) --2.3、判断客户类型是否满足限制要求   
                           )            
                    )  
               AND  a.order_product_price <= @ProductPrice --判断商品金额是否达到要求  
               AND (  
        c5.ids = '-1'    
        OR c5.ids = '-11'    
        OR c5.ids LIKE ('%,' + CONVERT(VARCHAR(10), @DeliveryID) + ',%')   
                   ) --判断货运方式是否满足要求  
        ORDER BY a.freight_discount DESC --取最优惠的活动  
     ) t  
          
    --如果没有满足的活动，则返回  
    IF( @PromoteActivityId IS NULL )  
    BEGIN  
        SET @PromoteActivityId = -1  
        RETURN;  
    END   
END
go


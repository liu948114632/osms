


---保存挽回订单签收日期和备注
CREATE PROC CRM_Customer_SaveLossedCustomerOrderInfo
(
@CustomerId INT ,
@OrderId VARCHAR(20),
@OperatorId INT ,
@SignInDate VARCHAR(20),
@Remark NVARCHAR(200)
)
AS
BEGIN

DECLARE @log VARCHAR(2000)=''

IF NOT EXISTS(SELECT * FROM dbo.T_LossedCustomerRedeemOrder WHERE CustomerId=@CustomerId AND OrderId=@OrderId AND Remark=@Remark)
 SET @log='设置备注->'+@Remark
 
IF NOT EXISTS(SELECT * FROM dbo.T_LossedCustomerRedeemOrder WHERE CustomerId=@CustomerId AND OrderId=@OrderId AND SignInDate=@SignInDate)
 SET @log=@log+';签收日期->'+@SignInDate

UPDATE  dbo.T_LossedCustomerRedeemOrder
SET     SignInDate = CASE WHEN ISDATE(@SignInDate)=1 THEN
  @SignInDate ELSE NULL END,
        Remark = @Remark
WHERE   OrderId = @OrderId
        AND CustomerId = @CustomerId        
        IF(@log>'')
        BEGIN
          SET  @log='订单号'+@OrderId+' '+@log
        EXEC CRM_Customer_AddLossedCustomerLog @CustomerId=@CustomerId,@OperatorId=@OperatorId,@log=@log,@EmailContent=''
        END        
END
go


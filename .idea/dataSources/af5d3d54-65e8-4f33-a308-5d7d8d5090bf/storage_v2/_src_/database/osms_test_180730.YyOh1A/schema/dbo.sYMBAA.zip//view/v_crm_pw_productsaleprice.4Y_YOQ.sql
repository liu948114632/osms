CREATE VIEW V_CRM_PW_ProductSalePrice      
AS       
SELECT       
b.id AS CmsProductId,      
a.id AS WebProductId,      
CAST(ISNULL(d.is_promote,0) AS BIT) AS IsPromote,    
(100 - ISNULL(d.Discount,0)) AS Discount, --注意：product_promote表中的Discount是降的折扣  
ISNULL(d.[type],0) AS PromoteType,  --促销类型   
CAST(ISNULL(d.is_bind_storage,0) AS BIT) AS IsBindStorage,  --是否绑定库存促销       
LastCostPrice AS CostPrice,      
b.unit_quantity AS UnitQuantity,      
ISNULL(c.Rate,8.2) AS ExchangeRate,      
a.first_profit_coefficient AS Profit1,      
first_quantity_from AS QuantityFrom1,      
first_quantity_to AS QuantityTo1,      
a.second_profit_coefficient AS Profit2,      
a.second_quantity_from AS QuantityFrom2,      
a.second_quantity_to AS QuantityTo2,      
a.third_profit_coefficient AS Profit3,      
a.third_quantity_from AS QuantityFrom3,      
a.third_quantity_to AS QuantityTo3,      
ISNULL(CAST((LastCostPrice * unit_quantity) / ISNULL(c.Rate,8.2) * first_profit_coefficient AS Decimal(18,2)),0) AS OriginalSalePrice,       
ISNULL(CAST((LastCostPrice * unit_quantity) / ISNULL(c.Rate,8.2) * (CASE WHEN d.discount > 0 THEN first_profit_coefficient ELSE second_profit_coefficient END) AS Decimal(18,2)),0) AS OriginalSalePrice2,     
ISNULL(CAST((LastCostPrice * unit_quantity) / ISNULL(c.Rate,8.2) * (CASE WHEN d.discount > 0 THEN first_profit_coefficient ELSE third_profit_coefficient END) AS Decimal(18,2)),0) AS OriginalSalePrice3,     
CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * unit_quantity) / ISNULL(c.Rate,8.2) * first_profit_coefficient AS Decimal(18,4)),0) * (100 - ISNULL(d.Discount,0)) / 100) AS FinalSalePrice,           
CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * unit_quantity) / ISNULL(c.Rate,8.2) * (CASE WHEN d.discount > 0 THEN first_profit_coefficient ELSE second_profit_coefficient END) AS Decimal(18,4)),0) * (100 - ISNULL(d.Discount,0)) / 100) AS FinalSalePrice2,     
CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * unit_quantity) / ISNULL(c.Rate,8.2) * (CASE WHEN d.discount > 0 THEN first_profit_coefficient ELSE third_profit_coefficient END) AS Decimal(18,4)),0) * (100 - ISNULL(d.Discount,0)) / 100) AS FinalSalePrice3,
d.id AS PromoteId
FROM dbo.pw_product a  WITH(NOLOCK)      
JOIN dbo.product b WITH(NOLOCK) ON a.product_id = b.id      
JOIN dbo.V_CRM_ProductLastCostPrice p ON p.CmsProductId=b.id
JOIN dbo.T_Currency c WITH(NOLOCK) ON c.Id=3    
LEFT JOIN product_promote_pw d WITH(NOLOCK) ON b.product_set_id = d.product_set_id AND d.is_promote=1
go

exec sp_addextendedproperty 'MS_Description', '是否促销', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice', 'COLUMN',
                            'IsPromote'
go

exec sp_addextendedproperty 'MS_Description', '促销折扣', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice', 'COLUMN',
                            'Discount'
go

exec sp_addextendedproperty 'MS_Description', '促销类型', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice', 'COLUMN',
                            'PromoteType'
go

exec sp_addextendedproperty 'MS_Description', '是否绑定库存促销', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice',
                            'COLUMN', 'IsBindStorage'
go

exec sp_addextendedproperty 'MS_Description', '第一段利润系数', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice', 'COLUMN',
                            'Profit1'
go

exec sp_addextendedproperty 'MS_Description', '第一段起订量(指批量数)', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice',
                            'COLUMN', 'QuantityFrom1'
go

exec sp_addextendedproperty 'MS_Description', '第一段最大订购量(指批量数,0表', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice',
                            'COLUMN', 'QuantityTo1'
go

exec sp_addextendedproperty 'MS_Description', '第二段利润系数', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice', 'COLUMN',
                            'Profit2'
go

exec sp_addextendedproperty 'MS_Description', '第二段起订量(指批量数)', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice',
                            'COLUMN', 'QuantityFrom2'
go

exec sp_addextendedproperty 'MS_Description', '第二段最大订购量(指批量数,0表', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice',
                            'COLUMN', 'QuantityTo2'
go

exec sp_addextendedproperty 'MS_Description', '第三段利润系数', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice', 'COLUMN',
                            'Profit3'
go

exec sp_addextendedproperty 'MS_Description', '第三段起订量(指批量数)', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice',
                            'COLUMN', 'QuantityFrom3'
go

exec sp_addextendedproperty 'MS_Description', '第三段最大订购量(指批量数,0表', 'SCHEMA', 'dbo', 'VIEW', 'V_CRM_PW_ProductSalePrice',
                            'COLUMN', 'QuantityTo3'
go


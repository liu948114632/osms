---获取客户购买商品的类别，一级类别+二级类别
CREATE PROC CRM_Customer_GetCustomerProductSecondCategory
(
@CustomerId INT ,
@SecondCategory NVARCHAR(MAX) OUT
)
AS
BEGIN
SET @SecondCategory='';
WITH cte AS
(
SELECT  DISTINCT c1.name+'>'+c2.name AS CategoryName FROM dbo.T_Order o INNER JOIN
 dbo.T_OrderItem i ON o.OrderId=i.OrderId INNER JOIN
dbo.product p ON i.CmsProductId=p.id INNER JOIN
dbo.category c1 ON p.category_id_1=c1.id INNER JOIN
dbo.category c2 ON p.category_id_2=c2.id
WHERE o.CustomerId=@CustomerId AND i.Status<>12 AND o.OrderStatus<>132
) 
--SELECT * FROM cte
SELECT @SecondCategory=@SecondCategory+','+cte.CategoryName  FROM cte;
END
go


 

CREATE PROC [dbo].[CMS_ProductSet_ProductSetManageList]
    (
      @CategoryId1 INT = NULL , --一级类别ID                
      @CategoryId2 INT = NULL , --二级类别ID                
      @CategoryId3 INT = NULL , --三级类别ID                
      @Status INT = NULL ,  --状态 
      @UploadUserId INT = NULL ,  --上传人   
      @DepartmentId INT = NULL,--部门
      @CreateTimeBegin VARCHAR(20) = NULL , --查询审核时间的开始时间                
      @CreateTimeEnd VARCHAR(20) = NULL , --查询审核时间的结束时间  
      @ProductSetCode VARCHAR(MAX) = NULL ,--商品集编号                
      @ProductSetOriginalName VARCHAR(MAX) = NULL ,--商品集中文名称              
      @ProductSetCodeList VARCHAR(MAX) = NULL , --产品集编号集合，多个编号用逗号隔开            
      @ProductSetName VARCHAR(MAX) = NULL ,--产品集名称      
      @PageSize INT = 50 ,  --页大小                
      @PageIndex INT = 1    --当前页号                
    )
AS 
    BEGIN                      
        SET NOCOUNT ON ;                      
                        
        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用                
            @FromSQL1 NVARCHAR(MAX) , --内查询用 
            @FromSQL2 NVARCHAR(MAX) ,
            @Condition VARCHAR(MAX) , --条件                
            @Column VARCHAR(MAX) ,--用于查询出来的列                
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ;    
       
     
        SET @FromSQL2 = ' 
     (
		 SELECT a.id AS categroyId1  ,b.id AS categroyId2 , c.id AS  categroyId3 ,
		 ISNULL(c.id,b.id) AS categroyId
		 FROM dbo.category a 
		 LEFT JOIN dbo.category AS b ON a.id = b.parent_id 
		 LEFT JOIN dbo.category AS c ON b.id = c.parent_id
		 WHERE a.parent_id IS NULL
     ) as cat_cateogry ' ;
                  
    --获得查询条件            
        SET @Condition = ' WHERE 1=1 AND p.is_delete = 0 and p.is_empty_set = 1' ;                
        IF @CategoryId1 IS NOT NULL 
            BEGIN                 
                SET @Condition = @Condition + ' AND cat_cateogry.categroyId1='
                    + CONVERT(VARCHAR(20), @CategoryId1)                
            END                 
        IF @CategoryId2 IS NOT NULL 
            BEGIN                 
                SET @Condition = @Condition + ' AND cat_cateogry.categroyId2='
                    + CONVERT(VARCHAR(20), @CategoryId2)                
            END                 
        IF @CategoryId3 IS NOT NULL 
            BEGIN                 
                SET @Condition = @Condition + ' AND cat_cateogry.categroyId3='
                    + CONVERT(VARCHAR(20), @CategoryId3)                
            END             
         
        IF @CreateTimeBegin IS NOT NULL 
            BEGIN                 
                SET @Condition = @Condition + ' AND p.creation_date >='''
                    + CONVERT(VARCHAR(20), @CreateTimeBegin) + ''''                
            END                 
        IF @CreateTimeEnd IS NOT NULL 
            BEGIN                 
                SET @Condition = @Condition + ' AND p.creation_date <='''
                    + CONVERT(VARCHAR(20), @CreateTimeEnd) + ''''                 
            END             
        IF @Status IS NOT NULL 
            BEGIN                 
                SET @Condition = @Condition + ' AND p.status='
                    + CONVERT(VARCHAR(20), @Status)              
            END
		IF @DepartmentId IS NOT NULL 
            BEGIN                 
                SET @Condition = @Condition + ' AND p.department_id='
                    + CONVERT(VARCHAR(20), @DepartmentId)              
            END               
          IF @UploadUserId IS NOT NULL 
            BEGIN                 
                SET @Condition = @Condition + ' AND p.upload_user_id='
                    + CONVERT(VARCHAR(20), @UploadUserId)              
            END                    
                    
        IF @ProductSetCode IS NOT NULL 
            BEGIN                              
                SET @Condition = @Condition + ' AND p.code like ''%'
                    + @ProductSetCode + '%'''                
            END                   
        IF @ProductSetCodeList IS NOT NULL 
            BEGIN                         
                SET @Condition = @Condition + ' AND p.code in ('''
                    + REPLACE(@ProductSetCodeList, ',', ''',''') + ''')'                
            END               
        IF @ProductSetOriginalName IS NOT NULL 
            BEGIN                              
                SET @Condition = @Condition + ' AND p.original_name like ''%'
                    + @ProductSetOriginalName + '%'''                
            END             
           
        IF @ProductSetName IS NOT NULL 
            BEGIN                     
                SET @Condition = @Condition + ' AND p.[name] LIKE ''%'
                    + @ProductSetName + '%'''          
            END        
 
                
    --设置条件查询必须关联的表            
        SET @FromSQL1 = ' FROM product_set p WITH (NOLOCK)
			Inner JOin ' + @FromSQL2
            + ' on p.category_id = cat_cateogry.categroyId'   
                
    --求符合条件的总数            
        SET @CountSql = ' SELECT @RowCount = count(p.id) ' + @FromSQL1
            + @Condition                
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                      
                    
   --SELECT @CountSql                
                     
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                      
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                      
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                      
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                   
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                      
        SET @end = @PageIndex * @PageSize     
             
    --设置需要取的字段信息              
        SET @Column = ' p.id,
		p.category_id as categoryId,
		p.department_Id as departmentId,
		p.classification_Id as classificationId,
		p.status ,
        p.code, 
        p.original_name  as  originalName,    
        p.name,                
        p.description as description,
        p.unit,  
        p.upload_user_id AS uploadUserId,              
        p.color_Card_Type as colorCardType,
        p.creation_date as creationDate,
        p.unit_quantity as unitQuantity,
        p.is_empty_set as isEmptySet '             
    
  
        SET @SQL = 'SELECT * from (                
         SELECT  ' + @Column + ',               
         ROW_NUMBER() OVER(ORDER BY p.status,p.creation_date DESC) rowIndex'    
                     
        SET @SQL = @SQL + @FromSQL1 + @Condition + ') temp2                 
    where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10)) 
      --SELECT @SQL;              
        EXEC(@SQL) ;                          
                    
        SELECT  @RowCount                    
    END

go



CREATE PROCEDURE [dbo].[CRM_Order_FBAOrderSplit]      
    (      
      @OrderId VARCHAR(20) ,      
      @ActionUserId INT = 0 ,      
      @OrderItemIds VARCHAR(MAX) ,--拆分订单商品Id字符串(逗号分隔)
      @Quantitys VARCHAR(MAX), 
      @OrderRemark NVARCHAR(500),
      @SplitOrderId VARCHAR(20) OUT -- 拆分订单号       
    )      
AS       
     DECLARE @Freight DECIMAL(9, 2) , -- 修改后原单的运费      
    @ReadyFreight DECIMAL(9, 2) , -- 修改后原单到货运费      
    @PFreight DECIMAL(9, 2) , --新订单的运费     
    @PReadyFreight DECIMAL(9, 2)--新订单到货运费    
       
    BEGIN      
        SET NOCOUNT ON ;      
      
        -- 1、增加拆分订单      
            EXEC CRM_Order_SplitOrderAdd @OrderId, @SplitOrderId OUT ;      
            
            UPDATE dbo.T_OrderRemark SET OrderRemark=@OrderRemark WHERE OrderId=@SplitOrderId;
            
            --UPDATE dbo.T_OrderRemark SET OrderRemark=OrderRemark+@OrderRemark WHERE OrderId=@OrderId;
            
            UPDATE dbo.T_Order SET OrderStatus=50 WHERE OrderId=@SplitOrderId
              
        IF @SplitOrderId > ''       
            BEGIN      
                -- 2、将拆分商品转移到拆分订单      
                EXEC CRM_Order_SplitFBAOrderItemAdd @OrderId, @SplitOrderId, @OrderItemIds,@Quantitys;  
                
                --2.2检查拆分的订单是否符合原先的运费折扣，不符合则去掉运费折扣
                DECLARE @Result BIT
                EXEC CRM_Order_IsQualifiedFreightDiscount  @OrderId=  @SplitOrderId,@Result=@Result OUT 
                IF( @Result = 0 )
                BEGIN
                    UPDATE dbo.T_Order SET FreightDiscount=0,DeliveryPromoteActivityId=NULL,FreeShipSurcharge=0
                    WHERE OrderId=@SplitOrderId
                    
                     EXEC CRM_Order_OrderHistoryAdd @UserId=0,@OrderId=@SplitOrderId,@Remark='拆分的订单因不满足运费活动要求，不再享受运费折扣';    
                END 
      
                -- 3、更新原始订单运费      
                -- 获取修改后费用       
                --EXEC dbo.CRM_Price_OrderFreightGet @OrderId, @Freight OUT,  @ReadyFreight OUT ; 
                --UPDATE dbo.T_Order SET Freight = @Freight WHERE OrderId = @OrderId;   
				
				/* 如果没有快照， 取实时 */
				IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.T_OrderDeliveryArea WHERE OrderId=@OrderId)
					BEGIN					   
						EXEC CRM_Order_UpdateFreightSnapshot @OrderId;
					END		                
                
				DECLARE @Action VARCHAR(100);
				SET @Action='订单' + @OrderId + '生成拆分订单' + @SplitOrderId;
				EXEC CRM_Order_UpdateGroupSendOrderFreight @OrderId=@OrderId, @UserId=@ActionUserId, @Action=@Action;
                
         
                --4、更新新订单运费      
                --EXEC dbo.CRM_Price_OrderFreightGet @SplitOrderId,@PFreight OUT, @PReadyFreight OUT ;
                --UPDATE dbo.T_Order SET Freight = @PFreight WHERE OrderId = @SplitOrderId;
                
				/* 2014-12-20 mzc 使用运费快照 */				
				EXEC dbo.CRM_Order_CopyFreightSnapshot @OrderId, @SplitOrderId; 
				SET @Action='从订单' + @OrderId + '生成拆分订单';
				EXEC CRM_Order_UpdateGroupSendOrderFreight @OrderId=@SplitOrderId, @UserId=@ActionUserId, @Action=@Action;                   
                    
                    
                --5、调整拆分订单金额    
                Exec CRM_Order_TransferOrderExcessPayment @OriginalOrderId=@OrderId,@TargetOrderId=@SplitOrderId,@TransferAction='生成拆分订单',@ActionUserId=@ActionUserId;      
      
                --6、调整订单状态      
                --原始订单状态    
                DECLARE @UpdatedStatus INT ;      
                EXEC CRM_Order_OrderStatusCheck @OrderId, @UpdatedStatus OUT ;       
                
                ---- 拆分订单状态      
                --DECLARE @SplitOrderUpdatedStatus INT ;      
                --EXEC CRM_Order_OrderStatusCheck @SplitOrderId, @SplitOrderUpdatedStatus OUT ;      

                -- 2014-09-10 mzc 拆分的单如果全部已备货，预计发货日期默认为当前日期
          --IF (@SplitOrderUpdatedStatus = 31)
					UPDATE  T_Order
					SET     AutoDelayDate = GETDATE()
					WHERE   OrderId = @SplitOrderId;   
                    
                --7、记录订单历史    
                DECLARE @Remark VARCHAR(100)    
                SET @Remark = '从订单' + @OrderId + '拆分生成订单' + @SplitOrderId    
                EXEC CRM_Order_OrderHistoryAdd @UserId=@ActionUserId,@OrderId=@OrderId,@Remark=@Remark    
                EXEC CRM_Order_OrderHistoryAdd @UserId=@ActionUserId,@OrderId=@SplitOrderId,@Remark=@Remark    
            END      
    END
go


 /**
 	@desc 待入电子业务备货商品列表
 	@date 2016-05-17
 	@author whw
  */
  CREATE VIEW dbo.v_dz_product_pool_prepare
  AS 
  SELECT d.id ,
         d.product_id ,
         d.sale_quantity ,
         d.prepare_quantity ,
         d.create_time,
         d.type,
         p.code AS productCode,
         p.cost_price AS costPrice,
         p.primary_picture_code AS primaryPictureCode,
         t.name AS strategyDepartment,
         p.category_id_1,
         p.category_id_2,
         p.category_id_3,
         t.id AS strategyId,
          p.unit_quantity ,
         p.unit,
 		CASE WHEN nt.id IS NOT NULL THEN 1 ELSE 0 END not_prepare
          FROM dbo.dz_product_pool_prepare d WITH(NOLOCK)
         JOIN dbo.product p WITH(NOLOCK) ON p.id=d.product_id
         LEFT JOIN dbo.product_strategy s WITH(NOLOCK) ON d.product_id=s.product_id
         LEFT JOIN dbo.department  t WITH(NOLOCK) ON s.department_id=t.id
 		LEFT JOIN dbo.dz_product_pool_not_prepare Nt ON nt.is_delete=0 AND nt.product_id=d.product_id


 go


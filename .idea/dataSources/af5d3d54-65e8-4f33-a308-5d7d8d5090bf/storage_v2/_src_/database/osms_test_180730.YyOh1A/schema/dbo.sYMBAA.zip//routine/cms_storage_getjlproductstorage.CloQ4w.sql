 
CREATE PROC CMS_Storage_GetjlProductStorage
    (
      @StartTime DATETIME = NULL , -- 开始时间                        
      @EndTime DATETIME = NULL  -- 结束时间                   
    )
AS 
    BEGIN                              
        SET NOCOUNT ON ;   
     
        SELECT  b.id AS id ,
                c.product_id AS productId ,
                c.id AS jlProductId ,
                d.phStorageQuantity-d.phHoldStorageQuantity AS availableQuantity
        FROM    ( SELECT    a.object_id
                  FROM      storage_operator_log a
                  WHERE     a.operator_time >= @StartTime
                            AND a.operator_time <= @EndTime
                  GROUP BY  a.[status] ,
                            a.[object_id]
                ) temp
                INNER JOIN dbo.storage AS b ON temp.object_id = b.id
                                              
                INNER JOIN dbo.view_business_department_storage d ON d.product_id = b.product_id
                INNER JOIN dbo.jl_product AS c ON c.product_id = b.product_id
                                                  AND c.is_on_shelf = 1  
     
        SET NOCOUNT OFF ;                        
    END
go




CREATE PROCEDURE [dbo].[CRM_Order_SplitFBAOrderItemAdd]          
    (          
      @OrderId VARCHAR(20) ,          
      @SplitOrderId VARCHAR(20) ,          
      @OrderItemIds VARCHAR(MAX),
      @Quantitys VARCHAR(MAX)    
    )          
AS           
    BEGIN          
 -- SET NOCOUNT ON added to prevent extra result sets from          
 -- interfering with SELECT statements.          
        SET NOCOUNT ON ;          
                  
        DECLARE @TempTable TABLE          
            (          
              [Id] INT ,          
              [ItemId] INT,
              [Qty] INT 
            ) ;          
            
        INSERT  INTO @TempTable          
                SELECT  Id ,          
                       CAST([Value] AS INT) ,  CAST(b.Qty AS INT)
                FROM    dbo.uf_Split(@OrderItemIds, ',')
             INNER JOIN
             (SELECT Id AS Id2, [Value]  AS Qty FROM dbo.uf_SplitAll(@Quantitys, ',')) b
            ON Id=b.Id2 
          
  -- 增加拆分订单商品          
        INSERT  INTO dbo.T_OrderItem          
                ( OrderId ,          
                  ProductId ,        
                  CmsProductId,     
                  ProductSetId,         
                  [Type] ,          
                  Quantity ,          
                  ReadyQty ,          
                  Unit ,          
                  UnitQuantity ,       
                  CostPrice,   
                  ItemPrice ,          
                  SalePrice ,          
                  [Weight] ,          
                  Volume ,          
                  IsPromote ,          
                  IsProductPool ,          
                  Box ,          
                  [Status] ,          
                  XFreight,        
                  ColorCardName,        
                  SpecficationName,        
                  MinBatchQty,          
                  JoinDate ,          
                  UpdateTime ,          
                  CustomerRemark ,          
                  BranchRemark ,          
                  CSRemark,  
                  ProcessingStatus,  
                  PackageProductId,
                  PromoteId ,
                  CollateStatus
            )          
                SELECT  @SplitOrderId ,          
                        ProductId ,         
                        CmsProductId,     
                        ProductSetId,        
                        Type ,
                        b.Qty ,          
                        b.Qty ,          
                        Unit ,          
                        UnitQuantity ,          
                             CostPrice, 
                        ItemPrice ,          
                        SalePrice ,          
                        Weight ,          
                        Volume ,          
                        IsPromote ,          
                        IsProductPool ,          
                        1 ,          --FBA拆单子箱都为1
                        [Status] ,          
                        XFreight,        
                        ColorCardName,        
                        SpecficationName,        
                        MinBatchQty,           
                        GETDATE() ,          
                        GETDATE() ,          
                        CustomerRemark ,          
                        BranchRemark ,          
                        CSRemark,  
                        ProcessingStatus,  
                        PackageProductId,
                        PromoteId ,
                        CollateStatus
                FROM    dbo.T_OrderItem          
                 INNER JOIN @TempTable b ON b.ItemId=OrderItemId
                                                   
   INSERT INTO T_OrderItemProduct          
   (          
     OrderItemId,          
     Name,          
     ItemCode,          
     Description,          
     ImageName,          
     Discount ,    
     ColorCode,    
     ColorImageName       
   )           
   SELECT c.OrderItemId,          
    b.Name,          
    b.ItemCode,          
    b.Description,          
    b.ImageName,          
    b.Discount,    
    b.ColorCode,    
          b.ColorImageName             
    FROM    dbo.T_OrderItem a          
    INNER JOIN dbo.T_OrderItemProduct b ON a.OrderItemId=b.OrderItemId          
    INNER JOIN T_OrderItem c ON a.ProductId = c.ProductId          
WHERE   a.OrderItemId IN ( SELECT ItemId FROM   @TempTable )       
   AND c.OrderId = @SplitOrderId         
                                 
--如果拆分的数量和原单中剩余数量相等，删除原始订单中的拆分订单项          
        UPDATE  dbo.T_OrderItem SET Status = 12 
        FROM @TempTable b
        WHERE   OrderId = @OrderId        
         AND b.ItemId=OrderItemId  
           AND Quantity=b.Qty
                                  
      --如果数量不相等，则修改原单订购数量     
       UPDATE  dbo.T_OrderItem SET Quantity=Quantity-b.Qty,ReadyQty=ReadyQty-b.Qty
        FROM @TempTable b
        WHERE   OrderId = @OrderId
        AND OrderItemId=b.ItemId 
           AND b.Qty<=Quantity
           AND Status<>12
    END

go



/*--------------------------------------------------          
备注：修改订单商品订购量          
创建人: FRH          
创建日期:2010-01-15          
--------------------------------------------------------*/          
CREATE PROC dbo.CRM_Order_OrderItemQtyUpdate           
(           
 @OrderId varchar(20),        
 @OrderItemId    INT,          
 @Quantity  INT, -- 新的订购数量          
 @OperatorId   INT,  --操作人ID        
 @FinalSalePrice DECIMAL(12,2),--最终售价
 @Action varchar(200), --修改订购量的事件        
 @PackFee DECIMAL(12,2)
)          
AS          
Declare          
 @OrderStatus Int ,        
 @OldQty INT ,        
 @ProductCode VARCHAR(100)  ,        
 @Remark VARCHAR(500)                             
Begin          
 SELECT @OrderStatus = OrderStatus          
 From dbo.T_Order Where OrderId = @OrderId;           

         IF EXISTS ( SELECT  *    
                    FROM    dbo.T_Order    
                    WHERE   OrderId = @OrderId    
                            AND OrderStatus > 45 )    
            BEGIN                              
                RAISERROR ('<info>订单校对中之后的状态不能修改订购量！</info>！' , 16, 1) WITH NOWAIT;                              
                RETURN;                              
            END                              
                    
        IF EXISTS ( SELECT  *    
                    FROM    dbo.T_Order    
                    WHERE   OrderId = @OrderId    
                            AND CollateStatus > 1 )    
            BEGIN                              
                RAISERROR ('<info>订单正在校对或已校对，如要修改请联系物流中心校对人员!</info>' , 16, 1) WITH NOWAIT;                              
                RETURN;                              
            END     

          
 -- 订单已发货后不允许修改          
 If @OrderStatus >= 60          
 Begin          
  RAISERROR ('<info>订单出库后就不能修改了！</info>' , 16, 1) WITH NOWAIT;          
  RETURN;          
 End          

DECLARE @OrderIndustryType INT ;
SELECT @OrderIndustryType=OrderIndustryType FROM dbo.T_Order WHERE OrderId=@OrderId;  
         
 SELECT @OldQty = a.Quantity,        
        @ProductCode = b.code        
 FROM dbo.T_OrderItem a        
 INNER JOIN dbo.V_CRM_Base_Product b ON a.CmsProductId = b.CmsProductId        
 WHERE a.OrderItemId = @OrderItemId AND a.OrderId = @OrderId;           
         
 --1、修改订购量，如果新订购量<已备量，则同时修改已备量=新订购量        
  Update dbo.T_OrderItem          
  Set Quantity = @Quantity,          
      ReadyQty = (CASE WHEN @Quantity < ReadyQty THEN @Quantity ELSE ReadyQty END),
	  PackFee=@PackFee
  Where OrderItemId = @OrderItemId AND OrderId = @OrderId;             
            
 --2、更新订单商品项状态          
 EXEC CRM_Order_OrderItemStatusCheck @OrderId;          

IF(@OrderIndustryType=5)
 SET @ProductCode='UK-'+@ProductCode;
IF(@OrderIndustryType=6)
 SET @ProductCode='US-'+@ProductCode; 
         
 --3、增加修改历史        
 IF (LEN(@Action) > 0 )        
 BEGIN        
    SET @Action = @Action + ','        
 END         
 ELSE        
 BEGIN        
    SET @Action = ''        
 END         
         
 SET @Remark = @Action + '修改商品[' + ISNULL(@ProductCode,'') + ']的订购数量:' + CONVERT(VARCHAR(10),@OldQty) + '->' + CONVERT(VARCHAR(10),@Quantity)        
 EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = @OperatorId, @OrderId = @OrderId,@Remark = @Remark -- varchar(5000)        
        
END

go


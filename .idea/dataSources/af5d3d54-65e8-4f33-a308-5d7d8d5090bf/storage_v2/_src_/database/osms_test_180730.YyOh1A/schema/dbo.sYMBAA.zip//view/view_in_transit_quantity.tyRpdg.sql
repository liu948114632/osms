
CREATE VIEW view_in_transit_quantity 
AS 
SELECT SUM(i.quantity) AS quantity,i.product_id FROM dbo.stock_out AS o 
JOIN dbo.stock_out_item AS i ON i.stock_out_id = o.id AND o.status = 1 AND o.is_received = 0
JOIN dbo.department AS dep ON dep.id = o.department_id AND dep.type = 1 
GROUP BY i.product_id
go




CREATE PROC [dbo].[CMS_Department_Delete_StorageFreezeLog]   
AS 
BEGIN   
DECLARE @tab TABLE(logId INT );
WITH cta_a AS (
SELECT operator_type,object_item_id,product_id 
FROM dbo.department_storage_freeze_log WHERE  (operator_type<>15 OR  (operator_type=15 AND  DATEDIFF(dd,freeze_time,GETDATE())>3))  AND  operator_type<>17
GROUP BY  operator_type,object_item_id,product_id
HAVING SUM(freeze_quantity)<=0
)

INSERT INTO @tab select a.id  FROM dbo.department_storage_freeze_log AS a
JOIN cta_a AS b ON a.product_id=b.product_id AND 
	b.operator_type=a.operator_type
	 AND b.object_item_id=a.object_item_id
DELETE a FROM  department_storage_freeze_log a JOIN @tab b ON  a.id =b.logId
DELETE a  FROM department_storage_freeze_log_detail a JOIN @tab b ON a.storage_freeze_log_id =b.logId
 

END;

go


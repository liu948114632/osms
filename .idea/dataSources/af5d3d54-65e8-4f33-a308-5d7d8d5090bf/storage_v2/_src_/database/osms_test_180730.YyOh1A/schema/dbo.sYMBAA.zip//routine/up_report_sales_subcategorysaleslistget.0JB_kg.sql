




/*----------------------------------------------------
[备注]
	某段时间统计网站BeadsFindings小类销售批量数排行列表
[dbo].[up_Report_Sales_SubCategorySalesListGet] '2009-11-02','2010-03-18'	
------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Sales_SubCategorySalesListGet] 
(
	@StartTime			DateTime, 
	@EndTime			DateTime
)
AS
Begin
	SET NOCOUNT ON;
	/*
	Select
		(Select [Name] From T_Category Where CategoryId = Max(e.ParentId)) As CategoryName,-- 三级类别名称 
		e.CategoryName As SubCategoryName, -- 四级类别名称
		Cast(Sum(a.Quantity) As Int) As Quantity -- 销售批量次数
	From
		B_OrderItem a
		Left Join B_Order b On a.OrderId = b.OrderId
		Left Join T_Item  c On a.ProductId = c.ItemKeyId
		Left Join T_CategorySearch	d On c.CategoryId = d.LeafageId
		Left Join T_CategoryHelp e On d.ParentId = e.CategoryId 
			And e.[Type] = 1 And e.[Level] = 4 --  小类指四级类别
	Where
		a.Status < 12 And b.Status < 132 And e.CategoryId > 0 And a.Quantity > 0
		And b.OrderDate > @StartTime And b.OrderDate < @EndTime -- And e.Disabled = 0
	Group by 
		e.CategoryName 
	Order by
		Sum(a.Quantity) DESC
	*/
	
	WITH cte AS
	(	
		SELECT 
			c.CategoryId,
			CAST(SUM(b.Quantity*1.0/b.UnitQuantity) AS DECIMAL(18,2)) AS qty
		FROM dbo.T_Order a 
			INNER JOIN dbo.T_OrderItem b 
				ON a.OrderId = b.OrderId 
					AND a.OrderStatus > 0 AND a.OrderStatus < 132 AND b.[Status] < 12 -- 非取消商品
						AND a.OrderDate > @StartTime AND a.OrderDate < @EndTime  
			INNER JOIN dbo.V_CategoryProduct c 
				ON b.ProductId = c.ProductId
		GROUP BY c.CategoryId
	)	
	
	SELECT 
		(SELECT [Name] FROM dbo.T_Category WHERE CategoryId = b.ParentId) AS CategoryName, -- 父类名称
		b.[Name] AS SubCategoryName,-- 最后一级类别名称
		a.qty AS Quantity -- 销售批量次数
	FROM cte a JOIN dbo.T_Category b
		ON a.CategoryId = b.CategoryId	
	ORDER BY a.qty DESC;
End


go


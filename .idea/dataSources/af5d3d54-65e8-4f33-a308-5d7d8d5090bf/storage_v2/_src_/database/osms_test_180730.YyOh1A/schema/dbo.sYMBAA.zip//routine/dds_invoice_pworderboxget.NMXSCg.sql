

--获得PW订单箱数
CREATE  PROCEDURE [dbo].[DDS_Invoice_PWOrderBoxGet] 
(
	@OrderId			NVARCHAR(255),
    @BoxCount           INT OUT
)
AS
BEGIN
	SET NOCOUNT ON;

	-- 创建表变量,用来缓存各个结算的订单
	Declare @Orders table(OrderId Nvarchar(20));

	-- 记录订单
	INSERT INTO	 @Orders(OrderId)
	SELECT [value] 
	FROM dbo.uf_Split(@OrderId,',');

	-- 获取子箱数
	SELECT	 @BoxCount = Count(Distinct Box)
	FROM @Orders a 
	JOIN dbo.[order] b ON b.code = a.OrderId
	JOIN dbo.order_item c ON c.order_id = b.id 
	WHERE c.status < 12; -- 不包括取消商品
END
go



/*-----------------------------------------
[备注]检查订单付款信息，确定订单是否全部付款
----------------------------------------------------*/
CREATE   PROCEDURE [dbo].[CRM_Service_OrderPriceCheck]
(
	@payment_fee		MONEY,			-- 付款金额
	@mc_currency		VARCHAR(20),	-- 付款币种
	@orderId			VARCHAR(20),
	@result				INT OUT			-- 返回结果
	
)
AS
DECLARE
	@discount			DECIMAL(18,2),  -- 客户折扣
	@orderPrice			MONEY,			-- 应付金额
	@limitPrice         MONEY,			-- 接收自动录单的最大金额
	@currency			DECIMAL(18,4)	-- 汇率转换
BEGIN
	SET	@limitPrice = 5000;	-- 老客户限制为5000
	SET	@result = 0;			-- 返回0代表通过

	
	-- 获取客户折扣
	SELECT @discount = Discount FROM dbo.T_CustomerRating WHERE RatingId = 
	(
		SELECT TOP 1 RatingId FROM dbo.T_Customer WHERE UserId =
		(
			SELECT TOP 1 CustomerId FROM dbo.T_Order WHERE orderId = @orderId
		)
	);
	
	IF @discount = 0.97 -- 新客户限制金额为1000
	BEGIN
		SET	@limitPrice = 1000;
	END
	
	-- 将付款金额转换为美金
	IF @mc_currency <> 'USD'
	BEGIN
		SELECT @currency = [Rate] FROM dbo.T_Currency WHERE currency = @mc_currency;
		IF @currency IS NULL
		BEGIN
			SET	@result = 4 -- 付款币种不在范围内
			RETURN; 
		END
		ELSE
		BEGIN
			SET	@payment_fee = @payment_fee/@currency; 
		END
	END
		

	-- 是否超过最大限制金额
	IF @limitPrice < @payment_fee
	BEGIN
		SET @result = 1; -- 付款金额过大
	END
	ELSE
	BEGIN
		-- 获取订单应付款
		SELECT @orderPrice = ProductPrice + Freight - CashPay - CouponPay FROM dbo.T_OrderPrice WHERE OrderId = @orderId; 
		IF @orderPrice IS NULL
		BEGIN
			SET	@result = 5; -- 信息不全
		END
		ELSE
		BEGIN
			IF ROUND(@payment_fee + 0.0005,2) < @orderPrice
			BEGIN
				SET	@result = 3; -- 付款金额不足
			END
			Else IF (ROUND(@payment_fee + 0.0005,2) - @orderPrice > 0.5)
			BEGIN
				SET	@result = 13; -- 付款金额多了
			END
		END
	END
END
go



/*-------------------------------
[描述]
	将时间加上一天后返回
---------------------------------*/
create FUNCTION [dbo].[uf_DealDateTime]
(
	@date	VARCHAR(50)
)
RETURNS VARCHAR(50)
AS
BEGIN
	DECLARE @result VARCHAR(50);
	DECLARE @d SMALLDATETIME;
	SET @d = CAST(@date AS SMALLDATETIME);
	SET @d = DATEADD(DAY,1,@d);
	SET @result =  CONVERT(VARCHAR(10),@d,25);
	RETURN @result;
END


go


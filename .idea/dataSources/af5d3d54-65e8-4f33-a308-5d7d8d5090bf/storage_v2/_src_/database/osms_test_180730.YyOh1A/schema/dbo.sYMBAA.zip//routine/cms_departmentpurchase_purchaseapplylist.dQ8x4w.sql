
     
/**      
2012-02-27    
获得办事处-采购申请单列表   
	v3.9.65 add by whw
	按：未申请＞审批中＞审批不通过＞复审中＞复审不通过＞审批通过   
*/      
CREATE PROC dbo.CMS_DepartmentPurchase_PurchaseApplyList          
(           
  @DepartmentId INT = NULL, --部门ID      
  @ApplyUserId INT = NULL, --申请人ID      
  @Status INT = NULL,  --申请状态      
  @ApplyCode VARCHAR(MAX) = NULL,--申请单号      
  @ProductCode VARCHAR(MAX) = NULL,--商品编号      
  @ProductEnName VARCHAR(MAX) = NULL,--商品英文名称      
  @ProductCnName VARCHAR(MAX) = NULL,--商品中文名称        
  @PageSize INT = 50 ,  --页大小      
  @PageIndex INT = 1    --当前页号      
)            
AS            
BEGIN            
    SET NOCOUNT ON ;            
              
    DECLARE @SQL VARCHAR(max),      
            @CountSql NVARCHAR(MAX), --查询数量用      
            @FromSQL NVARCHAR(max), --查询表    
            @FromSQL2 NVARCHAR(max), --查询外表    
            @Condition varchar(MAX), --条件       
            @Column NVARCHAR(max), --查询字段    
            @RowCount INT , @PageCount INT , @start INT ,@end INT ,      
            @IsQueryProduct BIT,@DistinctCode VARCHAR(10)    
        
    --获得查询条件    
    SET @Condition = ' WHERE 1=1 '       
    SET @IsQueryProduct = 0        
    SET @DistinctCode = ''     
          
    IF @DepartmentId IS NOT NULL       
    BEGIN       
       SET @Condition = @Condition + ' AND a.department_id=' + CONVERT(VARCHAR(10),@DepartmentId)      
    END         
    IF @ApplyUserId IS NOT NULL       
    BEGIN       
       SET @Condition = @Condition + ' AND a.apply_user_id=' + CONVERT(VARCHAR(10),@ApplyUserId)      
    END        
    IF @Status IS NOT NULL       
    BEGIN       
       SET @Condition = @Condition + ' AND a.status=' + CONVERT(VARCHAR(10),@Status)      
    END        
    IF @ApplyCode IS NOT NULL       
    BEGIN       
         SET @Condition = @Condition + ' AND a.code =''' + @ApplyCode + ''''    
    END        
    IF @ProductCode IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND c.code like ''' + @ProductCode + '%'''      
    END     
    IF @ProductEnName IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND c.name like ''%' + @ProductEnName + '%'''      
    END     
    IF @ProductCnName IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND c.original_name like ''%' + @ProductCnName + '%'''      
    END    
        
    --设置条件查询必须关联的表    
    SET @FromSQL =' FROM purchase_apply a WITH (NOLOCK)'      
        
    IF(@IsQueryProduct = 1)    
    BEGIN    
         SET @FromSQL = @FromSQL + ' INNER JOIN purchase_apply_item b WITH(NOLOCK) ON b.purchase_apply_id = a.id    
                                     INNER JOIN product c WITH(NOLOCK) ON b.product_id = c.id'    
         SET @DistinctCode = 'DISTINCT'    
    END     
    
    --求符合条件的总数    
    SET @CountSql = ' SELECT @RowCount = count(' + @DistinctCode + ' a.id) ' + @FromSQL + @Condition         
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
          
--     SELECT @CountSql             
    IF ISNULL(@PageSize, 0) < 1             
        SET @PageSize = 50            
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize            
    IF ISNULL(@PageIndex, 0) < 1             
        SET @PageIndex = 1            
    ELSE             
    IF ISNULL(@PageIndex, 0) > @PageCount             
        SET @PageIndex = @PageCount            
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1            
    SET @end = @PageIndex * @PageSize         
        
    --设置取字段信息必须关联的表        
    SET @FromSQL2 =' INNER JOIN purchase_apply a WITH (NOLOCK) ON temp.id = a.id'      
        
    --设置需要取的字段信息      
    SET @Column = 'a.id,      
       a.department_id as departmentId,    
       a.code,      
       a.apply_user_id AS applyUserId,    
       a.product_count AS productCount,      
       a.status,      
       a.audit_user_id AS auditUserId,      
       a.audit_remark AS auditRemark,    
       a.audit_time AS auditTime,      
     a.create_time AS createTime,
     a.review_audit_user as reviewAuditUser,
     a.review_audit_date as reviewAuditDate,      
       a.remark'    
           
 --组装基本查询的SQL    
 IF LEN(@DistinctCode) > 0    
 BEGIN     
  SET @SQL= 'SELECT * from    
       (    
       SELECT *,ROW_NUMBER() OVER(ORDER BY status ASC ,create_time DESC) rowIndex    
       from (SELECT ' + @DistinctCode + ' a.id,a.status,a.create_time' + @FromSQL +  @Condition + ') temp3    
       ) temp2         
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and ' + CAST(@end AS NVARCHAR(10))     
    END     
    ELSE     
    BEGIN    
        SET @SQL= 'SELECT * from (SELECT  a.id,ROW_NUMBER() OVER(ORDER BY  CASE a.status WHEN 4 THEN 3 WHEN 5 THEN 4 WHEN 7 THEN 5 WHEN 3 THEN 6 WHEN 6 THEN 7 ELSE a.status END ASC,a.create_time DESC) rowIndex' + @FromSQL +  @Condition + ') temp2         
                   where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and ' + CAST(@end AS NVARCHAR(10))        
    END      
                   
    --组装最终取数的SQL    
    SET @SQL= 'select ' + @Column + ' from (' + @SQL + ') temp ' + @FromSQL2     
    SET @SQL= @SQL + ' Order by rowindex'   
    
--     SELECT @SQL      
    EXEC(@SQL);                
     PRINT @SQL     
    select @RowCount          
END
go




/**************************************************************
		备注：订单处理速度统计

		本月所有发货的订单处理时间（小时）总和/本月发货的订单总数
up_Report_CustomerService_DealwithOrder '2008-01-01','2009-01-01'
**************************************************************/
CREATE PROCEDURE [dbo].[up_Report_CustomerService_DealwithOrder] 
	@StartTime		Datetime, 
	@EndTime		Datetime
AS
BEGIN
	SET NOCOUNT ON;
	
--	DECLARE @OrderCount DECIMAL(18,2);	
--	SET @OrderCount = 0.00;
	
	/*
	SET @OrderCount = (
	SELECT COUNT(1)
	FROM b_Order a 
	LEFT JOIN b_Package b ON a.OrderId = b.OrderId
	WHERE b.DueDate >= @StartTime AND b.DueDate <= @EndTime)

	SELECT 
	Cast(
	cast(SUM(datediff(hour, a.OrderDate, b.DueDate)) as decimal(18,2)) 
		/ @OrderCount  as decimal )  as DealwithOrderAvgTime
	FROM b_Order a 
	LEFT JOIN b_Package b ON a.OrderId = b.OrderId
	WHERE b.DueDate >= @StartTime AND b.DueDate <= @EndTime
	
	*/
	
	SELECT 
		ISNULL(CAST(SUM(DATEDIFF(hour,a.OrderDate,b.DueDate))*1.0/COUNT(1) AS DECIMAL(18,2)),0) AS DealwithOrderAvgTime
	FROM dbo.T_Order a
	JOIN dbo.T_OrderPackage b 
		ON a.OrderId = b.OrderId 
			AND b.DueDate > @StartTime AND b.DueDate < @EndTime;
	
	
END


go


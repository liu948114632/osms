
               
CREATE PROC [dbo].[CMS_DepartmentPurchase_PurchaseListItem]                    
(                     
  @DepartmentId INT = NULL, --部门ID                
  @CreatorId INT = NULL, --创建人ID                
  @PurchaseCode VARCHAR(20) = NULL, --采购单单号               
  @Type INT = NULL,  --采购单类型                
  @Status INT = NULL,  --采购单状态                
  @ProviderCode VARCHAR(MAX) = NULL,--供应商编号                
  @ProductCode VARCHAR(MAX) = NULL,--商品编号                
  @ProductEnName VARCHAR(MAX) = NULL,--商品英文名称                  
  @ProductCnName VARCHAR(MAX) = NULL,--商品中文名称          
  @ExpenseUserId INT = NULL,    
  @CreateTimeBegin VARCHAR(Max) = NULL,  
  @CreateTimeEnd VARCHAR(Max) = NULL,
  @CompleteTimeBegin VARCHAR(Max) = NULL,  
  @CompleteTimeEnd VARCHAR(Max) = NULL,  
  @CheckUser INT = NULL,
  @IsVip INT = NULL,
  @ItemStatus INT = NULL,      
  @PageSize INT = 50 ,  --页大小                
  @PageIndex INT = 1    --当前页号                
)                      
AS                      
BEGIN                      
    SET NOCOUNT ON ;                      
                        
    DECLARE @SQL VARCHAR(max),                
            @CountSql NVARCHAR(MAX), --查询数量用                
            @FromSQL NVARCHAR(max), --查询表              
            @FromSQL2 NVARCHAR(max), --查询外部              
            @Column NVARCHAR(max), --查询字段              
            @Condition varchar(MAX), --条件                 
            @RowCount INT , @PageCount INT , @start INT ,@end INT ,                
            @IsQueryProduct BIT,@IsQueryProvider BIT,@DistinctCode VARCHAR(10)               
              
    --获得查询条件              
    SET @DistinctCode = ''                    
    SET @Condition = ' WHERE 1=1 '                 
    SET @IsQueryProduct = 0                   
    SET @IsQueryProvider = 0              
    IF @IsVip IS NOT NULL
	 BEGIN
		  SET @Condition = @Condition + ' AND  a.is_vip=' + CONVERT(VARCHAR(10),@IsVip)       
	 END               
    IF @DepartmentId IS NOT NULL                 
    BEGIN                 
       SET @Condition = @Condition + ' AND a.department_id=' + CONVERT(VARCHAR(10),@DepartmentId)                
    END                   
    IF @CreatorId IS NOT NULL                 
    BEGIN                 
       SET @Condition = @Condition + ' AND a.creator_id=' + CONVERT(VARCHAR(10),@CreatorId)                
    END          
     IF @ExpenseUserId IS NOT NULL                 
    BEGIN                 
       SET @Condition = @Condition + ' AND a.expense_user_id=' + CONVERT(VARCHAR(10),@ExpenseUserId)                
    END          
    IF @PurchaseCode IS NOT NULL                 
    BEGIN                 
       SET @Condition = @Condition + ' AND a.code like ''%' + @PurchaseCode + '%'''              
    END                     
    IF @Type IS NOT NULL                 
    BEGIN                 
       SET @Condition = @Condition + ' AND a.type =' + CONVERT(VARCHAR(10),@Type)               
    END               
    IF @Status IS NOT NULL                 
    BEGIN                 
       SET @Condition = @Condition + ' AND a.status=' + CONVERT(VARCHAR(10),@Status)                
    END                  
    IF @ProductCode IS NOT NULL                 
    BEGIN                 
       SET @IsQueryProduct = 1              
       SET @Condition = @Condition + ' AND c.code like ''' + @ProductCode + '%'''                
    END               
    IF @ProductEnName IS NOT NULL                 
    BEGIN                 
       SET @IsQueryProduct = 1              
       SET @Condition = @Condition + ' AND c.name like ''%' + @ProductEnName + '%'''                
    END               
    IF @ProductCnName IS NOT NULL                 
    BEGIN                 
       SET @IsQueryProduct = 1              
       SET @Condition = @Condition + ' AND c.original_name like ''%' + @ProductCnName + '%'''                
    END              
    IF @ProviderCode IS NOT NULL                 
    BEGIN                 
         SET @IsQueryProvider = 1              
         SET @Condition = @Condition + ' AND d.code =''' + @ProviderCode + ''''              
    END           
    IF @CreateTimeBegin IS NOT NULL  
    BEGIN  
  SET @Condition = @Condition + ' AND a.create_time >= '''+ @CreateTimeBegin + ''''  
    END         
    IF @CreateTimeEnd IS NOT NULL  
    BEGIN  
  SET @Condition = @Condition + ' AND a.create_time <= '''+ @CreateTimeEnd + ''''  
    END  
   
   IF @CheckUser IS NOT NULL
   BEGIN 
       SET @Condition = @Condition + ' AND b.check_user like ''%,' +  CONVERT(VARCHAR(10),@CheckUser) + ',%'''      
   END   
   IF @ItemStatus IS NOT NULL
   BEGIN 
       SET @Condition = @Condition + ' AND b.status = ' +  CONVERT(VARCHAR(10),@ItemStatus)  
   END 
       IF @CompleteTimeBegin IS NOT NULL  
    BEGIN  
  SET @Condition = @Condition + ' AND a.purchase_complete_time >= '''+ @CompleteTimeBegin + ''''  
    END         
    IF @CompleteTimeEnd IS NOT NULL  
    BEGIN  
  SET @Condition = @Condition + ' AND a.purchase_complete_time <= '''+ @CompleteTimeEnd + ''''  
    END           
    --设置条件查询必须关联的表                
    SET @FromSQL =' FROM purchase a WITH (NOLOCK)
	                INNER JOIN purchase_item b WITH(NOLOCK) ON a.id = b.purchase_id AND b.is_deleted=0
					INNER JOIN product c WITH(NOLOCK) ON c.id = b.product_id
					LEFT JOIN dbo.exemption_product pr WITH(NOLOCK) ON pr.product_id =b.product_id'                
     IF(@IsQueryProvider = 1)              
     BEGIN              
           SET @FromSQL = @FromSQL + ' INNER JOIN provider d WITH(NOLOCK) ON d.id = b.provider_id'              
     END                      
                  
     
    --设置需要取的字段信息               
    SET @Column =' a.id AS purchaseId,                
       a.code AS purchaseCode,                
       a.creator_id AS creatorId,              
       a.create_time AS createTime,                
       a.status AS purchaseStatus,
	   b.package_user_id as packageUserId, 
	   b.id as purchaseItemId,   
	   b.status AS purchaseItemStatus, 
	   b.product_id as productId,  
	   (CASE WHEN b.is_exemption IS NULL THEN 
            (CASE WHEN pr.id IS NOT NULL AND  pr.is_exemption =1 THEN 1 ELSE 0 END )
       ELSE b.is_exemption END )  AS isExemption, 
	   c.code as productCode,  
	   c.unit_quantity  as unitQty ,
	   b.start_process_time AS startProcessTime,
	   b.audit_user AS auditUser,
	   b.audit_time AS auditTime,
	   b.apply_stock_in_time AS applyStockInTime,
	   b.check_user AS checkUser,
	   b.check_time AS checkTime,
	   b.completion_quantity AS completionQuantity
             '              
        SET @SQL= 'SELECT * from (SELECT ' + @Column + @FromSQL + @Condition + ') temp
		           ORDER BY purchaseStatus,createTime DESC,isExemption ASC,productCode ASC,completionQuantity DESC'
	
      
             
    EXEC(@SQL);                          
                    
    select @RowCount      
    PRINT @SQL;  
         --SELECT @SQL                   
END

go



/*------------------------------------------------        
[备注]:        
 修改订单折扣率        
--------------------------------------------------*/        
CREATE  PROCEDURE [dbo].[CRM_Order_OrderRateUpdate]        
(        
 @OrderId  VARCHAR(20),        
 @Rate   Decimal(9,2)        
)        
AS        
declare        
 @BalanceStatus Bit,        
 @CRate   Decimal(9,2) -- 当前订单折扣率        
Begin        
        
 -- 获取当前订单的折扣率的结算标志        
 Select          
  @CRate = OrderDiscount,        
  @BalanceStatus = IsBalance         
 From         
  dbo.T_Order         
 Where         
  OrderId = @OrderId;        
        
 -- 已经结算了        
 If @BalanceStatus = 1        
 Begin        
  RAISERROR ('提示：订单结算后就不能修改折扣了！' , 16, 1) WITH NOWAIT;        
  RETURN;        
 End        
        
 If @CRate > 0 And @Rate <> @CRate        
 Begin        
  -- 修改订单折扣        
  Update dbo.T_Order Set OrderDiscount = @Rate Where OrderId = @OrderId;        
        
  --同时修改订单商品冗余的折扣      
  UPDATE b SET discount = @Rate      
  FROM dbo.T_OrderItem a      
  INNER JOIN dbo.T_OrderItemProduct b ON a.OrderItemId=b.OrderItemId      
  WHERE a.OrderId = @OrderId AND a.Status <12 AND a.IsPromote !=1      
        
  -- 订单商品重新打折        
  Update a        
  Set a.ItemPrice = a.SalePrice * @Rate        
  From dbo.T_OrderItem a      
  Where a.OrderId = @OrderId   
       And ISNULL(a.ISPROMOTE,0) = 0; -- 排除促销商品        
 End        
END
go


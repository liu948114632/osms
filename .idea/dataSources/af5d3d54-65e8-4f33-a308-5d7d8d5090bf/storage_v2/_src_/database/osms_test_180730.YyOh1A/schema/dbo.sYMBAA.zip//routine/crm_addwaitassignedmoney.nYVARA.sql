
-- =============================================      
--update Author:  <ll>      
-- Create date: <2014-09-11>      
-- Description: <增加待分配资金>      
-- =============================================      
CREATE PROC dbo.CRM_AddWaitAssignedMoney
    @DeptId INT ,
    @CurrencyId INT ,
    @PayWayId int ,
    @PayMoney DECIMAL(18, 2) ,
    @OrderCode VARCHAR(500) ,
    @CustomerId int , 
    @CustomerName VARCHAR(50) ,
    @CreateDate VARCHAR(20) ,
    @TransactionNo VARCHAR(50),
   @Remark TEXT
AS
    BEGIN      
        SET NOCOUNT ON; 
        IF(@CustomerId=0)
           SELECT top 1 @CustomerId=UserId FROM dbo.T_Customer WHERE (FirstName+' '+LastName)=@CustomerName;
        INSERT  INTO T_WaitAssignedMoney
                ( [OrderCode] ,
                  [TransactionNo] ,
                  [BusinessId] ,
                  [CustomerName] ,
                  [PayMoney] ,
                  [CreateDate] ,
                  [ArrivalDate] ,
                  [CanAssignMoney] ,
                 [CustomerId],
                  [Status],
                  PayWayId,
                  CurrencyId,
                  CWTRemark
                )
        VALUES  ( @OrderCode ,
                  @TransactionNo ,
                  @DeptId ,
                  @CustomerName ,
                  @PayMoney ,
                  @CreateDate ,
                  GETDATE() ,
                  @PayMoney ,
                   @CustomerId,
                  0,
                  @PayWayId,
                  @CurrencyId,
                  @Remark
                );
    END

go



CREATE  PROCEDURE [dbo].[CMS_BussinessUS_CategorySeriesList]
(
	@CategoryId1 INT = NULL,
	@CategoryId2 INT = NULL,
	@CategoryId3 INT = NULL,
	@PageSize INT = 50 ,  --页大小              
	@PageIndex INT = 1    --当前页号    
)
AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE
		@SQL NVARCHAR(MAX),
		@CountSQL NVARCHAR(MAX),
		@FromSQL NVARCHAR(MAX),
		@FromSQL2 NVARCHAR(MAX),
		@Condition NVARCHAR(MAX),
		@Column NVARCHAR(MAX),
		@RowCount INT , 
        @PageCount INT , 
        @start INT ,
        @end INT
        
    --设置查询条件
    SET @Condition = ' where 1=1 ';
    IF @CategoryId1 IS NOT NULL 
    BEGIN
		SET @Condition = @Condition + ' AND a.category1_id=' + CONVERT(VARCHAR(10), @CategoryId1);
	END
	IF @CategoryId2 IS NOT NULL 
    BEGIN
		SET @Condition = @Condition + ' AND a.category2_id=' + CONVERT(VARCHAR(10), @CategoryId2);
	END
	IF @CategoryId3 IS NOT NULL 
    BEGIN
		SET @Condition = @Condition + ' AND a.category3_id=' + CONVERT(VARCHAR(10), @CategoryId3);
	END
	
	--查询显示的列
	SET @Column = ' a.id,
					a.category1_id category1Id,
					a.category2_id category2Id,
					a.category3_id category3Id,
					a.category_id categoryId,
					a.name,
					a.first_profit_coefficient firstProfitCoefficient,
					a.second_profit_coefficient secondProfitCoefficient,
					a.third_profit_coefficient thirdProfitCoefficient,
					a.is_default_domestic isDefaultDomestic,
					a.is_default_over_sea as isDefaultOverSea,
					a.is_domestic as isDomestic,
					a.is_over_sea as isOverSea,
					(select sum(productcount ) from (
					(SELECT COUNT(b.id) as productcount FROM dbo.us_product b WITH(NOLOCK) WHERE b.category_series_id=a.id 
					--	union all  
					--SELECT COUNT(b.id) FROM dbo.uk_domestic_product b WITH(NOLOCK) WHERE b.category_series_id=a.id
					))z) productCount';  	
    
    --设置查询基本表
    SET @FromSQL = ' FROM us_category_series a WITH(NOLOCK) ';
    --设置取字段表
    SET @FromSQL2 = ' us_category_series a WITH(NOLOCK) ON temp.id=a.id ';
    -- 查询记录数
    SET @CountSQL = '';
	SET @CountSQL = 'SELECT @RowCountOUT=count(a.id) ' + @FromSQL + @Condition;
	--print @CountSQL;
	EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;
	
   	--查询的分页条件
	IF ISNULL(@PageSize, 0) < 1                       
		SET @PageSize = 50                      
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                      
    IF ISNULL(@PageIndex, 0) < 1                       
        SET @PageIndex = 1                      
    ELSE                       
    IF ISNULL(@PageIndex, 0) > @PageCount                       
        SET @PageIndex = @PageCount                      
    SET @Start = ( @PageIndex - 1 ) * @PageSize + 1                      
    SET @End = @PageIndex * @PageSize
	
	--组装查询语句
		SET @SQL = 'SELECT a.id, ROW_NUMBER() OVER (ORDER BY a.category1_id,a.category2_id ,a.category3_id) RowIndex ' + @FromSQL + @Condition;
	
		SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp INNER JOIN '+@FromSQL2+' WHERE RowIndex between '
				 + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';
	PRINT @SQL
	EXEC(@SQL);                        
    select @RowCount  	
	SET NOCOUNT OFF;
END

go


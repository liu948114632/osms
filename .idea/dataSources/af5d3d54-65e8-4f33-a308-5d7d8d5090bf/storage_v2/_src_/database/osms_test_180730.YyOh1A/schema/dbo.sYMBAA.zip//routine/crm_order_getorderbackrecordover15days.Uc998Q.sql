CREATE PROC CRM_Order_GetOrderBackRecordOver15Days
AS
BEGIN
	SELECT  a.OrderId,b.SendGroupID  from T_OrderBackRecord a 
	INNER JOIN dbo.T_Order b ON a.OrderId=b.OrderId
	 WHERE DATEDIFF(DAY,CreateDate,GETDATE())>7
END
go


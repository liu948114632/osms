/**
根据客户信息和重量，获得当前满足的免运费的活动
*/
CREATE PROC CRM_Order_GetCurrentFreeShippingActivity
(  
  @CrmCustomerId INT = -1 ,--CRM客户ID
  @ShipCountryId INT = -1, --货运地址国家ID
  @ShipCity VARCHAR(500) = '', --货运地址城市
  @ShipZip VARCHAR(200) = '', --货运地址邮编
  @IsDhlRemote BIT = 0, --货运地址在DHL是否偏远
  @CustomerRatingId INT = -1, --客户等级ID
  @CustomerType  INT = -1, --客户类型
  @ProductPrice DECIMAL(18,2) = 0, --商品折前总价
  @OrderWeight DECIMAL(18,2) = 0, --订单重量
  @PromoteActivityId INT OUT, --返回最优的活动ID
  @ProcedureCost DECIMAL(18,2) OUT, --返回免运费的手续费
  @BestDeliveryId INT OUT,--返回最优的货运方式
  @DeliveryRange VARCHAR(500) OUT--返回免运费货运方式的范围
)  
AS   
BEGIN  
  DECLARE @ActivityCount INT ,@DeliveryCount INT ,@Index INT,@IsBestDelivery TINYINT,@TempDeliveryRange VARCHAR(500),@TempDeliveryID INT,
          @TempIsRemote BIT,@TempFreight DECIMAL(18,2)
  DECLARE @WebCustomerId int --网站的客户ID
  
  --默认没有满足的活动
  SET @PromoteActivityId = -1;
  
  SET  @WebCustomerId = -1
  IF (@CrmCustomerId >0 )
  BEGIN
      --获取网站的客户ID  
	  SELECT @WebCustomerId = BussinessCustomerId
	  FROM dbo.T_Customer
	  WHERE UserID=@CrmCustomerId
  END 
  
  IF (@WebCustomerId = -1 OR @CustomerRatingId = -1 OR @CustomerType = -1 OR @ShipCountryId = -1 )  
  BEGIN      
    RETURN;  
  END  
  
  --1、先获取客户所有满足要求的免运费活动
    SELECT a.promote_activity_id AS PromoteActivityId,
           a.freight_discount AS FreightDiscount,
           a.procedure_cost AS ProcedureCost,
           a.order_product_price AS OrderProductPrice,
           c5.ids AS DeliveryRange,
           IDENTITY(INT,1,1) rowIndex
        INTO #PromoteActivity
        FROM    dbo.ph_freight_promote_activity a WITH(NOLOCK)  
                INNER JOIN ph_promote_activity b WITH(NOLOCK) ON a.promote_activity_id = b.id 
                JOIN ph_promote_activity_range c1 WITH(NOLOCK) ON b.id = c1.promote_activity_id AND c1.range_type = 1  --国家限制
                JOIN ph_promote_activity_range c2 WITH(NOLOCK) ON b.id = c2.promote_activity_id AND c2.range_type = 2  --客户限制
                JOIN ph_promote_activity_range c3 WITH(NOLOCK) ON b.id = c3.promote_activity_id AND c3.range_type = 3  --客户等级限制
                JOIN ph_promote_activity_range c4 WITH(NOLOCK) ON b.id = c4.promote_activity_id AND c4.range_type = 4  --客户类型限制
                JOIN ph_promote_activity_range c5 WITH(NOLOCK) ON b.id = c5.promote_activity_id AND c5.range_type = 5  --货运方式限制
        WHERE   b.is_delete = 0 AND b.is_activity_start = 1  
                AND a.freight_discount = 1 --这里只取免运费的活动
                AND DATEADD(hh,-15,GETDATE())>=b.begin_time AND DATEADD(hh,-15,GETDATE())<=b.end_time --转成美国时间再比较
                AND (--判断是否满足活动的客户范围
                        c2.ids LIKE ('%,' + CONVERT(VARCHAR(10), @WebCustomerId) + ',%')  --1、如果促销针对特定的客户则其他条件不限  
                        OR (
                             ( c1.ids = '-1'  
                               OR c1.ids = '-11'  
                               OR c1.ids LIKE ('%,' + CONVERT(VARCHAR(10), @ShipCountryId) + ',%')  
                             )  --2.1、判断货运国家是否满足限制要求
                             AND ( c3.ids = '-1'  
                                   OR c3.ids = '-11'  
                                   OR c3.ids LIKE ('%,'  + CONVERT(VARCHAR(10), @CustomerRatingId) + ',%')  
                                 ) --2.2、判断客户等级是否满足限制要求 
                             AND ( c4.ids = '-1'  
                                   OR c4.ids = '-11'  
                                   OR c4.ids LIKE ('%,' + CONVERT(VARCHAR(10), @customerType) + ',%')  
                                 ) --2.3、判断客户类型是否满足限制要求 
                           )          
                    )
               AND  a.order_product_price <= @ProductPrice --判断商品金额是否达到要求
        
    --2、获取满足要求的活动个数
    SELECT @ActivityCount = COUNT(*)
    FROM #PromoteActivity
    
    --3、如果没有任何满足要求的活动，则返回
    IF( @ActivityCount = 0 )
    BEGIN
        RETURN;
    END 
    
    ---4、取出活动所有的货运 方式      
   DECLARE @Delivery TABLE(DeliveryId INT,Freight DECIMAL(18,2),RowIndex INT IDENTITY(1,1)); 
   
   IF EXISTS(SELECT TOP 1 1 FROM #PromoteActivity WHERE @DeliveryRange = '-1')
   BEGIN
         INSERT INTO @Delivery(DeliveryId)      
         SELECT  DeliveryId
		 FROM dbo.T_Delivery
		 WHERE IsDisplay = 1 AND DeliveryId NOT IN (0,17)
   END  
   ELSE
   BEGIN   
	   SET @Index = 0;
	   WHILE @Index < @ActivityCount
	   BEGIN
			SET @Index = @Index + 1; 
	        
			SELECT @TempDeliveryRange = DeliveryRange
			FROM #PromoteActivity 
			WHERE rowIndex = @Index
	        
			INSERT INTO @Delivery(DeliveryId)        
			SELECT [Value]         
			FROM dbo.uf_Split(@TempDeliveryRange,',') a
			LEFT JOIN  @Delivery b ON a.Value = b.DeliveryId
			WHERE b.DeliveryId IS NULL AND LEN(a.Value)>0
	   END 
	END 
    
    --4、确定最优的货运方式
    SET @BestDeliveryId = NULL;
    --4.1、先取运输成本最低的
    SELECT TOP 1 @BestDeliveryId = deliveryId
    FROM T_FreeShippingMethod
    WHERE countryId = @ShipCountryId AND to_weight>= @OrderWeight
    ORDER BY to_weight
    --如果运输成本最低的不在活动范围内，则不能作为最优的货运方式
    IF NOT EXISTS(SELECT TOP 1 1 FROM @Delivery WHERE DeliveryId = @BestDeliveryId)
    BEGIN
       SET @BestDeliveryId = null
    END 
    
    --4.2、如果没有运输成本最优的货运方式，则按照运费来计算
    IF( @BestDeliveryId IS NULL )
    BEGIN 
           SELECT @DeliveryCount = MAX(RowIndex)
           FROM @Delivery
           
           SET @Index = 0;
		   WHILE @Index < @DeliveryCount
		   BEGIN
				SET @Index = @Index + 1; 
				
				SELECT @TempDeliveryID = DeliveryId
				FROM @Delivery
				WHERE RowIndex = @Index
				
				--先判断偏远
				IF( @TempDeliveryID = 5 OR @TempDeliveryID=106)--DHL的偏远只能外面传进来
				BEGIN
				   SET @TempIsRemote = @IsDhlRemote;
				END 
				ELSE
				BEGIN
				   EXEC CRM_Settings_IsRemoteArea @CountryId=@ShipCountryId,@City=@ShipCity,@zip=@ShipZip,@DeliveryId=@TempDeliveryID,@result=@TempIsRemote OUT;
				END 
				
				IF( @TempIsRemote IS NULL )
				BEGIN
				    SET @TempIsRemote = 0;
				END 
				
				--再计算运费
				EXEC CRM_Freight_FreightGet @CountryId=@ShipCountryId,@DeliveryId=@TempDeliveryID,@IsRemote = @TempIsRemote,@Weight=@OrderWeight,@Freight=@TempFreight OUT;
	
	            UPDATE @Delivery SET Freight =@TempFreight WHERE RowIndex = @Index				
		   END 
		   
		   --取运费最小的货运方式，排除等于0的（一般自提货不支持的货运方式才是0）
		   SET @BestDeliveryId = (SELECT TOP 1 DeliveryId FROM @Delivery  WHERE Freight > 0 ORDER BY Freight)
    END 
    
    --5、根据最优的货运方式取免运费活动(优先取包含最优货运方式，且手续费最少的活动）
    SELECT @PromoteActivityId =PromoteActivityId,
           @ProcedureCost = ProcedureCost,
           @DeliveryRange = DeliveryRange,
           @IsBestDelivery = IsBestDelivery
    FROM 
    (   SELECT TOP 1 *
		FROM 
		(
			SELECT *,
				  (CASE WHEN @BestDeliveryId IS NOT NULL AND DeliveryRange LIKE '%,' + CONVERT(VARCHAR(10),@BestDeliveryId) + ',%'
						THEN 1 ELSE 0 END) AS IsBestDelivery ,
				  (CASE WHEN DeliveryRange = '-1' THEN 1 ELSE 0 END) AS IsUnlimitedDelivery--是否不限货运方式
			FROM #PromoteActivity
		) t
		ORDER BY IsBestDelivery DESC ,IsUnlimitedDelivery DESC ,ProcedureCost
    )t2
    
    --6、确定最优货运方式
    --如果没有运输成本最低的货运方式 或者 如果活动没有包括成本最低的货运方式，则从货运方式范围中取第一个
    IF( @BestDeliveryId IS NULL OR (@IsBestDelivery = 0 AND @DeliveryRange != '-1'))
    BEGIN
       SET @BestDeliveryId = (SELECT TOP 1 DeliveryId FROM @Delivery)
    END 
    
    --7、合并货运方式范围
    SET @DeliveryRange = 
    (SELECT  CONVERT(VARCHAR(10),DeliveryId) + ','
    FROM @Delivery FOR XML PATH(''))
    
    DROP TABLE #PromoteActivity
    
END
go


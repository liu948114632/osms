 
CREATE PROCEDURE [dbo].[CMS_OrderDetail]
    @orderId INT 
AS 
    BEGIN
	
SET NOCOUNT ON;	
SELECT a.id, 
	a.order_id AS orderId,
	a.product_id AS productId,
	a.status,
	order_quantity AS orderQuantity,
	prepared_quantity AS preparedQuantity,
	o.estimate_deliver_time AS estimateDeliverTime,
	a.unit,a.unit_quantity AS unitQuantity,
	a.weight,  
	a.volume,
	a.customer_remark AS customerRemark,
	a.customer_service_remark AS customerServiceRemark	,
	a.branch_remark AS branchRemark,
	a.business_id AS businessId,barcode,
	a.order_item_group_id AS orderItemGroupId,
	a.collate_status AS collateStatus,
	a.collate_time AS collateTime,
	a.collate_user_id AS collateUserId,
	a.collate_quantity AS collateQuantity,
	a.type,a.sale_price,
	c.name AS orderItemGruopName,
	p.code AS productCode,p.name AS productName,
	p.original_name AS productOriginalName,
	p.primary_picture_code AS primaryPictureCode,
	p.color_card_picture_code AS colorCardPictureCode,
	a.is_new_product AS isNewProduct,
	a.is_check AS isCheck,
	a.is_pool AS isPool,
	a.is_promote AS isPromote,
	a.processing_status AS processingStatus,
	a.is_receive AS isReceive,
	a.is_need_check AS needCheck,
	bp.qc_remark AS qcRemark,
	a.is_customize AS isCustomize,
	a.purchase_remark AS purchaseRemark,
	a.is_big_order AS isBigOrder,
	CASE WHEN o.department_id = 35 THEN a.zfq_department_received_qty
	      WHEN o.department_id = 36 THEN a.hdq_department_received_qty
	       WHEN o.department_id = 37 THEN a.zcq_department_received_qty END AS departmentReciveQty,
	CASE WHEN bp.id IS NOT NULL  THEN 1 ELSE 0 END AS isBlackPorduct,

	CASE  WHEN EXISTS (SELECT *  FROM check_product cp WHERE cp.order_item_id =a.id and  cp.status IS NOT NULL and cp.status = 1) THEN 1 ELSE 0 END AS isNeedQuantityInspection,

(SELECT  CAST (box AS VARCHAR(100))+',' FROM  dbo.order_item_relate_box   WITH(NOLOCK)   WHERE  order_item_id =a.id order BY box ASC  FOR XML PATH('')) AS box	,
(SELECT  CAST (quantity AS VARCHAR(100))+',' FROM  dbo.order_item_relate_box   WITH(NOLOCK)   WHERE  order_item_id =a.id order BY box ASC  FOR XML PATH('')) AS boxAssignQty
		  FROM dbo.order_item  a  WITH(NOLOCK)
		 JOIN dbo.[order] o  WITH(NOLOCK) ON o.id =@orderId
		 JOIN product p  WITH(NOLOCK) ON  a.product_id = p.id
		 LEFT JOIN  dbo.order_item_group c  WITH(NOLOCK) ON  c.id= a.order_item_group_id
		 LEFT JOIN blacklist_product bp WITH(NOLOCK) ON a.product_id = bp.product_id
		 --LEFT JOIN check_product cp WITH(NOLOCK) ON   
		 WHERE a.order_id = @orderId
		ORDER BY a.status ASC 
    END


go


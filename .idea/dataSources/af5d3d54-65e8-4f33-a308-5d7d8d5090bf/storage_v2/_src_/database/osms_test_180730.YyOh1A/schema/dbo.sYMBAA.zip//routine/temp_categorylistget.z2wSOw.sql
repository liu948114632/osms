/*--------------------------------------------------------------------------------------------
[描述]
	根据ParentId获取下级类别列表
--------------------------------------------------------------------------------------------*/
CREATE proc [dbo].[Temp_CategoryListGet]
	@ParentId	int = 0
as
	select 
		CategoryId, [Name] 
	from Temp_Category
	where ParentId = @ParentId and Disabled = 0
	order by [Name]
go



/**                  
 2012-03-27                
 获取订单待分配数量                  
*/                  
CREATE PROC [dbo].[CMS_StorageSheveGetAssignmentByRequire]  
    (  
      @ShelveItemId INT = NULL ,  
      @DepartmentId int =NULL   
    )  
AS   
    BEGIN                        
        SET NOCOUNT ON ;                  
		SELECT  b.id AS orderItemId ,  
                 d.id as orderId ,  
                 b.product_id AS productId ,  
				  b.order_quantity -b.prepared_quantity-ISNULL((SELECT  SUM(quantity) FROM  order_reservation r WHERE r.order_code =d.code AND r.product_id =b.product_id AND r.is_deal = 0),0) AS assignQuantity
                  FROM  dbo.shelve_item  a
		 JOIN dbo.order_item b ON a.product_id =b.product_id AND b.status = 1
		 JOIN dbo.[order] d ON d.id =b.order_id
		 JOIN dbo.business_type bt ON bt.order_type =d.type
		WHERE a.id =@ShelveItemId AND  b.processing_status <> 30 AND b.is_customize = 0
		--燕山仓库按照时间先后顺序
                                 ORDER BY  d.is_vip DESC, CASE WHEN @DepartmentId=24 THEN b.order_time ELSE GETDATE() END ,
		-- 网店订单优先级低
		CASE WHEN bt.business_storage_type =1 OR 	bt.business_storage_type =2	 THEN 	1 ELSE 0 END ASC ,			
		 ( d.valid_Order_Count - d.prepared_Count ) ,
                    CASE WHEN (b.order_quantity -b.prepared_quantity) <= a.plan_quantity THEN 0
                         ELSE 1
                    END ,
                    d.priority_Level DESC ,
                    d.order_Time ASC
 
    END


go


CREATE PROC [dbo].[CMS_logisticsCenter_ProductWeightVolume]  
(
	@ProductCode VARCHAR(25)=NULL, --产品编号
	@ProductCodes VARCHAR(MAX)=NULL, 
	@OrderCode VARCHAR(20)=NULL, --订单编号 
	@Status INT = NULL, --商品重量体积状态
	@InputWeight DECIMAL(18,3) = NULL , -- 录入批量
	@InputWeightIdentify VARCHAR(2) = NULL, --比较货运部批量时的模式：1、=,2、>3、<，4、>=,5、<=,6、!=   
	@InputVolume DECIMAL(18,3) = NULL , -- 录入批体
	@InputVolumeIdentify VARCHAR(2) = NULL, --比较货运部批体时的模式：1、=,2、>3、<，4、>=,5、<=,6、!=  
	@AuditTimeBegin VARCHAR(20) =NULL,   -- 3.9.31 审核开始时间
	@AuditTimeEnd  VARCHAR(20) =NULL,	-- 审核结束时间
    @PageSize INT = 50 ,  --页大小                              
    @PageIndex INT = 1    --当前页号        
)
AS
BEGIN
  
    SET NOCOUNT ON;

        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用 
            @FromSQL NVARCHAR(MAX) , --查询表                                         
            @Column NVARCHAR(MAX) , --查询字段                       
            @Condition VARCHAR(MAX) , --条件                         
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT
            
       
     
     SET @Condition = ' WHERE 1=1   and p.status = 4 and p.review_status=2 and p.is_delete = 0 '  
        
     IF @ProductCode is NOT NULL
     BEGIN
         SET @Condition = @Condition + ' AND p.code like ''%'+@ProductCode + '%'''; 
     END
     IF @productCodes IS NOT NULL  
	   BEGIN  
		SET @Condition = @Condition + ' AND p.code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')'     
		END
     
     IF @OrderCode is NOT NULL
     BEGIN
         SET @Condition = @Condition + ' AND o.code='''+@OrderCode+''''; 
      END     
     IF @Status is NOT NULL
        BEGIN 
         IF @Status != 4
         BEGIN
			 SET @Condition = @Condition + ' AND (pv.status is not null and pv.status = ' + CONVERT(VARCHAR(5),@Status)+' )'                       
         END
         ELSE
         BEGIN
			 SET @Condition = @Condition + ' AND  (pv.status is not null and pv.status = ' + CONVERT(VARCHAR(5),@Status) 
                                      + ' or pv.status IS null) '   
         END
          
        END
        
     --------------------------------------------------------------------   
     		IF @AuditTimeBegin IS NOT NULL 
		
			BEGIN
					 SET @Condition = @Condition + ' and pv.audit_time>=''' + @AuditTimeBegin + ''''
			END
		
		IF @AuditTimeEnd IS NOT NULL 
			BEGIN
				SET @Condition = @Condition + ' and pv.audit_time<=''' + @AuditTimeEnd + ''''
			END
     
     
      --------------------------------------------------------------------   
       

      IF @InputWeightIdentify IS NOT NULL AND @InputWeight IS NOT NULL     
        BEGIN       
          SET @Condition = @Condition + ' AND pv.delivery_weight'  + @InputWeightIdentify + CONVERT(VARCHAR(10),@InputWeight) 
          END 
     IF @InputVolumeIdentify IS NOT NULL AND @InputVolume IS NOT NULL     
        BEGIN       
          SET @Condition = @Condition + ' AND pv.delivery_volume'  + @InputVolumeIdentify + CONVERT(VARCHAR(10),@InputVolume) 
         END 

      SET @FromSQL =' FROM dbo.product p WITH (NOLOCK)  
						 left join product_set ps with(nolock) on ps.id =p.product_set_id    
						 LEFT JOIN dbo.product_weight_volume pv WITH (NOLOCK) on p.id = pv.id  
             left JOIN dbo.category c WITH (NOLOCK) ON c.id = 
					  (CASE WHEN p.category_id_3 =0 THEN  CASE WHEN  p.category_id_2 = 0 then category_id_1 else p.category_id_2 end   ELSE p.category_id_3 END ) '

     IF @OrderCode is NOT NULL
          BEGIN 
          SET @FromSQL = @FromSQL + ' JOIN dbo.order_item oi WITH (NOLOCK) ON P.id=oi.product_id and oi.status<>12
             JOIN dbo.[order] o WITH (NOLOCK) ON o.id=oi.order_id  '            
          end     
      
    --设置需要取的字段信息                        
        SET @Column = ' 
					 p.id as productId,
					 p.primary_picture_code as primaryPictureCode,
					 p.color_card_picture_code as colorCardPictureCode,
					 p.code as code,
					 p.unit as unit,
					 ps.code as productSetCode,
					 p.product_set_specification_id as productSpecificationId,
					 p.unit_quantity as unitQuantity,
					 p.volume as volume,
					 p.weight as weight,
				   c.volume_rate as volumeRate,
				   c.weight_rate as weightRate,
					 c.package_volume_rate as packageVolumeRate,
           pv.over_sea_info  as overSeaInfo,
           isNull(pv.status,4)  as status,
          (p.unit_quantity*p.weight*c.weight_rate) as forecastWeight,
          (case when  p.volume>0  then p.unit_quantity*p.volume*c.package_volume_rate 
                when (p.volume=0 or p.volume is null) then
           case when  c.volume_rate=0 then 0 
           ELSE  p.unit_quantity*p.weight*c.weight_rate * c.package_volume_rate  end end) as forecastVolume ,
           pv.delivery_weight as deliveryWeight,    
           pv.delivery_volume  as deliveryVolume,      
           pv.input_Weight as inputWeight,    
           pv.input_Volume  as inputVolume,
           pv.submit_time  as submitTime,
           pv.submit_user_id as submitUserId, 
           pv.audit_time  as auditTime,
           pv.audit_user_id as auditUserId ,
           pv.input_skin_weight as inputSkinWeight,
           pv.delivery_skin_weight as deliverySkinWeight '
           IF @OrderCode is NOT NULL
           BEGIN
           SET @Column = @Column + '
           ,o.code as orderCode,
           o.deliver_weight as orderWeight,
           oi.order_quantity as orderQty, 
           (case when oi.status = 12 then null else
           cast(((oi.order_quantity*1.000)/(oi.unit_quantity*1.00)*oi.weight) as DECIMAL(18,3)) end)  as webWeight,
           (case when oi.status = 12 then null else
           cast(((oi.order_quantity*1.000)/(oi.unit_quantity*1.00)*oi.volume) as DECIMAL(18,3)) end) as webVolume'
           END
								
        --求符合条件的总数                      
        SET @CountSql = ' SELECT @RowCount = count(p.id) ' + @FromSQL + @Condition                 
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
                            
		
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                              
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                              
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                              
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                              
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                              
        SET @end = @PageIndex * @PageSize   
    
        SET @SQL = 'SELECT * from                      
       (                      
       SELECT *,ROW_NUMBER() OVER(ORDER BY temp.productId ASC) rowIndex                      
       from (SELECT ' + @Column + @FromSQL + @Condition
            + ') temp                      
       ) temp2                           
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))    
       print @SQL      
       EXEC(@SQL);             
	   select @RowCount  


END
go





/*获取英语货运地址*/
CREATE PROC [dbo].[CRM_Order_GetEnglishOrderAddress] ( @OrderId VARCHAR(20) )
AS 
    BEGIN
	-- 从订单地址表获取信息
        WITH    cte
                  AS (
                       SELECT   *
                       FROM     dbo.T_Addresses t1
                                INNER JOIN dbo.T_SmllLanguageOrder t2 ON t2.EnglishAddressId = t1.AddressID
                     )
            SELECT  c.AddressId ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.FirstName
                         ELSE cte.Firstname
                    END AS [FirstName] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.LastName
                         ELSE cte.Lastname
                    END AS [LastName] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.Address1
                         ELSE cte.Street1
                    END AS [Address1] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.Address2
                         ELSE cte.Street2
                    END AS [Address2] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.City
                         ELSE cte.City
                    END AS [City] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.[State]
                         ELSE cte.[State]
                    END AS [State] ,
                    c.Country ,
                    c.Zip ,
                    c.Phone ,
                    c.Fax ,
                    c.Port ,
                    c.CompanyName
            FROM    dbo.T_OrderAddresses c WITH ( NOLOCK )
                    LEFT JOIN dbo.T_Order a ON a.ShipAddressId = c.AddressId
                    LEFT JOIN cte ON cte.OrderId = a.OrderId
            WHERE   a.OrderId = @OrderId
    END

go




/**      
*  2012-08-10 修改 加出库人查询条件      
*/      
CREATE PROC [dbo].[CMS_StockOut_PrintBarCodeUnitQty]                  
(                   
  @DepartmentId INT = NULL, --出库部门ID              
  @ReceiveDepartmentId INT = NULL, --接收部门ID              
  @StockOutCode VARCHAR(20) = NULL, --出库单单号              
  @IsReceived BIT = NULL ,--是否接收     
  @IsSendReceived BIT = NULL, --是否接货             
  @Type INT = NULL,  --出库单类型              
  @Status INT = NULL,  --出库单状态              
  @ObjectId VARCHAR(20)  = NULL,  --相关单号         
  @StorageOrderCode VARCHAR(30)  = NULL,  --仓库子单号             
  @CreateTimeBegin VARCHAR(20) = NULL, --查询生成时间的开始时间              
  @CreateTimeEnd VARCHAR(20) = NULL, --查询生成时间的结束时间             
  @ProductCode VARCHAR(MAX) = NULL,--商品编号              
  @ProductEnName VARCHAR(MAX) = NULL,--商品英文名称                
  @ProductCnName VARCHAR(MAX) = NULL,--商品中文名称        
  @StockOutUserId INT = NULL, --出库人   
  @ReiceveUserId INT = NULL,--接货人  
  @ReiceveTimeBegin VARCHAR(20) = NULL,--接货校对时间,开始  
  @ReiceveTimeEnd VARCHAR(20) = NULL,--接货校对时间，结束
  @PurchaseReturnCode VARCHAR(22) = NULL,--采购退货单编号               
  @ToAreaId INT = NULL,--到达区域
  @IsOrderStockOutType BIT = NULL,--是否按订单出库订单
  @AlrealyDelivery BIT = NULL,	-- 是否已发货
  @AlrealyStartCar BIT = NULL,	-- 已发车
  @AlrealyUnloadCar BIT = NULL,	-- 已卸车
  @IsSameArea BIT = NULL,-- 发货区域与接货区域是否相同
  @IsVip BIT =NULL,--是否VIP客户
  @TimeOutCollate INT = NULL, --3.9.33 超时校对
  @PackageUser NVARCHAR(100)=null
)                    
AS          
BEGIN                    
    SET NOCOUNT ON ;                    
                      
    DECLARE @SQL VARCHAR(max),                 
            @FromSQL NVARCHAR(max), --查询表            
            @Condition varchar(MAX), --条件        
            @IsQueryProduct BIT,@DistinctCode VARCHAR(10)             
                      
    SET @FromSQL =' FROM stock_out a WITH (NOLOCK)'               
    SET @DistinctCode = ''            
                  
    SET @Condition = ' WHERE 1=1 '               
    SET @IsQueryProduct = 0                 
     

	 IF @PackageUser IS NOT NULL
	BEGIN
	    SET @IsQueryProduct = 1    
		SET @Condition = @Condition  +' and b.package_info like ''%'+@PackageUser+'%'''
	END  
	              
    IF @DepartmentId IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.department_id=' + CONVERT(VARCHAR(10),@DepartmentId)              
    END                 
    IF @ReceiveDepartmentId IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.receive_department_id=' + CONVERT(VARCHAR(10),@ReceiveDepartmentId)              
    END               
    IF @StockOutCode IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.code like ''%' + @StockOutCode + '%'''            
    END
    IF @PurchaseReturnCode IS NOT NULL
    BEGIN
		SET @Condition = @Condition + ' AND a.type=22 AND a.object_id like ''%' + @PurchaseReturnCode + '%'''  
    END             
    IF @IsReceived IS NOT NULL               
    BEGIN               
        IF @IsReceived = 1             
        BEGIN             
            SET @Condition = @Condition + ' AND a.is_received=1'            
        END             
        ELSE            
        begin            
           SET @Condition = @Condition + ' AND a.is_received=0'            
        END             
    END      
               
    IF @Type IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.type =' + CONVERT(VARCHAR(10),@Type)             
    END             
    IF @Status IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.status=' + CONVERT(VARCHAR(10),@Status)              
    END            
    IF @ObjectId IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.object_id like ''%' + @ObjectId + '%'''              
    END              
	IF @StorageOrderCode IS NOT NULL AND LEN(@StorageOrderCode) > 0
	BEGIN               
	   SET @FromSQL = @FromSQL + ' INNER JOIN storage_order_ref_stock_out d1 (NOLOCK) ON a.id= d1.stock_out_id
	                               INNER JOIN storage_order  d2 (NOLOCK) ON d1.storage_order_id = d2.id'
	   IF CHARINDEX(';',@StorageOrderCode,1) > 0
        BEGIN                  
            SET @Condition = @Condition + ' AND d2.code in ('''  
                + REPLACE(@StorageOrderCode, ';', ''',''') + ''')'                
        END  
		ELSE
        BEGIN
             SET @Condition = @Condition + ' AND d2.code like ''%' + @StorageOrderCode + '%'''  
	    END              
    END   
    IF @CreateTimeBegin IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.create_time >=''' + CONVERT(VARCHAR(20),@CreateTimeBegin) + ''''              
    END               
    IF @CreateTimeEnd IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.create_time <=''' + CONVERT(VARCHAR(20),@CreateTimeEnd) + ''''               
    END      
    IF @ReiceveUserId IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.receive_collate_user_id =' + CONVERT(VARCHAR(10),@ReiceveUserId)             
    END   
    IF @ReiceveTimeBegin IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.stock_out_collate_time >=''' + CONVERT(VARCHAR(20),@ReiceveTimeBegin) + ''''              
    END               
    IF @ReiceveTimeEnd IS NOT NULL               
    BEGIN               
       SET @Condition = @Condition + ' AND a.stock_out_collate_time <=''' + CONVERT(VARCHAR(20),@ReiceveTimeEnd) + ''''               
    END          
    IF @ProductCode IS NOT NULL               
    BEGIN               
       SET @IsQueryProduct = 1            
       SET @Condition = @Condition + ' AND c.code like ''%' + @ProductCode + '%'''              
    END             
    IF @ProductEnName IS NOT NULL               
    BEGIN                    SET @IsQueryProduct = 1            
       SET @Condition = @Condition + ' AND c.name like ''%' + @ProductEnName + '%'''              
    END             
    IF @ProductCnName IS NOT NULL               
    BEGIN               
       SET @IsQueryProduct = 1            
       SET @Condition = @Condition + ' AND c.original_name like ''%' + @ProductCnName + '%'''              
    END            
    IF @StockOutUserId IS NOT NULL       
    BEGIN      
	   SET @Condition = @Condition + ' AND a.creator_id = ' + CONVERT(VARCHAR(20), @StockOutUserId)      
	END           
                
    IF( @IsQueryProduct = 1)            
    begin             
       SET @FromSQL = @FromSQL + ' INNER JOIN stock_out_item b WITH(NOLOCK) ON a.id = b.stock_out_id            
                                   INNER JOIN product c WITH(NOLOCK) ON c.id = b.product_id'            
       SET @DistinctCode = 'DISTINCT'            
    END                   
    
    IF @ToAreaId IS NOT NULL
    BEGIN
		SET @Condition = @Condition + ' AND a.to_area_id =' + CONVERT(VARCHAR(10),@ToAreaId)
    END  
	           
    IF @IsOrderStockOutType IS NOT NULL
    BEGIN
		IF @IsOrderStockOutType = 1
		BEGIN
			SET @Condition = @Condition  + 
								' AND EXISTS ( SELECT 1 FROM dbo.stock_out_ref_storage_task AS sors
								JOIN dbo.off_shelf_item AS osi ON sors.off_shelf_item_id = osi.id
								JOIN dbo.off_shelf AS os ON os.id = osi.off_shelf_id
								 WHERE sors.stock_out_id =a.id and os.type = 5)' 
		END
		IF @IsOrderStockOutType = 0
		BEGIN
			SET @Condition = @Condition  + 
								' AND NOT EXISTS ( SELECT 1 FROM dbo.stock_out_ref_storage_task AS sors
								JOIN dbo.off_shelf_item AS osi ON sors.off_shelf_item_id = osi.id
								JOIN dbo.off_shelf AS os ON os.id = osi.off_shelf_id
								 WHERE sors.stock_out_id =a.id and os.type = 5)' 
		END
    END 
	
	
	
	  
 -- V3.9.25 WZM   	
    IF @AlrealyDelivery IS NOT NULL
    BEGIN
		IF @AlrealyDelivery  = 1
		BEGIN
			SET @Condition = @Condition  + ' and  exists (select id from stock_out_scan_receive_log log where log.stock_out_id= a.id and log.remark=''已发货'' )'
		END
		ELSE
		BEGIN
			SET @Condition = @Condition  + + ' and  not exists (select id from stock_out_scan_receive_log log where log.stock_out_id= a.id and log.remark=''已发货'' )'
		END
    END
    
    IF @AlrealyStartCar IS NOT NULL
    BEGIN
		IF @AlrealyStartCar  = 1
		BEGIN
			SET @Condition = @Condition  + 
								' and  exists (select id from stock_out_scan_receive_log log where log.stock_out_id= a.id and log.remark=''已发车'' )'
		END
		ELSE
		BEGIN
			SET @Condition = @Condition  + 
								' and not exists (select id from stock_out_scan_receive_log log where log.stock_out_id= a.id and log.remark=''已发车'' )'
		END
    END
    
    IF @AlrealyUnloadCar IS NOT NULL
    BEGIN
		IF @AlrealyUnloadCar  = 1
		BEGIN
			SET @Condition = @Condition  + 
								' and  exists (select id from stock_out_scan_receive_log log where log.stock_out_id= a.id and log.remark=''已卸车'' )'
		END
		ELSE
		BEGIN
			SET @Condition = @Condition  + 
								' and not exists (select id from stock_out_scan_receive_log log where log.stock_out_id= a.id and log.remark=''已卸车'' )'
		END
    END
  --  to_area_id
  
    IF @IsSameArea IS NOT NULL
    BEGIN	
		IF	@IsSameArea = 1
		BEGIN
			SET @Condition = @Condition  + ' AND EXISTS(SELECT id FROM area_department WHERE a.to_area_id =
  (SELECT area_id FROM dbo.area_department ad WHERE a.department_id = ad.department_id AND ad.is_defult =1))'
		END
		ELSE
		BEGIN
			SET @Condition = @Condition  + ' AND EXISTS(SELECT id FROM area_department WHERE a.to_area_id !=
  (SELECT area_id FROM dbo.area_department ad WHERE a.department_id = ad.department_id AND ad.is_defult =1))'
		END
    END

	IF @IsVip IS NOT NULL AND @IsVip > -1
	BEGIN
          SET @Condition = @Condition + ' AND a.is_vip =' + CONVERT(VARCHAR(10),@IsVip)
	END 
    
   ------------------------------------3.33 wzm------------------------------------------------------- 
  IF @TimeOutCollate  IS NOT NULL
	BEGIN
		IF @TimeOutCollate = 1
			BEGIN
				SET @Condition = @Condition  + ' AND a.stock_out_time IS NOT NULL AND datediff(day,a.stock_out_time,getdate()) > 3 AND a.is_received =0 ';
			END
		IF @TimeOutCollate = 0
			BEGIN
				SET @Condition = @Condition  + ' AND (a.stock_out_time IS NULL OR(a.stock_out_time IS NOT NULL AND datediff(day,a.stock_out_time,getdate()) <= 3 ) OR a.is_received <> 0 )';
			END	
		
	END
   
   ------------------------------------3.33 wzm------------------------------------------------------- 
   
	  
             
    SET @SQL= 'SELECT SUM(x.quantity *1.0 /x.unit_quantity) FROM dbo.stock_out_item AS x WITH(NOLOCK)  
   
      WHERE  x.is_print_barcode = 1 and  x.stock_out_id IN (SELECT  a.id '+@FromSQL +  @Condition +')'  
                   
    --SELECT @SQL              
  EXEC(@SQL);                       
END

go


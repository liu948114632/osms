
 
  
/**    
出口易出库单出库成功    
*/    
CREATE PROC CRM_Order_SetCK1SendOutSuccess
    (
      @OrderId VARCHAR(20) , --订单号    
      @StockOutCode VARCHAR(30) --出库单号    
    )
AS
    BEGIN    
        UPDATE  a
        SET     Status = 8
        FROM    dbo.T_OrderItem a
                JOIN dbo.T_OverseasWarehouseStockOutOrderItem b ON a.OrderItemId = b.OrderItemId
        WHERE   b.StockOutCode = @StockOutCode
                AND OrderId = @OrderId;    
    
      --记录订单历史    
        DECLARE @remark VARCHAR(MAX);    
        SET @remark = N'海外仓出库单(' + @StockOutCode + ')已发货';     
        EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int    
            @OrderId = @OrderId, -- varchar(14)    
            @Remark = @remark; -- varchar(5000)    
           
      --更新物流商ID
        UPDATE  a
        SET     LogisticsCarriersId = ( SELECT TOP 1
                                                LogisticsCarriersId
                                        FROM    dbo.T_OverseasWarehousePackage
                                        WHERE   StockOutCode = a.StockOutCode
                                      )
        FROM    T_OverseasWarehouseStockOutOrder a
        WHERE   OrderId = @OrderId;
             --全海外仓不需要更新订单备注
        IF NOT EXISTS ( SELECT TOP 1
                                1
                        FROM    dbo.T_Order
                        WHERE   IsOverseasWarehouseOrder = 1
                                AND OverseasWarehouseStatus = 30  AND OrderId=@OrderId)
            BEGIN
			   --修改订单备注  
                SELECT  @remark = '北京时间 【' + CONVERT(VARCHAR(20),GETDATE(),20)
                        + '】 该订单的部分商品由 【' + WarehouseName + '】 发出，包裹追踪号为【'
                        + ISNULL(( SELECT TOP 1
                                            TrackingNumber
                                   FROM     dbo.T_OverseasWarehousePackage
                                   WHERE    StockOutCode = a.StockOutCode
                                 ),'') + '】，查询网址为'
                        + ( CASE WHEN d.ID IS NOT NULL THEN d.TrackingUrl
                                 ELSE c.TrackingUrl
                            END )
                FROM    dbo.T_OverseasWarehouseStockOutOrder a WITH ( NOLOCK )
                        LEFT JOIN dbo.T_OverseasWarehouse b ON a.Warehouse = b.WarehouseCode
                        LEFT JOIN dbo.T_OverseasWarehouseExpressService c ON a.ExpressService = c.ExpressServiceCode
                        LEFT JOIN dbo.T_OverseasWarehouseLogisticsCarriers d ON a.LogisticsCarriersId = d.ID
                WHERE   OrderId = @OrderId;  
		         
                UPDATE  a
                SET     OrderRemark = @remark + ';' + ISNULL(OrderRemark,'')
                FROM    dbo.T_OrderRemark a
                WHERE   OrderId = @OrderId;  
            END;
          
      --检查订单是否全部为发货状态，如果是则修改订单为发货状态    
        IF ( NOT EXISTS ( SELECT TOP 1
                                    1
                          FROM      T_OrderItem a
                          WHERE     OrderId = @OrderId
                                    AND Status NOT IN ( 12,8 ) )
           )
            BEGIN    
                UPDATE  T_Order
                SET     OrderStatus = 64 ,
                        DeliveryDate = GETDATE()
                WHERE   OrderId = @OrderId;    
	           
		 --记录订单历史    
                EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int    
                    @OrderId = @OrderId, -- varchar(14)    
                    @Remark = N'因海外仓商品全部发货，修改订单为已发货'; -- varchar(5000)    
            END;     
    END;     

	--如果是转运的出库单已发货，则更新转运状态
	IF EXISTS(SELECT TOP 1 1 FROM dbo.T_OverseasWarehouseStockOutOrder WHERE StockOutCode=@StockOutCode AND IsTransshipment=1)
	BEGIN
	      UPDATE dbo.T_Order SET TransshipmentStatus=3 WHERE OrderId=@OrderId

		   EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int    
                    @OrderId = @OrderId, -- varchar(14)    
                    @Remark = N'转运的商品已从海外仓发往客户'; -- varchar(5000)  
	END
go


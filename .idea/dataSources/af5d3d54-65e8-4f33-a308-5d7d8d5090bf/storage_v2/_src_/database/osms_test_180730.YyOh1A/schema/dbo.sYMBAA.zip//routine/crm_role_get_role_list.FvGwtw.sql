CREATE PROC dbo.CRM_Role_Get_Role_List  
(  
 @Name NVARCHAR(50) = NULL,  
 @Description NVARCHAR(500) = NULL,  
 @RightIdOne INT =NULL,  
 @RightIdTwo INT =NULL,  
 @RightIdThree INT =NULL,  
 @UserCode NVARCHAR(50) = '',  
 @UserName NVARCHAR(50) = '',
 @UserCodes NVARCHAR(500) = '',  
 @UserNames NVARCHAR(500) = ''  
)  
AS   
    BEGIN                      
        SET NOCOUNT ON ;   
        DECLARE @SQL VARCHAR(MAX)   
        DECLARE @Condition VARCHAR(MAX)  --条件   
        DECLARE @Column VARCHAR(MAX) --用于查询出来的列  
        DECLARE @FromSQL NVARCHAR(MAX)  --内查询用   
        DECLARE @Counts INT   
          
            --获得查询条件            
        SET @Condition = ' WHERE 1=1 '   
        SET @FromSQL = ' T_role R WITH (NOLOCK)   
       LEFT JOIN T_userRole UR WITH (NOLOCK) ON UR.roleid = R.id  
       LEFT JOIN [T_user] U  WITH (NOLOCK) ON U.id = UR.userid  '   
          
          
        IF @Name >''
   BEGIN  
    SET @Condition = @Condition + ' AND R.name like ''%'+ @Name + '%'''         
   END   
     
  IF @Description>''
   BEGIN  
    SET @Condition = @Condition + ' AND R.description like '''+ @Description + '%'''         
   END  
     
  IF  @RightIdThree>0
   BEGIN  
    SET @Condition = @Condition + ' AND R.id IN(  
     SELECT roleId FROM T_roleRight WHERE rightId = '+ CONVERT(VARCHAR(20), @RightIdThree)  +')'  
       
       
   END   
  IF  @RightIdTwo>0
   BEGIN  
    SET @Condition = @Condition + ' AND R.id IN   
      (select roleId from T_roleRight where rightId in  
       (  
        select id from [T_right] where  rightGroupId in  
        (  
         select id from t_rightGroup where id = '+ CONVERT(VARCHAR(20), @RightIdTwo) +'  
        )  
       )   
      ) '  
   END    
   IF @RightIdOne>0
   BEGIN  
       
    SELECT @Counts = Count(*) from right_group where parent_id =  CONVERT(VARCHAR(20), @RightIdOne)  
    IF @Counts IS NOT NULL AND @Counts > 0  
     BEGIN  
      SET @Condition = @Condition + ' AND R.id IN   
        (select roleId from T_roleright where rightId in  
         (  
          select id from [T_right] where  rightgroupid in  
          (  
           select id from t_rightGroup where parentid = '+ CONVERT(VARCHAR(20), @RightIdOne) +'  
          )  
         )   
        ) '  
     END  
    ELSE  
     BEGIN  
      SET @Condition = @Condition + ' AND R.id IN   
      (select roleid from T_roleright where rightid in  
       (  
        select id from [T_right] where  rightgroupid in  
        (  
         select id from T_rightgroup where id = '+ CONVERT(VARCHAR(20), @RightIdOne) +'  
        )  
       )   
      ) '  
     END      
   END   
     
  IF @UserCode>''
   BEGIN  
    SET @Condition = @Condition + ' AND U.code like '''+ @UserCode + '%'''   
   END  
     
  IF @UserName>''
   BEGIN  
    SET @Condition = @Condition + ' AND U.name like '''+ @UserName + '%'''   
   END   
       
  IF @UserCodes>''
  BEGIN  
   SET @Condition = @Condition +' AND U.code in (''' + REPLACE(@UserCodes,',',''',''') + ''')'    
  END  
  IF @UserNames>''
  BEGIN  
   SET @Condition = @Condition +' AND U.name in (''' + REPLACE(@UserNames,',',''',''') + ''')'    
  END   
      
  --设置需要取的字段信息              
        SET @Column = ' DISTINCT R.* ,  
   (SELECT u2.name +'','' FROM [t_user] u2 WHERE u2.id  
    IN (SELECT userid FROM T_userrole ur2 WHERE ur2.roleid = r.id) AND u2.isvalid = 1 
   FOR XML PATH('''')) AS userName '   
     
  SET @SQL = 'SELECT ' + @Column + ' FROM ' + @FromSQL +  @Condition  
  PRINT @SQL  
  EXEC (@SQL)     
     END
go



CREATE PROC dbo.CRM_UpdateBankTransferRecord
 (
 @Id INT,
@CustomerName VARCHAR(50),
@OrderId VARCHAR(200),
@CountryId INT,
@AccountType INT,
@PayCurrencyId INT,
@PayMoney DECIMAL(9,2),
@ReceiptCurrencyId INT,
@ReceiptMoeny DECIMAL(9,2),
@ReceiptTime VARCHAR(20),
@PayUserInfo NVARCHAR(200),
@TranNo VARCHAR(100),
@Remark NVARCHAR(500),
@Status INT
 )
 AS 
 BEGIN


  DECLARE @Message VARCHAR(100)='';

 IF   LEN(RTRIM(@TranNo))>0 AND  EXISTS (SELECT TOP 1 1 FROM dbo.T_BankTransferRecord WHERE TransactionNo=@TranNo AND Id<>@Id AND Type=1)
 BEGIN
 	       SET @Message = '<info>交易号'+@TranNo+'重复!</info>'            
       RAISERROR(@Message, 16, 1) WITH NOWAIT ;        
 END

 	UPDATE dbo.T_BankTransferRecord 
	SET 
		CustomerName=@CustomerName,
		OrderId=@OrderId,
		CountryId=@CountryId,
		AccountType=@AccountType,
		PayCurrencyId=@PayCurrencyId,
		PayMoney=@PayMoney,
		ReceiptCurrencyId=@ReceiptCurrencyId,
		ReceiptMoeny=@ReceiptMoeny,
 	  ReceiptTime=CASE WHEN ISDATE(@ReceiptTime)=1 AND  DATEPART(YEAR,@ReceiptTime)>1000 THEN convert(VARCHAR,@ReceiptTime, 121) ELSE NULL END , -- ReceiptTime - datetime
		PayUserInfo=@PayUserInfo,
		TransactionNo=@TranNo,
		Remark=@Remark,
		status=@Status
	WHERE Id=@Id
 END

go


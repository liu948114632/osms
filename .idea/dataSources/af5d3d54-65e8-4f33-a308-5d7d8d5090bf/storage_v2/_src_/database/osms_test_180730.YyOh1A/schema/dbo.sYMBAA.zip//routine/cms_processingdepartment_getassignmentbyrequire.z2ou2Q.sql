 
/**                  
 2012-03-27                
 获取订单待分配数量                  
*/                  
CREATE  PROC [dbo].[CMS_ProcessingDepartment_GetAssignmentByRequire]  
    (  
      @StockOutItemId INT = NULL ,  
      @ProductId INT = NULL ,--产品Id                
      @Qty INT = NULL , --数量      
      @DepartmentId INT = NULL ,--接货部门
      @StockOutId INT = null               
    )  
AS   
    BEGIN                        
        SET NOCOUNT ON ;                  
                        
        DECLARE @OrderItemId INT  
                --@receive_department_id INT,
            
        IF OBJECT_ID('#temp_processing_department_assignment_product') IS NOT NULL   
            DROP TABLE #temp_assignment_product ;                
         
        --SELECT  @receive_department_id = b.receive_department_id,
        --        @StockOutId = b.id  
        --FROM    dbo.stock_out_item AS a WITH ( NOLOCK )  
        --        INNER JOIN dbo.stock_out AS b WITH ( NOLOCK ) ON a.stock_out_id = b.id  
        --WHERE   a.id = @StockOutItemId              
        
        SELECT  temp.id AS orderItemId ,
                    temp.order_id AS orderId ,
                    temp.department_id AS departmentId ,
                    temp.code AS orderCode ,
                    temp.product_id AS productId ,
                   ( temp.quantity - temp.prepareLockQty2)
                      AS assignQuantity,
                      unit AS  productUnit,
                    0 
					 AS orderAssignQuantity 
                    ,co.number AS position,us.name AS assignPersion
                    INTO #temp_processing_department_assignment_product 
        FROM    ( SELECT  i.id ,
								o.id AS order_id,
                                ( i.plan_quantity ) AS quantity ,
                                i.product_id ,
                                i.unit ,
                                i.processing_id ,
                                o.code ,
                                o.department_id ,
                                o.create_time,
                                @Qty AS stock_out_qty ,
                                o.processor_id,
                                o.status,
                                i.task_status,
                                o.task_type,
                                  ISNULL(( SELECT SUM(sp.assign_quantity)
                                         FROM   dbo.assigment_stay_product AS sp
                                         WHERE  sp.order_item_id = i.id
                                                AND sp.status IN (0,1,2) AND sp.department_id =@DepartmentId
                                       ), 0) AS prepareLockQty2 
                  FROM      dbo.processing_item AS i
                                INNER JOIN dbo.processing AS o ON o.id = i.processing_id
                  WHERE     i.product_id = @ProductId  and   o.department_id = @DepartmentId
                                AND o.status <= 20  AND i.status IN (1,2,3)  
                ) temp  
                LEFT JOIN dbo.processing_processor_code co ON co.processor_id =temp.processor_id
                LEFT JOIN dbo.[user] us ON us.id =co.processor_id
            WHERE   temp.quantity > prepareLockQty2
            ORDER BY temp.status DESC,
            CASE WHEN temp.task_status=1 THEN 20 ELSE temp.task_status END DESC ,
            CASE WHEN temp.task_type IS NULL OR temp.task_type=0 THEN 20 ELSE temp.task_type END  ASC,
                    temp.create_time ASC   
                
              SELECT * FROM #temp_processing_department_assignment_product;  
          
        INSERT INTO dbo.temp_logistics_assignment_product_log
                ( orderItemId ,
                  orderId ,
                  departmentId ,
                  orderCode ,
                  productId ,
                  assignQuantity ,
                  orderAssignQuantity ,
                  productUnit ,
                  position ,
                  stockOutId  ,
                  createTime
                )
         SELECT orderItemId ,
                  orderId ,
                  departmentId ,
                  orderCode ,
                  productId ,
                  assignQuantity ,
                  orderAssignQuantity ,
                  productUnit ,
                  position ,
                  @StockOutId,
                  GETDATE()
        FROM #temp_processing_department_assignment_product;
                    
        DROP TABLE #temp_processing_department_assignment_product;  
    END


go


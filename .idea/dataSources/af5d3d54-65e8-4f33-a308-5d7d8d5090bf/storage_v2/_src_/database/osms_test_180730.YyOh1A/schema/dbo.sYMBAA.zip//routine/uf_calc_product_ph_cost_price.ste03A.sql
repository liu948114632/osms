

CREATE FUNCTION uf_calc_product_ph_cost_price
    (
      @cost_price DECIMAL(18, 6) ,
      @package_cost_price DECIMAL(18, 6) ,
      @proccing_cost_price DECIMAL(18, 6) ,
      @unit_qty INT ,
      @rate DECIMAL(18, 6) ,
      @first_profit_coefficient DECIMAL(18, 6)
    )
RETURNS DECIMAL(18, 6)
AS
    BEGIN
		DECLARE @operate_cost_price DECIMAL(18, 6);
		SET @operate_cost_price=dbo.uf_calc_product_operate_cost_price(@cost_price,@package_cost_price,
					@proccing_cost_price,@unit_qty)
        RETURN ISNULL(@operate_cost_price *@unit_qty/@rate*@first_profit_coefficient,0);
    END;


go


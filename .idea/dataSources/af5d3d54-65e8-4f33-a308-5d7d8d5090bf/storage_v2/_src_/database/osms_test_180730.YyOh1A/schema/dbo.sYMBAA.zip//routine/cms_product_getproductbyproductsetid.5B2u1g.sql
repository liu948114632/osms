
  
  

/*        
* 2012-08-10        
* 根据产品集ID获取产品集下产品信息        
* 2012-09-10 返回仿牌与定制 
* 2014-02-18 增加下架状态返回字段 
*/        
CREATE PROC [dbo].[CMS_Product_GetProductByProductSetID]      
    (      
      @ProductSetId INT = NULL   --产品集ID          
    )      
AS       
    BEGIN                                
        SET NOCOUNT ON ;            
            
        SELECT temp1.*,    
               pp.provider_id AS providerId    
        FROM (     
        SELECT  p.[id] ,      
                p.[product_set_id] productSetId ,      
                p.[classification_id] classificationId ,      
                p.[material_id] materialId ,      
                p.[category_id_1] categoryId1 ,      
                p.[category_id_2] categoryId2 ,      
                p.[category_id_3] categoryId3 ,      
                p.[developer_id] developerId ,      
                p.[department_id] departmentId ,      
                p.[code] ,      
                p.[original_name] originalName ,      
                p.[name] ,      
                p.[product_set_specification_id] productSpecificationId ,      
                p.[unit_quantity] unitQuantity ,      
                p.[unit] ,      
                p.[provider_code] providerCode ,      
                p.[cost_price] costPrice ,      
                p.[weight] ,      
                p.[volume] ,      
                p.[product_set_color_card_id] productSetColorCardId ,      
                p.[guarantee_period] guaranteePeriod ,      
                p.[is_gift] isGift ,      
                p.[is_mix] isMix ,      
                p.[packaging_standard] packagingStandard ,      
                p.[heavy_metals] heavyMetals ,      
                p.[publish_status] publishStatus ,      
                p.[status] ,      
                p.[is_display_ph] isDisplayPh ,      
                p.[is_display_pw] isDisplayPw ,      
                p.[is_display_jl] isDisplayJl ,
                p.[is_display_uk] isDisplayUk ,
                p.[is_display_us] isDisplayUs ,
                p.[deal_mode] dealMode ,      
                p.[uploader_id] uploaderId ,      
                p.[upload_time] uploadTime ,      
                p.[submitter_id] submitterId ,      
                p.[submit_time] submitTime ,      
                p.[audit_time] auditTime ,      
                p.[primary_picture_code] primaryPictureCode ,      
                p.[color_card_picture_code] colorCardPictureCode ,      
                p.[auditor_id] auditorId ,      
                p.[audit_remark] auditRemark ,      
                p.[processing_cost] processingCost ,      
                p.[is_display] isDisplay ,      
                p.[competitor_type] competitorType ,      
                p.[processing_web_cost] processingWebCost ,   
				p.is_roughcast isRoughcast,  
				p.is_imitation_brand isImitationBrand,    
				p.is_cleaning AS isCleaning,
				p.feature_code AS featureCode,
				p.minimum_quantity AS minimumQuantity,
				p.offline_status AS offlineStatus,
				p.is_provider_stock isProviderStock,
				p.is_small_quantities isSmallQuantities,
                (CASE WHEN ps.department_id IS NOT NULL THEN ps.department_id ELSE p.department_id END) AS strategyDepartmentId,    
                pd.description AS description ,
                pd.keyword AS keyword,
                pd.specific_description AS  specificDescription,
                p.is_valuables AS isValuables , 
                p.is_oversea AS isOverSea ,
                p.valuation_mode AS valuationMode ,
				p.original_price AS originalPrice ,
				p.work_fee AS workFee ,
				p.discount_rate AS discountRate ,
				p.silver_price AS silverPrice,
				p.is_ts AS isTs,
				p.is_ph_final_good AS isPhFinalGood,
				p.is_Boutique AS isBoutique,
				p.is_sw AS isSW 
        FROM    dbo.product p WITH ( NOLOCK )      
                INNER JOIN dbo.product_description pd WITH(NOLOCK) ON pd.product_id=p.id     
                LEFT JOIN dbo.product_strategy ps WITH ( NOLOCK ) ON p.id = ps.product_id    
                 WHERE   p.product_set_id = @ProductSetId      
                AND p.is_delete = 0       
         ) temp1          
                LEFT JOIN dbo.product_provider pp WITH ( NOLOCK ) ON temp1.strategyDepartmentId = pp.department_id      
                                                                    AND temp1.id = pp.product_id      
            
              
        SET NOCOUNT OFF ;                   
    END


go


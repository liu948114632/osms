
CREATE PROC dbo.CRM_Mac_EditMacAddress
(
@id INT,
@macAddress VARCHAR(30),
@departmentId INT,
@userCode VARCHAR(50)='',
@location VARCHAR(200)='',
@last_update_user_id int
)
AS 
BEGIN
	IF @id=0
	BEGIN
	 IF EXISTS (SELECT TOP 1 1 FROM dbo.T_MACAddress WHERE mac_address=@macAddress)
	 BEGIN
	 	  RAISERROR ('<info>mac地址重复</info>' , 16, 1) WITH NOWAIT;    
	 END
		INSERT INTO dbo.T_MACAddress
		        ( mac_address ,
		          user_code ,
		          location ,
		          department_id ,
		          last_update_user_id 
		        )
		VALUES  ( @macAddress , -- mac_address - varchar(50)
		          @userCode, -- user_code - varchar(50)
		          @location , -- location - nvarchar(500)
		          @departmentId, -- department_id - int
		          @last_update_user_id-- last_update_user_id - int		         
		        )
	END
	ELSE
	BEGIN
		UPDATE dbo.T_MACAddress
		 SET mac_address=@macAddress,
		 location=@location,
		 user_code=@userCode,
		 department_id=@departmentId
		 WHERE id=@id
	END
END

go


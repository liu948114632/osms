CREATE PROCEDURE CMS_addProductDescriptionInfoLog(
	@PropertyValueId INT = NULL--属性值id
)
AS
BEGIN
	insert into product_description_info_log(product_id,status,operate_time,property_value_id)
	select p.product_id,1,getDate(),@PropertyValueId
	from product_property_value p  where p.property_value = @PropertyValueId 
END

go


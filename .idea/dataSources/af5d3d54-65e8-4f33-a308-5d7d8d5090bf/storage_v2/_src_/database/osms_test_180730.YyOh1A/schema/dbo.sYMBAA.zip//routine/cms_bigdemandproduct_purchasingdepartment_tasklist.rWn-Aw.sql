
/**  
2014-11-08
获得大需求产品管理列表  
*/  
CREATE PROC [dbo].[CMS_BigDemandProduct_PurchasingDepartment_TaskList]      
(       
  @DepartmentId INT = NULL ,--部门ID
  @TaskType INT = NULL,  --任务类型  
  @TaskSubType INT = NULL,  --任务子类型 
  @AssginTimeBegin VARCHAR(20) = NULL, --查询任务到达时间的开始时间  
  @AssginTimeOver VARCHAR(20) = NULL, --查询任务到达时间的结束时间 
  @ProductCode VARCHAR(MAX) = NULL,--商品编号 
  @ProductCodeList VARCHAR(MAX) = NULL,--商品编号集合，多个编号用逗号隔开  
  @IsInvitedBidsTask BIT = NULL,--是否招标任务  
  @IsInvitedBidsProduct BIT = NULL,--是否招标产品
  @IsInvitedBidsResult INT = NULL,--招标结果 1.无投标、2.招标失败 3.招标成功
  @PurchasePrice DECIMAL(18,6) = NULL, --采购金额    
  @PageSize INT = 50 ,  --页大小  
  @PageIndex INT = 1    --当前页号  
)        
AS        
BEGIN        
    SET NOCOUNT ON ;        
          
    DECLARE @SQL VARCHAR(max),  
            @CountSql NVARCHAR(MAX), --查询数量用  
            @FromSQL NVARCHAR(max), --查询表
            @FromSQL2 NVARCHAR(max), --查询总数
            @Condition varchar(MAX), --条件   
            @RowCount INT , @PageCount INT , @start INT ,@end INT 
          
    SET @FromSQL =' FROM view_all_purchasing_department_task a WITH (NOLOCK)
					INNER JOIN product b WITH(NOLOCK) ON a.product_id = b.id
					LEFT JOIN task_invited_bids tib WITH (NOLOCK) ON tib.purchase_task_id = a.id'   
    SET @FromSQL2 =' FROM view_all_purchasing_department_task a WITH (NOLOCK)
					 INNER JOIN product b WITH(NOLOCK) ON a.product_id = b.id
					 LEFT JOIN task_invited_bids tib WITH (NOLOCK) ON tib.purchase_task_id = a.id'

    SET @Condition = ' WHERE 1=1 AND a.status IN (2,3,5) AND a.assign_to_department_id <> 0 '     
      
    IF @DepartmentId IS NOT NULL   
    BEGIN   
       SET @Condition = @Condition + ' AND a.assign_to_department_id=' + CONVERT(VARCHAR(10),@DepartmentId)  
    END  
    IF @TaskType IS NOT NULL   
    BEGIN   
       SET @Condition = @Condition + ' AND a.type=' + CONVERT(VARCHAR(10),@TaskType)  
    END     
    IF @TaskSubType IS NOT NULL   
    BEGIN   
       SET @Condition = @Condition + ' AND a.sub_type=' + CONVERT(VARCHAR(10),@TaskSubType)  
    END   
  
    IF @AssginTimeBegin IS NOT NULL   
    BEGIN   
       SET @Condition = @Condition + ' AND a.transmit_time >=''' + CONVERT(VARCHAR(20),@AssginTimeBegin) + ''''  
    END   
    IF @AssginTimeOver IS NOT NULL   
    BEGIN   
       SET @Condition = @Condition + ' AND a.transmit_time <=''' + CONVERT(VARCHAR(20),@AssginTimeOver) + ''''   
    END 
    IF @ProductCode IS NOT NULL   
    BEGIN   
       SET @Condition = @Condition + ' AND b.code like ''' + @ProductCode + '%'''  
    END 
    IF @ProductCodeList IS NOT NULL 
    BEGIN               
        SET @Condition = @Condition + ' AND b.code in ('''
            + REPLACE(@ProductCodeList, ',', ''',''') + ''')'              
    END
    IF @IsInvitedBidsProduct IS NOT NULL
    BEGIN 
        IF @IsInvitedBidsProduct = 1 
            BEGIN              
                SET @Condition = @Condition + ' AND b.is_invited_bid=1'              
            END               
        IF @IsInvitedBidsProduct = 0  
            BEGIN               
                SET @Condition = @Condition + ' AND b.is_invited_bid=0'              
            END                     
    END
    
    IF @IsInvitedBidsTask IS NOT NULL
    BEGIN           
        IF @IsInvitedBidsTask = 1 
            BEGIN              
                SET @Condition = @Condition + ' AND a.id IN (SELECT purchase_task_id  FROM task_invited_bids WITH(NOLOCK))'              
            END               
        IF @IsInvitedBidsTask = 0 
            BEGIN               
                SET @Condition = @Condition + ' AND a.id NOT IN (SELECT purchase_task_id FROM task_invited_bids WITH(NOLOCK))'              
            END                   
    END
    
    IF @IsInvitedBidsResult IS NOT NULL
    BEGIN
    	
    	IF @IsInvitedBidsResult = 1
    		BEGIN
    			 SET @Condition = @Condition + ' AND a.id IN (SELECT purchase_task_id FROM task_invited_bids WITH(NOLOCK) WHERE task_invited_bids_result = 1)' 
    		END
		IF @IsInvitedBidsResult = 2
			BEGIN
				 SET @Condition = @Condition + ' AND a.id IN (SELECT purchase_task_id FROM task_invited_bids WITH(NOLOCK) WHERE task_invited_bids_result = 2)' 
			END
		IF @IsInvitedBidsResult = 3
			BEGIN
				 SET @Condition = @Condition + ' AND a.id IN (SELECT purchase_task_id FROM task_invited_bids WITH(NOLOCK) WHERE task_invited_bids_result = 3)' 
			END
    END
    
    IF @PurchasePrice IS NOT NULL
    BEGIN
		SET @Condition = @Condition + ' AND (b.cost_price * a.plan_quantity) >= ' + CONVERT(VARCHAR(20),@PurchasePrice)  
    END
    
    
    
    
       
  
    SET @CountSql = ' SELECT @RowCount = count(a.id) ' + @FromSQL2 + @Condition  
    
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT        
      
--     SELECT @CountSql  
       
    IF ISNULL(@PageSize, 0) < 1         
        SET @PageSize = 50        
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize        
    IF ISNULL(@PageIndex, 0) < 1         
        SET @PageIndex = 1        
    ELSE         
    IF ISNULL(@PageIndex, 0) > @PageCount         
        SET @PageIndex = @PageCount        
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1        
    SET @end = @PageIndex * @PageSize 
    
          
            
    SET @SQL= 'SELECT * from (  
    SELECT a.id AS id,
      a.type as type,
      a.sub_type as subType,     
      a.product_id AS productId,
      b.code as productCode,
      CASE WHEN tib.id IS NOT NULL THEN 
				CASE WHEN tib.success_bids_provider_id > 0
					 THEN tib.success_bids_price
					 WHEN tib.success_bids_provider_id = 0
					 THEN b.cost_price
					 ELSE b.cost_price
					 END
		   ELSE  b.cost_price
		   END   AS costPrice,
			
     
      b.is_invited_bid as isInvitedBidsProduct,
      CASE WHEN tib.id IS NULL THEN 0 ELSE 1 END AS  isInvitedBidsTask, 
      a.plan_quantity AS planQuantity,  
      a.assign_time AS assignTime,
      a.assign_to_department_id AS assignToDepartmentId,  '
      
   
      
 SET @SQL = @SQL + 'ROW_NUMBER() OVER(ORDER BY a.status,a.transmit_time DESC) rowIndex' 
      
      
 SET @SQL = @SQL + @FromSQL +  @Condition + ') temp   
      where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and ' + CAST(@end AS NVARCHAR(10))
      +' ORDER BY assignTime DESC '  
       
--     SELECT @SQL  
     PRINT(@SQL)
   EXEC(@SQL);            
      
    select @RowCount      
END


go


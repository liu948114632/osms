


-- =============================================  
-- Author:  <HYD>  
-- Create date: <2010-01-07>  
-- Description: <得到订单付款记录>  
-- =============================================  
CREATE PROCEDURE [dbo].[CRM_Order_OrderPaysGet]  
(  
 @OrderId  NVARCHAR(20)  
)  
AS  
BEGIN  
 SET NOCOUNT ON;  
  
 SELECT  
  Id,  
  OrderId,  
  PaySum,  
  CurrencyId,  
  PayDate,  
  Remark,  
  ActionUserId,  
  [Action],
  PayType,
  PayId,
  IseCheckNoClear
 FROM  
  T_OrderPay   
 WHERE  
  OrderId = @OrderId   
 ORDER BY   
  PayDate DESC  
END

go


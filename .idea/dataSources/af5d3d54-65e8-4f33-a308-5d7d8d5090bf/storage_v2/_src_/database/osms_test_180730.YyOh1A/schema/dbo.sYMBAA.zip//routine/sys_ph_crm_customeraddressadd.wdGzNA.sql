CREATE PROC [dbo].[SYS_PH_CRM_CustomerAddressAdd]
    (
      @Firstname NVARCHAR(50) ,
      @Lastname NVARCHAR(50) ,
      @Phone NVARCHAR(50) ,
      @Fax NVARCHAR(50) ,
      @Street1 NVARCHAR(200) ,
      @Street2 NVARCHAR(200) ,
      @City NVARCHAR(50) ,
      @Country INT ,
      @State NVARCHAR(50) ,
      @Zip NVARCHAR(50) ,
      @CompanyName VARCHAR(100) ,
      @AddressID INT OUT	
    )
AS 
    BEGIN
        IF @AddressID > 0 
            BEGIN
                UPDATE  [dbo].[T_Addresses]
                SET     [Firstname] = @Firstname ,
                        [Lastname] = @Lastname ,
                        [Phone] = @Phone ,
                        [Fax] = @Fax ,
                        [Street1] = @Street1 ,
                        [Street2] = @Street2 ,
                        [City] = @City ,
                        [Country] = @Country ,
                        [State] = @State ,
                        [Zip] = @Zip ,
                        [CompanyName] = @CompanyName
                WHERE   [AddressId] = @AddressID
            END
        ELSE 
            BEGIN
                SET @AddressID = ( SELECT   ISNULL(MAX(AddressID), 0) + 1
                                   FROM     dbo.T_Addresses
                                 );
			
                INSERT  INTO dbo.T_Addresses
                        ( [AddressID] ,
                          [Firstname] ,
                          [Lastname] ,
                          [Phone] ,
                          [Fax] ,
                          [Street1] ,
                          [Street2] ,
                          [City] ,
                          [Country] ,
                          [State] ,
                          [Zip] ,
                          [CompanyName]
					    )
                VALUES  ( @AddressID ,
                          @Firstname ,
                          @Lastname ,
                          @Phone ,
                          @Fax ,
                          @Street1 ,
                          @Street2 ,
                          @City ,
                          @Country ,
                          @State ,
                          @Zip ,
                          @CompanyName 
						);  
            END
    END

go


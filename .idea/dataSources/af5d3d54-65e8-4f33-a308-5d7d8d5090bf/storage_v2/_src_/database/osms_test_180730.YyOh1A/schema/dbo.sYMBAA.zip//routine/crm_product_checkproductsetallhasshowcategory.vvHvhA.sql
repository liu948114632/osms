--检查PW产品集里面产品是否都绑定了展示类别
CREATE PROC CRM_Product_CheckProductSetAllHasShowCategory
(
@ProductSetId INT,
@IsAllHas BIT =1 OUT
)
AS 
BEGIN
	IF EXISTS(SELECT  TOP 1 1 FROM dbo.V_CRM_All_Product  a WITH(NOLOCK)
	LEFT JOIN pw_show_category_related_category b WITH(NOLOCK) ON a.CategoryId=b.category_id
	WHERE a.ProductSetId=@ProductSetId
	AND ISNULL(b.first_show_category_id,0)=0)
	BEGIN
			SET @IsAllHas=0
	END
	ELSE
	BEGIN
		SET @IsAllHas=1
	END
END

go


  
-- =============================================    
-- Author:  HYD    
-- Create date: 2011-10-18    
-- Description: 根据产品Id获取产品信息    
-- =============================================    
CREATE PROC CRM_Product_ProductGetById    
 @ProductId INT    
AS    
BEGIN    
 -- SET NOCOUNT ON added to prevent extra result sets from    
 -- interfering with SELECT statements.    
 SET NOCOUNT ON;    
    
 SELECT * FROM dbo.V_CRM_Base_Product WHERE CmsProductId = @ProductId    
END
go


--获得商品的状态
--返回值：0、不存在，1、存在并且显示，2、存在但不显示
CREATE PROCEDURE [dbo].[US_Product_GetProductStatus]
(  
    @ProductId INT  
)  
AS  
BEGIN   
     DECLARE @IsDisplay BIT 
     SELECT @IsDisplay = Is_Display FROM T_Product_US WHERE ProductId=@ProductId AND IsDeleted=0
  
	 IF @IsDisplay IS NULL
	 BEGIN-- 商品不存在
		 SELECT 0  
	 END 
	 ELSE IF @IsDisplay = 1
	 BEGIN --存在并且显示
		 SELECT 1  
	 END 
	 ELSE
	 BEGIN  --存在但不显示
		 SELECT 2 
	 END 
END
go


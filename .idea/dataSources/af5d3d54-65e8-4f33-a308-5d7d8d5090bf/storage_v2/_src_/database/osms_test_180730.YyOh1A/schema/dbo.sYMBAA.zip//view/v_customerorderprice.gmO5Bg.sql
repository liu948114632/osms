
/*--------------------------------------------------------      
[备注]      
 获取每个客户的总订单金额,已发货的才算      
-------------------------------------------------------------*/      
CREATE VIEW dbo.V_CustomerOrderPrice         
AS   
WITH cte AS(
SELECT     
 e.CustomerId, e.OrderIndustryType, c.IsPHClone,
--ISNULL(SUM((CASE WHEN EXISTS (SELECT TOP 1 ProductId FROM dbo.T_StylebookProduct WHERE ProductId=CmsProductId) THEN (f.Quantity - f.UnitQuantity) ELSE f.Quantity END)* f.ItemPrice * 1.0 / f.UnitQuantity),0) AS OrderPrice
  ISNULL(SUM( CASE WHEN g.ProductId>0 THEN  f.Quantity- f.UnitQuantity ELSE f.Quantity END * f.ItemPrice * 1.0 / f.UnitQuantity),0)  AS OrderPrice
FROM dbo.T_Order e  WITH(NOLOCK)
JOIN dbo.T_OrderItem f WITH(NOLOCK) ON f.OrderId = e.OrderId AND f.Status < 12 
LEFT JOIN T_StylebookProduct g WITH(NOLOCK) ON g.ProductId=f.CmsProductId
LEFT JOIN dbo.T_BusinessType c WITH(NOLOCK) ON c.BusinessTypeValue=e.OrderIndustryType
WHERE  e.OrderStatus IN(64,128) AND (e.OrderIndustryType IN(1,5,6,16,17)  OR c.IsPHClone=1)
GROUP BY e.CustomerId,c.IsPHClone, OrderIndustryType 
)
SELECT DISTINCT
a.CustomerId,
(SELECT SUM(OrderPrice) FROM cte h WHERE h.CustomerId = a.CustomerId AND (h.OrderIndustryType = 1 OR h.OrderIndustryType=5 OR h.OrderIndustryType=6 OR h.IsPHClone=1)) AS PhOrderPrice,
(SELECT OrderPrice FROM cte w WHERE w.CustomerId = a.CustomerId AND w.OrderIndustryType = 16) AS PwOrderPrice,
(SELECT OrderPrice FROM cte j WHERE j.CustomerId = a.CustomerId AND j.OrderIndustryType = 17) AS JlOrderPrice
FROM cte a
go


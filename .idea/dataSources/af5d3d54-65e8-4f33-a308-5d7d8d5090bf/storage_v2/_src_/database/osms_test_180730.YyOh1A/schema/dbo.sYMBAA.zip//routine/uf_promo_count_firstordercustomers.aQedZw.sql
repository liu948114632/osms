
/*-----------------------------------------------------
[描述]
	获取某天的首次下单客户数量
当天有过订单，但之前从来没有下个单的数量
网站订单取下单日期，邮件订单取录单日期
Convert(VARCHAR(8),OrderDate,112)
------------------------------------------------------*/
CREATE FUNCTION [dbo].[uf_promo_count_FirstOrderCustomers]
(
	@Date		Nvarchar(8) -- 20071004
)
RETURNS Int
AS
BEGIN
	Declare	@n	INT;

	Set @n = 0;

	WITH cte1 AS
	(
		SELECT
			CustomerId,OrderDate
			From dbo.T_Order
		Where
			OrderStatus > 0 AND OrderStatus < 132 -- 以录单数据为准
				AND OrderType IN(1,2) -- 网站订单和邮件订单且不包含P单 
	),
	cte2 AS 
	(
		-- 返回每个客户的首个订单
		SELECT CustomerId,CONVERT(VARCHAR(8),MIN(OrderDate),112) AS OrderDate
		FROM cte1
		GROUP BY CustomerId
	)
	
	-- 搜索第一个订单为统计当天的客户
	SELECT @n = COUNT(1) FROM cte2 WHERE OrderDate = @Date;
	
	IF @n IS NULL SET @n = 0;
	
	RETURN @n;
	
END

go


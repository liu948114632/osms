---获取订单扣件列表
CREATE PROC dbo.CRM_Order_GetOrderDetentionList
(
@OrderId VARCHAR(15)='',
@StartDate VARCHAR(30)='',        
@EndDate VARCHAR(30)='',     
@isDetention INT=-1,
@OrderIndustryType INT=-1,
@CreaterUser VARCHAR(20)='' ,
@HandlerId INT=-1,
@OrderStatus INT=-1,
@PageSize INT=50,        
@PageIndex INT=1  
)
AS        
BEGIN        
 SET NOCOUNT ON;        
 DECLARE @sql NVARCHAR(max)        
 DECLARE @countSql NVARCHAR(max)        
 DECLARE @rowCount int,@pageCount int, @startPageIndex int, @endPageIndex int        
         
 SET  @sql = N' 
 select a.*,b.OrderIndustryType,b.OrderStatus,b.HandlerId,
 ROW_NUMBER() OVER(ORDER BY Id desc ) AS RowNo 
  from T_OrderDetention  a WITH(NOLOCK)
  INNER JOIN dbo.T_Order b WITH(NOLOCK) ON a.OrderId=b.OrderId
     where 1=1  '    

   IF(@OrderId<>'')        
 BEGIN        
  SET @sql = @sql + ' AND a.OrderId= '''+@OrderId+''''        
 END         
         
   IF(@OrderStatus>-1)        
 BEGIN        
  SET @sql = @sql + ' AND b.OrderStatus= '+LTRIM(@OrderStatus)
 END         
         

   IF(@StartDate<>'')        
 BEGIN         
    SET @sql = @sql + ' AND CreateTime>='''+ @StartDate+''''        
 END         
         
 IF(@EndDate<>'')        
 BEGIN         
    SET @sql = @sql + ' AND CreateTime<='''+ @EndDate+''''        
 END         
  
 IF(@isDetention>-1)        
 BEGIN        
     SET @sql = @sql + ' AND isDetention='+ ltrim(str(@isDetention))        
 END        
  
  IF(@OrderIndustryType>0)  
     BEGIN         
    SET @sql = @sql + ' AND OrderIndustryType='+ltrim(str(@OrderIndustryType))        
    END   
    
   IF(@CreaterUser<>'')        
 BEGIN        
  SET @sql = @sql + ' AND CreatorUserName ='''+ @CreaterUser+''''           
 END       

 IF @HandlerId>0
 BEGIN
 	     SET @sql = @sql + ' AND b.HandlerId='+ ltrim(str(@HandlerId))        
 END
     
 --得到记录条数          
    SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql + ') AS Items'          
    EXEC sp_executesql  @countSql, N'@rowCount INT OUT', @rowCount OUT           
         
 IF(@PageIndex<1) SET @PageIndex=1        
    SET @pageCount = (@RowCount + @PageSize - 1) / @PageSize          
    IF ISNULL(@PageIndex, 0) < 1 SET @PageIndex = 1          
    ELSE IF @PageIndex > @pageCount  SET @PageIndex = @pageCount          
    SET @startPageIndex = (@PageIndex - 1) * @PageSize + 1          
    SET @endPageIndex = @PageIndex * @PageSize         
              
 SET @sql = 'SELECT * FROM ('+@sql+') AS Items WHERE RowNo BETWEEN ' + ltrim(STR(@startPageIndex)) + ' AND ' + ltrim(STR(@endPageIndex))+' ORDER BY Id desc'        
         
    PRINT @sql        
    EXEC(@sql)         
         
    SELECT @rowCount   AS 'RowCount',@pageCount AS 'PageCount'  
END
go


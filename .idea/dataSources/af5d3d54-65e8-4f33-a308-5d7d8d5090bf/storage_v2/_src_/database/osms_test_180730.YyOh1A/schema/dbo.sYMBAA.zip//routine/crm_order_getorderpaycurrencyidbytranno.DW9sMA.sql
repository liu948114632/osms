CREATE PROC dbo.CRM_Order_GetOrderPayCurrencyIdByTranNo
(
@PayType INT,
@TranNo VARCHAR(100),
@CurrencyId INT OUT
)
AS
BEGIN

SET @CurrencyId=0;
IF @PayType=1--PayPal支付
BEGIN
		SELECT  TOP 1 @CurrencyId=b.Id FROM dbo.T_PaypalReturn a 
INNER JOIN dbo.T_Currency b ON a.mc_currency=b.Currency
WHERE a.txn_id=@TranNo
END
ELSE	--IF @PayType=2 --GC支付，15=FHT，16=Asia
BEGIN
	SELECT TOP 1  @CurrencyId=CurrenyId FROM dbo.T_GCReturn WHERE PayId=@TranNo
END

IF @CurrencyId=0
BEGIN
	SELECT TOP 1 @CurrencyId=CurrencyId  FROM dbo.T_WaitAssignedMoney WHERE TransactionNo=@TranNo
END

END
go



CREATE PROCEDURE [dbo].[CMS_Get_ProviderStorageProductApplayItem] 
@applayId INT = NULL  
AS  
    BEGIN      
        DECLARE @status INT;  
        SELECT  @status = status  
        FROM    dbo.provider_storage_product_buying_applay  
        WHERE   id = @applayId;  
        IF @status = 4  
            BEGIN  
                SELECT  a.id ,  
                        a.applay_id AS applayId ,  
                        a.product_id AS productId ,  
                        b.primary_picture_code AS primaryPictureCode ,  
                        b.code AS productCode ,  
                        a.unit ,  
                        a.cost_price AS costPrice ,  
                        a.unit_quantity AS unitQuantity ,  
                        a.prepare_quantity AS prepareQuantity ,  
                        a.buying_quantity AS buyingQuantity ,  
                        a.provider_quantity AS providerQuantity ,  
                        a.sell_quantity AS sellQuantity ,  
                        a.provider_id AS providerId ,  
                        c.code AS providerCode ,  
                        a.plan_buy_quantity AS planBuyQuantity ,  
                        a.actual_buy_quantity AS actualBuyQuantity, 
                        discount 
                FROM    dbo.provider_storage_product_buying_applay_item a  
                        JOIN product b ON a.product_id = b.id  
                        JOIN dbo.provider c ON c.id = a.provider_id  
                WHERE   a.applay_id = @applayId;  
            END;  
        ELSE  
            BEGIN  
                SELECT  a.id ,  
                        a.applay_id AS applayId ,  
                        a.product_id AS productId ,  
                        b.primary_picture_code AS primaryPictureCode ,  
                        b.code AS productCode ,  
                        b.unit ,  
                        b.cost_price AS costPrice ,
                        dbo.Fu_CMS_GetProductProviderPromote(b.id, a.actual_buy_quantity) AS discount,
                        b.unit_quantity AS unitQuantity ,  
                        g.prepare_qty AS prepareQuantity ,  
                        g.buying_quantity AS buyingQuantity ,  
                        v.quantity - g.buying_quantity AS providerQuantity ,  
                        g.sellQty AS sellQuantity ,  
                        f.provider_id AS providerId ,  
                        c.code AS providerCode ,  
                         case when g.is_hot=0 then 0  
							  WHEN (ISNULL(g.prepare_qty,0)-ISNULL(g.buying_quantity,0))<0 then 0  
                             WHEN FLOOR(( ISNULL(g.prepare_qty, 0)  
                                          - ISNULL(g.buying_quantity, 0) )  
                                        * 1.00 / b.unit_quantity)  
                                  * b.unit_quantity <= FLOOR(( ISNULL(v.quantity,  
                                                              0)  
                                                              - ISNULL(g.buying_quantity,  
                                                              0) )  
                                                             / b.unit_quantity)*b.unit_quantity  
                             THEN FLOOR(( ISNULL(g.prepare_qty, 0)  
                                          - ISNULL(g.buying_quantity, 0) )  
                                        * 1.00 / b.unit_quantity)  
                                  * b.unit_quantity  
                             ELSE FLOOR(( ISNULL(v.quantity, 0)  
                                          - ISNULL(g.buying_quantity, 0) )  
                                        / b.unit_quantity) * b.unit_quantity  
                        END AS planBuyQuantity ,  
                        a.actual_buy_quantity AS actualBuyQuantity  
                FROM    dbo.provider_storage_product_buying_applay_item a  
                        JOIN product b ON a.product_id = b.id  
                        JOIN dbo.product_strategy d ON d.product_id = b.id  
                        JOIN dbo.product_provider f ON f.product_id = b.id  
                                                       AND f.department_id = d.department_id  
             JOIN dbo.provider c ON c.id = f.provider_id  
                        LEFT JOIN dbo.provider_storage_product g ON g.product_id = b.id  
                        LEFT JOIN dbo.view_product_all_storage_quantity_info v ON v.product_id = a.product_id  
                WHERE   a.applay_id = @applayId;  
            END;  
    END;

go


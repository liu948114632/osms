


/*-----------------------------------------------
[备注]: 
	 逻辑删除指定的包裹
--------------------------------------------*/
CREATE PROC [dbo].[CRM_Order_PackageDelete]
(
    @OrderId   NVARCHAR(20)
)
AS
BEGIN
	UPDATE dbo.T_OrderPackage SET [Disabled] = 1 WHERE [OrderId] = @OrderId;
END
go


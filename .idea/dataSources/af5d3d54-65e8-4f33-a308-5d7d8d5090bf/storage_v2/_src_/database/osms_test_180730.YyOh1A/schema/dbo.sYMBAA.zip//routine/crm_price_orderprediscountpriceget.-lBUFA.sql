
/*----------------------------------------------------    
[备注]:获取订单正常商品的折前价值    
[创建人]:FRH    
[创建时间]:2009-12-28    
----------------------------------------------------------*/    
CREATE PROC [dbo].[CRM_Price_OrderPreDiscountPriceGet]     
(    
 @OrderId   VARCHAR(20), -- 订单编号    
 @Price   DECIMAL(18,2) OUT, -- 商品价值    
 @ReadyPrice  DECIMAL(18,2) OUT -- 备货商品价值    
)    
AS    
BEGIN    
 Select     
  @Price = SUM(Quantity*1.0*SalePrice/UnitQuantity),    
  @ReadyPrice = SUM(ReadyQty*1.0*SalePrice/UnitQuantity)    
 From    
  dbo.T_OrderItem      
 Where     
  OrderId = @OrderId      
   And Status < 12 -- 排除取消商品    
    AND IsPromote = 0 -- 排除促销    
       
 If @Price Is Null Set @Price = 0;    
 If @ReadyPrice Is Null Set @Price = 0;    
     
END

go


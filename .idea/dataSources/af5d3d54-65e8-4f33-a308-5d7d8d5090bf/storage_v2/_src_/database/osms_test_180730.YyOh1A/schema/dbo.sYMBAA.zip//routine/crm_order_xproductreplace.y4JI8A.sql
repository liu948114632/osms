


/*--------------------------------------------------
备注:多个商品替代原订单中的X商品
创建人: FRH
创建日期:2009-12-31	
-------------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_XProductReplace] 
(
	@OrderId 		NVARCHAR(20),
	@XOrderItemId	INT,	-- 被替换掉的X商品	
	@UserId			INT	
)
AS
Declare
	@OrderItemId	INT,
	@ProductId		INT,
	@XProductId		INT,
	@No				INT,
	@Count			INT,
	@Weight			INT,
	@SingleWeight	INT,
	@ReadyQty		INT,
	@TidyUpId		VARCHAR(13),
	@XStatus		INT,
	@XFreight		Decimal(18,2),
	@SingleFreight	DECIMAL(18,2),
	@AddFreight		DECIMAL(18,2) -- 商品分配到的x运费总和
BEGIN

	-- 不记录行的变化 
	SET NOCOUNT ON;

	-- 获取订单中已经添加的用于替代X商品的新商品的总重量
	SET @Weight = 0
	SELECT 
		@Weight = SUM(Quantity*1.0*WEIGHT/UnitQuantity) 
	From 
		dbo.T_OrderItem 
	Where 
		OrderId = @OrderId AND [Type] = 255;  -- 类型255：替代X商品的新商品 
	
	-- 获取X商品的运费和备货数
	SET @XFreight = 0
	SET @XProductId = 0

	SELECT @XFreight = XFreight,@ReadyQty = ReadyQty,@XProductId = ProductId,@XStatus = Status
	FROM dbo.T_OrderItem 
	WHERE OrderItemId = @XOrderItemId;

	-- 定义表变量，用来保存用于替代X商品的新商品
	DECLARE 
		@OrderItems 
	TABLE
	(
		Id			INT IDENTITY,
		ProductId	INT,
		OrderItemId INT,			-- 订单商品项Id
		Weight		INT				-- 订单商品的总重量
	);

	-- 插入数据
	INSERT INTO 
		@OrderItems
	SELECT 
		ProductId,
		[OrderItemId],
		[Weight] * Quantity * 1.0/UnitQuantity
	FROM
		dbo.T_OrderItem
	WHERE
		OrderId = @OrderId AND [Type] = 255;
		
	SET @Count = @@ROWCOUNT;
	SET @No = 1;
	SET @AddFreight = 0;
	
	WHILE(@No <= @Count)
	BEGIN				
		-- 获取临时表中单个商品的总重量
		SET @SingleWeight = 0;			
		SELECT @SingleWeight = [Weight] FROM @OrderItems WHERE Id = @No;
		
		-- 获取订单商品编号
		SET @ProductId = 0;
		SET @OrderItemId = 0;
		SELECT @ProductId = ProductId,@OrderItemId = OrderItemId FROM @OrderItems WHERE Id = @No;

		-- 最后一个商品取剩余的X运费
		IF (@No = @Count)
		BEGIN
			SET	@SingleFreight = @XFreight - @AddFreight;					
		END
		ELSE
		BEGIN
			SET @SingleFreight = ROUND(@XFreight * @SingleWeight/@Weight,2);
		END			

		-- 更新订单中商品的运费
		UPDATE dbo.T_OrderItem 
		SET XFreight = @SingleFreight,[Type] = 2 -- 2:X商品 
		WHERE OrderItemId = @OrderItemId;
		
		SET @No = @No + 1;
		SET @AddFreight = @AddFreight + @SingleFreight;
	END

	-- 更新被替换掉的X商品
	UPDATE dbo.T_OrderItem
	SET [Status] = 12 -- XFreight = 0,
	WHERE OrderItemId = @XOrderItemId;
END

go


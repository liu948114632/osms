CREATE PROCEDURE [dbo].[US_PropertyValue_AddPropertyValue]
(
	@PropertyValueId INT,
	@PropertyId INT
)
AS
BEGIN 
	IF NOT EXISTS (SELECT 1 FROM dbo.T_PropertyValue_US WHERE PropertyValueId=@PropertyValueId)
	BEGIN
		INSERT INTO dbo.T_PropertyValue_US (
			PropertyValueId,
			PropertyId,
			IsDeleted,
			CreateDate,
			LastUpdateDate
		) VALUES ( 
			@PropertyValueId,
			@PropertyId,
			0,
			GETDATE(),
			GETDATE() ) 
	END
	ELSE
	BEGIN
		UPDATE dbo.T_PropertyValue_US SET IsDeleted=0,LastUpdateDate=GETDATE() WHERE PropertyValueId=@PropertyValueId
	END
END
go


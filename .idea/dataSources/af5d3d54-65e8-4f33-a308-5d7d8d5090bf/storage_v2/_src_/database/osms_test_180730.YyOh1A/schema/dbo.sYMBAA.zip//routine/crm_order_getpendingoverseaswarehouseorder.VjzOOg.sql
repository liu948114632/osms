
CREATE PROC CRM_Order_GetPendingOverseasWarehouseOrder
AS
begin
      SELECT OrderId
      FROM dbo.T_Order 
      WHERE IsOverseasWarehouseOrder = 1 AND OverseasWarehouseStatus = 10 AND OrderStatus<>132--排除取消订单
      AND OrderId NOT  IN (SELECT OrderId FROM dbo.T_OrderSubmitOverseasWarehouseLog WHERE  Status=0)
END

go


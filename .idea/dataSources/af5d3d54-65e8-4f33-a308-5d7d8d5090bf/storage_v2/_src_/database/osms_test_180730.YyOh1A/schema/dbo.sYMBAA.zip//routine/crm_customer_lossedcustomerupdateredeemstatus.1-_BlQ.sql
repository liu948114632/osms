CREATE PROC dbo.CRM_Customer_LossedCustomerUpdateRedeemStatus                  
( 
@OrderId VARCHAR(20) 
)
AS
BEGIN
DECLARE @CustomerId INT=0
DECLARE @DigCustomerId INT=0

   SELECT TOP 1 @CustomerId=CustomerId  FROM dbo.T_Order WHERE OrderId=@OrderId AND (OrderIndustryType=1 OR OrderIndustryType=5 OR OrderIndustryType=6)
   
	IF @CustomerId>0 AND  EXISTS (SELECT TOP  1 1 FROM dbo.T_LossedCustomer WHERE CustomerId=@CustomerId AND RedeemStatus<>10)
	BEGIN
		UPDATE T_LossedCustomer SET RedeemStatus=10 WHERE CustomerId=@CustomerId
	END

	
   SELECT TOP 1 @CustomerId=CustomerId  FROM dbo.T_Order WHERE OrderId=@OrderId  AND (OrderIndustryType=1 OR OrderIndustryType=5 OR OrderIndustryType=6 OR OrderIndustryType=16)
		IF @CustomerId>0 AND  EXISTS (SELECT TOP  1 1 FROM dbo.T_LossedCustomerNew WHERE CustomerId=@CustomerId AND RedeemStatus<>10)
	BEGIN
		UPDATE dbo.T_LossedCustomerNew SET RedeemStatus=10 WHERE CustomerId=@CustomerId
		EXEC dbo.CRM_Customer_AddLossedCustomerLog @CustomerId =@CustomerId, -- int
		    @OperatorId = 0, -- int
		    @log = N'客户下单，自动变为 已挽回', -- nvarchar(2000)
		    @EmailContent = N'' -- nvarchar(max)
		
	END

	   
	IF @CustomerId>0 AND  EXISTS (SELECT TOP  1 1 FROM dbo.T_DigCustomerDetail a INNER JOIN dbo.T_DigCustomer b ON a.DigCustomerId=b.DigCustomerId WHERE b.CustomerId=@CustomerId AND a.ActiveStatus<>4)
	BEGIN
		UPDATE a SET a.ActiveStatus=4
		 FROM  dbo.T_DigCustomerDetail a INNER JOIN 
		 dbo.T_DigCustomer b ON a.DigCustomerId=b.DigCustomerId
		  WHERE b.CustomerId=@CustomerId 

			SELECT @DigCustomerId=DigCustomerId FROM dbo.T_DigCustomer b WHERE	 b.CustomerId=@CustomerId

		  EXEC dbo.CRM_Customer_AddDigCustomerLog @DigCustomerId = @DigCustomerId, -- int
		      @OperatorId = 0, -- int
		      @log = N'客户下单，自动变为已激活', -- nvarchar(2000)
		      @EmailContent = N'' -- nvarchar(max)
		  
	END
END

go


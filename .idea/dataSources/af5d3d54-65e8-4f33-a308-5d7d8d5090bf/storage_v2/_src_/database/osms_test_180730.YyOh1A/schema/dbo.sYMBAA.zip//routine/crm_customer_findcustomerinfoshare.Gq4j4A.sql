CREATE PROC CRM_Customer_FindCustomerInfoShare
(
@ShareByHandlerId INT=-1,
@ShareToHandler INT=-1,
@ShareTimeQuantum INT=-1,
@ShareWay INT=-1,
@pageIndex INT=1,
@pageSize INT=50
)
AS
	BEGIN        
 SET NOCOUNT ON;        
 DECLARE @sql NVARCHAR(max)=''      
 DECLARE @countSql NVARCHAR(max) =''
 DECLARE @rowCount int,@pageCount int, @startPageIndex int, @endPageIndex int 

 SET  @sql = N' 
 SELECT id,ShareByHandlerId,ShareTimeQuantum,ShareWay,CreateUserId,CreateDate,
 (SELECT c.name+CASE WHEN b.BusinessType=1 THEN ''(PH)'' ELSE ''(PW)'' END +'';'' FROM dbo.T_CustomerInfoShareHandler b WITH(NOLOCK) 
 INNER JOIN t_user c WITH(NOLOCK) ON c.id=b.HandlerId
 WHERE  b.ShareId=a.Id FOR XML PATH('''')) AS ShareToHandlerStr,
 ROW_NUMBER() OVER(ORDER BY id DESC ) as RowNo FROM dbo.T_CustomerInfoShare a  WITH(NOLOCK) 
  where 1=1  '    


 --得到记录条数          
    SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql + ') AS Items'          

	PRINT @countSql

    EXEC sp_executesql  @countSql, N'@rowCount INT OUT', @rowCount OUT         
	
 IF(@PageIndex<1) SET @PageIndex=1        
    SET @pageCount = (@RowCount + @PageSize - 1) / @PageSize          
    IF ISNULL(@PageIndex, 0) < 1 SET @PageIndex = 1          
    ELSE IF @PageIndex > @pageCount  SET @PageIndex = @pageCount          
    SET @startPageIndex = (@PageIndex - 1) * @PageSize + 1          
    SET @endPageIndex = @PageIndex * @PageSize         
              
 SET @sql = 'SELECT * FROM ('+@sql+') AS Items WHERE RowNo BETWEEN ' + ltrim(STR(@startPageIndex)) + ' AND ' + ltrim(STR(@endPageIndex))+' ORDER BY RowNo '        
         
    PRINT @sql        
    EXEC(@sql)         

  SELECT @rowCount   AS 'RowCount',@pageCount AS 'PageCount'   
         
END
go


-- =============================================      
-- Author:  LXH      
-- Create date: 2012-8-3      
-- Description: 根据产品Id获取主图      
-- =============================================      
CREATE PROC CRM_Product_ProductPrimaryImageGet      
 @ProductId INT,      
 @ImageName VARCHAR(300) OUT       
AS      
BEGIN      
 -- SET NOCOUNT ON added to prevent extra result sets from      
 -- interfering with SELECT statements.      
 SET NOCOUNT ON;      
      
 SELECT @ImageName = dbo.V_CRM_ProductImages.PictureName FROM dbo.V_CRM_ProductImages WHERE CmsProductId = @ProductId AND dbo.V_CRM_ProductImages.Type = 1      
       
 IF( @ImageName IS NULL ) SET @ImageName = ''      
END
go


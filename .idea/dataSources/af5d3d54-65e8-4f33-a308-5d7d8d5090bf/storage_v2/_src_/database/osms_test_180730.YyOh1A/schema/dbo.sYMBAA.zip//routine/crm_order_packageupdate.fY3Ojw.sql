

/*----------------------------------------------         
备注:更新包裹        
创建人: FRH        
创建日期:2009-12-30        
------------------------------------------------------*/        
-- =============================================        
-- modify:  HYD        
-- Create date: 2010-06-08        
-- Description: 原先判断包裹是否确认IF @Status = 4 改为 IF @Status = 90        
-- Version:CRM 5.1        
-- =============================================        
CREATE PROCEDURE [dbo].[CRM_Order_PackageUpdate]        
(        
 @OrderId   VARCHAR(20),        
 @DeliveryId   INT,        
 @TraceNo   VARCHAR(200),        
 @GoodsCode   VARCHAR(200),   --货代号     
 @Status    INT,        
 @DealStatus   int,        
 @Disabled   BIT,        
 @Remark    NVARCHAR(500)        
)        
AS        
BEGIN        
 UPDATE          
  dbo.T_OrderPackage        
 SET           
  DeliveryId  = @DeliveryId,        
  TraceNo   = @TraceNo,        
  GoodsCode = (CASE WHEN @GoodsCode is null then GoodsCode else @GoodsCode END),      
  [Status]  = @Status,        
  DealStatus  = @DealStatus,        
  Remark   = @Remark,        
  UpdateDate  = GETDATE()        
 WHERE         
  [OrderId]  = @OrderId;         

 -- 包裹状态为确认时，更新订单状态为完成        
 IF @Status = 90        
 BEGIN        
  -- 更新订单状态           
  UPDATE dbo.T_Order         
  SET [OrderStatus] = 128,LastModifyTime = GETDATE()        
  WHERE OrderId = @OrderId;        

  -- 完成订单项        
  UPDATE dbo.T_OrderItem        
  SET [Status] = 10        
  WHERE OrderId = @OrderId And [Status] < 10;        
 END         

END
go


CREATE PROC CRM_Mac_GetMacAddressList
(
@departmentId INT=-1,
@userCode VARCHAR(50)='',
@macAddress VARCHAR(30)='',
@userName VARCHAR(50)='',
@pageIndex INT=1,
@pageSize INT=50
)
AS
	BEGIN        
 SET NOCOUNT ON;        
 DECLARE @sql NVARCHAR(max)        
 DECLARE @countSql NVARCHAR(max)        
 DECLARE @rowCount int,@pageCount int, @startPageIndex int, @endPageIndex int 
         
 SET  @sql = N' 
SELECT a.*,b.Name AS DeptName,c.name AS userName, ROW_NUMBER() OVER(ORDER BY a.Id desc ) AS RowNo  FROM dbo.T_MACAddress a WITH(NOLOCK)
LEFT JOIN dbo.T_Dept b WITH(NOLOCK) ON a.department_id=b.Id
LEFT JOIN dbo.T_User c WITH(NOLOCK) ON c.code=a.user_code
   where 1=1  '    

  IF(@departmentId>0)  
     BEGIN         
    SET @sql = @sql + ' AND department_id='+ltrim(str(@departmentId))        
    END   
	
  IF(@userCode>'')        
 BEGIN        
     SET @sql = @sql + ' AND user_code  like ''%'+@userCode+'%'''
 END        
  
  IF(@macAddress>'')        
 BEGIN        
     SET @sql = @sql + ' AND mac_address  like ''%'+@macAddress+'%'''
 END   

  IF(@userName>'')        
 BEGIN        
     SET @sql = @sql + ' AND c.Name  like ''%'+@userName+'%'''
 END   
 --得到记录条数          
    SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql + ') AS Items'          

	PRINT @countSql

    EXEC sp_executesql  @countSql, N'@rowCount INT OUT', @rowCount OUT          
	

         
 IF(@PageIndex<1) SET @PageIndex=1        
    SET @pageCount = (@RowCount + @PageSize - 1) / @PageSize          
    IF ISNULL(@PageIndex, 0) < 1 SET @PageIndex = 1          
    ELSE IF @PageIndex > @pageCount  SET @PageIndex = @pageCount          
    SET @startPageIndex = (@PageIndex - 1) * @PageSize + 1          
    SET @endPageIndex = @PageIndex * @PageSize         
              
 SET @sql = 'SELECT * FROM ('+@sql+') AS Items WHERE RowNo BETWEEN ' + ltrim(STR(@startPageIndex)) + ' AND ' + ltrim(STR(@endPageIndex))+' ORDER BY Id desc'        
         
    PRINT @sql        
    EXEC(@sql)         

  SELECT @rowCount   AS 'RowCount',@pageCount AS 'PageCount'   
         
END
go


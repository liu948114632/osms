CREATE PROC CRM_Customer_SaveAddress
    (
      @UserId INT ,
      @Usage TINYINT ,
      @Firstname NVARCHAR(50) ,
      @Lastname NVARCHAR(50) ,
      @Phone NVARCHAR(50) ,
      @Fax NVARCHAR(50) ,
      @Street1 NVARCHAR(200) ,
      @Street2 NVARCHAR(200) ,
      @City NVARCHAR(50) ,
      @Country INT ,
      @State NVARCHAR(50) ,
      @Zip NVARCHAR(50) ,
      @CompanyName VARCHAR(100) ,
      @AddressID INT
    )
AS
    BEGIN
        DECLARE @Type INT,@EnglishAddressId INT=0 ;              
        IF ( @Usage = 2 )
            SET @Type = 1
        IF ( @Usage = 1 )
            SET @Type = 2
            
            select top 1 @EnglishAddressId=EnglishAddressId from    [T_CustomerAddresses]   WHERE   UserID = @UserId and isnull(EnglishAddressId,0)>0
            
         --如果货运地址和账单地址一样，删除其他地址，只用一个地址 
        IF ( @Usage = 3 )
            BEGIN
                DELETE  FROM [dbo].[T_CustomerAddresses]
                WHERE   UserID = @UserId;
                        
                EXEC SYS_PH_CRM_CustomerAddressAdd @Firstname, @Lastname,
                    @Phone, @Fax, @Street1, @Street2, @City, @Country, @State,
                    @Zip, @CompanyName, @AddressID OUT;
                      
                INSERT  INTO dbo.T_CustomerAddresses
                        ( UserID, AddressID, [Type] ,EnglishAddressId)
                VALUES  ( @UserId, @AddressID, @Usage,@EnglishAddressId);
            END
          
           --如果货运地址和账单地址修改成不一样，数据中存的是同一地址 
        IF ( @Usage <> 3 )
            AND EXISTS ( SELECT TOP 1     UserId     FROM   T_CustomerAddresses    WHERE  UserID = @UserId      AND [Type] = 3 )
            BEGIN              
                UPDATE  [dbo].[T_CustomerAddresses]    SET     [Type] = @Type,EnglishAddressId=@EnglishAddressId    WHERE   UserID = @UserId   AND [Type] = 3            
                      
                SET @AddressID = 0;
                EXEC SYS_PH_CRM_CustomerAddressAdd @Firstname, @Lastname,
                    @Phone, @Fax, @Street1, @Street2, @City, @Country, @State,
                    @Zip, @CompanyName, @AddressID OUT;
                    
                INSERT  INTO dbo.T_CustomerAddresses ( UserID, AddressID, [Type] ,EnglishAddressId)
                                VALUES  ( @UserId, @AddressID, @Usage,@EnglishAddressId );
            END
        ELSE
            BEGIN
           --如果货运地址和账单地址不一样，2个地址是分开设置的，单独修改
                EXEC SYS_PH_CRM_CustomerAddressAdd @Firstname, @Lastname,
                    @Phone, @Fax, @Street1, @Street2, @City, @Country, @State,
                    @Zip, @CompanyName, @AddressID OUT;      
                   IF EXISTS(SELECT TOP 1     UserId    FROM   T_CustomerAddresses   WHERE  UserID = @UserId AND [Type]=@Usage)      
                        BEGIN 
							      UPDATE  [dbo].[T_CustomerAddresses]       SET     [UserID] = @UserId ,       [AddressID] = @AddressID ,  [Type] = @Usage      WHERE   UserID = @UserId   AND [Type] = @Usage;
                        END 
                        ELSE
							BEGIN
									   INSERT  INTO dbo.T_CustomerAddresses   ( UserID, AddressID, [Type] ,EnglishAddressId)
										  VALUES  ( @UserId, @AddressID, @Usage,@EnglishAddressId );
							END
            END          
    END
go


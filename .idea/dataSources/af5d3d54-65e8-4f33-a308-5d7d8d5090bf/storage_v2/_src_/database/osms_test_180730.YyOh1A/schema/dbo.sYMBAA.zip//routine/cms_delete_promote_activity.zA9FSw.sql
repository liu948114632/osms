create PROCEDURE CMS_delete_promote_activity
(
	@promoteActivityId int =null
) 
AS 
begin
SET NOCOUNT ON

-- 删除促销商品
delete from provider_promote_activity_product where activity_provider_id in (
	select id from provider_promote_activity_provider where promote_activity_id = @promoteActivityId)
	
-- 删除促销供应商
delete from provider_promote_activity_provider where promote_activity_id = @promoteActivityId

-- 删除促销活动
delete from provider_promote_activity where id = @promoteActivityId
	
end

go


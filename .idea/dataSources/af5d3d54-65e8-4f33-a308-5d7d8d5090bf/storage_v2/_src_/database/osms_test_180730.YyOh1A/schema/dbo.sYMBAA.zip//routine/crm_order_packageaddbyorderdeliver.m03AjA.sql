
/*--------------------------------------------------    
[备注]    
 订单发货时候添加包裹信息    
----------------------------------------------------*/    
-- =============================================    
-- modify:  <HJJ>重新发货时，增加了更新追踪时间    
-- Create date: <2010-03-22>    
-- Description: <PH重新发货>    
-- =============================================    
-- =============================================    
-- modify:  HYD    
-- Create date: 2010-06-08    
-- Description: 去掉增加包裹时候的状态值，Disabled,DealStatus,IsSendMail,DueDate,UpdateDate,Remark    
-- 使用T_OrderPackage的默认值就可以    
-- Version:CRM 5.1    
-- =============================================    
CREATE PROC dbo.CRM_Order_PackageAddByOrderDeliver     
(    
 @OrderId   VARCHAR(20),    
 @TraceNo   VARCHAR(200),  
 @ServiceLineType VARCHAR(10),
 @ServiceLineName VARCHAR(100),
 @ServiceCompany VARCHAR(100) 
)    
AS    
BEGIN    
 DECLARE @CustomerId INT,    
 @CustomerName  VARCHAR(50),    
 @EmailId   INT,    
 @DeliveryId   INT,    
 @Id     INT    
  
 SET @CustomerId = 0;    
 SET @CustomerName = '';    
 SET @EmailId = 0;    
 SET @CustomerId = 0;    
 SET @Id = 0;    
  
 SELECT @DeliveryId = DeliveryId,@CustomerId = CustomerId FROM dbo.T_Order WHERE OrderId = @OrderId;    
 SELECT @CustomerName = FullName,@EmailId = EmailId FROM dbo.T_Customer WHERE UserId = @CustomerId;    
  
 IF EXISTS(SELECT * FROM dbo.T_OrderPackage WHERE OrderId = @OrderId)    
 BEGIN    
  UPDATE dbo.T_OrderPackage    
   SET TraceNo = @TraceNo,
   DueDate=GETDATE(),
   DeliveryId=@DeliveryId,
   UpdateDate = GETDATE() ---HJJ add 重新发货时，增加了更新追踪时间    
    WHERE OrderId = @OrderId;    
 END    
 ELSE    
 BEGIN     
  INSERT INTO dbo.T_OrderPackage (    
   OrderId,    
   TraceNo,    
   CustomerName,    
   EmailId,    
   DeliveryId,    
   QuestionStatus,    
   IsConfirm,  
   ServiceLineType,
   ServiceLineName,
   ServiceCompany 
  ) VALUES (     
   /* OrderId - VARCHAR(14) */ @OrderId,    
   /* TraceNo - varchar(255) */ @TraceNo,    
   /* CustomerName - varchar(100) */@CustomerName,    
   /* Email - varchar(100) */ @EmailId,    
   /* DeliveryId - int */ @DeliveryId,    
   /* QuestionStatus - tinyint */ 0,    
   /* IsConfirm - tinyint */ 0,  
   @ServiceLineType,
   @SErviceLineName,
   @ServiceCompany );     
 END     
END
go


/*  
*2014-05-15
*加工计件报销单明细 
*2014-05-15
*/  
CREATE PROCEDURE [dbo].[CMS_Processing_ProcessingPieceworkExpenseItemDetail]  
(  
 @ExpenseId INT = NULL, --报销单id
 @PageSize INT = 50 ,  --页大小        
 @PageIndex INT = 1    --当前页号        
)  
AS  
BEGIN  
 SET NOCOUNT ON ;   
    DECLARE @SQL VARCHAR(max),        
            @CountSql NVARCHAR(MAX), --查询数量用        
            @FromSQL NVARCHAR(max), --查询表        
            @RowCount INT , @PageCount INT , @start INT ,@end INT  
             
                 SET @FromSQL = 'processing_piecework_expense a JOIN processing_piecework_inventory_expense b
                 ON processing_piecework_expense_id = a.id  
				 JOIN processing_piecework_inventory c ON processing_piecework_inventory_id = c.id  
				 join processing_piecework d on c.id =d.inventory_id   
				 join product e  on  d.product_id=e.id  where  a.id='+ CONVERT(VARCHAR(10), @ExpenseId);  
				
				  
   
   
    SET @CountSql = 'SELECT @RowCount = count(a.id) from ' + @FromSQL
             
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT      
    --PRINT @CountSql  
    IF ISNULL(@PageSize, 0) < 1                 
        SET @PageSize = 50  
                        
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize               
    IF ISNULL(@PageIndex, 0) < 1                 
        SET @PageIndex = 1                
    ELSE                 
    IF ISNULL(@PageIndex, 0) > @PageCount                 
        SET @PageIndex = @PageCount   
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1   
    SET @end = @PageIndex * @PageSize    
      
  
     
 --组装查询语句      
  SET @SQL = 'SELECT a.id, ROW_NUMBER() OVER (ORDER BY a.id asc) RowIndex,c.part_time_user as partTimeUser
  ,c.code as pieceworkInventoryCode,e.code as productCode, before_processing_count as beforeProcessingCount,processing_unit as processingUnit,
   processing_spec as processingSpec,''bag'' as processingSpecUnit, d.estimate_processing_fee as estimateProcessingFee,d.actual_packages_count as actualBagCount,
   actual_mantissa_count as actualMantissa,d.actual_processing_count as actualProcessingCount,d.act_processing_fee as actualProcessingFee from ' + @FromSQL          
       
  SET @SQL = 'SELECT * FROM (' + @SQL + ') temp  where RowIndex between '      
     + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';    
  --PRINT(@sql);
  EXEC(@SQL);                  
  select @RowCount            
END

go


-- =============================================
-- Author:		Hyd
-- Create date: 2011-10-19
-- Description:	获取产品售价
-- =============================================
CREATE FUNCTION uf_get_product_sale_price
(
	@ProductId INT,
	@Qty INT-- 购买批量数量
)
RETURNS DECIMAL(18,2)
AS
BEGIN

	-- Declare the return variable here
	DECLARE @SalePrice DECIMAL(18,2);
	SET @SalePrice = 0;
	-- 获取第一个梯度价格
--	IF @Qty = 0 
--	BEGIN
		SELECT @SalePrice = (CostPrice * UnitQuantity) / ExchangeRate * Profit FROM dbo.T_ProductSalePrice WHERE ProductId = @ProductId
--	END	
--	ELSE	
--	BEGIN
--		DECLARE @QuantityFrom1 INT
--		DECLARE @QuantityFrom2 INT
--		DECLARE @QuantityFrom3 INT
--		
--		SET @QuantityFrom1 = 0;
--		SET @QuantityFrom2 = 0;
--		SET @QuantityFrom3 = 0;
--		
--		SELECT @QuantityFrom1 = QuantityFrom1,@QuantityFrom2 = QuantityFrom2,@QuantityFrom3 = QuantityFrom3 FROM dbo.T_ProductSalePrice WHERE ProductId = @ProductId
--		
--		IF @QuantityFrom3 > 0 AND @Qty >= @QuantityFrom3
--		BEGIN
--			SELECT @SalePrice = (CostPrice * UnitQuantity) / ExchangeRate * Profit3 FROM dbo.T_ProductSalePrice WHERE ProductId = @ProductId
--			RETURN @SalePrice;
--		END
--		IF @QuantityFrom2 > 0 AND @Qty >= @QuantityFrom2
--		BEGIN
--			SELECT @SalePrice = (CostPrice * UnitQuantity) / ExchangeRate * Profit2 FROM dbo.T_ProductSalePrice WHERE ProductId = @ProductId
--			RETURN @SalePrice;
--		END
--		IF @QuantityFrom1 > 0 AND @Qty >= @QuantityFrom1
--		BEGIN
--			SELECT @SalePrice = (CostPrice * UnitQuantity) / ExchangeRate * Profit1 FROM dbo.T_ProductSalePrice WHERE ProductId = @ProductId
--			RETURN @SalePrice;
--		END
--	END
	-- Return the result of the function
	RETURN @SalePrice

END
go


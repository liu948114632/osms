---获取挽回客户的电话记录
CREATE PROC CRM_Customer_GetLossedCustomerPhoneRecord
(
@CustomerId INT
)
AS 
BEGIN
SELECT a.*,u.name AS 'Operator'  FROM dbo.T_LossedCustomerPhoneRecord a INNER JOIN 
dbo.[user] u ON a.CreatorId=u.id  WHERE a.CustomerId=@CustomerId  ORDER BY a.Id DESC
END

go


/**
	v3.9.47 add by whw
	如果来源单号是订单，取订单产品的订购数
	如果来源单号是加工单，取加工产品的计划加工数
*/
CREATE FUNCTION getProcessingPieceworkPlanQuantity
(
	@sourceCode VARCHAR(100),
	@productId INT
)RETURNS INT 
AS
BEGIN
	DECLARE @qty INT=NULL
    SELECT TOP 1 @qty=oi.order_quantity FROM dbo.[order] o WITH(NOLOCK)
	INNER JOIN dbo.order_item oi WITH(NOLOCK)
	ON oi.order_id = o.id
	 WHERE code=@sourceCode AND oi.product_id=@productId
	 ORDER BY oi.id DESC

	 IF @qty IS NULL
	 BEGIN
	     SELECT @qty=p.plan_processing_quantity FROM dbo.processing p  WITH(NOLOCK)
		 WHERE p.code=@sourceCode AND p.product_id=@productId
	 END

	 RETURN @qty
END

go



CREATE PROC [dbo].[CMS_PurchasingManagement_SmallLotProductManageList]
    (           
      @ProductCode VARCHAR(MAX) = NULL ,--小批量商品编号              
      @ProductCodeList VARCHAR(MAX) = NULL ,--小批量商品编号集合，多个编号用逗号隔开              
      @OriginalProductCode VARCHAR(MAX)=NULL, --原商品编号
      @OriginalProductCodeList VARCHAR(MAX)=null,--原商品编号集合，多个编号用逗号隔开 
      @ProductStatus INT=NULL,
      @IsOnShelf INT = NULL, --是否上架
      @PublishTimeBegin VARCHAR(20) = NULL, --上架开始时间
      @PublishTimeOver VARCHAR(20) = NULL,	--上架结束时间
      @CategoryId1 INT=NULL,--v3.9,wanghw 类别
      @CategoryId2 INT=NULL,
      @CategoryId3 INT=NULL,
      @ProductFlag INT = NULL,--原产品Or小批量产品
      @OfflineStatus INT = NULL,--下架状态
      @OriginalProductOfflineStatus INT = NULL,--原产品下架状态
      @SmallLotProductOfflineStatus INT = NULL,--小批量产品下架状态
      @OriginalProductIsDisplayPh INT = NULL,--原产品ph显示
      @SmallLotProductIsDisplayPh INT = NULL,--小批量产品ph显示
      @PageSize INT = 50 ,  --页大小              
      @PageIndex INT = 1    --当前页号            
    )
AS 
    BEGIN                    
        SET NOCOUNT ON ;                    
                      
        DECLARE @SQL VARCHAR(MAX) ,
            @TempSQL NVARCHAR(MAX) ,
            @BaseSQL VARCHAR(MAX) ,   --基本查询用          
            @CountSql NVARCHAR(MAX) , --查询数量用              
            @FromSQL1 NVARCHAR(MAX) , --内查询用              
            @FromSQL2 NVARCHAR(MAX) , --外查询用              
            @Condition VARCHAR(MAX) , --条件              
            @Column VARCHAR(MAX) ,--用于查询出来的列              
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ,
            @IsQueryProductSet BIT ,
            @IsQueryProductPool BIT ,
            @IsQueryProvider BIT         
                      
        SET @IsQueryProductSet = 0                
        SET @IsQueryProductPool = 0        
        SET @IsQueryProvider = 0           
                
    --获得查询条件          
        SET @Condition = ' WHERE 1=1 AND p.is_small_quantities=1 AND p.is_delete = 0 and p2.is_delete = 0'              
        IF @ProductCode IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND p.code like '''+ @ProductCode + '%'''              
            END              
        IF @ProductCodeList IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND p.code in ('''+ REPLACE(@ProductCodeList, ',', ''',''') + ''')'              
            END 
                         
        IF @OriginalProductCode IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND sp.original_product_code like '''+ @OriginalProductCode + '%'''              
            END              
        IF @OriginalProductCodeList IS NOT NULL 
            BEGIN               
                SET @Condition = @Condition + ' AND sp.original_product_code in ('''+ REPLACE(@OriginalProductCodeList, ',', ''',''') + ''')'              
            END 
		IF @ProductStatus IS NOT NULL
			 BEGIN               
					SET @Condition = @Condition + ' AND p.status ='+ CONVERT(VARCHAR(20),@ProductStatus)                 
			 END 
		IF @IsOnShelf IS NOT NULL
         BEGIN
			IF @IsOnShelf = 0
			BEGIN
				SET @Condition = @Condition + ' AND (ph1.is_on_shelf = ' + CONVERT(VARCHAR(20),@IsOnShelf) + 'OR ph1.is_on_shelf IS NULL)'
			END
			IF @IsOnShelf = 1
			BEGIN
				SET @Condition = @Condition + ' AND ph1.is_on_shelf = ' + CONVERT(VARCHAR(20),@IsOnShelf)
			END
			
         END
		IF @PublishTimeBegin IS NOT NULL
			 BEGIN
				 SET @Condition = @Condition + ' and ph1.publish_time>=''' + @PublishTimeBegin + ''''
			 END 
		IF @PublishTimeOver IS NOT NULL
			BEGIN
				 SET @Condition = @Condition + ' and ph1.publish_time<=''' + @PublishTimeOver + ''''
			 END 
		IF @CategoryId1 IS NOT NULL
			BEGIN
				SET @Condition=@Condition+' and p.category_id_1='+CONVERT(VARCHAR(20),@CategoryId1)
			END
		IF @CategoryId2 IS NOT NULL
			BEGIN
				SET @Condition=@Condition+' and p.category_id_2='+CONVERT(VARCHAR(20),@CategoryId2)
			END
		IF @CategoryId3 IS NOT NULL
			BEGIN
				SET @Condition=@Condition+' and p.category_id_3='+CONVERT(VARCHAR(20),@CategoryId3)
			END
		 --v3.9.6 add @ProductFlag为请选择
		IF @OfflineStatus IS NOT NULL AND @ProductFlag IS NULL
			BEGIN
				SET @Condition=@Condition+' and p.offline_status ='+CONVERT(VARCHAR(20),@OfflineStatus) 
										+' or p2.offline_status ='+CONVERT(VARCHAR(20),@OfflineStatus)
			END
		IF @ProductFlag IS NOT NULL AND @OfflineStatus IS NOT NULL
			BEGIN
			--原产品
			IF @ProductFlag = 1
				BEGIN
					SET @Condition=@Condition+' and p2.offline_status='+CONVERT(VARCHAR(20),@OfflineStatus)
				END
			--小批量产品
			IF @ProductFlag = 2
				BEGIN
					SET @Condition=@Condition+' and p.offline_status='+CONVERT(VARCHAR(20),@OfflineStatus)
				END	
			END	
		 IF @ProductFlag IS NOT NULL AND @OfflineStatus IS NULL
			BEGIN
			--原产品
			IF @ProductFlag = 1
				BEGIN
					SET @Condition=@Condition+' and p2.offline_status in (0,1,2)'
				END
			--小批量产品
			IF @ProductFlag = 2
				BEGIN
					SET @Condition=@Condition+' and p.offline_status in (0,1,2)'
				END	
			END
		IF @OriginalProductOfflineStatus IS NOT NULL
		BEGIN
			SET @Condition=@Condition+' and p2.offline_status='+CONVERT(VARCHAR(20),@OriginalProductOfflineStatus)
		END
		IF @SmallLotProductOfflineStatus IS NOT NULL
		BEGIN
			SET @Condition=@Condition+' and p.offline_status='+CONVERT(VARCHAR(20),@SmallLotProductOfflineStatus)
		END
		IF @OriginalProductIsDisplayPh IS NOT NULL
		BEGIN
			IF @OriginalProductIsDisplayPh =1
			BEGIN
				SET @Condition=@Condition+' and p2.is_display_ph=1'
			END
			ELSE
			BEGIN
				SET @Condition=@Condition+' and p2.is_display_ph=0'
			END
		END
		IF @SmallLotProductIsDisplayPh IS NOT NULL
		BEGIN
			IF @SmallLotProductIsDisplayPh =1
			BEGIN
				SET @Condition=@Condition+' and p.is_display_ph=1'
			END
			ELSE
			BEGIN
				SET @Condition=@Condition+' and p.is_display_ph=0'
			END
		END
    --设置条件查询必须关联的表          
        SET @FromSQL1 = ' FROM product p WITH (NOLOCK) 
						  JOIN product_small_quantities sp on  sp .product_id= p.id
						  JOIN dbo.product p2 WITH (NOLOCK) ON sp.original_product_id = p2.id 
						  LEFT JOIN dbo.ph_product ph1 WITH(NOLOCK) ON ph1.product_id = p.id'           
       
      
    --求符合条件的总数          
        SET @CountSql = ' SELECT @RowCount = count(p.id) ' + @FromSQL1
            + @Condition              
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                    
                  
--     SELECT @CountSql              
                   
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                    
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                    
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                    
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                 
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                    
        SET @end = @PageIndex * @PageSize            
              
    --设置取字段信息必须关联的表          
        SET @FromSQL2 = 'INNER JOIN dbo.product a WITH (NOLOCK) ON temp.id = a.id'          
        SET @FromSQL2 = @FromSQL2
            + ' INNER JOIN dbo.T_Currency WITH (NOLOCK) ON 1 = 1 AND dbo.T_Currency.Currency = ''CNY''' 
        SET @FromSQL2 = @FromSQL2
            + ' left join product_description pd with(nolock) on pd.product_id=a.id'         
        SET @FromSQL2 = @FromSQL2
            + ' LEFT JOIN dbo.[view_product_all_storage_quantity_info] AS s WITH(NOLOCK) ON s.product_id = temp.id'
        SET @FromSQL2 = @FromSQL2
            + ' INNER JOIN dbo.product_small_quantities AS sm WITH(NOLOCK) ON sm.product_id = temp.id '
        SET @FromSQL2 = @FromSQL2
            + ' INNER JOIN dbo.product AS op WITH(NOLOCK) ON op.id = sm.original_product_id ' 
         SET @FromSQL2 = @FromSQL2
            + ' LEFT JOIN dbo.ph_product ph WITH(NOLOCK) ON ph.product_id = a.id'   
           
           
    --设置需要取的字段信息            
        SET @Column = ' a.id,          
                    a.code,              
        a.name,    
        a.original_name as originalName,          
        a.unit,              
        a.unit_quantity AS unitQuantity,              
        a.cost_price AS costPrice,              
        a.category_id_1 AS categoryId1,              
        a.category_id_2 AS categoryId2,              
        a.category_id_3 AS categoryId3,              
        a.is_gift AS isGift,              
        a.is_mix AS isMix,              
        a.is_display AS isDisplay,              
        a.is_display_ph AS isDisplayPh,              
        a.is_display_pw AS isDisplayPw,              
        a.is_display_jl AS isDisplayJl,  
        a.status,    
        a.aldi AS aldi,  
        a.is_big_purchase AS isBigPurchase,           
        a.publish_status AS publishStatus,             
        a.department_id AS departmentId,              
        a.material_id AS materialId,             
        a.product_set_id AS productSetId,              
        a.auditor_id AS auditorId,              
        a.audit_time AS auditTime,            
        a.developer_id AS developerId,              
        a.uploader_id AS uploaderId,            
        a.upload_time AS uploadTime,                 
        a.submitter_id AS submitterId,            
        a.submit_time AS submitTime,       
        a.is_roughcast isRoughcast,    
        a.is_imitation_brand isImitationBrand,    
        a.primary_picture_code AS primaryPictureCode,            
        a.color_card_picture_code AS colorCardPictureCode,   
        a.provider_code AS providerCode,
        a.product_set_specification_id as productSpecificationId,
        a.weight,
        a.volume,
        a.is_HSCO as isHSCO,
        pd.description,
        ISNULL(s.quantity - s.lock_quantity,0) AS storageQty,                    
         a.offline_status offlineStatus,
         a.is_provider_stock isProviderStock,
         sm.original_product_code as originalProductCode,
         sm.convert_factor as convertFactor,
         sm.processing_fees as processingFees,
         sm.floating_rate as floatingRate,
         op.unit_quantity as  originalProductUnitQuantity,
         op.unit as  originalProductUnit,
         op.cost_price as originalProductCostPrice,
         ph.is_on_shelf as isOnShelf,
         ph.publish_time as publishTime,
         op.offline_status as originalProductOfflineStatus 
         ' 
                   
       
  --组装基本查询的SQL       
        IF @ProductCodeList IS NOT NULL 
            BEGIN    
                SET @TempSQL = 'select * from uf_Split(''' + @ProductCodeList
                    + ''', '','')) m on P.code=m.[Value] ' ;    
                SET @BaseSQL = 'select * from (select p.id, p.product_set_id, row_number() over(order by sp.create_date DESC) rowIndex '
                    + @FromSQL1 + ' Inner join (' + @TempSQL + @Condition
                    + ')temp2 where rowIndex between '
                    + CAST(@start AS NVARCHAR(10)) + ' and '
                    + CAST(@end AS NVARCHAR(10))     
            END        
        ELSE 
            BEGIN    
                SET @BaseSQL = 'SELECT * from (              
         SELECT  p.id,            
           p.product_set_id,               
         ROW_NUMBER() OVER(ORDER BY sp.create_date DESC) rowIndex'              
                SET @BaseSQL = @BaseSQL + @FromSQL1 + @Condition
                    + ') temp2               
    where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
                    + CAST(@end AS NVARCHAR(10))              
            END    
     
             
    --组装最终取数的SQL          
        SET @SQL = 'select ' + @Column + ' from (' + @BaseSQL + ') temp '
            + @FromSQL2 + ' ORDER BY rowIndex'                   
       PRINT @sql
       
        EXEC(@SQL) ;               
        SELECT  @RowCount                  
    END

go


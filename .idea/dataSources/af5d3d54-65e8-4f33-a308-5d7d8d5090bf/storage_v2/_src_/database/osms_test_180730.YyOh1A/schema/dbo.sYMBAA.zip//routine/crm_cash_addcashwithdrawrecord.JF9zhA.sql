
  /*------------------------------------------          
[备注]:增加Cash提现记录          
------------------------------------*/     
CREATE PROC CRM_Cash_AddCashWithdrawRecord
(
@CustomerId   int,
@WithdrawAmount  DECIMAL(9,2), 
@WithdrawCurrencyId int, 
@RefundAmount DECIMAL(9,2), 
@WithdrawWayId int, 
@TransactionId VARCHAR(200),
@CustomerNo varchar(200), 
@Account  varchar(200), 
@CustomerAddress varchar(500), 
@OrderCode varchar(15),
@Remark varchar(1000),
@HandlerId  int, 
@CashId int, 
@BusinessTypeId int
)
AS  BEGIN
INSERT INTO T_CashWithdrawRecord(
CustomerId,
WithdrawAmount, 
WithdrawCurrencyId, 
RefundAmount, 
WithdrawWayId, 
TransactionId,
CustomerNo, Account, 
CustomerAddress, 
OrderCode,
Remark, 
HandlerId, 
CashId, 
BusinessTypeId,
CreateDate) VALUES(
@CustomerId   ,
@WithdrawAmount , 
@WithdrawCurrencyId , 
@RefundAmount, 
@WithdrawWayId , 
@TransactionId ,
@CustomerNo , 
@Account  , 
@CustomerAddress ,
@OrderCode ,
@Remark,
@HandlerId  , 
@CashId ,
@BusinessTypeId,
GETDATE()
)
END

  go


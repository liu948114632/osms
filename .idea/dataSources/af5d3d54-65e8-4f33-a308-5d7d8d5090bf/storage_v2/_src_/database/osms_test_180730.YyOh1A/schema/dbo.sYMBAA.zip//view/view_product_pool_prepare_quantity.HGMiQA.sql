--自动更新商品池商品的备货量
CREATE VIEW view_product_pool_prepare_quantity 
AS 
SELECT product_id,
	(CASE WHEN temp.prepare_quantity<=3 THEN 3*c.unit_quantity 
	ELSE  temp.prepare_quantity*c.unit_quantity END ) AS prepare_quantity 
FROM (
	SELECT product_id,SUM(prepare_quantity) AS prepare_quantity
		FROM (
			SELECT b.product_id,
			(CEILING(SUM(b.order_quantity*1.0/b.unit_quantity)/3)*2) AS  prepare_quantity --备货量
			FROM dbo.[order] AS a  
			JOIN dbo.order_item  AS b ON a.id = b.order_id
			JOIN dbo.product_pool AS p ON p.product_id = b.product_id
			WHERE a.status < 132 -- 排除取消订单
			AND b.status <>12
			AND a.type = 1 
			AND a.order_time >= DATEADD(MONTH,-3,CONVERT(VARCHAR(7),GETDATE(),25) + '-01') -- 录单时间
			AND a.order_time < CONVERT(VARCHAR(7),GETDATE(),25) + '-01'
			GROUP BY b.product_id 
	UNION ALL 
			SELECT f.product_id,
			(CEILING(SUM(f.quantity*1.0/f.unit_quantity)/3)*2)  AS prepare_quantity
			FROM dbo.stock_out AS e 
			INNER JOIN dbo.stock_out_item AS f ON e.id = f.stock_out_id
			WHERE e.type= 17 AND e.status = 2
				AND e.create_time >= DATEADD(MONTH,-3,CONVERT(VARCHAR(7),GETDATE(),25) + '-01') -- 录单时间
				AND e.create_time < CONVERT(VARCHAR(7),GETDATE(),25) + '-01'
			GROUP BY f.product_id
	) t	
	GROUP BY product_id
) temp 
JOIN dbo.product AS c ON c.id = temp.product_id


go


/*------------------------------------------              
备注:根据员工工号获取用户信息      
创建人: LXH              
创建日期:2012-12-29              
------------------------------------------------------*/              
CREATE PROC dbo.CRM_Order_GetUserInfoByCode              
(              
  @Code VARCHAR(30)  
)              
AS               
BEGIN           
     SELECT Id,      
     Code,      
     [Name], 
     (SELECT TOP 1 b.TicketSignature FROM dbo.T_Handler  b WITH(NOLOCK) WHERE b.HandlerId=Id AND b.TicketSignature>'' ORDER BY b.BusinessType) AS EnglishName,    
     Email,    
  CAST(IsValid AS BIT) AS IsValid
 FROM dbo.V_CRM_UserInfo 
 WHERE dbo.V_CRM_UserInfo.Code=@Code
END
go


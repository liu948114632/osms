
/*-------------------------------------------------     
备注:获取订单付款金额    
创建人: FRH    
创建日期:2009-12-30    
------------------------------------------------------*/    
CREATE PROC [dbo].[CRM_Order_OrderPaymentGet]    
(    
 @OrderId   VARCHAR(20) = '',    
 @Pay    DECIMAL(9,2) OUT  ,  
 @PayType TINYINT = NULL --付款方式  
)    
AS    
BEGIN    
DECLARE @Sql NVARCHAR(MAX) ,      
        @Where NVARCHAR(2000) ,      
        @Parameters NVARCHAR(1000)   
 SET @Where = ' AND 1=1 '  
 IF( @PayType IS NOT NULL AND @PayType > 0)  
 BEGIN  
    SET @Where = @Where + ' AND a.PayType=' + CONVERT(VARCHAR(3),@PayType)  
 END   

IF(@PayType=4)--Coupon 分开用新表
BEGIN
    SET @Where ='';
	 SET @Sql ='Select       
  @pPay = Sum(Value)  
 From     
  dbo.T_CashCoupon  where   OrderId = ''' + @OrderId + ''''     
END
ELSE
BEGIN
 SET @Sql ='Select       
  @pPay = Sum(a.PaySum/b.Rate)  
 From     
  dbo.T_OrderPay a INNER Join  T_Currency b    
   On a.OrderId = ''' + @OrderId + ''' AND a.CurrencyId = b.Id'     
END
 SET @Sql = @Sql + @Where  

 SET @Parameters = N'@pPay DECIMAL(9,2) OUT'   
PRINT @Sql;
 EXEC sp_executesql @Sql, @Parameters, @pPay = @Pay OUT  

 If @Pay is null      
  Set @Pay = 0;    
End

go


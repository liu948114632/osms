
CREATE VIEW view_purchase_analyst_items     
AS     
 SELECT b.id,a.department_id,a.expense_user_id AS buyer_id ,b.purchase_id,a.code AS purchase_code    
 ,a.expense_time AS purchase_expense_time ,b.completion_quantity,b.purchase_price,b.provider_id,b.product_id    
 FROM dbo.purchase  AS a     
 JOIN dbo.purchase_item AS b ON a.id = b.purchase_id    
 WHERE a.status = 8 --已报销  
 AND b.is_deleted=0 
 AND b.purchase_price > 0    
 AND a.department_id IN (2,3)
go


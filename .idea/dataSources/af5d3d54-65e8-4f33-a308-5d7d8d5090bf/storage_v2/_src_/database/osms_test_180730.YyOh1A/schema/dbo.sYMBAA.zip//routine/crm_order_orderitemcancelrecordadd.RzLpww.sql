/*------------------------------------------------        
[备注]:        
 增加取消商品项纪录        
--------------------------------------------------*/       
CREATE PROC CRM_Order_OrderItemCancelRecordAdd    
    (    
      @OrderItemId INT ,  --订单项Id          
      @Operator INT , --操作人          
      @Reason VARCHAR(20) --原因    
    )    
AS     
BEGIN    
        INSERT  INTO dbo.T_OrderItemCancelRecord    
                ( OrderItemId ,    
                  ProductCode ,    
                  Operator ,    
                  OperateTime ,    
                  Reason    
           )    
         SELECT a.OrderItemId,b.ItemCode,@Operator,GETDATE(),@Reason  
         FROM dbo.T_OrderItem a  
         LEFT JOIN dbo.T_OrderItemProduct b ON a.OrderItemId=b.OrderItemId  
         WHERE a.OrderItemId = @OrderItemId  
END
go




/*----------------------------------------    
备注：获取订单到货商品装箱数据    
创建人: HYD    
创建日期:2010-05-28    
创建版本：CRM 5.1    
-----------------------------------------------*/    
CREATE PROC [dbo].[CRM_Order_OrderReadyItemsForWeightExport]     
(    
 @OrderIds  VARCHAR(MAX)-- 多个订单号    
)    
AS    
BEGIN    
 SET NOCOUNT ON;    
    
 DECLARE @tOrder TABLE (OrderId VARCHAR(20));    
    
 INSERT INTO @tOrder(OrderId)    
 SELECT [Value] FROM dbo.uf_Split(@OrderIds,',');    
     
 WITH cte AS (    
  SELECT     
  a.OrderId,
   (CASE WHEN b.CategoryId3 > 0 THEN b.CategoryId3    
      WHEN b.CategoryId2 > 0 THEN b.CategoryId2    
      WHEN b.CategoryId1 > 0 THEN b.CategoryId1    
   END) AS CategoryId ,    
   (CASE WHEN o.OrderIndustryType=5 THEN 'UK-'+b.Code WHEN o.OrderIndustryType=6 THEN 'US-'+b.Code ELSE b.Code END) AS Code,  -- 商品编号    
   a.UnitQuantity,-- 商品批量数量    
   a.Unit, -- 商品批量单位    
   a.Weight AS UnitWeight, -- 批量重量    
   a.Volume AS UnitVolum, -- 批量体积    
   a.ReadyQty, -- 已备量    
   CAST(a.weight*(a.readyqty*1.0/a.UnitQuantity) AS DECIMAL(18,2)) AS ReadyWeight,-- 到货重量    
   CAST((a.Volume*(a.readyqty*1.0/a.UnitQuantity)) / 5 AS DECIMAL(18,2)) AS ReadyVolumeWeight -- 到货体积重量    
  FROM dbo.T_OrderItem a   
  INNER JOIN dbo.T_Order o ON a.OrderId=o.OrderId
   INNER JOIN dbo.V_CRM_All_Product b    
    ON a.CmsProductId = b.CmsProductId AND a.OrderId IN(SELECT OrderId FROM @tOrder)    
  WHERE  a.ReadyQty > 0 -- 已经在备货的商品    
  AND a.[Status] < 12 -- 非取消状态的商品       
 )    
 SELECT b.[Name] AS CategoryName,a.Code,a.UnitQuantity,a.Unit,a.UnitWeight,a.UnitVolum,a.ReadyQty,a.ReadyWeight,a.ReadyVolumeWeight    
 FROM cte a     
  LEFT JOIN dbo.T_Category b ON a.CategoryId = b.CategoryId    
 ORDER BY a.OrderId,b.[Name],a.Code;    
END


go


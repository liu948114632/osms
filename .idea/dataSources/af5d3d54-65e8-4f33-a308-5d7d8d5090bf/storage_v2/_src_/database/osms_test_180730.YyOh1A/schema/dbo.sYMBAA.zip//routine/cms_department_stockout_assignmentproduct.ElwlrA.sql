     
CREATE PROC [dbo].[CMS_Department_Stockout_AssignmentProduct]
    (
      @StockOutId INT = NULL ,
      @DepartmentId INT = NULL  
    )
AS
    BEGIN                        
        SET NOCOUNT ON;
        IF OBJECT_ID('#temp_assignment_product2') IS NOT NULL
            DROP TABLE #temp_assignment_product2;   
         declare @cat_stock_out_item TABLE (product_id INT ,stock_out_id INT ,stock_out_qty DECIMAL(18,3) )             
       INSERT INTO  @cat_stock_out_item 
                  SELECT   a.product_id ,stock_out_id,
                                SUM(a.quantity) AS stock_out_qty
                       FROM     dbo.stock_out_item AS a WITH ( NOLOCK )
                       WHERE    a.stock_out_id = @StockOutId
                       GROUP BY product_id,stock_out_id
                     
            SELECT  temp.id AS orderItemId ,
                    temp.order_id AS orderId ,
                    temp.department_id AS departmentId ,
                    temp.code AS orderCode ,
                    temp.product_id AS productId ,
                    temp.quantity-prepareLockQty5-prepareLockQty2  AS assignQuantity ,
                    temp.quantity-prepareLockQty5-prepareLockQty2   AS orderAssignQuantity ,
                    CONVERT(VARCHAR(100), temp.unit_quantity) + ' '
                    + temp.unit AS productUnit ,
                    
                    ROW_NUMBER() OVER ( PARTITION BY product_id ORDER BY ( temp.valid_order_count
                                                              - temp.prepared_count ) , CASE
                                                              WHEN temp.quantity <= temp.stock_out_qty
                                                              THEN 0
                                                              ELSE 1
                                                              END , temp.priority_level DESC , temp.order_time ASC , temp.product_id ) AS rowindex
            INTO    #temp_assignment_product2
            FROM    ( SELECT    i.id ,
                                i.order_item_group_id ,
                                ( i.order_quantity - i.prepared_quantity ) AS quantity ,
                                 ISNULL(( SELECT SUM(a.assign_qty)  
                                         FROM   department_stock_out_ref_order a  
                                                JOIN dbo.stock_out b ON a.stock_out_id = b.id  
                                                LEFT JOIN  stay_shelve_product c ON c.object_code =b.code AND c.product_id = i.product_id
                                         WHERE  a.order_item_id = i.id 
                                                AND (c.id IS NULL OR c.status =1)
                                       ), 0) AS prepareLockQty5 , 
								ISNULL((SELECT  SUM(quantity) FROM  order_reservation r WHERE r.order_code =o.code AND r.product_id =i.product_id AND r.is_deal = 0),0) AS prepareLockQty2,
                                i.product_id ,
                                i.unit_quantity ,
                                i.unit ,
                                i.order_id ,
                                o.code ,
                                o.department_id ,
                                o.valid_order_count ,
                                o.prepared_count ,
                                o.priority_level ,
                                o.order_time ,
                                a.stock_out_qty 
                              
                      FROM      @cat_stock_out_item AS a
                                INNER JOIN dbo.order_item AS i ON a.product_id = i.product_id
                                INNER JOIN dbo.[order] AS o ON o.id = i.order_id
                             
                      WHERE     
                                o.status = 1
                                AND i.processing_status <> 30
                                AND i.status < 6
                               
                    ) temp WHERE  temp.quantity-prepareLockQty5-prepareLockQty2>0
                   
           
        INSERT  INTO dbo.department_stock_out_ref_order
                ( stock_out_id ,
                  order_id ,
                  order_item_id ,
                  assign_qty
                )
                SELECT  a.stock_out_id ,
                        b.orderId ,
                        b.orderItemId ,
                        CASE WHEN a.stock_out_qty
                                  - ISNULL(( SELECT SUM(c.assignQuantity)
                                             FROM   #temp_assignment_product2 c
                                             WHERE  c.productId = a.product_id
                                                    AND c.rowindex < b.rowindex
                                           ), 0) > 0
                             THEN CASE WHEN a.stock_out_qty
                                            - ISNULL(( SELECT SUM(c.assignQuantity)
                                                       FROM   #temp_assignment_product2 c
                                                       WHERE  c.productId = a.product_id
                                                              AND c.rowindex < b.rowindex
                                                     ), 0) >= b.assignQuantity
                                       THEN b.assignQuantity
                                       ELSE a.stock_out_qty
                                            - ISNULL(( SELECT SUM(c.assignQuantity)
                                                       FROM   #temp_assignment_product2 c
                                                       WHERE  c.productId = a.product_id
                                                              AND c.rowindex < b.rowindex
                                                     ), 0)
                                  END
                             ELSE 0
                        END
                FROM    @cat_stock_out_item a
                        JOIN #temp_assignment_product2 b ON a.product_id = b.productId
                ORDER BY b.rowindex ASC ;
        
      
         --删除预分配数为0的数据
         DELETE FROM     department_stock_out_ref_order WHERE assign_qty = 0     
		 DROP TABLE #temp_assignment_product2;                  
        SET NOCOUNT OFF;         
    END;


go


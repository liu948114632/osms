CREATE PROC  CMS_Storage_GetUkProductStorage   
    (              
      @StartTime DATETIME = NULL , -- 开始时间                      
      @EndTime DATETIME = NULL  -- 结束时间                 
    )          
AS           
    BEGIN                            
        SET NOCOUNT ON ; 
		 
		 SELECT b.id AS id , c.product_id AS productId , c.id AS ukProductId
		  ,d.phStorageQuantity  AS availableQuantity
		  
		 FROM (
			 SELECT a.object_id  FROM  storage_operator_log a  
			 WHERE a.operator_time >= @StartTime
			 AND a.operator_time <= @EndTime  GROUP BY a.[status],a.[object_id]  
		 ) temp 
		 INNER JOIN dbo.storage AS b ON temp.object_id=b.id 
		 INNER JOIN dbo.view_business_department_storage d ON d.product_id = b.product_id
		 INNER JOIN dbo.uk_product AS c ON c.product_id=b.product_id  
		 INNER JOIN dbo.uk_domestic_product f  ON f.id =c.id
        SET NOCOUNT OFF ;                      
    END

go


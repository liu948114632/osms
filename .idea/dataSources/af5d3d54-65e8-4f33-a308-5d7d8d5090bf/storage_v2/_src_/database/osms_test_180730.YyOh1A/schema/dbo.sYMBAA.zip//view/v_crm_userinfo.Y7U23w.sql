CREATE VIEW dbo.V_CRM_UserInfo
AS
SELECT id AS Id,code AS Code,[name],englishName,email ,IsValid
FROM dbo.[t_user] WITH(NOLOCK)

go


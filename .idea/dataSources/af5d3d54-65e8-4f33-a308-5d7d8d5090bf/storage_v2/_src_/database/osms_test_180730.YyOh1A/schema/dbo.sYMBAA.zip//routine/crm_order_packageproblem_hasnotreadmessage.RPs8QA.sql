



CREATE  PROC CRM_Order_PackageProblem_HasNotReadMessage
(
@HandlerId INT
)
AS
BEGIN
SELECT COUNT(*) FROM dbo.T_PackageProblem a INNER JOIN dbo.T_Order o ON o.OrderId=a.OrderId
WHERE o.HandlerId=@HandlerId AND a.IsRead=0;
END


go


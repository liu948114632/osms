
CREATE PROC [dbo].[CMS_ProviderStorageProduct_BuyingApplayItem]                              
(                               
  @DepartmentId INT = NULL ,--部门ID
  @ApplayCode VARCHAR(20)=NULL, --申请单号
  @FactoryCode VARCHAR(20)=NULL,--厂家编号 
  @ApplayUserId INT =NULL,--申请人          
  @ApplayTimeBegin VARCHAR(20) = NULL, --查询申请时间的开始时间                          
  @ApplayTimeEnd VARCHAR(20) = NULL, --查询申请时间的结束时间                                          
  @ProductCode VARCHAR(MAX) = NULL,--商品编号
  @ProductCodes VARCHAR(MAX) = NULL,--多个商品编号                                                   
  @ProviderCode VARCHAR(MAX) = NULL,--供应商编号
  @AuditUserId INT = NULL ,--审核人  
  @Status INT = NULL,--任务状态
  @PageSize INT = 50 ,  --页大小                          
  @PageIndex INT = 1    --当前页号                          
)                                
AS            
BEGIN                                
    SET NOCOUNT ON ;                                
                                  
    DECLARE @SQL VARCHAR(MAX),                          
            @CountSql NVARCHAR(MAX), --查询数量用                          
            @FromSQL NVARCHAR(MAX), --查询内表                        
                               
            @Column NVARCHAR(MAX), --取的字段                        
            @Condition VARCHAR(MAX), --条件                           
            @RowCount INT , @PageCount INT , @start INT ,@end INT                                         
                                    
    --获得查询条件                        
    SET @Condition = ' WHERE a.is_system=1 '                           
                            
    IF @DepartmentId IS NOT NULL                           
    BEGIN                           
       SET @Condition = @Condition + ' AND a.department_id=' + CONVERT(VARCHAR(10),@DepartmentId)                          
    END
                         
    IF @Status IS NOT NULL
    BEGIN
		 SET @Condition = @Condition + ' AND a.status=' + CONVERT(VARCHAR(10),@Status)  
    END
    
    IF @ApplayCode IS NOT NULL                           
    BEGIN                           
       SET @Condition = @Condition + ' AND a.code like ''%' + @ApplayCode + '%'''                        
    END
    
    IF @ApplayUserId IS NOT NULL
    BEGIN
		SET @Condition = @Condition + ' AND a.applay_user_id = ' + + CONVERT(VARCHAR(10),@ApplayUserId)   
    END
    
                  
    IF @ApplayTimeBegin IS NOT NULL                           
    BEGIN                           
       SET @Condition = @Condition + ' AND a.applay_time >=''' + CONVERT(VARCHAR(20),@ApplayTimeBegin) + ''''                          
    END                           
    IF @ApplayTimeEnd IS NOT NULL                           
    BEGIN                           
       SET @Condition = @Condition + ' AND a.applay_time <=''' + CONVERT(VARCHAR(20),@ApplayTimeEnd) + ''''                           
    END               
                 
    IF @ProductCode IS NOT NULL                           
    BEGIN                           
                          
       SET @Condition = @Condition + ' AND  c.code like ''%' + @ProductCode + '%'''                          
    END
    IF @ProductCodes IS NOT NULL                           
    BEGIN                                             
       SET @Condition = @Condition + ' AND    c.code in ('''+ REPLACE(@ProductCodes, ',', ''',''') + ''')'                    
    END                        
    IF @FactoryCode IS NOT NULL                           
    BEGIN                           
                          
       SET @Condition = @Condition + 'AND   c.provider_code like ''%' + @FactoryCode + '%'''                          
    END     
                     
    IF @ProviderCode IS NOT NULL                           
    BEGIN                                             
       SET @Condition = @Condition + ' AND p.code  like ''%' + @ProviderCode + '%'''                          
    END                          
    IF @AuditUserId IS NOT NULL
    BEGIN
		SET @Condition = @Condition + ' AND a.audit_user_id = ' + + CONVERT(VARCHAR(10),@AuditUserId) 
    END
    
   
       --设置条件查询必须关联的表 历史表                       
	  SET @FromSQL =' FROM dbo.provider_storage_product_buying_applay a WITH ( NOLOCK ) join 
						dbo.provider_storage_product_buying_applay_item b WITH ( NOLOCK )  on  b.applay_id = a.id
						JOIN dbo.product c WITH ( NOLOCK ) ON c.id = b.product_id 
						JOIN dbo.provider p WITH ( NOLOCK ) ON p.id = b.provider_id
						 '
                    
    
              
                        
    --求符合条件的总数                        
    SET @CountSql = ''--此语句不要去掉，不然查询供应商时会有问题                      
    SET @CountSql=' SELECT @RowCount = count(a.id) ' + @FromSQL + @Condition                      
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                         
                      
    IF ISNULL(@PageSize, 0) < 1                                 
        SET @PageSize = 50                                
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
    IF ISNULL(@PageIndex, 0) < 1                                 
        SET @PageIndex = 1                                
    ELSE                                 
    IF ISNULL(@PageIndex, 0) > @PageCount                                 
        SET @PageIndex = @PageCount                                
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                
    SET @end = @PageIndex * @PageSize                         
                            
                   
                            
    --设置需要取的字段信息                          
    SET @Column = '
			b.id ,  
            b.applay_id AS applayId ,  
            b.product_id AS productId ,  
            c.primary_picture_code AS primaryPictureCode ,  
            c.code AS productCode ,
			c.cost_price as productCostPrice,  
            b.unit ,  
            b.cost_price AS costPrice ,  
            b.unit_quantity AS unitQuantity ,  
            b.prepare_quantity AS prepareQuantity ,  
            b.buying_quantity AS buyingQuantity ,  
            b.provider_quantity AS providerQuantity ,  
            b.sell_quantity AS sellQuantity ,  
            b.provider_id AS providerId ,  
            p.code AS providerCode ,  
            b.plan_buy_quantity AS planBuyQuantity ,  
            b.actual_buy_quantity AS actualBuyQuantity, 
            b.discount,
			a.applay_time as operateDate,
			a.remark                      
      '             
                       
                            
    --组装基本查询的SQL                 
    SET @SQL= 'SELECT * from (                            
        SELECT  '+@Column+',ROW_NUMBER() OVER(ORDER BY a.status,a.applay_time desc) rowIndex'                            
            + @FromSQL +  @Condition + ') temp2                             
      where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and ' + CAST(@end AS NVARCHAR(10))                            
                    

    PRINT @SQL
    EXEC(@SQL);                                    
                              
    select @RowCount                              
END


go


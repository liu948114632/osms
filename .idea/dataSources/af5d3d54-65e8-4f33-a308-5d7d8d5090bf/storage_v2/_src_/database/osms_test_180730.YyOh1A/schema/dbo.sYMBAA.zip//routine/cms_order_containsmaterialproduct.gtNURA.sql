  
  
---检查商品是否有限制的属性值  
---2015-11-02  
---@LimitType 限制类型，1=带电判断，2=带磁判断，4=纺织品判断  
CREATE  PROC CMS_Order_ContainsMaterialProduct    
(  
 @OrderId int,  
 @LimitType INT --限制类型，1=带电判断，2=带磁判断，4=纺织品判断  
)   
AS  
BEGIN  
DECLARE @Sql NVARCHAR(max),@Condition NVARCHAR(max),@Parameter NVARCHAR(max)  
IF(@LimitType=1)  
 BEGIN  
  SET @Condition='3029,3030,3031';  
 END  
   
IF(@LimitType=2)  
BEGIN  
 SET @Condition='394,1139,3134'  
END  
   
IF(@LimitType=4)  
 BEGIN  
   SET @Condition='220,231,234,253,264,270,306,334,663,667,669,672,675,676,677,678,679,1398,2341,2342,2359,2457,2473,2477,2484,2485,2486,2489,2537,2567,2573,2578,2581,2583,2588,2592,2593,2594,2595'  
 END  
  
SET @Sql='  
WITH cte AS  
(                                
SELECT  t1.product_id,  
    p3.id AS property_id ,  
    p4.id AS property_value_id   
FROM    dbo.product p1  
        INNER JOIN dbo.product_property_value p2 ON p1.id = p2.product_id  
        INNER JOIN dbo.property p3 ON p3.id = p2.property_id  
        INNER JOIN dbo.property_value p4 ON p4.id = p2.property_value  
       INNER JOIN dbo.order_item t1 ON t1.product_id=p1.id  
WHERE  t1.Order_Id=@OrderId AND t1.[status] <12  
)            
SELECT DISTINCT t.product_id as productId FROM cte t WHERE  t.property_value_id IN  ('+@Condition+')';  
SET @Parameter=N'@OrderId int,@LimitType int'  
PRINT @Sql  
EXEC sp_executesql @Sql,@parameter,@OrderId=@OrderId,@LimitType=@LimitType  
END  

/****** Object:  StoredProcedure [dbo].[CRM_Order_IsOrderInfoLimited]    Script Date: 03/18/2016 10:46:36 ******/
SET ANSI_NULLS ON

go


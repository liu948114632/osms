
/**************************************************************
		备注：月订单的平均金额统计
指标：月订单平均金额= 月订单总金额/月订单总数。
CQ: 查询条件为月时间段，统计的订单为已录单的订单
up_Report_CustomerService_OrderMoney '2008-08-01','2009-08-01'
**************************************************************/
CREATE PROCEDURE [dbo].[up_Report_CustomerService_OrderMoney] 
	@StartTime	Datetime, 
	@EndTime	Datetime
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @OrderCount INT; -- 订单个数
	DECLARE @TotalPrice DECIMAL(18,2); -- 总订单金额

	SET @OrderCount = 1;
	SET @TotalPrice = 0;
	
	-- 订单个数
	SELECT @OrderCount = COUNT(1) 
	FROM dbo.T_Order
	WHERE OrderStatus > 0 AND OrderStatus < 132 
		AND OrderDate > @StartTime AND OrderDate < @EndTime;
	
	
	-- 订单金额
	SELECT @TotalPrice = SUM(b.Quantity*0.0728*b.ItemPrice/b.UnitQuantity)
	FROM dbo.T_Order a 
		INNER JOIN dbo.T_OrderItem b 
			ON a.OrderId = b.OrderId AND a.OrderStatus > 0 AND a.OrderStatus < 132 AND b.[Status] < 12 -- 非取消商品
				AND a.OrderDate > @StartTime AND a.OrderDate < @EndTime;

	IF 	@OrderCount > 0
	BEGIN
		SET @TotalPrice = @TotalPrice*1.0/@OrderCount;
		SELECT  @TotalPrice AS AvgTotalPrice;
	END	
	ELSE
	BEGIN
		SELECT  0 AS AvgTotalPrice;
	END				
				
	/*

	WITH cteOrders AS 
	(
		SELECT orderId FROM b_Order
		WHERE OrderDate >= @StartTime And OrderDate <= @EndTime AND Status < 132
	),
	cte AS 
	(
		SELECT SUM(ItemPrice * Quantity)  AS totalPrice,
		(SELECT COUNT(1) FROM cteOrders) AS c
		FROM cteOrders a JOIN b_OrderItem b ON a.orderId = b.OrderId
		AND b.Status < 12 AND b.ItemPrice > 0 AND b.Quantity > 0
	)
	
	SELECT @OrderCount = c,@TotalPrice = TotalPrice FROM cte
	
	IF @OrderCount IS NULL SET @OrderCount = 1
	IF @TotalPrice IS NULL SET @TotalPrice = 0
	SET @TotalPrice = CAST( @TotalPrice/@OrderCount AS DECIMAL(18,2))
	
	-- 在于0时按指标值进行转换
	IF @TotalPrice > 0
	BEGIN
		DECLARE @KeyId INT,@StandardValue INT,@AvgProductsPrice DECIMAL(18,2)
		SELECT @KeyId = Id,@StandardValue = StandardValue FROM Y_Guide_Key WHERE Status = 1
		
		SELECT @AvgProductsPrice = AvgProductsPrice FROM  Y_Guide_Value WHERE KeyId = @KeyId
		
		SET @TotalPrice = @TotalPrice*1000 /@AvgProductsPrice 
	END
	
	SELECT  @TotalPrice AS AvgTotalPrice
	
	*/
	
END


go


--更新订单附加费中的加工费，商品项加工费汇总
CREATE PROC [CRM_Order_OrderUpdateOrderSurchargesProcessingFee]   
(  
 @OrderId  VARCHAR(15),
 @CategoryId INT,
 @Surcharge DECIMAL(12,2),
 @Remark NVARCHAR(500)
)  
AS  
BEGIN  
PRINT 1
IF(@Surcharge=0)
BEGIN
	DELETE dbo.T_OrderSurcharge WHERE OrderId=@OrderId AND CategoryId=@CategoryId 
	RETURN;
END
print 2
IF EXISTS(SELECT TOP 1 1 FROM dbo.T_OrderSurcharge WHERE OrderId=@OrderId AND CategoryId=@CategoryId)
BEGIN
	UPDATE dbo.T_OrderSurcharge SET Surcharge=@Surcharge WHERE OrderId=@OrderId AND CategoryId=@CategoryId
END
ELSE
BEGIN
	INSERT INTO dbo.T_OrderSurcharge
	        ( OrderId ,
	          CategoryId ,
	          Surcharge ,
	          Remark ,
	          pwname
	        )
	VALUES  ( @OrderId , -- OrderId - varchar(15)
	          @CategoryId , -- CategoryId - int
	          @Surcharge , -- Surcharge - decimal
	          ISNULL(@Remark,''), -- Remark - varchar(500)
	          NULL  -- pwname - varchar(200)
	        )
END
END
go


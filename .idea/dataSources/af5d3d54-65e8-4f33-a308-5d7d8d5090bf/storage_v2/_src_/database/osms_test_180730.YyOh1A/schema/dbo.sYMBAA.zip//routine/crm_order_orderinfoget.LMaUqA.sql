

-- =============================================      
-- Author:  <Author,,>      
-- Create date: <Create Date,,>      
-- Description: <Description,,获取客户信息>      
-- =============================================  
CREATE PROC [dbo].[CRM_Order_OrderInfoGet]
(
	@OrderId VARCHAR(20)
)   
AS      
BEGIN      
   
SET NOCOUNT ON;      
	SELECT a.OrderId ,a.HandlerId ,a.CustomerId ,b.FullName AS CustomerName ,b.EmailId  , a.OrderStatus   
    FROM dbo.T_Order a
    JOIN dbo.T_Customer b ON a.CustomerId = b.UserID
    WHERE a.OrderId = @OrderId
END

go


CREATE PROCEDURE [dbo].[US_Category_DeleteCategory]
(
	@CategoryId INT
)
AS
BEGIN 
	UPDATE dbo.T_Category_US SET IsDeleted=1 WHERE CategoryId=@CategoryId
END
go





CREATE PROC dbo.CRM_Order_AddPackageProblem
(
@OrderId VARCHAR(20),
@OrderCodes VARCHAR(200),
@CreatorUserName VARCHAR(20),
@DeliveryUserName VARCHAR(20) ,
@CreateTime VARCHAR(20),
@Type INT=1,
@isFromDMS BIT 
)
AS
BEGIN

IF EXISTS(SELECT TOP 1 1 FROM dbo.T_PackageProblem WHERE OrderId=@OrderId AND type=@Type)
BEGIN
--DECLARE @Info NVARCHAR(100)
----SET @Info='<info>添加问题件跟踪出错，订单'+@OrderId+'已创建问题件！</info>';
----	   RAISERROR (@Info, 16, 1) WITH NOWAIT;      
   RETURN; 
END

DECLARE @ProblemId INT

INSERT INTO dbo.T_PackageProblem
        ( IsRead ,
          Status ,
          OrderId ,
          OrderCodes ,
          CreatorUserName ,
          DeliveryUserName ,
          CreateTime,
		  type,
		  IsFromDMS
        )
VALUES  ( 0 , -- IsRead - bit
          0 , -- Status - int
          @OrderId , -- OrderId - varchar(15)
          @OrderCodes, -- OrderCodes - varchar(200)
          @CreatorUserName , -- CreatorUserId - int
          @DeliveryUserName, -- DeliveryUserId - int
          @CreateTime , -- CreateTime - smalldatetime
		  @Type,
		  @isFromDMS
        )

		SET @ProblemId=SCOPE_IDENTITY();

			UPDATE dbo.T_PackageProblem SET ProblemId=@ProblemId WHERE OrderCodes=@OrderCodes AND type=@Type AND Status=0 

END


go


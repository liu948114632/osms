/*        
* 2012-09-12 采购部获取扩展产品列表 create  
*/        
CREATE PROCEDURE [dbo].[CMS_PurchasingDepartment_ProductExpandList]        
(        
 @ProviderCode VARCHAR(100) = NULL,  
 @ProductCode VARCHAR(100) = NULL,  
 @ProductCodes VARCHAR(max) = NULL,   
 @ProductName  VARCHAR(max) = NULL,  
 @Status  INT = NULL,  
 @DealUserId  INT = NULL,  
 @CreateTimeBegin  VARCHAR(max) = NULL,  
 @CreateTimeEnd VARCHAR(max) = NULL,  
 @OperateTimeBegin  VARCHAR(max) = NULL, --产品拓展历史时间开始 v3.9.0 add
 @OperateTimeEnd VARCHAR(max) = NULL,--产品拓展历史时间结束
 @ProductCompetitor  INT = NULL,--竞争对手
 @SDepartmentId INT = NULL,
 @PageSize INT = 50 ,  --页大小                  
 @PageIndex INT = 1    --当前页号          
)        
AS            
BEGIN            
 SET NOCOUNT ON            
 DECLARE        
  @SQL NVARCHAR(MAX),          
  @tempSQL NVARCHAR(MAX),          
  @FromSQL NVARCHAR(MAX),           
  @FromSQL2 NVARCHAR(MAX),          
  @Column NVARCHAR(MAX),
  --@Column2 NVARCHAR(MAX),       --v3.9.0 add      
  @Condition NVARCHAR(MAX),            
  @CountSQL NVARCHAR(MAX),       
  @RowCount INT , @PageCount INT , @start INT ,@end INT;         
         
 --组装查询条件        
SET @Condition = ' WHERE 1=1 ';
IF @ProviderCode IS NOT NULL
BEGIN
	SET @Condition = @Condition + ' AND e. code like ''' + @ProviderCode + '%''';
END 
IF @ProductCode IS NOT NULL
BEGIN
	SET @Condition = @Condition + ' AND b. code like ''' + @ProductCode + '%''';
END                 
IF @ProductCodes IS NOT NULL         
 BEGIN        
  SET @Condition = @Condition + ' AND b.code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')';        
 END      
   
 IF @ProductName IS NOT NULL         
 BEGIN        
  SET @Condition = @Condition + ' AND b.name LIKE ''' + @ProductName + '%''';        
 END    
 IF @Status IS NOT NULL         
 BEGIN        
  SET @Condition = @Condition + ' AND a.status = ' + CONVERT(VARCHAR(10), @Status);        
 END    
 IF @DealUserId IS NOT NULL         
 BEGIN        
  SET @Condition = @Condition + ' AND a.deal_user_id = ' + CONVERT(VARCHAR(10), @DealUserId);        
 END  
     
  IF @CreateTimeBegin IS NOT NULL                     
 BEGIN                
  SET @Condition = @Condition + ' AND a.create_time >=''' + CONVERT(VARCHAR(20), @CreateTimeBegin) + '''';                
 END                   
 IF @CreateTimeEnd IS NOT NULL                     
 BEGIN                
  SET @Condition = @Condition + ' AND a.create_time <=''' + CONVERT(VARCHAR(20), @CreateTimeEnd) + '''';                
 END
 --v3.9.0 add
 IF @OperateTimeBegin IS NOT NULL                     
 BEGIN                
  SET @Condition = @Condition + ' AND (CASE WHEN a.status = 40 THEN (select max(operate_time) from product_expand_history where product_expand_id = a.id and operate_message=''结束拓展'') ELSE NULL END) >=''' + CONVERT(VARCHAR(20), @OperateTimeBegin) + '''';                
 END                   
 IF @OperateTimeEnd IS NOT NULL                     
 BEGIN                
  SET @Condition = @Condition + ' AND (CASE WHEN a.status = 40 THEN (select max(operate_time) from product_expand_history where product_expand_id = a.id and operate_message=''结束拓展'') ELSE NULL END) <=''' + CONVERT(VARCHAR(20), @OperateTimeEnd) + '''';                
 END
 
 IF @SDepartmentId  IS NOT NULL
 BEGIN
 	SET @Condition = @Condition + ' and c.department_id = ' + CONVERT(VARCHAR(10), @SDepartmentId);
 END
 
 --v3.9.5 add
 IF @ProductCompetitor IS NOT NULL
 BEGIN
 	SET @Condition = @Condition + ' and f.competitor_type = ' + CONVERT(VARCHAR(10), @ProductCompetitor);
 END
  
SET @FromSQL = ' FROM dbo.product_expand AS a WITH(NOLOCK) 
        INNER JOIN dbo.product AS b WITH(NOLOCK) ON a.data_product_id = b.id  
        INNER JOIN dbo.product_strategy AS c WITH(NOLOCK) ON c.product_id = b.id  
        INNER JOIN dbo.product_provider AS d WITH(NOLOCK) ON d.department_id = c.department_id  
                                                AND d.product_id = c.product_id  
        INNER JOIN dbo.provider AS e WITH(NOLOCK) ON e.id = d.provider_id 
        INNER JOIN ph_product_competitor as f WITH(NOLOCK) ON f.id = a.competitors_id ';        

--获取符合条件的总记录数        
SET @CountSQL = ' SELECT @RowCount = count(a.id) ' + @FromSQL + @Condition                  
EXEC sp_executesql @CountSQL, N'@RowCount INT OUT', @RowCount OUT         
            
--设置分页参数(一定要放在取记录数的后面)        
IF ISNULL(@PageSize, 0) < 1                         
    SET @PageSize = 50                        
SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                        
IF ISNULL(@PageIndex, 0) < 1                         
    SET @PageIndex = 1                        
ELSE                         
IF ISNULL(@PageIndex, 0) > @PageCount                         
    SET @PageIndex = @PageCount                     
SET @start = ( @PageIndex - 1 ) * @PageSize + 1                        
SET @end = @PageIndex * @PageSize    
--V3.9.0 ADD g.operate_time AS completeTime
SET @Column = 'SELECT  a.id AS id ,  
        a.competitors_id AS competitorsId ,  
        a.create_time AS createTime ,  
        a.data_product_id AS dataProductId ,  
        a.data_type AS dataType ,  
        a.deal_user_id AS dealUserId ,  
        a.department_remark AS departmentRemark ,  
        a.purchase_remark AS purchaseRemark ,  
        a.status AS status ,  
        a.type AS type ,  
        b.code AS productCode ,  
        b.name AS productName ,  
        b.id AS productId,
        b.original_name AS productOriginalName ,  
        CONVERT(VARCHAR(100),b.unit_quantity )+'' ''+ b.unit AS productUnit ,  
        b.primary_picture_code AS primaryPictureCode ,
        b.color_card_picture_code AS colorCardPictureCode ,  
        c.department_id AS productStrategyDepartmentId ,  
        e.code AS productProviderCode ,  
        e.level AS productProviderType ,  
        f.competitor_type AS competitorsName ,  
		f.picture_code competitorPictureCode,
		f.product_code competitorProductCode,
		f.product_name competitorProductName,
		f.link_address linkAddress,
		CONVERT(VARCHAR(18), CAST(f.batch_quantity AS DECIMAL(18, 0))) + '' '' + f.unit competitorUnit,
		f.estimate_cost_price estimateCost,
		b.cost_price,
		a.purchase_manage_remark purchaseManageRemark,
		(CASE WHEN a.status = 40 THEN (select max(operate_time) from product_expand_history where product_expand_id = a.id and operate_message=''结束拓展'') ELSE NULL END) as completeTime,
		(SELECT MAX(operate_time) FROM dbo.product_expand_history WHERE product_expand_id = a.id and operate_message=''分派处理人'') AS assignTime,
        e.support_level AS productProviderLevel,ROW_NUMBER() OVER(ORDER BY a.status) rowIndex ';       
--v3.9.0 
--(CASE WHEN a.status = 40 THEN g.operate_time ELSE NULL END)AS completeTime,bug update original g.operate_time AS completeTime,add SET @Condition = @Condition + ' and g.operate_message =''结束拓展'''     
 SET @SQL = 'select temp.*,ISNULL(PH.current_cost_price,cost_price) AS phCostPrice from (' +@Column + @FromSQL + @Condition +') as temp left join ph_product PH on ph.product_id=temp.productId where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and ' + CAST(@end AS NVARCHAR(10));       
          
   --SELECT @SQL
	 print @SQL
   EXEC(@SQL);                                    
                              
    select @RowCount    
END
go


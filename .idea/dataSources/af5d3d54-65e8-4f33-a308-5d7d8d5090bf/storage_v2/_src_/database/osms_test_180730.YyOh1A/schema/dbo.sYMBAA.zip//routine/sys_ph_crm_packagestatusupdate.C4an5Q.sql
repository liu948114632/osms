


/*-----------------------------------------------
备注：各系统间的交互:更新订单包裹状态
创建人: FRH
创建日期:2010-01-15
--------------------------------------------------*/
CREATE PROC [dbo].[SYS_PH_CRM_PackageStatusUpdate]
(
	@OrderId			VARCHAR(20),
	@PackageStatus		INT
)
AS
BEGIN
	EXEC CRM_Order_PackageStatusUpdate @OrderId = @OrderId,@Status = @PackageStatus;
END
go


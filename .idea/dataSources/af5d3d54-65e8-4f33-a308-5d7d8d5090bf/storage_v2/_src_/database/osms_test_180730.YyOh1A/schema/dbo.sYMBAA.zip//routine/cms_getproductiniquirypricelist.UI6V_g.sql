  
/**
* 添加@ProductCodeList 查询条件 20130601
*/
CREATE PROCEDURE CMS_GETProductIniquiryPriceList      
(      
 @ImportTimeBegin VARCHAR(24) = NULL, --导入时间起      
 @ImportTimeOver VARCHAR(24) = NULL,--导入时间止      
 @Status INT = NULL, --状态      
 @DepartmentID INT = NULL,--策略部门      
 @CostRatio VARCHAR(24)= NULL,--成本价比条件      
 @ProductCode VARCHAR(24)=NULL, --产品编号        
 @ProductCodeList VARCHAR(MAX)=NULL, --产品编号列表
 @PageSize INT = 50 ,  --页大小                    
 @PageIndex INT = 1    --当前页号           
)      
AS      
BEGIN      
 SET NOCOUNT ON;      
 DECLARE      
  @SQL VARCHAR(max),                    
        @CountSql NVARCHAR(MAX), --查询数量用                    
        @FromSQL NVARCHAR(max), --查询内表                  
        @FromSQL2 NVARCHAR(max), --查询                  
        @Column NVARCHAR(max), --取的字段                  
        @Condition varchar(MAX), --条件                     
        @RowCount INT ,       
        @PageCount INT ,       
        @start INT ,      
        @end INT      
              
   --设置查询主表      
   SET @FromSQL = ' SELECT Q.id, ROW_NUMBER() OVER(ORDER BY Q.status, P.Code) rowIndex FROM '      
    + ' dbo.product_inquiry_price Q WITH(NOLOCK) LEFT JOIN Product P WITH(NOLOCK) ON P.id=Q.product_id ';      
          
   --设置关联表      
   SET @FromSQL2 = 'INNER JOIN product_inquiry_price Q WITH(NOLOCK) ON temp.id=Q.id     
     INNER JOIN Product P WITH(NOLOCK) ON Q.product_id=p.id      
     INNER JOIN ph_product PH WITH(NOLOCK) ON PH.product_id=Q.product_id      
     INNER JOIN product_strategy S WITH(NOLOCK) ON s.product_id = Q.product_id      
     LEFT JOIN product_set_color_card as PSC WITH(NOLOCK) ON P.product_set_color_card_id = PSC.id     
     LEFT JOIN (SELECT PR.department_id, PR.product_id, PV.code providerCode FROM dbo.product_provider PR       
     INNER JOIN dbo.provider PV ON PR.department_id=PV.department_id AND PR.provider_id=PV.id)      
     PPS ON PPS.department_id=s.department_id AND PPS.product_id=S.product_id      
     LEFT JOIN product_property_value ppv1 WITH(NOLOCK) ON Q.product_id = ppv1.product_id and ppv1.property_id = 2                  
     LEFT JOIN property_value pv1 WITH(NOLOCK) ON ppv1.property_value = pv1.id                   
     LEFT JOIN product_property_value ppv2 WITH(NOLOCK) ON Q.product_id = ppv2.product_id and ppv2.property_id = 4                  
     LEFT JOIN property_value pv2 WITH(NOLOCK) ON ppv2.property_value = pv2.id                  
     LEFT JOIN product_property_value ppv3 WITH(NOLOCK) ON Q.product_id = ppv3.product_id and ppv3.property_id = 10                  
     LEFT JOIN property_value pv3 WITH(NOLOCK) ON ppv3.property_value = pv3.id                 
     LEFT JOIN category C WITH(NOLOCK) ON C.id = CASE WHEN P.category_id_3 IS NULL OR P.category_id_3=0       
     THEN CASE WHEN P.category_id_2 IS NULL  OR P.category_id_2=0 THEN       
     P.category_id_1 ELSE P.category_id_2 END ELSE P.category_id_3 END';          
         
   --设置查询条件      
   SET @Condition = ' where 1=1 ';      
   IF @ImportTimeBegin IS NOT NULL       
   BEGIN      
    SET @Condition = @Condition + ' AND Q.create_time >= ''' + @ImportTimeBegin + '''';      
   END      
   IF @ImportTimeOver IS NOT NULL       
   BEGIN      
    SET @Condition = @Condition + ' AND Q.create_time <= ''' + @ImportTimeOver + '''';      
   END      
   IF @Status IS NOT NULL       
   BEGIN      
    SET @Condition = @Condition + ' And Q.status=' + CONVERT(VARCHAR(10), @Status);      
   END      
   IF @DepartmentID IS NOT NULL      
   BEGIN      
 SET @Condition = @Condition + ' and exists(select S.product_id from product_strategy S '       
        + ' where Q.product_id = S.product_id and s.department_id=' + CONVERT(VARCHAR(10), @DepartmentID) + ') ';      
   END       
   IF @CostRatio IS NOT NULL       
   BEGIN      
    SET @Condition = @Condition + ' AND Q.cost_price_ratio' + @CostRatio;      
   END      
   IF @ProductCode IS NOT NULL      
   BEGIN      
 SET @Condition = @Condition + ' AND P.code like ''' + @ProductCode + '%''';      
   END    
 IF @ProductCodeList IS NOT NULL               
 BEGIN                 
    SET @Condition = @Condition + ' AND P.code in (''' + REPLACE(@ProductCodeList,',',''',''') + ''')'              
 END       
       
 --SET @Condition = @Condition + ' AND RowIndex BETWEEN ' + CAST(@Start AS VARCHAR(10))       
 -- + ' AND ' + CAST(@End AS VARCHAR(10));      
        
 --设置查询显示列      
 SET @Column = ' C.[name] categoryName, P.color_card_picture_code colorCardPictureCode,       
     P.cost_price costPrice, Q.cost_price_ratio costPriceRatio,      
     Q.create_time createTime, Q.factory_quantity factoryQuantity,       
     PH.first_profit_coefficient firstProfitCoefficient,      
     Q.id, Q.inquiry_price inquiryPrice, Q.plan_batch planBatch,       
     Q.plan_day planDay, Q.plan_quantity planQuantity,      
     P.primary_picture_code primaryPictureCode, P.code productCode,       
     PPS.providerCode, Q.product_id productId,      
     P.NAME productName, P.original_name productOriginalName,      
     dbo.MergeProductSpec(P.product_set_specification_id) productSpecification,      
     CONVERT(VARCHAR(10),P.unit_quantity) + P.unit  productUnit,      
     Q.quote_remark quoteRemark, Q.quote_time quoteTime,      
     Q.quote_user_id quoteUserId, Q.status status,      
     S.department_id strategyDepartmentId,      
     S.product_id strategyId,      
     PSC.name colorCardEnName,      
     P.heavy_metals productHeavyMetals,      
     pv1.name as productMaterial,                  
     pv2.name as productColor,                  
     pv3.name as productShape ';      
      
 --查询记录数      
 SET @CountSQL = '';      
 SET @CountSQL = 'SELECT @RowCountOUT=count(temp.id) FROM (' + @FromSQL + @Condition + ') temp ';      
 --print @CountSQL;      
 EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;        
        
    --查询的分页条件      
 IF ISNULL(@PageSize, 0) < 1                             
  SET @PageSize = 50                            
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                            
    IF ISNULL(@PageIndex, 0) < 1                             
        SET @PageIndex = 1                            
    ELSE                             
    IF ISNULL(@PageIndex, 0) > @PageCount                             
        SET @PageIndex = @PageCount                            
    SET @Start = ( @PageIndex - 1 ) * @PageSize + 1                            
    SET @End = @PageIndex * @PageSize                     
        
 --组装查询语句      
 SET @SQL = 'SELECT ' + @Column + 'From (SELECT * FROM (' + @FromSQL + @Condition + ') temp2 '       
    + 'WHERE RowIndex BETWEEN ' + CAST(@Start AS VARCHAR(10))       
    + ' AND ' + CAST(@End AS VARCHAR(10)) + ')temp ' + @FromSQL2      
 PRINT @SQL      
 EXEC(@SQL);                              
    select @RowCount        
END

go


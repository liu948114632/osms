
CREATE VIEW V_CRM_ProductRelatedSpec  
AS   
SELECT   
 a.id AS CmsProductId,  
 b.spec_id AS SpecId,  
 b.spec_value AS SpecValue  
FROM dbo.product a WITH(NOLOCK)  
     INNER JOIN dbo.product_set_specification_value b WITH(NOLOCK) ON a.product_set_specification_id=b.product_set_specification_id

go


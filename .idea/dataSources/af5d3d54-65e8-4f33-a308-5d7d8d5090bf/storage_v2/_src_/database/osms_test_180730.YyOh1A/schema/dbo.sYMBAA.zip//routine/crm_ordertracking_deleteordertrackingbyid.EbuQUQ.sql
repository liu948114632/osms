
----删除订单跟踪
CREATE PROC dbo.CRM_OrderTracking_DeleteOrderTrackingById
(
@Codes VARCHAR(MAX),
@OperatorId INT
)
AS
BEGIN
    IF EXISTS ( SELECT TOP 1
                        1
                FROM    dbo.T_OrderTracking
                WHERE   code IN (SELECT Value FROM dbo.uf_Split(@Codes,','))
                        AND status <> 10 )
        BEGIN
            RAISERROR ('<info>只能删除未答复状态的咨询！</info>' , 16, 1) WITH NOWAIT;            
            RETURN;  
        END
    ELSE
        BEGIN

		INSERT INTO dbo.T_OrderTrackingHistory
		        ( OrderTrackingId ,
		          CreateTime ,
		          OperatorId ,
		          Remark
		        )
SELECT b.id,GETDATE(),@OperatorId,'删除订单跟踪' FROM dbo.uf_Split(@Codes,',') a
INNER JOIN dbo.T_OrderTracking b ON a.Value=b.code

           UPDATE   dbo.T_OrderTracking SET IsDelete=1
             WHERE   code IN (SELECT Value FROM dbo.uf_Split(@Codes,','))

        END
END


go


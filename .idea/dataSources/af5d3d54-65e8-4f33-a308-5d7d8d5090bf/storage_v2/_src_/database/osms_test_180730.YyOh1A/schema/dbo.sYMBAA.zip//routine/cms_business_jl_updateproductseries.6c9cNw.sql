CREATE PROC [dbo].CMS_Business_JL_UpdateProductSeries      
(       
 @CategorySeriesId INT = NULL, --类别系列Id      
 @FirstProfitCoefficient DECIMAL(10, 6) = NULL, --第一段系数      
 @SecondProfitCoefficient DECIMAL(10, 6) = NULL, --第二段系数      
 @ThirdProfitCoefficient DECIMAL(10, 6) = NULL, --第三段系数   
 @RetailProfitCoefficient DECIMAL(10, 6) = NULL --零售系数
)      
AS       
    BEGIN                
        SET NOCOUNT ON ;              
        DECLARE @ProductStr VARCHAR(max);
		SET @ProductStr = '';
	    UPDATE dbo.jl_product SET first_profit_coefficient = @FirstProfitCoefficient,      
			second_profit_coefficient = @SecondProfitCoefficient,      
			third_profit_coefficient = @ThirdProfitCoefficient,
			retail_profit_coefficient = @RetailProfitCoefficient WHERE category_series_id = @CategorySeriesId       
   
	    SELECT @ProductStr = @ProductStr + ',' + cast(product_id as varchar) from
	    (
			SELECT product_id FROM  dbo.jl_product WHERE category_series_id = @CategorySeriesId 
		) temp
		
		IF @ProductStr = NULL OR @ProductStr = ''
		RETURN
		
	    SET @ProductStr = right(@ProductStr , len(@ProductStr) - 1) 
	    INSERT INTO dbo.communication_log  
			  ( command ,  
				object_id ,  
				status ,  
				create_time ,  
				operator ,  
				model_type ,  
				execute_time  
			  )   
	    VALUES('UPDATE_JL_SALE_PRICE',@ProductStr, 1,GETDATE(), 0,'PRODUCT',NULL )   
   SET NOCOUNT OFF ;           
END
go




/*
* 2012-08-10
* 根据产品集ID获取产品集下产品的图片信息
*/
CREATE PROC [dbo].[CMS_Product_GetProductPictureByProductSetID]       
(        
	@ProductSetId INT = NULL   --产品集ID  
)      
AS       
BEGIN                        
	SET NOCOUNT ON ;     
	SELECT 
		pc.id,
		pc.product_id productId,
		pc.picture_code pictureCode,
		pc.picture_name pictureName,
		pc.[type],
		pc.order_index orderIndex
	FROM dbo.product p WITH(NOLOCK) LEFT JOIN dbo.product_picture_collection pc WITH(NOLOCK)  
		ON p.id = pc.product_id WHERE p.product_set_id=@ProductSetId and p.is_delete=0
		ORDER BY product_id,[type] ASC ,order_index ASC 
    SET NOCOUNT OFF ;           
END
go


 CREATE PROC dbo.CMS_storage_order         
     (          
       @receiveDepartmentId INT =NULL,
 	  @warehouseAreaId INT=NULL,
 	  @type INT=NULL,
 	  @code VARCHAR(100)=NULL,
 	  @codes VARCHAR(max) =NULL,
 	  @productCode VARCHAR(100)=NULL,
 	  @productCodes VARCHAR(max)=NULL,
 	  @orderCode VARCHAR(100)=NULL,
 	  @orderCodes VARCHAR(max)=NULL,
 	  @warehouseAreaCategoryIds VARCHAR(max)=NULL,
 	  @dealUserId INT=NULL,
 	  @status INT=NULL,
 	  @createdTimeBegin DATETIME=NULL,
 	  @createdTimeEnd DATETIME=NULL,
 	  @dealTimeBegin DATETIME=NULL,
 	  @dealTimeEnd DATETIME=NULL,  
 	  @department INT=NULL,
	  @layer NVARCHAR(100)=NULL, 
	  @isVip INT =NULL ,
	  @timeType INT = NULL,       
       @PageSize INT = 50 ,  --页大小                      
       @PageIndex INT = 1    --当前页号                      
     )          
 AS           
     BEGIN                                                         
         DECLARE @SQL VARCHAR(MAX) ,          
             @CountSql NVARCHAR(MAX) , --查询数量用                      
             @FromSQL NVARCHAR(MAX) , --查询表                    
             @Condition VARCHAR(MAX) , --条件           
             @PriceCondition VARCHAR(MAX) ,--外查询条件          
             @RowCount INT ,          
             @PageCount INT ,          
             @start INT ,          
             @end INT ,          
             @Column VARCHAR(MAX)                 
                               
         SET @FromSQL = '  FROM dbo.storage_order so WITH(NOLOCK)
 					      INNER JOIN dbo.[order] o WITH(NOLOCK) ON o.id=so.order_id 
 						  
 						  '                       
                           
         SET @Condition = ' WHERE 1=1 and so.is_deleted=0 '            
                      
    IF @isVip IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND o.is_vip = ' + CONVERT(VARCHAR(20),@isVip)
	END
	IF @layer IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND so.layer = ''' + @layer+''''
	end                  
 	IF @warehouseAreaId IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND so.warehouse_area_id = ' + CONVERT(VARCHAR(20),@warehouseAreaId)
 	END
 
 	IF @department IS NOT NULL
 	BEGIN
 	   SET @FromSQL = @FromSQL + '  INNER JOIN dbo.[warehouse_area] w1 WITH(NOLOCK) ON so.warehouse_area_id=w1.id '   
 
 		SET @Condition =  @Condition + ' AND w1.department_id= ' + CONVERT(VARCHAR(20),@department) 
 	END 
 
	IF @timeType IS NOT NULL 
	BEGIN
		SET @Condition =@Condition  + ' AND so.can_deal_time <= ''' + CONVERT(VARCHAR(10),GETDATE(),25) + ' 16:00'''  
    END
  	IF @dealUserId IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND so.deal_user_id = ' + CONVERT(VARCHAR(20),@dealUserId)
 	END
 
 	IF @status IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND so.status = ' + CONVERT(VARCHAR(20),@status)
 	END
 
 	IF @receiveDepartmentId IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND so.receive_department_id = ' + CONVERT(VARCHAR(20),@receiveDepartmentId)
 	END
 	--直发区子单任务=1, 合单区子单任务=2, 暂存区子单任务=3, 需加工子单任务=4
 	IF @type IS NOT NULL
 	BEGIN
 		IF @type=1
 		BEGIN
 		    SET @Condition =  @Condition + ' AND o.department_id =35 '
 		END
 		IF @type=2
 		BEGIN
 		     SET @Condition =  @Condition + ' AND o.department_id =36 '
 		END
 		IF @type=3
 		BEGIN
 		     SET @Condition =  @Condition + ' AND o.department_id =37 AND (so.receive_department_id < 9 OR so.receive_department_id > 9)'
 		END
 		IF @type=4
 		BEGIN
 		     SET @Condition =  @Condition + ' AND so.receive_department_id =9 '
 		END
 	END
       
 	IF @code IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND so.code LIKE ''' + @code + '%'''  
 	END 
 
 	IF @codes IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND so.code IN (''' + REPLACE(@codes,',',''',''') + ''')'    
 	END
 
 	IF @orderCode IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND o.code  LIKE ''' + @orderCode + '%'''  
 	END 
 
 	IF @orderCodes IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND o.code IN (''' + REPLACE(@orderCodes,',',''',''') + ''')'    
 	END
 
 	IF @createdTimeBegin IS NOT NULL
 		BEGIN
 			SET @Condition =  @Condition +' AND so.create_time >=''' + CONVERT(VARCHAR(20),@createdTimeBegin) + ''''
 		END	
 	IF @createdTimeEnd IS NOT NULL
 		BEGIN
 			SET @Condition =  @Condition +' AND so.create_time <=''' + CONVERT(VARCHAR(20),@createdTimeEnd) + ''''
 		END	
 
 	IF  @dealTimeBegin IS NOT NULL
 		BEGIN
 			SET @Condition =  @Condition +' AND so.deal_time >=''' + CONVERT(VARCHAR(20),@dealTimeBegin) + ''''
 		END	
 	IF @dealTimeEnd IS NOT NULL
 		BEGIN
 			SET @Condition =  @Condition +' AND so.deal_time <=''' + CONVERT(VARCHAR(20),@dealTimeEnd) + ''''
 		END	
 
    IF @warehouseAreaCategoryIds IS NOT NULL AND LEN(@warehouseAreaCategoryIds)>0
    BEGIN 
        SET @warehouseAreaCategoryIds = REPLACE(@warehouseAreaCategoryIds,'&',';')
        SET @FromSQL = @FromSQL + ' INNER JOIN dbo.view_storage_order vso WITH(NOLOCK) ON so.id=vso.id'
 	   SET @Condition =  @Condition + ' AND vso.warehouse_area_category_ids in (select Value from dbo.uf_Split(''' + @warehouseAreaCategoryIds + ''',''|''))'
 
 	    SET @FromSQL = @FromSQL + ' LEFT JOIN dbo.disable_storage_position dis WITH(NOLOCK) ON vso.storage_position_names LIKE ''%;'' + dis.storage_position_name + ''%'' AND so.warehouse_area_id=dis.warehouse_area_id '  --此行临时用
 		SET @Condition =  @Condition +' AND dis.id is null '--此行临时用
    END 
    ELSE --此行临时用
    BEGIN--此行临时用
        SET @FromSQL = @FromSQL + ' INNER JOIN dbo.view_storage_order vso WITH(NOLOCK) ON so.id=vso.id'  --此行临时用
 	     SET @FromSQL = @FromSQL + ' LEFT JOIN dbo.disable_storage_position dis WITH(NOLOCK) ON vso.storage_position_names LIKE ''%;'' + dis.storage_position_name + ''%'' AND so.warehouse_area_id=dis.warehouse_area_id '  --此行临时用
 	   SET @Condition =  @Condition +' AND dis.id is null ' --此行临时用
    END --此行临时用
 
 	
 	IF @productCode IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND EXISTS (SELECT 1 FROM dbo.storage_order_item soi WITH(NOLOCK) 
 								 INNER JOIN dbo.view_all_storage_task st WITH(NOLOCK)
 								 ON st.id=soi.task_id
 								 INNER JOIN  dbo.product p WITH(NOLOCK) ON p.id=st.product_id
 								 WHERE soi.storage_order_id=so.id and soi.is_deleted=0 AND p.code LIKE ''' + @productCode + '%'')'  
 	END 
 
 	IF @productCodes IS NOT NULL
 	BEGIN
 		SET @Condition =  @Condition + ' AND EXISTS (SELECT 1 FROM dbo.storage_order_item soi WITH(NOLOCK) 
 								 INNER JOIN dbo.view_all_storage_task st WITH(NOLOCK)
 								 ON st.id=soi.task_id
 								 INNER JOIN  dbo.product p WITH(NOLOCK) ON p.id=st.product_id
 								 WHERE soi.storage_order_id=so.id and soi.is_deleted=0 AND p.code IN (''' + REPLACE(@productCodes,',',''',''') + '''))'    
 	END
 
 
 	SET @CountSql = ' SELECT @RowCount = count(so.id) ' + @FromSQL + @Condition            
     EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                           
                           
         --SELECT  @CountSql                      
                            
         IF ISNULL(@PageSize, 0) < 1           
            SET @PageSize = 50                            
         SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                            
         IF ISNULL(@PageIndex, 0) < 1           
             SET @PageIndex = 1                            
   ELSE           
             IF ISNULL(@PageIndex, 0) > @PageCount           
                 SET @PageIndex = @PageCount                            
         SET @start = ( @PageIndex - 1 ) * @PageSize + 1                            
         SET @end = @PageIndex * @PageSize                     
 
 
     --设置需要取的字段信息            
     SET @Column = '
 		   so.id ,
 		   so.code ,
		   so.layer as layer,
 		   so.receive_department_id AS receiveDepartmentId,
 		   so.receive_box_position_id receiveBoxPositionId,
 		   so.receive_box_position_name receiveBoxPositionName,
 		   so.warehouse_area_id warehouseAreaId,
 		   so.item_count itemCount,
 		   (SELECT COUNT(DISTINCT st2.product_id) FROM dbo.storage_order_item st1 WITH(NOLOCK) JOIN dbo.view_all_storage_task st2 WITH(NOLOCK)
 		    ON st1.task_id=st2.id WHERE st1.storage_order_id=so.id AND st1.is_deleted=0 AND st1.status!=5) as productCount,
 		   so.volume volume,
 		   so.status ,
 		   so.create_time as createdTime,
 		   so.can_deal_time as canDealTime,
		   so.order_index as orderIndex,
 		   so.deal_user_id dealUserId,
 		   so.deal_time dealTime,
 		   so.complete_time complatedTime,
 		   so.is_received received,
 		   so.order_id orderId,
 		   so.off_shelf_id AS offShelfId,
 		   so.remark,
 		   o.code AS orderCode,
		   o.is_vip as isVip,
 		   o.send_group_id AS sendGroupId,
 		   o.customer_service_remark as orderRemark,
 		   dbo.CMS_storage_order_department(so.id) as department
 	 ' 
    IF @warehouseAreaCategoryIds IS NOT NULL AND LEN(@warehouseAreaCategoryIds)>0
    BEGIN      
           SET @Column = @Column + ',vso.warehouse_area_category_names as warehouseAreaCategoryNames'
    END
    ELSE
    BEGIN
           SET @Column = @Column + ',vso.warehouse_area_category_names as warehouseAreaCategoryNames'--此行临时用，去掉时需启用下面行的代码
           --SET @Column = @Column + ',(Select warehouse_area_category_names from view_storage_order vso where vso.id=so.id) as warehouseAreaCategoryNames'
    END       
                           
 	    --组装基本查询的SQL                     
 		 SET @SQL = 'SELECT * from                      
 		          (                      
 		          SELECT *,ROW_NUMBER() OVER(ORDER BY CASE WHEN status=20 THEN 1
			WHEN status=50 THEN 2
            WHEN status=30 THEN 3
			WHEN status=40 THEN 4
			WHEN status=10 THEN 5
			WHEN status=60 THEN 6
			WHEN status=70 THEN 7 END ASC,
			CASE WHEN layer=''4楼'' THEN 1
			WHEN layer=''3楼'' THEN 2
            WHEN layer=''2楼'' THEN 3
			WHEN layer=''4楼,3楼''THEN 4
			WHEN layer=''4楼,3楼,2楼'' THEN 5
			WHEN layer=''4楼,2楼'' THEN 6
			WHEN layer=''3楼,2楼'' THEN 7 END ASC,orderIndex asc,canDealTime ASC
			 ) rowIndex                      
 		          from (SELECT ' +@Column + @FromSQL + @Condition
 		               + ') temp                      
 		          ) temp2                           
 		          where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
 		               + CAST(@end AS NVARCHAR(10))                     
         EXEC(@SQL) ;                                
          PRINT @SQL                 
         SELECT  @RowCount                          
     END
 go


CREATE PROC CRM_Service_UpdateShopEmailAlreadySendMark
(
@OrderIds VARCHAR(MAX)
)
AS 
BEGIN
		UPDATE dbo.T_ShopCustomer
	SET T_ShopCustomer.IsAlreadySendConfirmArrivalEmail=1
	 FROM dbo.uf_Split(@OrderIds,',') b
	 WHERE b.Value=T_ShopCustomer.OrderId	
END
go


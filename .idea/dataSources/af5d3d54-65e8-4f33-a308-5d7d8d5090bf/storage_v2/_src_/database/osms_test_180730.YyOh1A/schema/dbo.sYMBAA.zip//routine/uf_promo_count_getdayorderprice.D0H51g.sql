
/*---------------------------------------------------------
[函数:
每天订单的销售金额,不包括运费
--------------------------------------------------------*/
CREATE FUNCTION [dbo].[uf_promo_count_GetDayOrderPrice]
(
	@Date		VARCHAR(8) -- 20071004
)
RETURNS DECIMAL(9,2)
AS
BEGIN
	DECLARE @d DECIMAL(9,2);

	SELECT @d = CAST(SUM(b.Quantity*b.ItemPrice*1.0/b.UnitQuantity) AS DECIMAL(18,2)) 
	FROM dbo.T_Order a INNER JOIN dbo.T_OrderItem b 
	ON a.OrderId = b.OrderId 
		AND a.OrderStatus > 0 AND a.OrderStatus < 132 AND b.[Status] < 12 -- 录入的且非取消商品
		AND CONVERT(VARCHAR(8),a.OrderDate,112) = @date;
		-- AND a.OrderType IN(1,2) 因为生成P单后原始订单金额会转移，所以应该包括P单金额在内来计算
		
	IF @d IS NULL SET @d = 0;
	
	RETURN @d;
END
go


CREATE PROCEDURE [dbo].[CMS_Business_UK_ProductStartPromotion]  
    (  
      @ProductIds VARCHAR(MAX) = NULL  
    )  
AS   
    BEGIN   
        DECLARE @ProductStr VARCHAR(MAX);  
        DECLARE @SQL VARCHAR(MAX) ;   
        SET @SQL = '';  
        SET @ProductStr = '';  
        IF @ProductIds IS NOT NULL AND @ProductIds <> ''   
            BEGIN    
                SET  @SQL = 'UPDATE  uk_product_promote  SET     is_promote = 1 WHERE   
					 product_id IN ( ' + @ProductIds + ') and type <> 3 and promote_type =0';   
       EXEC (@SQL);
        SELECT  @ProductStr = STUFF(( SELECT ','
                                                + CONVERT(VARCHAR(50),a.id) 
                                                  FROM  uk_product_promote AS a
                                                 INNER JOIN  dbo.uf_Split(@ProductIds,',') AS b ON a.product_id = b.Value
                                                    where a.type <> 3  and promote_type =0
                                     FOR XML PATH('')), 1, 1, '');          
                INSERT  INTO dbo.communication_log  
                        ( command ,  
                          object_id ,  
                          status ,  
                          create_time ,  
                          operator ,  
                          model_type ,  
                          execute_time    
						)  
                VALUES  ( 'UK_BEGIN_PROMOTE' ,  
                          @ProductStr ,  
                          1 ,  
                          GETDATE() ,  
                          0 ,  
                          'PROMOTE' ,  
                          NULL   
                        )   
            END  
        ELSE   
            BEGIN     
                UPDATE  uk_product_promote  SET     is_promote = 1  
                WHERE   is_promote = 0 and type <> 3 AND  promote_type =0;  
				if object_id('tempdb..#tempUKStartPromote') is not null Begin DROP TABLE #tempUKStartPromote End
				CREATE TABLE #tempUKStartPromote(
					id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
					pid INT null
				)
				INSERT INTO #tempUKStartPromote(pid) SELECT id FROM dbo.uk_product_promote WHERE type<>3 and promote_type =0

				DECLARE @Count INT, @Index INT
				SELECT @Count = COUNT(1) FROM #tempUKStartPromote;
				SET @Index = 0;
				 
				WHILE @Index < @Count
				BEGIN
					SELECT  @ProductStr = STUFF(( SELECT ',' + CONVERT(VARCHAR(50),pid) FROM #tempUKStartPromote WHERE id BETWEEN @Index+1 AND @Index + 2000  FOR XML PATH('')), 1, 1, '');
				                    
					--插入通讯日志   
					INSERT  INTO dbo.communication_log  
							( command ,  
							  object_id ,  
							  status ,  
							  create_time ,  
							  operator ,  
							  model_type ,  
							  execute_time    
							)  
					VALUES  ( 'UK_BEGIN_PROMOTE' ,  
							  @ProductStr ,  
							  1 ,  
							  GETDATE() ,  
							  0 ,  
							  'PROMOTE' ,  
							  NULL   
							) 
					SET @Index = @Index + 2000;
				END
    
            END  
    END
go


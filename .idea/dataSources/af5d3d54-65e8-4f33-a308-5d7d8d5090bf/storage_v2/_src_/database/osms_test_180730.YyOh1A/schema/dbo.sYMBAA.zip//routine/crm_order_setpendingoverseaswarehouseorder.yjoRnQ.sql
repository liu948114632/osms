
/**
设置订单为未决的海外仓订单
*/
CREATE PROC CRM_Order_SetPendingOverseasWarehouseOrder
(
  @OrderId VARCHAR(20)
)
AS
begin
      UPDATE T_Order SET IsOverseasWarehouseOrder = 1,
                         OverseasWarehouseStatus = 10 --未决状态
      WHERE OrderId = @OrderId
END
go


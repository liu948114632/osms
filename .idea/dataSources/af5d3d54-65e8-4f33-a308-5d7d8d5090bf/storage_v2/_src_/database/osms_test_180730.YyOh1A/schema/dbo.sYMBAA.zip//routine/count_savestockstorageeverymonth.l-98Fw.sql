-- =============================================  
-- Author:  frh  
-- Create date: <2009-09-26>  
-- Description: <每个月末的时候记录一下仓库库存>  
-- =============================================  
CREATE procEDURE [dbo].[Count_SaveStockStorageEveryMonth]  
AS  
BEGIN  
 -- 记录仓库的库存  
 INSERT INTO Count_STockStorage(department_id,ItemKeyId,Unit,Quantity,LockQty,UpdateTime,last_update_time,save_period)  
 SELECT a.department_id,a.product_id,b.unit_quantity,a.quantity - a.lock_quantity,a.lock_quantity,GETDATE(),a.update_time,ISNULL(b.guarantee_period,0)*30
 FROM dbo.storage as a with(nolock)  
 INNER JOIN dbo.product as b with(nolock) ON a.product_id = b.id  
 WHERE a.department_id  IN ( SELECT id  FROM dbo.department WHERE type = 3) AND a.quantity > 0  
   
 -- 记录行政办事处(department_id = 17)的库存 or else stock's storage  
 INSERT INTO Count_STockStorage_Administration(department_id,ItemKeyId,Unit,Quantity,LockQty,UpdateTime,last_update_time,save_period)  
 SELECT a.department_id,a.product_id,b.unit_quantity,a.quantity - a.lock_quantity,a.lock_quantity,GETDATE(),a.update_time,ISNULL(b.guarantee_period,0)*30  
 FROM dbo.department_storage as a with(nolock)  
 INNER JOIN dbo.product as b  with(nolock)  
 ON a.product_id = b.id  
 WHERE a.department_id NOT IN ( SELECT id  FROM dbo.department WHERE type = 1) AND a.quantity > 0
 
  INSERT INTO Count_STockStorage_Administration(department_id,ItemKeyId,Unit,Quantity,LockQty,UpdateTime,last_update_time,save_period)  
 SELECT a.department_id,a.product_id,b.unit_quantity,a.quantity - a.lock_quantity,a.lock_quantity,GETDATE(),a.update_time,ISNULL(b.guarantee_period,0)*30  
 FROM dbo.logistics_storage as a with(nolock)  
 INNER JOIN dbo.product as b  with(nolock)  
 ON a.product_id = b.id  
 WHERE a.department_id NOT IN ( SELECT id  FROM dbo.department WHERE type = 2) AND a.quantity > 0 
   
END
go


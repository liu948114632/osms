


/*-----------------------------------------------------------
[销售]
	某段时间按日统计客户的下单情况
--------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Sales_CustomerOrderCaseGetByDay] 
(
	@StartTime			DateTime, 
	@EndTime			DateTime
)
AS
Begin
	SET NOCOUNT ON;
	/*
	WITH cte   AS
	(
		Select 
			Convert(Varchar(8),a.OrderDate,112) As Date,
			Count(1) As Orders, -- 订单数
			Sum(a.OrderPrice + a.CashPay + a.CouponPay - b.DeliveryCost) As OrderAmount,-- 订单金额
			Sum(a.OrderPrice + a.CashPay + a.CouponPay - b.DeliveryCost)/Count(1) As AvgOrderAmount-- 平均订单金额

		From 
			T_Order a JOIN dbo.T_OrderPackages b ON a.OrderId = b.OrderId
		AND 
			a.Status > 1 And a.OrderDate > @StartTime And a.OrderDate < @EndTime
		Group By
			Convert(VARCHAR(8),a.OrderDate,112)
	)
	SELECT 
		Date,
		Orders,
		Cast(OrderAmount*0.0728 As decimal(9,2)) As OrderAmount,
		Cast(AvgOrderAmount*0.0728 As decimal(9,2)) As AvgOrderAmount,
		dbo.uf_NewCustomersGetByDay(Date) As RegCustomers,-- 注册客户数
		dbo.uf_FirstOrderCustomersGetByDay(@StartTime,Date)  As FirstOrderCustomers -- 首次下单客户数
	FROM cte ORDER BY Date
	*/
	
	WITH cte AS 
	(
		SELECT 
			Convert(VARCHAR(8),a.OrderDate,112) AS Date,
			COUNT(DISTINCT a.Orderid) AS Orders,-- 订单数
			CAST(SUM(b.Quantity*1.0*b.ItemPrice/b.UnitQuantity) AS DECIMAL(18,2)) AS  OrderAmount -- 订单金额
		FROM dbo.T_Order a 
		JOIN dbo.T_OrderItem b 
			ON a.OrderId = b.OrderId
		WHERE a.OrderType IN(1,2) -- 不包括未决订单
			AND a.OrderStatus > 0 AND a.OrderStatus < 132 -- 录单且未取消
				AND a.OrderDate > @StartTime And a.OrderDate < @EndTime
					AND b.[Status] < 12 -- 订单商品项未取消
		GROUP BY Convert(VARCHAR(8),a.OrderDate,112)
						
	)
	
	SELECT 
		Date,
		Orders,-- 订单数
		CAST(OrderAmount*0.0728  AS DECIMAL(9,2)) AS OrderAmount,
		CAST(OrderAmount*0.0728/Orders AS DECIMAL(9,2)) AS AvgOrderAmount,
		dbo.uf_Report_NewCustomersGetByDay(Date) AS RegCustomers,-- 注册客户数
		dbo.uf_Report_FirstOrderCustomersGetByDay(@StartTime,Date)  As FirstOrderCustomers -- 首次下单客户数
	FROM cte ORDER BY Date
End


go


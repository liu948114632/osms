
CREATE PROC CRM_PakcageProblem_UpdatePakcageProblemOrderCodes
(
@OrderId VARCHAR(15),
@OrderCodes VARCHAR(500)
)
AS 
BEGIN

IF EXISTS(SELECT TOP 1 1 FROM dbo.T_PackageProblem WHERE OrderId=@OrderId)
BEGIN
	UPDATE dbo.T_PackageProblem SET OrderCodes=@OrderCodes WHERE OrderId=@OrderId;
END
ELSE
BEGIN
INSERT INTO dbo.T_PackageProblem
        ( IsRead ,
          Status ,
          OrderId ,
          OrderCodes ,
          CreatorUserName ,
          DeliveryUserName ,
          CreateTime ,
          CloseTime ,
          CloseUserId ,
          ContactTimes ,
          Remark ,
          type ,
          CRMProcessResult ,
          DMSProcessResult ,
          ProblemId ,
          IsFromDMS
        )
SELECT TOP 1  IsRead ,
          Status ,
          @OrderId ,
          @OrderCodes,
          CreatorUserName ,
          DeliveryUserName ,
          CreateTime ,
          CloseTime ,
          CloseUserId ,
          ContactTimes ,
          Remark ,
          type ,
          CRMProcessResult ,
          DMSProcessResult ,
          ProblemId ,
          IsFromDMS
		  FROM
	 dbo.T_PackageProblem  a WHERE a.OrderId IN (SELECT value FROM dbo.uf_Split(@OrderCodes,','))
END

END

go


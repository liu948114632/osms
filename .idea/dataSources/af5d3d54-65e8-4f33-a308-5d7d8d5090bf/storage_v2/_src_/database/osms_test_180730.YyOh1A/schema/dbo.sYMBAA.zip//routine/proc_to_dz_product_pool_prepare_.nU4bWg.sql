/**
	@desc 刷选待入电子业务备货商品
	@date 2016-05-19
	@author whw	
*/ 
CREATE PROC proc_to_dz_product_pool_prepare_(
	@endDate DATETIME,
	@process_product_provider VARCHAR(max)=NULL, --子膜供应商
	@PageSize INT = 50 ,  --页大小              
	@PageIndex INT = 1    --当前页号   
)AS
	DECLARE  @RowCount INT , @PageCount INT , @start INT ,@end INT;  
	BEGIN
		--设置分页参数(一定要放在取记录数的后面)    
		IF ISNULL(@PageSize, 0) < 1                     
			SET @PageSize = 50                    
		SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                    
		IF ISNULL(@PageIndex, 0) < 1                     
			SET @PageIndex = 1                    
		ELSE                     
		IF ISNULL(@PageIndex, 0) > @PageCount                     
			SET @PageIndex = @PageCount                 
		SET @start = ( @PageIndex - 1 ) * @PageSize + 1                    
		SET @end = @PageIndex * @PageSize 
		;
	    WITH child_product AS (--子膜商品
	    
			SELECT p.id AS productId FROM dbo.product p WITH(NOLOCK)
			INNER JOIN  dbo.product_strategy ps WITH(NOLOCK)
			ON ps.product_id=p.id
			INNER JOIN product_provider pp WITH(NOLOCK)
			ON ps.department_id=pp.department_id AND pp.product_id = ps.product_id
			WHERE pp.provider_id IN (ISNULL(@process_product_provider,0))
			
	    ),
	    original_product AS (--原膜商品
			SELECT original_product_id AS productId FROM 
			 storage_product_processing_accessories
	    )
	    
		SELECT p.id,t.saleQuantity*1.0/3 AS saleQuantity,
		dbo.dz_product_pool_calc_original_product_preprae_qty(t.saleQuantity*0.5,NULL,p.unit_quantity) AS prepareQuantity
		INTO #product_list_sale_info FROM dbo.product p
		INNER JOIN dbo.dz_count_order_product_sale_info(@endDate,90) t 
		ON p.id=t.product_id AND t.orderNum>=3 --31天销量&&上个月订单数>=3
		INNER JOIN dbo.category c ON p.category_id_1=c.id AND c.type=2		--电子
		LEFT JOIN dbo.dz_product_pool dz ON dz.product_id=p.id				--非电子业务备货
		LEFT JOIN dbo.product_inventory i ON i.product_id=p.id				--非小批量
		LEFT JOIN dbo.product_pool pp ON pp.product_id=p.id					--非商品池
		LEFT JOIN dbo.product_ready_sell prs ON prs.product_id=p.id	
		AND prs.is_ready_sell=1												--非备货销售											
		LEFT JOIN stay_shield_product ssp ON operate_type=1 AND ssp.product_id = p.id AND ssp.status = 1
		LEFT JOIN child_product child ON child.productId=p.id
		LEFT JOIN original_product original ON original.productId = p.id
		WHERE p.offline_status=0 AND i.id IS NULL AND pp.id IS NULL
			AND prs.id IS NULL 
			AND dz.id IS NULL
			AND p.is_provider_stock<>1										--非供应商
			AND p.is_imitation_brand<>1										--非仿牌
			AND ssp.id IS NULL												--非待下架
			AND child.productId IS NULL
			AND original.productId IS NULL	
	    
		
		SELECT temp.id AS productId,temp.saleQuantity,temp.prepareQuantity FROM 
		(
			 SELECT *,ROW_NUMBER()OVER(ORDER BY product_list.id DESC) AS rowIndex  FROM #product_list_sale_info AS product_list
		 ) AS temp  WHERE rowIndex between  CONVERT(VARCHAR(10), @Start)  AND  CONVERT(VARCHAR(10), @End) 
		ORDER BY rowIndex
		
		
		EXEC sp_executesql N'SELECT @RowCount = count(id) FROM #product_list_sale_info', N'@RowCount INT OUT', @RowCount OUT     
         --获取符合条件的总记录数    
		 
		SELECT @RowCount 
	END

go


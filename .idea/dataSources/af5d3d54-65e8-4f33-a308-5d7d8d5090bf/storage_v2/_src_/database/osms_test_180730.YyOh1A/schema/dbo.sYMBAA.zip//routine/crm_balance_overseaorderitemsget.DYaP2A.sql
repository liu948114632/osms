--获取海外仓订单结算信息
CREATE PROC dbo.CRM_Balance_OverSeaOrderItemsGet         
    (        
      @OrderIds NVARCHAR(255) ,
	  @IsGoOverseasWarehouse INT = -1 --是否走海外仓： -1 不限、0 不走海外仓 1走海外仓
    )        
AS         
    DECLARE @Remark NVARCHAR(50) ;        
    BEGIN        
        
 -- 创建表变量,用来缓存各个结算的订单        
        DECLARE @Orders TABLE ( OrderId VARCHAR(20) ) ;        
        
 -- 记录订单        
        INSERT  INTO @Orders        
                ( OrderId        
                )        
                SELECT  [value]        
                FROM    dbo.uf_Split(@OrderIds, ',') ;                
    
                SELECT  a.OrderId ,        
                      (CASE WHEN o.OrderIndustryType=5 THEN  'UK-'+c.Code WHEN o.OrderIndustryType=6 THEN  'US-'+c.Code  ELSE c.Code END) AS Code,  
                        d.[Name] +  
                        (CASE WHEN b.ColorCardName IS NULL THEN '' ELSE ',color:'+ b.ColorCardName END)+  
                        (CASE WHEN b.SpecficationName IS NULL THEN '' ELSE ',size:'+ b.SpecficationName END) AS ProductName,        
                        b.Quantity AS Quantity ,        
                        ( LTRIM(b.UnitQuantity) + ' ' + b.Unit ) AS Unit ,        
                        b.UnitQuantity ,        
                        b.ItemPrice ,        
                        b.CustomerRemark ,        
                        CAST(( b.ItemPrice * b.Quantity * 1.0 / b.UnitQuantity ) AS DECIMAL(18,2)) AS Price ,        
                        b.ProductId ,  
						b.CmsProductId,
                        b.Quantity AS RequireQty , -- 订单商品需求数        
                        b.Weight ,
                        c.PrimaryPictureCode ,
                        c.ColorCardPictureCode, 
                        b.Box	
                FROM    @Orders a        
                        INNER JOIN dbo.T_OrderItem b ON a.OrderId = b.OrderId        
                        INNER JOIN dbo.T_Order o ON a.OrderId=o.OrderId
                        INNER JOIN dbo.V_CRM_Base_Product c ON b.CmsProductId = c.CmsProductId   
                        LEFT JOIN T_OrderItemProduct d ON d.OrderItemId = b.OrderItemId        
                WHERE   b.Status < 12 -- 不包括取消的商品        
				 AND (
                      @IsGoOverseasWarehouse = -1
                      OR IsGoOverseasWarehouse = @IsGoOverseasWarehouse
                    )
                  ORDER BY a.OrderId ,  b.Status,
                        c.code ;     

			 SELECT     CAST(SUM( b.ItemPrice * b.Quantity * 1.0 / b.UnitQuantity ) AS DECIMAL(18,2)) AS OrderPrice 
                FROM    @Orders a        
                 INNER JOIN dbo.T_OrderItem b ON a.OrderId = b.OrderId        
                WHERE   b.Status < 12 -- 不包括取消的商品        
				 AND (
                      @IsGoOverseasWarehouse = -1
                      OR IsGoOverseasWarehouse = @IsGoOverseasWarehouse
                    )
				
	END

go


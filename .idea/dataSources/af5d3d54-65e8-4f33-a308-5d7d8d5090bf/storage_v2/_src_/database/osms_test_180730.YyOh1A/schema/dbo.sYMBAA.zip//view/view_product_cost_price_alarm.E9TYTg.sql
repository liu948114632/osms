
CREATE VIEW view_product_cost_price_alarm       
AS       
      
SELECT a.product_id FROM dbo.purchase_item AS a       
JOIN dbo.purchase AS b ON a.purchase_id = b.id      
JOIN dbo.product AS c ON c.id = a.product_id      
JOIN dbo.product_provider AS e ON e.product_id = c.id AND e.department_id=b.department_id       
JOIN dbo.provider AS g ON g.id = e.provider_id      
WHERE a.is_deleted = 0 AND b.status >= 40 AND b.status < 160 --已完成      
AND ABS(a.purchase_price-c.cost_price)>= c.cost_price * 0.1       
AND DATEDIFF(day,b.expense_time, GETDATE()) = 0       
AND g.[level] <> 'A' AND a.discount=1    
UNION      
SELECT temp.product_id  FROM (      
      
SELECT a.id,a.processing_cost,a.product_id,      
(SELECT SUM(((CONVERT(decimal(18,2),round((item.used_quantity*(1.0))/item.process_convert_rate,(2)),0)) * p.cost_price)) FROM processing_item item      
JOIN dbo.product p ON item.product_id = p.id WHERE item.processing_id = a.id AND item.status <>4 ) /a.actual_processing_quantity AS itemCost       
FROM dbo.processing a      
JOIN dbo.product_provider c ON a.product_id = c.product_id AND c.department_id = a.department_id       
JOIN dbo.provider d ON c.provider_id = d.id AND d.level <> 'A'      
WHERE a.status >= 30 AND a.status < 60 AND a.actual_processing_quantity>0 AND DATEDIFF(day,a.completion_time, GETDATE()) = 0       
)  AS temp       
JOIN dbo.product AS e ON e.id= temp.product_id       
WHERE  ABS(temp.itemCost-e.cost_price) >= (e.cost_price * 0.1)
go


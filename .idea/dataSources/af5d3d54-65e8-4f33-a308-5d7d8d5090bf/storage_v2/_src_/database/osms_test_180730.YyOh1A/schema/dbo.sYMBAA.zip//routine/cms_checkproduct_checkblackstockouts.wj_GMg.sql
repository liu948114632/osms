
     
CREATE PROC [dbo].[CMS_CheckProduct_CheckBlackStockOuts]          
(           
  @ProductIds VARCHAR(max) = NULL --产品Id
)            
AS            
BEGIN            
    SET NOCOUNT ON ;            
               
    SELECT b.product_id AS productId,MAX(a.code) AS stockOutCode, MAX(a.department_id) AS stockOutDepartmentId
       ,MAX(a.receive_department_id) AS receiveDepartmentId,SUM(b.quantity) AS quantity,MAX(d.code) AS productCode
    FROM dbo.stock_out AS a WITH(NOLOCK) 
    INNER JOIN dbo.stock_out_item AS b WITH(NOLOCK) ON a.id = b.stock_out_id
    INNER JOIN dbo.uf_Split(@ProductIds,',') AS temp ON b.product_id = temp.value 
    INNER JOIN dbo.product AS d WITH(NOLOCK) ON d.id= b.product_id
    WHERE a.status = 2 AND a.is_received = 0 AND a.receive_department_id <> 0
    GROUP BY b.product_id,b.stock_out_id
    SET NOCOUNT OFF;            
END

go


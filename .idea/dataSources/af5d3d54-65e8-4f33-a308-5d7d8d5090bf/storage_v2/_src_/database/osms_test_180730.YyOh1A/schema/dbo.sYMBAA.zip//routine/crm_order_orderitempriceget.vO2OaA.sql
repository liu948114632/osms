

-- =============================================
-- Author:		HYD
-- Create date: 2010-05-31
-- Description:	获取订单商品的SalePrice，ItemPrice
-- Version：CRM 5.1.0.0
-- =============================================
CREATE PROCEDURE [dbo].[CRM_Order_OrderItemPriceGet]
(
	@OrderItemId INT,
	@SalePrice DECIMAL(9,2) OUT,
	@ItemPrice DECIMAL(9,2) OUT
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SET @SalePrice = 0;
	SET @ItemPrice = 0;
	
	SELECT @SalePrice = SalePrice,@ItemPrice = ItemPrice
		 FROM dbo.T_OrderItem WHERE OrderItemId = @OrderItemId
END

go


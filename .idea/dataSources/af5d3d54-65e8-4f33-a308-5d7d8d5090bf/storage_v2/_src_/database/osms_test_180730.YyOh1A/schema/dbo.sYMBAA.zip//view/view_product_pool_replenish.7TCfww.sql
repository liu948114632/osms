
--商品池补货
CREATE VIEW dbo.view_product_pool_replenish       
AS      
SELECT id,product_id,prepare_quantity       
FROM 
(      
	SELECT a.* ,ISNULL(b.quantity,0) AS storage_count	
	FROM dbo.product_pool AS a   
	LEFT JOIN view_product_generalized_storage b ON a.product_id=b.product_id    
	WHERE NOT EXISTS 
	(
		SELECT pmt.id FROM   dbo.view_all_purchasing_management_task AS pmt 
		WHERE  pmt.[type]=3 AND  pmt.sub_type  IN (10,3,7,4,5)    
		AND (pmt.[status]<6 OR (pmt.[status]=6 AND DATEDIFF(DAY,pmt.completion_time,GETDATE()) <= 1) )         
		AND pmt.product_id = a.product_id          
	)      
	AND NOT EXISTS( SELECT TOP 1 id FROM dbo.stay_shield_product WITH(NOLOCK) 
			        WHERE product_id=a.product_id AND status=1 AND shield_type=1) 
) AS temp 
WHERE  temp.storage_count  < (temp.prepare_quantity * (CONVERT(DECIMAL(18,2),temp.plan_day/30.0)))
go


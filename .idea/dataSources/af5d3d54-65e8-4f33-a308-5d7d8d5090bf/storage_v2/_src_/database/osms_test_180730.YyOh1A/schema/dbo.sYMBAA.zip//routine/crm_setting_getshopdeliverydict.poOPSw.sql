

CREATE PROC CRM_Setting_GetShopDeliveryDict
(
	@BusinessType INT,
	@ShopDeliveryName VARCHAR(100) = NULL
)
AS
BEGIN

	SELECT * FROM T_ShopDeliveryDict 
	WHERE BusinessType=@BusinessType 
	AND (@ShopDeliveryName IS NULL OR ShopDeliveryName=@ShopDeliveryName)
END
go


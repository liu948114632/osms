CREATE PROCEDURE CMS_BussinessJL_CategoryProductList(            
 @CategoryId1 INT = NULL,-- 一级类别            
 @CategoryId2 INT = NULL,-- 二级类别            
 @CategoryId3 INT = NULL,-- 三级类别            
 @SeriesId INT = NULL, --系列            
 @PropertyValueId1 INT = NULL,--第一个属性值            
 @PropertyValueId2 INT = NULL,--第二个属性值            
 @PropertyValueId3 INT = NULL,--第三个属性值            
 @IsOnShelf INT = NULL, --是否上架             
 @IsDisplay INT = NULL,--是否显示                       
 @ProductCode VARCHAR(22) = NULL, --产品编号
 @ProductCodes VARCHAR(MAX) = NULL, --产品编号               
 @ProductName VARCHAR(MAX) = NULL, --产品名称 
 @RefName VARCHAR(50) = NULL,--关系集名称
 @PageSize INT = 50 ,  --页大小                          
 @PageIndex INT = 1    --当前页号               
)            
AS          
BEGIN            
 SET NOCOUNT ON;            
 DECLARE            
  @SQL VARCHAR(max),                          
        @CountSql NVARCHAR(MAX), --查询数量用                          
        @FromSQL NVARCHAR(max), --查询内表                        
        @Column NVARCHAR(max), --取的字段                        
        @Condition varchar(MAX), --条件                           
        @RowCount INT ,             
        @PageCount INT ,             
        @start INT ,            
        @end INT,            
        @IsQueryProperty BIT;            
 --设置查询主表            
 SET @FromSQL = ' FROM jl_product JL WITH(NOLOCK) INNER JOIN product P WITH(NOLOCK) ON JL.product_id = P.id ';                
 --设置查询条件            
 SET @Condition = ' WHERE 1=1 ';            
 IF @CategoryId1 IS NOT NULL            
 BEGIN            
  SET @Condition = @Condition + ' AND P.category_id_1=' + CONVERT(VARCHAR(10), @CategoryId1)            
 END            
 IF @CategoryId2 IS NOT NULL             
 BEGIN            
  SET @Condition = @Condition + ' AND P.category_id_2=' + CONVERT(VARCHAR(10), @CategoryId2)            
 END            
 IF @CategoryId3 IS NOT NULL            
 BEGIN            
  SET @Condition = @Condition + ' AND P.category_id_3=' + CONVERT(VARCHAR(10), @CategoryId3)            
 END
             
 DECLARE @TempSQL NVARCHAR(MAX);            
 SET @TempSQL = '';            
             
 IF @PropertyValueId1 IS NOT NULL            
 BEGIN            
  IF @IsQueryProperty = 1            
  BEGIN            
   SET @TempSQL = @TempSQL + ',';            
  END            
  SET @IsQueryProperty = 1;            
  SET @TempSQL = @TempSQL + CONVERT(VARCHAR(10), @PropertyValueId1);             
 END            
 IF @PropertyValueId2 IS NOT NULL            
 BEGIN            
  IF @IsQueryProperty = 1            
  BEGIN            
   SET @TempSQL = @TempSQL + ',';            
  END            
  SET @IsQueryProperty = 1;            
  SET @TempSQL = @TempSQL + CONVERT(VARCHAR(10), @PropertyValueId2);              
 END            
 IF @PropertyValueId3 IS NOT NULL            
 BEGIN            
  IF @IsQueryProperty = 1            
  BEGIN            
   SET @TempSQL = @TempSQL + ',';            
  END            
  SET @IsQueryProperty = 1;            
  SET @TempSQL = @TempSQL + CONVERT(VARCHAR(10), @PropertyValueId3);             
 END            
 IF @IsQueryProperty = 1            
 BEGIN            
  SET @Condition = @Condition + ' AND EXISTS(SELECT PP.id FROM dbo.product_property_value PP WITH(NOLOCK)'            
        + ' WHERE PP.product_id=JL.product_id AND PP.property_id IN (' + @TempSQL + '))';            
  SET @TempSQL = '';            
 END            
           
 IF @SeriesId is not null            
 BEGIN            
  set @Condition = @Condition + ' AND JL.category_series_id=' + convert(varchar(10), @SeriesId);            
 END             
             
 IF @IsOnShelf is not null            
 BEGIN            
  SET @Condition = @Condition + ' AND JL.is_on_shelf=' + convert(varchar(10), @IsOnShelf);            
 END            
             
 IF @IsDisplay IS NOT NULL            
 BEGIN            
  SET @Condition = @Condition + ' AND P.is_display_jl =' + CONVERT(VARCHAR(10), @IsDisplay);            
 END            
             
 IF @ProductCode IS NOT NULL            
 BEGIN            
  SET @Condition = @Condition + ' AND P.code like ''' + @ProductCode + '%''';            
 END 
 IF @ProductCodes IS NOT NULL
	BEGIN
		SET @Condition = @Condition + ' AND P.code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')'   
	END           
 IF @ProductName IS NOT NULL             
 BEGIN            
  SET @Condition = @Condition + ' AND P.name like ''%' + @ProductName + '%''';            
 END             
 IF @RefName IS NOT NULL             
 BEGIN            
  SET @Condition = @Condition + ' AND EXISTS(SELECT R.id FROM dbo.jl_ref_set ST
INNER JOIN dbo.jl_product_ref_set R ON st.id=r.jl_ref_set_id AND JL.id=R.jl_product_id WHERE ST.name LIKE ''%' + @RefName + '%'')';            
 END              
             
 --设置查询列            
 SET @Column = 'PD.id,            
       PD.product_id productId,            
       PD.is_on_shelf isOnShelf,    
       PD.order_count orderCount,            
       PD.browse_count browseCount,            
       PD.publish_time publishTime,            
       PD.publish_user_id publishUserId,            
       PD.current_cost_price currentCostPrice,            
       PD.reference_cost_price referenceCostPrice,            
       PD.category_series_id categorySeriesId,            
       PD.first_profit_coefficient firstProfitCoefficient,            
       PD.second_profit_coefficient secondProfitCoefficient,            
       PD.third_profit_coefficient thirdProfitCoefficient,            
       PD.first_quantity_from firstQuantityFrom,            
       PD.first_quantity_to firstQuantityTo,            
       PD.second_quantity_from secondQuantityFrom,            
       PD.second_quantity_to secondQuantityFrom,            
       PD.third_quantity_from thirdQuantityFrom,            
       PD.third_quantity_to thirdQuantityTo,          
       P.code productCode,
       P.unit_quantity unitQuantity,
       PD.retail_profit_coefficient retailProfitCoefficient,
       p.unit
       ';            
                   
 --查询记录数            
 SET @CountSQL = '';            
 SET @CountSQL = 'SELECT @RowCountOUT=count(JL.id) ' + @FromSQL + @Condition;            
 --print @CountSQL;            
 EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;       
          
 --查询的分页条件            
 IF ISNULL(@PageSize, 0) < 1                                   
  SET @PageSize = 50                                  
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                  
    IF ISNULL(@PageIndex, 0) < 1                                   
        SET @PageIndex = 1                                  
    ELSE                                   
    IF ISNULL(@PageIndex, 0) > @PageCount                                   
        SET @PageIndex = @PageCount                                  
    SET @Start = ( @PageIndex - 1 ) * @PageSize + 1                                  
    SET @End = @PageIndex * @PageSize                    
 --组装查询语句            
  SET @SQL = 'SELECT JL.id, ROW_NUMBER() OVER (ORDER BY JL.id desc) RowIndex ' + @FromSQL + @Condition;            
             
  SET @SQL = 'SELECT  ' + @Column + ' FROM (' + @SQL + ') temp INNER JOIN JL_product PD WITH(NOLOCK) on PD.id=temp.id '          
     + 'INNER JOIN product P WITH(NOLOCK) ON PD.product_id = P.id '                   
     + 'WHERE RowIndex between ' + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';            
 --PRINT @SQL            
 EXEC(@SQL);                                    
 select @RowCount                      
END
go



CREATE PROC CRM_Order_AddPackageProblemDetail
(
@ProblemId INT=0,
@CreatorUserName  VARCHAR(20),
@Content NVARCHAR(500),
@OrderCodes VARCHAR(200),
@CreateTime VARCHAR(20),
@Id INT OUT
)
AS
BEGIN

INSERT INTO dbo.T_PackageProblemDetail
        ( 
	 ProblemId,
	CreatorUserName ,
          Content ,
          CreateDate ,
          OrderCodes
        )
VALUES  (
	 @ProblemId,
	   	@CreatorUserName , -- CreatorId - int
          @Content , -- Content - nvarchar(500)
          @CreateTime , -- CreateDate - smalldatetime
          @OrderCodes  -- OrderCodes - varchar(200)
        )

        SET @Id=@@IDENTITY;
END

go


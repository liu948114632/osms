

--退出商品池
CREATE VIEW [dbo].[view_product_pool_exit] AS 
WITH cte_product_pool AS 
(
   SELECT a.product_id,
          a.is_forever_exit AS is_forever_exit, --毛坯商品按6个月的原则退出
          DATEDIFF(d,a.create_time,GETDATE()) AS join_days,--加入商品池天数
          a.factory_quantity,
          b.is_roughcast
   FROM dbo.product_pool a WITH(NOLOCK)
   JOIN dbo.product b WITH(NOLOCK) ON a.product_id=b.id
)
--统计商品池商品前180天内的销量(不统计PW订单和取消的订单)
,cte_product_180days_sale_quantity AS  
(    
   SELECT b.product_id,
          b.total_real_quantity AS sale_quantity   --前180天的销量 
   FROM product_pool a WITH(NOLOCK)
   join dbo.uf_product_sale_info(GETDATE() - 180 ,GETDATE(),1,0,0) b ON a.product_id = b.product_id 
)

--获得需要退出的商品
--增加下架商品退出商品池条件 v 3.4.2
SELECT a.product_id
FROM cte_product_pool a
JOIN dbo.product AS b WITH(NOLOCK) ON a.product_id = b.id  
LEFT JOIN cte_product_180days_sale_quantity c ON a.product_id = c.product_id
WHERE (b.is_display_ph = 0 AND b.is_roughcast = 0)  --非毛坯商品如PH已屏蔽，则退出商品池
   OR b.offline_status = 2
   OR ( (join_days >= 180) --进入商品池后至少180天
          AND 
         (ISNULL(c.sale_quantity,0) < (ISNULL(b.unit_quantity,0) * 3)) --前180天总销量＜ 3 × 当前批量  
         AND a.is_forever_exit = 0 AND  NOT EXISTS ( SELECT psq.id  FROM product_small_quantities psq JOIN product p ON psq.product_id = p.id WHERE
          p.offline_status <>2  AND  psq.original_product_id=b.id   ) 
       )
      OR (b.is_provider_stock =1 and a.is_forever_exit = 0 )-- 供应商库存商品自动退出
      OR (EXISTS (SELECT TOP 1 *  FROM  dbo.product_inventory inv WHERE inv.product_id = a.product_id  ) AND a.is_forever_exit = 0) -- 备货商品自动退出
union 
select a.product_id
from product_ready_sell a
WHERE is_ready_sell= 1

go


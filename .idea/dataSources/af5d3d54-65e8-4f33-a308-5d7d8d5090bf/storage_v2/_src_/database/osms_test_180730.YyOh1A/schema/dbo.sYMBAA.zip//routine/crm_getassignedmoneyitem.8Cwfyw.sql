
-- =============================================      
--update Author:  <ll>      
-- Create date: <2014-09-11>      
-- Description: <获取待分配资金>      
-- =============================================      
CREATE PROCEDURE [dbo].[CRM_GetAssignedMoneyItem] ( @AssignId INT )
AS
    BEGIN      
        SET NOCOUNT ON                          
        DECLARE @count INT;--查询表中数据
        DECLARE @number INT;--循环条件
        DECLARE @OrderId VARCHAR(20);---表ID
        DECLARE @Price DECIMAL(18, 2);
        DECLARE @ReadyPrice DECIMAL(18, 2);
        DECLARE @Freight DECIMAL(18, 2);                                    
        DECLARE @Pay DECIMAL(18, 2);
        DECLARE @Surchage DECIMAL(18, 2);
        SET @count = (
                       SELECT   COUNT(1)
                       FROM     T_AssignedMoneyItem
                       WHERE    AssignId = @AssignId
                     );
        IF (
             @count IS NOT NULL
             AND @count <> 0
           )----如果表中有数据才可以进行循环
            BEGIN
                SET @number = 0;
                CREATE TABLE #SurchageT
                    (
                      SurchargeId INT ,
                      CategoryId INT ,
                      orderId VARCHAR(20) ,
                      remark VARCHAR(20) ,
                      surchage DECIMAL(18, 2) ,
                      CategoryName VARCHAR(20)
                    )
                WHILE @number < @count
                    BEGIN
                        SELECT  @number = @number + 1;----每循环一次循环条件+1
---将表按照循序进行排序，然后每次查询排序字段
                        SELECT  @OrderId = hh.OrderId
                        FROM    (
                                  SELECT    ROW_NUMBER() OVER ( ORDER BY OrderId ) AS Rowindex ,
                                            *
                                  FROM      T_AssignedMoneyItem
                                  WHERE     AssignId = @AssignId
                                ) hh
                        WHERE   hh.Rowindex = @number;
                        BEGIN


                            DECLARE @DuePay DECIMAL(18, 2) , --应付款
											  @RealPay DECIMAL(18, 2) --实付款    
                            EXEC dbo.[CRM_Order_OrderPaymentInfoGet] @OrderId,  @DuePay = @DuePay OUT, @RealPay = @RealPay OUT 

                            UPDATE T_AssignedMoneyItem
                            SET		DueMoney = @DuePay ,
									ActualMoney = @RealPay
                            WHERE   OrderId = @OrderId
                        END
                    END
                IF OBJECT_ID('tempdb..#SurchageT') IS NOT NULL
                    BEGIN
                        DROP TABLE #SurchageT
                    END
            END
        SELECT  *
        FROM    T_AssignedMoneyItem
        WHERE   AssignId = @AssignId
    END
go


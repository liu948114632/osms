CREATE PROC CRM_Customer_SetCustomerSuspicionMarking
(
@customerId INT,
@suspicionMarking INT,
@operatorName VARCHAR(20)
)
AS 
BEGIN

DECLARE @remark VARCHAR(50)=''

IF @suspicionMarking=1
SET @remark='设置为嫌疑客户'
ELSE
SET @remark='设置为正常客户'

IF NOT  EXISTS (SELECT TOP 1 1  FROM dbo.T_Customer WHERE UserID=@customerId AND suspicionMarking=@suspicionMarking)
BEGIN
		UPDATE dbo.T_Customer SET suspicionMarking=@suspicionMarking WHERE UserID=@customerId

	EXEC dbo.CRM_Customer_LostCustomerHistoryAdd @CustomerId =@customerId, -- int
	    @Content =@remark,
	    @User =@operatorName -- nvarchar(50)
END
END

go


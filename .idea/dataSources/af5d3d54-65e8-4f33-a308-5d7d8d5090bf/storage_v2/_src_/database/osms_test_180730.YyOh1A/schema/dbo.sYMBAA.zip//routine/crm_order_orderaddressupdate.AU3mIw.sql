


/*--------------------------------------------------
[备注]保存订单地址
----------------------------------------------------
--------------------------------------------------
修改人：LY
修改时间：2010-11-18
修改内容：如果货运地址修改导致国家不是巴西了，那就把税号清空
--------------------------------------------------
修改人：LY
修改时间：2011-1-4
修改内容：订单货运方式是Port to port时， 如果修改货运地址， port的信息保持不变，目前是自动清空掉了
--------------------------------------------------
修改人：LY
修改时间：2011-3-22
修改内容：CRM6.2.0新增公司名称
------------------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_OrderAddressUpdate]
    (
      @AddressId INT ,
      @OrderId NVARCHAR(20) ,
      @Firstname NVARCHAR(50) ,
      @Lastname NVARCHAR(50) ,
      @Address1 NVARCHAR(200) ,
      @Address2 NVARCHAR(200) ,
      @City NVARCHAR(100) ,
      @State NVARCHAR(100) ,
      @Country INT ,
      @Zip NVARCHAR(50) ,
      @Phone NVARCHAR(50) ,
      @Fax NVARCHAR(50) ,
      @IsRemote BIT ,
      @CompanyName NVARCHAR(100)
    )
AS 
    BEGIN
        UPDATE  T_OrderAddresses
        SET     Firstname = @Firstname ,
                Lastname = @Lastname ,
                Address1 = @Address1 ,
                Address2 = @Address2 ,
                City = @City ,
                [State] = @State ,
                Country = @Country ,
                Zip = @Zip ,
                Phone = @Phone ,
                Fax = @Fax ,
                CompanyName = @CompanyName
        WHERE   AddressId = @AddressId ;

	-- 修改偏远地区标志
        UPDATE  dbo.T_Order
        SET     IsRemote = @IsRemote
        WHERE   OrderId = @OrderId ;
		
--	-- 更新备货系统订单对应的国家
--        UPDATE  dbo.C_Order
--        SET     CountryId = @Country
--        WHERE   OrderId = @OrderId
--                AND ( CountryId < @Country
--                      OR CountryId > @Country
--                    ) ;
	
	--如果货运地址修改导致国家不是巴西了，那就把税号清空
--        IF @Country <> 13 
--            BEGIN
--                UPDATE  dbo.T_Order
--                SET     CPFCode = ''
--                WHERE   OrderId = @OrderId ;
--            END
    END
go


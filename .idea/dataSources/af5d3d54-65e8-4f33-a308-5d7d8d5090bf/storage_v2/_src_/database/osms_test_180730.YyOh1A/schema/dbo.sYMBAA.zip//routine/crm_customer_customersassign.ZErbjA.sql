/********************************************************    
描述：分配客户给新跟单员     
    
创建人：  YL    
创建时间：2009-08-15    
修改版本：V3.1    
修改内容：分配客户给新跟单员    
    
修改人：HYD    
修改版本：    
修改时间：2010-04-27    
修改内容：增加更新CMS中的订单跟单员    
    
********************************************************/    
CREATE PROC dbo.CRM_Customer_CustomersAssign     
(    
 @OldHandlerId  INT,    
 @NewHandlerId  INT,    
 @Qty    INT,    
 @UserId    INT,
 @BusinessType INT
)    
AS    
BEGIN     
 DECLARE @OldName    NVARCHAR(50)    
 DECLARE @NewName    NVARCHAR(50)    
 DECLARE @UserName   NVARCHAR(50)    
 DECLARE @Remark     NVARCHAR(100)   
 --DECLARE @OldBusinessType TINYINT    
 --DECLARE @NewBusinessType TINYINT  
 DECLARE @OldLangType TINYINT    
 DECLARE @NewLangType TINYINT  
   
   
 --判断两个处理人的业务类型是否相同  
 --SELECT @OldBusinessType = BusinessType FROM dbo.T_Handler WHERE HandlerId = @OldHandlerId  
 SELECT @OldLangType = dbo.T_HandlerLang.Lang FROM dbo.T_HandlerLang WHERE dbo.T_HandlerLang.HandlerId= @OldHandlerId
 --SELECT @NewBusinessType = BusinessType FROM dbo.T_Handler WHERE HandlerId = @NewHandlerId  
 SELECT @NewLangType = dbo.T_HandlerLang.Lang FROM dbo.T_HandlerLang WHERE dbo.T_HandlerLang.HandlerId= @NewHandlerId
   
 --IF @OldBusinessType <> @NewBusinessType  
 --BEGIN  
 --  RAISERROR('<info>处理人的业务类型不一致。</info>',16,1) WITH NOWAIT;  
 --  RETURN  
 --END    
 
 IF @OldLangType <> @NewLangType  
 BEGIN  
   RAISERROR('<info>处理人的操作语种不一致。</info>',16,1) WITH NOWAIT;  
   RETURN  
 END 
     
 CREATE  TABLE #CustomerIdTable   
 (    
  TempId  INT IDENTITY(1,1),    
  CustomerId INT     
 )    
     
 CREATE  TABLE #TempTable      
 (    
  TempId  INT IDENTITY(1,1),    
  CustomerId  INT,    
  OrderId  VARCHAR(50) COLLATE Chinese_PRC_CI_AS NULL,    
  HandlerId INT     
 )    
     
 SELECT @OldName = [name] FROM dbo.[user] WHERE Id = @OldHandlerId    
 SELECT @NewName = [name] FROM dbo.[user] WHERE Id = @NewHandlerId    
 SELECT @UserName = [name] FROM dbo.[user] WHERE Id = @UserId    
   
 SET @Remark = @UserName + '分配客户后跟单员由'+ @OldName + '更改为' + @NewName     
     
 -- 随机从原跟单员负责的客户中，选取指定数量的客户    
 INSERT INTO #CustomerIdTable (CustomerId)    
 SELECT CustomerId FROM    
 (      
  SELECT TOP (@Qty) CustomerId FROM dbo.T_CustomerHandler 
  WHERE T_CustomerHandler.HandlerId = @OldHandlerId 
  AND BusinessType=@BusinessType
  ORDER BY NEWID()    
 )    
 AS a    
     
 -- 获取这些客户在系统中所有完成状态之前的订单    
 INSERT INTO #TempTable (CustomerId,OrderId,HandlerId)    
 SELECT CustomerId,OrderId,HandlerId    
 FROM      
 (    
  SELECT CustomerId,OrderId,HandlerId     
  FROM dbo.T_Order     
  WHERE CustomerId IN (SELECT CustomerId FROM #CustomerIdTable) AND [OrderStatus] < 128 AND OrderIndustryType = @BusinessType   
 )     
 AS b    
     
 -- 更新跟单员设置表    
 UPDATE dbo.T_CustomerHandler SET HandlerId = @NewHandlerId 
 WHERE CustomerId IN (SELECT CustomerId FROM #CustomerIdTable) 
 AND HandlerId = @OldHandlerId 
 AND BusinessType=@BusinessType
   
 --批量更新客户已完成状态之前的订单中的跟单员为新跟单员    
 UPDATE dbo.T_Order Set HandlerId = @NewHandlerId   
 WHERE OrderId IN (SELECT OrderId FROM #TempTable)   
   
 -- 更新订单跟单员后记录订单日志   
 INSERT INTO dbo.order_history  
         ( operator_id ,  
           operator_time ,  
           process ,  
           order_code  
         )  
SELECT  @UserId , -- operator_id - int  
     GETDATE() , -- operator_time - smalldatetime  
     @Remark , -- process - varchar(5000)  
     OrderId  -- order_code - char(50)  
FROM #TempTable  

    IF(@NewHandlerId<>@OldHandlerId)
			BEGIN
			--跟单员变更日志
			INSERT INTO dbo.T_HandlerChangeLog
					( OldHandlerId ,
					  NewHandlerId ,
					  CreateDate ,
					  Reason ,
					  BusinessType,
					  CustomerId,
					  OperatorId
					)
			SELECT  @OldHandlerId , -- OldHandlerId - int
					  @NewHandlerId , -- NewHandlerId - int
					  GETDATE() , -- CreateDate - datetime
					  N'新老跟单员调整' , -- Reason - nvarchar(100)
					  @BusinessType, -- BusinessType - tinyint
					  CustomerId,
					  @UserId
					FROM #CustomerIdTable
			END
 
     
 -- 返回分配后的订单对应的跟单员    
 SELECT OrderId,@NewHandlerId AS handlerId FROM #TempTable   
 -- 返回分配过的客户列表，用于发送邮件     
 SELECT * FROM #CustomerIdTable     
   
 DROP TABLE #TempTable  
 DROP TABLE #CustomerIdTable  
END
go



CREATE PROC CRM_Order_PackageProblem_GetDMSUsers
AS
BEGIN
	SELECT  a.CreatorUserName,ROW_NUMBER() OVER(ORDER BY a.CreatorUserName) AS RowIndex  FROM dbo.T_PackageProblem a
	GROUP BY a.CreatorUserName

	
		SELECT  a.DeliveryUserName,ROW_NUMBER() OVER(ORDER BY a.DeliveryUserName) AS RowIndex   FROM dbo.T_PackageProblem a
	GROUP BY a.DeliveryUserName
END

go


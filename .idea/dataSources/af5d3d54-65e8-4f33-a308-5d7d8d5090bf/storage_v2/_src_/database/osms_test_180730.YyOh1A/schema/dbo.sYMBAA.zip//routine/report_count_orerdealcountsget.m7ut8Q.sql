/*----------------------------------------- 
[描述]
	报表统计，每月目标订单数(统计订单完货率情况)
------------------------------------------------*/
create  PROCEDURE [dbo].[Report_Count_OrerDealCountsGet]
(
	@Start	DATETIME,
	@End	DATETIME,
	@Price1 DECIMAL(18,2),
	@Price2 DECIMAL(18,2),
	@Orders	INT OUT
)
AS
BEGIN
	SET @Orders = 0;
	
	WITH cte AS -- 统计该月订单金额
	(
		SELECT  a.OrderId,
			CAST(SUM(b.Quantity*1.0*b.ItemPrice/b.UnitQuantity) AS DECIMAL(9,2)) AS Price
		FROM dbo.T_Order
		a JOIN dbo.T_OrderItem b 
		ON a.OrderId = b.OrderId
		AND a.OrderStatus > 0 
		AND a.OrderStatus < 132
		AND a.OrderDate > @Start
		AND a.OrderDate < @End
		AND b.[Status] < 12
		GROUP BY a.OrderId
	),cteOrders  AS -- 锁定价格区的订单
	(
		SELECT OrderId
		FROM cte 
		WHERE Price > @Price1 AND Price <= @Price2
	),cteOrderItems AS -- 锁定这个价格区的订单商品
	(
		SELECT a.OrderItemDataId,b.OrderId
		FROM dbo.C_OrderItem a
		JOIN cteOrders b 
		ON a.OrderId = b.OrderId AND a.Status < 12
	),cteOrderItemsStart AS -- 目标订单第一次备货时间
	(
		SELECT c.OrderId,MIN(a.AssignTime) AS FirstReadyTime
		FROM dbo.C_Assignment a
		JOIN dbo.C_AssignmentItem b
		ON a.AssignmentId = b.AssignmentId
		AND a.[Status] > 1
		JOIN cteOrderItems c
		ON b.OrderItemDataId = c.OrderItemDataId
		GROUP BY c.OrderId
	),cteOrderCounts AS -- 订单个数
	(
		SELECT COUNT(*) AS OrderCounts
		FROM cteOrderItemsStart
	)

	SELECT @Orders = OrderCounts  FROM cteOrderCounts;
END
go


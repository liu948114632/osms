  
CREATE PROC dbo.CMS_Compute_ProviderStorageBuying_Price  
    (  
      @productCode VARCHAR(MAX) = NULL , --一产品编号   
      @productCodes VARCHAR(MAX) = NULL ,--多产品编号    
      @providerCode VARCHAR(MAX) = NULL ,--供应商编号  
      @factoryCode VARCHAR(MAX) = NULL , --厂家编号  
      @factoryCodes VARCHAR(MAX) = NULL , --厂家编号  
      @providerId INT = NULL , -- 供应商id  
      @orderIndex INT = NULL , --可选的排序方式  
      @isNeedReplenishment INT = NULL ,  
      @replenishmentStatus INT = NULL ,  
      @AvailableStockCompareMode VARCHAR(2) = NULL , --v3.9.0 add 比较有效库存时的模式：1、=,2、>3、<，4、>=,5、<=,6、!=      
      @AvailableStock INT = NULL , -- v3.9.0 add 有效库存量  
   @buyingStockCompareMode VARCHAR(2) = NULL ,    
      @buyingStock INT = NULL ,   
      @StockMoneyMatchPattern VARCHAR(2) = NULL , --v3.9.30 比较库存总金额的模式  
      @StockMoney Decimal(18,6)= NULL,     -- V3.9.30 库存总金额  
      @ProductFeedbackToProvider VARCHAR(MAX) =NULL, --V3.9.30 给供应商留言  
      @ProductProviderFeedback VARCHAR(MAX) =NULL, --V3.9.30 给我们留言  
      @IsDullSale INT = NULL ,--是否滞销品  
      @omsDataSource INT = NULL , --OMS数据源  
      @ISHot INT = NULL ,--是否畅销品  
      @NoProviderCode VARCHAR(MAX) = NULL ,  
   @isDisplayPH INT=NULL,  
   @isDisplayPW INT =NULL,  
      @isFullBuy INT = NULL,  
       @PageSize INT = 50 ,  --页大小                
  @PageIndex INT = 1    --当前页号          
    )  
AS  
    BEGIN            
        SET NOCOUNT ON;            
        DECLARE @SQL NVARCHAR(MAX) ,  
            @tempSQL NVARCHAR(MAX) ,  
            @FromSQL NVARCHAR(MAX) ,  
            @FromSQL2 NVARCHAR(MAX) ,  
            @Column NVARCHAR(MAX) ,  
            @Condition NVARCHAR(MAX) ,  
            @CountSQL NVARCHAR(MAX) ,  
            @OrderCondition NVARCHAR(MAX) ,  
            @IsQueryProvider BIT ,  
            @RowCount INT ,  
            @PageCount INT ,  
            @start INT ,  
            @end INT;         
 --组装查询条件       
        SET @Condition = ' WHERE P.is_provider_stock=1 and P.status = 4 and is_delete = 0 ';        
        IF @productCode IS NOT NULL  
            BEGIN        
                SET @Condition = @Condition + ' AND P.code like ''%'  
                    + @productCode + '%''';        
            END;  
       IF @IsDullSale IS NOT NULL
            BEGIN
				IF @IsDullSale>2
				BEGIN
				    SET @Condition = @Condition + ' and PSP.is_dull_sale <>0 '
				END
				ELSE 
				BEGIN
				    SET @Condition = @Condition + ' and PSP.is_dull_sale='
                    + CONVERT(VARCHAR(10), @IsDullSale);
				END
                
            END; 
     IF @AvailableStock IS NOT NULL  
            AND @AvailableStockCompareMode IS NOT NULL  
            BEGIN         
                IF ( @AvailableStockCompareMode = '!=' )  
                    BEGIN      
                        SET @Condition = @Condition  
                            + ' AND isnull(v1.quantity,0) > isnull(v1.lock_quantity,0) + '  
                            + CONVERT(VARCHAR(10), @AvailableStock);        
                        SET @Condition = @Condition  
                            + ' AND isnull(v1.quantity,0) < isnull(v1.lock_quantity,0) + '  
                            + CONVERT(VARCHAR(10), @AvailableStock);        
                    END;       
                ELSE  
                    BEGIN      
                        SET @Condition = @Condition  
                            + ' AND isnull(v1.quantity,0) '  
                            + @AvailableStockCompareMode  
                            + ' isnull(v1.lock_quantity,0) + '  
                            + CONVERT(VARCHAR(10), @AvailableStock);  
                    END;       
            END;    
  IF @buyingStock IS NOT NULL  
            AND @buyingStockCompareMode IS NOT NULL  
            BEGIN         
                IF ( @buyingStockCompareMode = '!=' )  
                    BEGIN      
                        SET @Condition = @Condition  
                            + ' AND isnull(PSP.buying_quantity,0) <> '  
                            + CONVERT(VARCHAR(10), @buyingStock);      
                    END;       
                ELSE  
                    BEGIN      
                        SET @Condition = @Condition  
                            + ' AND isnull(PSP.buying_quantity,0) '  
                            + @buyingStockCompareMode  
                            + CONVERT(VARCHAR(10), @buyingStock);  
                    END;       
            END;  
     ------------------------------------------  
      IF @StockMoney IS NOT NULL AND @StockMoneyMatchPattern IS NOT NULL  
         BEGIN  
   IF ( @StockMoneyMatchPattern = '!=' )  
                    BEGIN      
                        SET @Condition = @Condition  
                            + ' AND (isnull(v.quantity,0) -isnull(PSP.buying_quantity,0))*P.cost_price > '  
                            + CONVERT(VARCHAR(10), @StockMoney);        
                        SET @Condition = @Condition  
                            + 'AND (isnull(v.quantity,0) -isnull(PSP.buying_quantity,0))*P.cost_price < '  
                            + CONVERT(VARCHAR(10), @StockMoney);        
                    END;       
                ELSE  
                    BEGIN      
                        SET @Condition = @Condition  
                            + 'AND (isnull(v.quantity,0) -isnull(PSP.buying_quantity,0))*P.cost_price '  
                            + @StockMoneyMatchPattern  
                            + CONVERT(VARCHAR(10), @StockMoney);  
                    END;   
         END     
       
     -----------------------------------------         
              
     IF @ProductFeedbackToProvider IS NOT NULL  
  BEGIN  
   SET  @Condition = @Condition + ' AND PSP.product_feedback_to_provider like ''%'  
                    + @ProductFeedbackToProvider + '%''';    
  END    
    
 IF @ProductProviderFeedback IS NOT NULL  
  BEGIN  
   SET  @Condition = @Condition + ' AND PSP.product_provider_feedback like ''%'  
                    + @ProductProviderFeedback + '%''';    
  END         
                
    ------------------------------------------  
      
              
        IF @productCodes IS NOT NULL  
            BEGIN        
                SET @Condition = @Condition + ' AND P.code in ('''  
                    + REPLACE(@productCodes, ',', ''',''')  
                    + ''') and P.code is  not  null';        
            END;    
   
        IF @providerCode IS NOT NULL  
            BEGIN  
                SET @Condition = @Condition + ' AND PR.code like ''%'  
                    + @providerCode + '%''';        
            END;      
        IF @NoProviderCode IS NOT NULL  
            BEGIN  
                SET @Condition = @Condition + ' AND PR.code not like ''%'  
                    + @providerCode + '%''';      
            END;   
        IF @isFullBuy IS NOT NULL  
            BEGIN  
              SET @Condition = @Condition
                    + ' and not exists ( select a1.id from provider_storage_product_buying_applay_item a1 join provider_storage_product_buying_applay b1 on a1.applay_Id=b1.id where a1.product_id =p.id and b1.status <>4 ) and  CASE WHEN FLOOR((ISNULL(prepare_qty,0)-ISNULL(PSP.buying_quantity,0))*1.00/P.unit_quantity)*P.unit_quantity<=FLOOR((ISNULL(v.quantity,0)-ISNULL(PSP.buying_quantity,0))/P.unit_quantity) THEN FLOOR((ISNULL(prepare_qty,0)-ISNULL(PSP.buying_quantity,0))*1.00/P.unit_quantity)*P.unit_quantity ELSE FLOOR((ISNULL(v.quantity,0)-ISNULL(PSP.buying_quantity,0))/P.unit_quantity)*P.unit_quantity END >0 and (ISNULL(v.quantity,0)-ISNULL(PSP.buying_quantity,0))>0	AND PR.code not like ''sz-%''';  
            END;  
        IF @factoryCode IS NOT NULL  
            BEGIN        
                SET @Condition = @Condition + ' AND P.provider_code like ''%'  
                    + @factoryCode + '%''';        
            END;      
     
        IF @factoryCodes IS NOT NULL  
            BEGIN        
                SET @Condition = @Condition + ' AND P.provider_code in ('''  
                    + REPLACE(@factoryCodes, ',', ''',''')  
                    + ''') and P.provider_code  is not null';     
            END;        
     
        IF @providerId IS NOT NULL  
            BEGIN        
              SET @Condition = @Condition + ' AND PR.id ='  
                    + CONVERT(VARCHAR(10), @providerId);     
            END;   
   
        IF @isNeedReplenishment IS NOT NULL  
            BEGIN  
                SET @Condition = @Condition  
                    + ' AND PSP.is_need_replenishment='  
                    + CONVERT(VARCHAR(10), @isNeedReplenishment);  
            END;  
        IF @replenishmentStatus IS NOT NULL  
            BEGIN  
                SET @Condition = @Condition + ' AND PSP.replenishment_status='  
                    + CONVERT(VARCHAR(10), @replenishmentStatus);  
            END;  
        IF @ISHot IS NOT NULL  
            BEGIN  
                SET @Condition = @Condition + ' AND PSP.is_hot='  
                    + CONVERT(VARCHAR(10), @ISHot);  
            END;  
   
        IF @orderIndex IS NOT NULL  
            BEGIN  
                IF @orderIndex = 1  
                    SET @OrderCondition = ' ORDER BY v1.available_qty DESC ';  
                ELSE  
                    IF @orderIndex = 2  
                        SET @OrderCondition = ' ORDER BY P.upload_time DESC ';  
                    ELSE  
                        IF @orderIndex = 3  
                            SET @OrderCondition = ' ORDER BY PSP.sellQty DESC ';  
                        ELSE  
                            IF @orderIndex = 4  
                                SET @OrderCondition = ' ORDER BY PSP.providedQty DESC ';  
            END;  
        ELSE  
            BEGIN  
                SET @OrderCondition = ' ORDER BY P.id desc';  
            END;  
 IF @isDisplayPH IS NOT NULL  
 BEGIN  
      SET @Condition = @Condition + ' and P.is_display_ph='  
                    + CONVERT(VARCHAR(10), @isDisplayPH);  
 END  
 IF @isDisplayPW IS NOT NULL  
 BEGIN  
      SET @Condition = @Condition + ' and P.is_display_pw='  
                    + CONVERT(VARCHAR(10), @isDisplayPW);  
 END  
   
 --设置查询主表        
        SET @FromSQL = ' FROM product P WITH (NOLOCK)    
 INNER JOIN product_strategy PS WITH (NOLOCK) ON P.id = PS.product_id AND P.status=4 AND P.is_delete=0  
 JOIN provider_storage_product PSP WITH(NOLOCK) ON PSP.product_id = P.id  
 ';        
     
        SET @FromSQL = @FromSQL  
            + ' LEFT JOIN product_provider PP WITH (NOLOCK) ON P.id = PP.product_id AND PP.department_id = PS.department_id'  
            + ' LEFT JOIN provider PR WITH (NOLOCK) ON PP.provider_id = PR.id  
            LEFT JOIN dbo.view_product_all_storage_quantity_info v ON v.product_id = p.id  
            LEFT JOIN dbo.view_product_provider_storage_quantity_info v1 ON v1.product_id = p.id';        
     
         
 --设置取字段表        
        SET @FromSQL2 = ' INNER JOIN product P WITH(NOLOCK) ON temp.id=P.id   
      LEFT JOIN dbo.view_product_all_storage_quantity_info v ON v.product_id = p.id  
      --LEFT JOIN dbo.view_product_provider_storage_quantity_info v1 ON v1.product_id = p.id  
      LEFT JOIN dbo.product_set_specification  ps WITH(NOLOCK) ON ps.id = P.product_set_specification_id  
      LEFT JOIN dbo.product_description pd  WITH(NOLOCK) ON pd.product_id =P.id  
      JOIN provider_storage_product PSP WITH(NOLOCK) ON PSP.product_id = P.id  
      ';  
        
        IF @providerId IS NOT NULL  
            BEGIN  
                SET @FromSQL2 = @FromSQL2  
                    + ' JOIN product_strategy PS1 WITH (NOLOCK) ON P.id = PS1.product_id  
        JOIN product_provider PP1 WITH (NOLOCK) ON P.id = PP1.product_id AND PP1.department_id = PS1.department_id  
        JOIN provider PR1 WITH (NOLOCK) ON PP1.provider_id = PR1.id       
        LEFT JOIN product_picture_collection ppcm WITH(NOLOCK) on ppcm.picture_code = P.primary_picture_code  
        LEFT JOIN product_set_color_card ccpc WITH(NOLOCK) on ccpc.id = P.product_set_color_card_id  
          
        LEFT JOIN view_product_color pv2 WITH(NOLOCK) ON  PSP.product_id=pv2.id   
        LEFT JOIN product_property_value ppv3 WITH(NOLOCK) ON PSP.product_id = ppv3.product_id and ppv3.property_id = 10          
        LEFT JOIN property_value pv3 WITH(NOLOCK) ON ppv3.property_value = pv3.id'; --v3.9.0 add  
            END;  
        ELSE  
            BEGIN  
                SET @FromSQL2 = @FromSQL2  
                    + ' LEFT JOIN product_strategy PS1 WITH (NOLOCK) ON P.id = PS1.product_id  
        LEFT JOIN product_provider PP1 WITH (NOLOCK) ON P.id = PP1.product_id AND PP1.department_id = PS1.department_id  
        LEFT JOIN provider PR1 WITH (NOLOCK) ON PP1.provider_id = PR1.id   
          
        LEFT JOIN view_product_color pv2 WITH(NOLOCK) ON  PSP.product_id=pv2.id   
        LEFT JOIN product_property_value ppv3 WITH(NOLOCK) ON PSP.product_id = ppv3.product_id and ppv3.property_id = 10                          
  LEFT JOIN property_value pv3 WITH(NOLOCK) ON ppv3.property_value = pv3.id  
        ';--v3.9.0 add  
            END;  
           
 --获取符合条件的总记录数        
        SET @CountSQL = ' SELECT @RowCount = count(P.id) ' + @FromSQL  
            + @Condition;              
        EXEC sp_executesql @CountSQL, N'@RowCount INT OUT', @RowCount OUT;         
            
        
            
    --设置取字段信息      
  
        SET @Column = 'SUM(ISNULL(PSP.buying_quantity,0)* P.cost_price ) AS totalBuyingPrice ';       
               
 --组装基本查询语句        
      
        SET @SQL = 'select P.id, ROW_NUMBER() OVER(' + @OrderCondition  
            + ') rowIndex '  
            + @FromSQL + @Condition;        
 --END        
 --v3.9.0 add      + @Condition2 ------------  
        SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp '  
            + @FromSQL2        
        PRINT @SQL;  
        EXEC(@SQL);  
                 
    END;
go


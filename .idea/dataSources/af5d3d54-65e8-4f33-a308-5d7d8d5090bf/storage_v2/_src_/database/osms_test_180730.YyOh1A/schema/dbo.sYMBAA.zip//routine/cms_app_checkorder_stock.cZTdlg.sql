/*
	2014-07-04
	APP,需质检订单列表.“已备货”,“待检”
*/
CREATE PROCEDURE [dbo].[CMS_APP_CheckOrder_stock]
	@departmentId INT =NULL,
    @code VARCHAR(50) = NULL ,
    @PageSize INT = 50 ,  --页大小                        
    @PageIndex INT = 1    --当前页号   
AS 
    BEGIN
	
        SET NOCOUNT ON;

        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用  
            @FromSQL NVARCHAR(MAX) , --查询表                                         
            @Column NVARCHAR(MAX) , --查询字段                       
            @Condition VARCHAR(MAX) , --条件                         
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ,
            @DistinctCode VARCHAR(10) 
            
        SET @DistinctCode = ' DISTINCT '   
        SET @FromSQL =' FROM check_order as x WITH (NOLOCK) 
						inner join  [order] a WITH (NOLOCK) on x.order_id=a.id 
						inner JOIN dbo.[user] u WITH(NOLOCK) ON u.id=a.merchandiser_id
						LEFT JOIN dbo.department dt WITH (NOLOCK) ON dt.id=a.department_id
						LEFT JOIN T_CustomerSpecial as tx WITH (NOLOCK) on a.customer_id = tx.CustomerId  
						AND (CASE  a.type WHEN 2 THEN 16 when 5 then 17 ELSE 1 END) = tx.BusinessType'
		SET @Condition = ' WHERE a.status=31 AND x.status=10  '              
        IF @code IS NOT NULL 
            BEGIN
                SET @Condition = @Condition + ' AND a.code like ''%' + @code
                    + '%'''   
            END 
           
       IF @departmentId IS NOT NULL
	   BEGIN
	   	SET @Condition = @Condition + ' AND a.department_id='+CONVERT(VARCHAR(20),@departmentId);
	   END
          
    --设置需要取的字段信息                        
        SET @Column = 'a.id as orderId, 
						a.code as orderCode,
						a.merchandiser_id as merchandiserId,
						u.name,
						a.customer_service_remark as remark,
						a.department_id as departmentId,
						dt.name as departmentName,
						a.customer_remark as customerRemark,
						position=dbo.f_position_app_str(a.id),
						a.customer_id as customerId,
						a.type,
						x.status AS status'
				
		   			
        --求符合条件的总数                      
        SET @CountSql = ' SELECT @RowCount = count(' + @DistinctCode
            + ' a.id) ' + @FromSQL + @Condition                 
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
                            
		
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                              
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                              
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                              
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                              
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                              
        SET @end = @PageIndex * @PageSize   
    
        SET @SQL = 'SELECT * from                      
       (                      
       SELECT *,ROW_NUMBER() OVER(ORDER BY temp.orderCode ASC) rowIndex                      
       from (SELECT ' + @DistinctCode + @Column + @FromSQL + @Condition
            + ') temp                      
       ) temp2                           
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))    
            
       EXEC(@SQL);             
	   select @RowCount                
    END
go


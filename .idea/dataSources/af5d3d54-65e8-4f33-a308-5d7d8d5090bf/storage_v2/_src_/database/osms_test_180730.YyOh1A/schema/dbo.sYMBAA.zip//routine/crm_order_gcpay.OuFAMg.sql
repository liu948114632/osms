

/*-----------------------------------------------                    
备注：新增订单信用卡支付信息                   
创建人: LXH                    
创建日期:2012-05-30                    
--------------------------------------------------*/                    
CREATE PROC dbo.CRM_Order_GCPay                    
(                    
 @OrderId     VARCHAR(20),                    
 @PayId       VARCHAR(30),                    
 @PayAmount   DECIMAL(18,2),        
 @CurrencyId  INT ,        
 @CountryId   INT,        
 @PayStatus   INT,      
 @GCType      INT,      
 @BusinessType INT,
 @FirstName NVARCHAR(50),
 @SurName NVARCHAR(50),
  @PayAmountUS DECIMAL(18,2)=0
)                    
AS                    
BEGIN                    
    DECLARE @DealStatus INT ,@Message VARCHAR(max) ,@Rate DECIMAL(18,6), @CurrencyName VARCHAR(20),@PayType INT,
            @OrderCurrencyId INT ,@OrderRate DECIMAL(18,6)
      
   IF( @PayAmount <= 0 )            
   BEGIN            
       SET @Message = '提示：订单' + @OrderId + '支付金额无效(' + LTRIM(@PayAmount) + ')!'            
       RAISERROR(@Message, 16, 1) WITH NOWAIT ;             
       RETURN;            
   END      
       
    IF NOT (@BusinessType=1 OR @BusinessType=5 OR @BusinessType=6 OR @BusinessType=16)--不是PH,PH_UK的才验证
      BEGIN 
   --根据信用卡的类型确定支付方式    
   IF ( @GCType = 1 )
    BEGIN    
        SET @PayType = 2 --GC信用卡    
    END        
   ELSE    IF ( @GCType = 2 )
        BEGIN    
            SET @PayType = 8 --WebMoney    
        END      
    ELSE        IF ( @GCType = 3 )
            BEGIN    
                SET @PayType = 9 --Sofort    
            END       
        ELSE
            BEGIN    
                SET @Message = '提示：订单' + @OrderId + '的GC类型不正确'            
                RAISERROR(@Message, 16, 1) WITH NOWAIT;             
                RETURN;       
            END     
      END
      ELSE
      BEGIN
        SET @PayType=@GCType
      END
      
    SET @DealStatus = 1 --默认为信息正确        
    --1、检查币种        
    SELECT @Rate = Rate,@CurrencyName =Currency  FROM dbo.T_Currency WHERE dbo.T_Currency.Id = @CurrencyId         
	 IF( @Rate IS NULL )        
	 begin        
	  SET @DealStatus = 2 -- 付款币种无效        
	 END         
 
   --获取订单币种和下单时汇率
   SELECT @OrderCurrencyId = Currency,@OrderRate=Rate
   FROM dbo.T_Order
   WHERE OrderId = @OrderId
   
   --以下单时的汇率进行转换，如果不是下单的币种，则实时汇率转换
   IF( @OrderCurrencyId = @CurrencyId AND @OrderRate > 0)
   BEGIN
       SET @Rate = @OrderRate
   END 
   
 IF(@PayAmountUS=0)
         BEGIN
            SET @PayAmountUS = @PayAmount / @Rate        
      END
      
   --2、检查付款国家与订单国家        
   IF @DealStatus = 1  AND ISNULL(@CountryId,0)>0
   BEGIN        
         DECLARE @addressId INT ,@OrderCountryId INT         
       -- 获取相应的地址Id        
		  SELECT @addressId = [ShipAddressId] FROM dbo.T_Order WHERE OrderId = @orderId;        
		  IF @addressId IS NULL         
		  BEGIN        
		   SET @DealStatus = 4;-- 信息不全，匹配失败        
		  END         
      
		  -- 获取寄货地址里面的国家        
		  SELECT @OrderCountryId = dbo.T_OrderAddresses.Country        
		  FROM dbo.T_OrderAddresses WHERE AddressId =  @addressId;        
      
		  IF @OrderCountryId IS NULL        
		  BEGIN        
		   SET @DealStatus = 4; -- 信息不全，匹配失败        
		  END        
		  ELSE IF(@CountryId <> @OrderCountryId)         
		  BEGIN        
		   SET @DealStatus = 3; -- 地址匹配失败        
		  END        
   END          
      
   --3、付款状态是否正确        
   IF @PayStatus < 800        
   BEGIN        
      SET @DealStatus = 5; -- 付款状态不对        
   END         
      
   --插入GC付款信息        
   INSERT INTO dbo.T_GCReturn        
           ( OrderId ,        
             PayId ,        
             PayAmount ,        
             PayAmountOfUS ,        
             CurrenyId ,        
             CountryId ,        
             PayStatus ,        
             DealStatus ,        
             CreateTime ,      
       BusinessType,
             FirstName,
             SurName,
			 CreditCardType
           )        
   VALUES  ( @OrderId , -- OrderId - varchar(13)        
             @PayId , -- PayId - varchar(30)        
             @PayAmount , -- PayAmount - decimal        
             @PayAmountUS , -- PayAmountOfUS - decimal        
             @CurrencyId , -- CurrenyId - int        
             @CountryId , -- CountryId - int        
             @PayStatus , -- PayStatus - tinyint        
             @DealStatus , -- DealStatus - tinyint        
             GETDATE() , -- CreateTime - datetime      
             @BusinessType,  --行业      
             @FirstName,
             @SurName,
			 1
           )        
    
   IF @DealStatus != 1    
   BEGIN--如果信息不正确，则设置为不允许自动录单    
      UPDATE dbo.T_Order SET IsCanAutoImportOrder=0 WHERE OrderId=@OrderId    
   END     
                  
   --录入订单支付记录                  
   DECLARE @Action VARCHAR(100),@Remark VARCHAR(100),@PayDate DATETIME ,@USCurrencyId INT            
   Select @USCurrencyId = [Id] From t_Currency Where Currency = 'USD'              
   SET @PayDate = GETDATE();            
   SET @Action = '自动录入GC支付金额:' + LTRIM(@PayAmountUS) + 'USD';          
   SET @Remark = ''        
   IF @CurrencyName !=  'USD'        
   BEGIN --如果支付币种不是没有，则在备注里加上原金额        
      SET @Remark = 'GC:' + LTRIM(@PayAmount) + @CurrencyName        
   END          
      
   EXEC CRM_Order_OrderPayAdd @OrderId=@OrderId,@PaySum=@PayAmountUS,@CurrencyId =@USCurrencyId,@Remark=@Remark,@PayDate=@PayDate,@ActionUserId=0,@Action=@Action,@PayType=@PayType,@PayId=@PayId                      
END
go


/*
	2014-07-04
	APP,查一查(废除分页)
*/
CREATE PROCEDURE [dbo].[CMS_APP_Product]
    @code VARCHAR(50) = NULL ,
    @PageSize INT = 50 ,  --页大小                        
    @PageIndex INT = 1    --当前页号   
AS 
    BEGIN
	
        SET NOCOUNT ON;

        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用  
            @FromSQL NVARCHAR(MAX) , --查询表                                         
            @Column NVARCHAR(MAX) , --查询字段                       
            @Condition VARCHAR(MAX) , --条件                         
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ,
            @DistinctCode VARCHAR(10) 
            
        --SET @DistinctCode = ' DISTINCT '   
        SET @FromSQL =' FROM dbo.product a WITH (NOLOCK) LEFT JOIN dbo.storage b WITH(NOLOCK)  ON a.id = b.product_id AND b.department_id = 4 '
        SET @Condition = ' WHERE  status = 4 AND is_delete = 0  '              
        IF @code IS NOT NULL 
            BEGIN
                SET @Condition = @Condition + ' AND a.code like ''%' + @code
                    + '%'''   
            END 
    --设置需要取的字段信息                        
        SET @Column = 'a.id as id,
					a.code as code,
					a.unit as unit,
					a.unit_quantity as unitQuantity,
					a.[weight] as weight,
					a.primary_picture_code as primaryPictureCode,
					a.name as name,
					a.original_name as originalName,
					ISNULL(b.quantity,0)-ISNULL(b.lock_quantity,0) AS quantity'
				
		   			
        --求符合条件的总数                      
        SET @CountSql = ' SELECT @RowCount = count(' 
            + ' a.id) ' + @FromSQL + @Condition                 
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
                            
		
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                              
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                              
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                              
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                              
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                              
        SET @end = @PageIndex * @PageSize   
    
       -- SET @SQL = 'SELECT * from                      
       --(                      
       --SELECT *,ROW_NUMBER() OVER(ORDER BY temp.quantity DESC,temp.code ASC) rowIndex                      
       --from (SELECT '  + @Column + @FromSQL + @Condition
       --     + ') temp                      
       --) temp2                           
       --where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
       --     + CAST(@end AS NVARCHAR(10))    
       
            SET @SQL = '
       SELECT top 100  *                      
       from (SELECT '  + @Column + @FromSQL + @Condition
            + ') temp order by temp.quantity DESC,temp.code ASC'                      
            
   PRINT    @SQL 
       EXEC(@SQL);             
	   select @RowCount                
    END
go


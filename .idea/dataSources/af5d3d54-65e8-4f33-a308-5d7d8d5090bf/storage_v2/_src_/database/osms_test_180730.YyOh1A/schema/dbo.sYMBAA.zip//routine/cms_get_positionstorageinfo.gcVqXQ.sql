-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CMS_Get_PositionStorageInfo]
	@positionId INT =NULL,
	@departmentId INT =NULL
AS
BEGIN
DECLARE @type INT
SELECT @type = type FROM dbo.department WHERE id =@departmentId
IF @type =1
BEGIN
SELECT a.id,b.product_id AS productId,b.department_id AS departmentId,b.id AS storageId,a.position_id AS positionId,a.quantity AS quantity,a.lock_quantity AS lockQuantity,a.purchase_time AS purchaseTime  FROM  dbo.department_storage_detail a JOIN dbo.department_storage b ON a.storage_id =b.id
	WHERE a.position_id = @positionId AND b.department_id = @departmentId AND a.quantity>0
END
ELSE IF @type = 2
BEGIN
	SELECT a.id,b.product_id AS productId,b.department_id AS departmentId,b.id AS storageId,a.position_id AS positionId,a.quantity AS quantity,a.lock_quantity AS lockQuantity,a.purchase_time AS purchaseTime  FROM  dbo.logistics_storage_detail a JOIN dbo.logistics_storage b ON a.storage_id =b.id
	WHERE a.position_id = @positionId AND b.department_id = @departmentId AND a.quantity>0

END
ELSE
begin
	SELECT a.id,b.product_id AS productId,b.department_id AS departmentId,b.id AS storageId,a.position_id AS positionId,a.quantity AS quantity,a.lock_quantity AS lockQuantity,a.purchase_time AS purchaseTime  FROM  dbo.storage_detail a JOIN dbo.storage b ON a.storage_id =b.id
	WHERE a.position_id = @positionId AND b.department_id = @departmentId AND a.quantity>0
end
END

go




/*------------------------------------------------------
报表统计-考核-当月新商品咨询处理率
up_Report_Assess_NewProductsConsultationDealRate '2008-01-01','2010-01-01','GZ'
------------------------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Assess_NewProductsConsultationDealRate]
(
	@StartTime		DateTime,
	@EndTime		DateTime,
	@Stock			VARCHAR(10)
)
AS
BEGIN
	DECLARE @StockId INT;
	
	SET @StockId  = (SELECT ISNULL(Id,0) FROM dbo.C_Stock WHERE [Short] = @Stock);
	IF (@StockId > 0)
	BEGIN
		/*
		with Consultation(UserId,ConsultationCount ) as
		(
			select trackerId as UserId, count(1) as ConsultationCount from dbo.C_Consultation 
			where CreateDate >=  @StartTime AND CreateDate <=  @EndTime AND trackerId > 0 GROUP BY trackerId 
		),
		ConsultationFind(UserId,FindCount) as 
		(
			select a.UserId,Count(1) as FindCount from C_ConsultationHistory a 
			left join C_Consultation b on a.ConsultationId = b.Id
			where [action] = '咨询已找到'
			AND b.CreateDate >=  @StartTime AND b.CreateDate <=  @EndTime AND DATEDIFF(day,  b.CreateDate,a.OperateTime) <= 4
			GROUP BY a.UserId
		)

		SELECT c.FirstName as UserName,a.ConsultationCount,IsNULL(b.FindCount,0) as FindCount,
		LTRIM(Cast((cast(IsNULL(b.FindCount,0) as decimal(18,2)) / a.ConsultationCount) * 100 as decimal(18,2))) + '%' AS Rate
		FROM Consultation a LEFT JOIN ConsultationFind b ON a.UserId = b.UserId 
		LEFT JOIN b_User c ON a.UserId = c.Id
		where c.stock like '%' + ltrim(@stockId) + '%'
		Order by c.FirstName
		*/
		
		WITH Consultation(UserId,ConsultationCount ) AS
		(
			SELECT TrackerId AS UserId, COUNT(1) AS ConsultationCount 
			FROM dbo.T_Consultation 
			WHERE CreateDate >  @StartTime AND CreateDate <  @EndTime AND TrackerId > 0 
			GROUP BY TrackerId 
		),
		ConsultationFind(UserId,FindCount) AS 
		(
			SELECT a.UserId,Count(DISTINCT b.Id) AS FindCount 
			FROM dbo.T_ConsultationHistory a 
			JOIN dbo.T_Consultation b on a.ConsultationId = b.Id
			WHERE [action] = N'咨询已找到'
			AND b.CreateDate >  @StartTime AND b.CreateDate <  @EndTime AND DATEDIFF(DAY,b.CreateDate,a.OperateTime) <= 4
			GROUP BY a.UserId
		)

		-- 返回最终结果
		SELECT 
			c.FirstName AS UserName,
			a.ConsultationCount,ISNULL(b.FindCount,0) AS FindCount,
			LTRIM(CAST((CAST(ISNULL(b.FindCount,0) AS DECIMAL(18,2)) / a.ConsultationCount) * 100 AS DECIMAL(18,2))) + '%' AS Rate
		FROM Consultation a 
		LEFT JOIN ConsultationFind b ON a.UserId = b.UserId 
		LEFT JOIN dbo.B_User c ON a.UserId = c.Id
		WHERE c.[stock] like '%' + ltrim(@stockId) + '%'
		ORDER BY c.FirstName;
		
	END
END


go


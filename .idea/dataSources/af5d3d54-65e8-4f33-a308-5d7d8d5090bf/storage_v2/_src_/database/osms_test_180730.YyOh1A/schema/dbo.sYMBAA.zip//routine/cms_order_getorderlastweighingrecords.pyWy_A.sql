CREATE PROC [dbo].[CMS_Order_GetOrderLastWeighingRecords]  
    (  
      @OrderId INT = NULL   --订单Id          
    )  
AS   
   BEGIN                                
        SET NOCOUNT ON ;             
	SELECT b.order_codes AS orderCodes,c.id,c.box,c.website_weight AS websiteWeight  
	,c.actual_weight AS actualWeight,c.volume_weight AS volumeWeight  
	,c.length,c.width,c.height,c.order_volume_weight AS orderVolumeWeight  
	 FROM (  
	 SELECT TOP 1 a.order_id,a.weighing_record_id  FROM dbo.order_ref_order_weighing_record AS a  
	 WHERE a.order_id =@OrderId  
	 ORDER BY a.id DESC  
	) AS temp  
	INNER JOIN dbo.order_weighing_record b ON temp.weighing_record_id = b.id  
	INNER JOIN dbo.order_weighing_record_item c ON c.weighing_record_id = b.id  
	WHERE b.status = 1  
   
  SET NOCOUNT OFF ;         
    
  END
go


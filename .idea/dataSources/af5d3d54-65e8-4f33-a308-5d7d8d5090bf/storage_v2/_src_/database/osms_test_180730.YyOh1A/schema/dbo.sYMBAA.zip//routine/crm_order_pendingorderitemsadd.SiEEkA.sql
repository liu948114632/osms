/*------------------------------------------------          
备注:增加未决订单商品          
创建人: FRH          
创建日期:2009-12-30          
---------------------------------------------------      
修改人：LXH      
修改时间：2012-09-28      
修改内容：未决单生不再有X商品      
-------------------------------------------------*/          
CREATE PROC dbo.CRM_Order_PendingOrderItemsAdd          
(          
 @OrderId     VARCHAR(20), -- 当前订单          
 @PendingOrder VARCHAR(20) -- 生成的未决订单       
)          
AS          
BEGIN              
     SET NOCOUNT ON;      
            
  -- 增加未决订单商品          
  INSERT INTO dbo.T_OrderItem (          
   OrderId,          
   ProductId,          
   CmsProductId,      
   ProductSetId,    
   [Type],          
   Quantity,          
   ReadyQty,          
   Unit,          
   UnitQuantity,      
      CostPrice,    
   ItemPrice,          
   SalePrice,          
   [Weight],          
   Volume,          
   IsPromote,          
   IsProductPool,          
   Box,          
   [Status],          
   XFreight,          
   JoinDate,          
   UpdateTime,          
   CustomerRemark,          
   BranchRemark,          
   CSRemark,      
   ColorCardName,      
   SpecficationName,      
   MinBatchQty,  
   ProcessingStatus,  
   PackageProductId,
   PromoteId ,
   PackFee,
   PurchaseHandlerRemark,
   IsQualityInspection
  )       
  SELECT           
   @PendingOrder,          
   ProductId,          
   CmsProductId,      
   ProductSetId,    
   1,          
   Quantity - ReadyQty,          
   0,          
   Unit,          
   UnitQuantity,          
   CostPrice,
   ItemPrice,          
   SalePrice,          
   Weight,          
   Volume,          
   IsPromote,          
   IsProductPool,          
   Box,          
   [Status],          
   0,          
JoinDate,     
   GETDATE(),          
   CustomerRemark,          
   BranchRemark,          
   CSRemark,      
   ColorCardName,      
   SpecficationName,      
   MinBatchQty,  
   ProcessingStatus,  
   PackageProductId,
   PromoteId,
   PackFee*((Quantity-ReadyQty)*1.0/Quantity),
   PurchaseHandlerRemark,
   IsQualityInspection
  From dbo.T_OrderItem          
  Where OrderId = @OrderId And ReadyQty < Quantity And [Status] < 12;         
            
  INSERT INTO T_OrderItemProduct        
  (        
    OrderItemId,        
    Name,        
    ItemCode,        
    Description,        
    ImageName,        
    Discount,    
    ColorCode,    
    ColorImageName       
  )         
  SELECT c.OrderItemId,        
   b.Name,        
   b.ItemCode,        
   b.Description,        
   b.ImageName,        
   b.Discount,    
   b.ColorCode,    
   b.ColorImageName        
   FROM    dbo.T_OrderItem a        
   INNER JOIN dbo.T_OrderItemProduct b ON a.OrderItemId=b.OrderItemId        
   INNER JOIN T_OrderItem c ON a.CmsProductId = c.CmsProductId        
   WHERE  a.OrderId = @OrderId            
            AND c.OrderId = @PendingOrder         
            And a.ReadyQty < a.Quantity           
            And a.[Status] < 12;         
              
          
 -- 更新原始订单的未到货商品          
 Update dbo.T_OrderItem          
 Set Quantity = ReadyQty,          
     [Status] = 6,
	 PackFee=PackFee*(ReadyQty*1.0/Quantity)
 Where OrderId = @OrderId  And [Status] < 12           
       And ReadyQty < Quantity AND ReadyQty > 0;          
          
 -- 删除订购数量为0的订单项          
 UPDATE dbo.T_OrderItem SET Status = 12 Where OrderId = @OrderId And ReadyQty = 0 And [Status] < 12;          
          
End

go


/*--------------------------------------------------------------------------------------------
[描述]
	根据策略编号得到策略的所有信息
--------------------------------------------------------------------------------------------*/
CREATE proc [dbo].[Temp_StrategyGet]
(
	@Id INT = 0
)
AS
BEGIN
	IF(@Id = 0)
		SELECT * FROM Temp_Strategy order by Name asc
	ELSE
		SELECT * FROM Temp_Strategy WHERE [Id] = @Id order by Name asc
END

go


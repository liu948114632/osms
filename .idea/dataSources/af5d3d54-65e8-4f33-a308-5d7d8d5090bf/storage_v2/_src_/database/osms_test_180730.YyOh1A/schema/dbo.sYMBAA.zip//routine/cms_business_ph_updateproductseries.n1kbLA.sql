
CREATE  PROC [dbo].[CMS_Business_PH_UpdateProductSeries]
    (
      @CategorySeriesId INT = NULL , --类别系列Id        
      @FirstProfitCoefficient DECIMAL(10, 6) = NULL , --第一段系数        
      @SecondProfitCoefficient DECIMAL(10, 6) = NULL , --第二段系数        
      @ThirdProfitCoefficient DECIMAL(10, 6) = NULL --第三段系数        
    )
AS 
    BEGIN                  
        SET NOCOUNT ON ;                
        DECLARE @ProductStr VARCHAR(MAX);  
        DECLARE @ProductStr2 VARCHAR(MAX);
        SET @ProductStr = '' ;  
        SET @ProductStr2 = '' ;  
        UPDATE  dbo.ph_product
        SET     first_profit_coefficient = @FirstProfitCoefficient ,
                second_profit_coefficient = @SecondProfitCoefficient ,
                third_profit_coefficient = @ThirdProfitCoefficient
        WHERE   category_series_id = @CategorySeriesId         
     
        SELECT  @ProductStr = @ProductStr + ',' + CAST(product_id AS VARCHAR)
        FROM    ( SELECT    product_id
                  FROM      dbo.ph_product
                  WHERE     category_series_id = @CategorySeriesId
                ) temp  
        IF @ProductStr !=''
        BEGIN
			SET @ProductStr = RIGHT(@ProductStr, LEN(@ProductStr) - 1)
			-- PH产品的销售梯度与UK产品销售梯度一致则同步UK产品利润系数
			--UPDATE b SET b.first_profit_coefficient = a.first_profit_coefficient*1.3*temp.series,
			--			 b.second_profit_coefficient = a.second_profit_coefficient*1.3*temp.series,
			--			 b.third_profit_coefficient = a.third_profit_coefficient*1.3*temp.series
			--FROM dbo.ph_product AS a 
			--JOIN dbo.uk_product AS b ON a.product_id = b.product_id
			--JOIN (SELECT  CASE WHEN t.volumeWeight IS NULL OR t.actualWeight = 0 THEN 1
			--				 WHEN t.volumeWeight / t.actualWeight <= 2 THEN 1
			--				 WHEN t.volumeWeight / t.actualWeight > 2 AND t.volumeWeight / t.actualWeight <= 5 THEN 1.3
			--				 WHEN t.volumeWeight / t.actualWeight > 5 THEN 1.5
			--				 ELSE 1
			--				END AS series,t.productId
			--		FROM    ( SELECT    b.id AS productId,CASE WHEN b.volume IS NOT NULL
			--								 THEN CEILING(b.volume * b.unit_quantity * 1.3) / 5
			--								 ELSE NULL
			--							END AS volumeWeight ,
			--							CEILING(b.weight * b.unit_quantity * 1.15) AS actualWeight
			--				  FROM      dbo.product AS b   
			--				) AS t) AS temp ON temp.productId = a.product_id
			--WHERE a.category_series_id = @CategorySeriesId
			--AND CASE WHEN a.first_quantity_from IS NULL THEN 0 ELSE a.first_quantity_from END = 
			--	CASE WHEN b.first_quantity_from IS NULL THEN 0 ELSE b.first_quantity_from END
			--AND CASE WHEN a.first_quantity_to IS NULL THEN 0 ELSE a.first_quantity_to END = 
			--	CASE WHEN b.first_quantity_to IS NULL THEN 0 ELSE b.first_quantity_to END
			--AND CASE WHEN a.second_quantity_from IS  NULL THEN 0 ELSE a.second_quantity_from END = 
			--	CASE WHEN b.second_quantity_from IS  NULL THEN 0 ELSE b.second_quantity_from END
			--AND CASE WHEN a.second_quantity_to IS  NULL THEN 0 ELSE a.second_quantity_to END = 
			--	CASE WHEN b.second_quantity_to IS  NULL THEN 0 ELSE b.second_quantity_to END
			--AND CASE WHEN a.third_quantity_from IS NULL THEN 0 ELSE a.third_quantity_from END = 
			--	CASE WHEN b.third_quantity_from IS NULL THEN 0 ELSE b.third_quantity_from END
			--AND CASE WHEN a.third_quantity_to IS NULL THEN 0 ELSE a.third_quantity_to END = 
			--	CASE WHEN b.third_quantity_to IS NULL THEN 0 ELSE b.third_quantity_to END 

			-- PH产品的销售梯度与UK产品销售梯度一致则同步UK产品利润系数
			--UPDATE c SET c.profit_coefficient = b.first_profit_coefficient 
			--FROM dbo.ph_product AS a 
			--JOIN dbo.uk_product AS b ON a.product_id = b.product_id
			--JOIN dbo.uk_domestic_product c ON c.id =b.id
			--WHERE a.category_series_id = @CategorySeriesId
			--AND CASE WHEN a.first_quantity_from IS NULL THEN 0 ELSE a.first_quantity_from END = 
			--	CASE WHEN b.first_quantity_from IS NULL THEN 0 ELSE b.first_quantity_from END
			--AND CASE WHEN a.first_quantity_to IS NULL THEN 0 ELSE a.first_quantity_to END = 
			--	CASE WHEN b.first_quantity_to IS NULL THEN 0 ELSE b.first_quantity_to END
			--AND CASE WHEN a.second_quantity_from IS  NULL THEN 0 ELSE a.second_quantity_from END = 
			--	CASE WHEN b.second_quantity_from IS  NULL THEN 0 ELSE b.second_quantity_from END
			--AND CASE WHEN a.second_quantity_to IS  NULL THEN 0 ELSE a.second_quantity_to END = 
			--	CASE WHEN b.second_quantity_to IS  NULL THEN 0 ELSE b.second_quantity_to END
			--AND CASE WHEN a.third_quantity_from IS NULL THEN 0 ELSE a.third_quantity_from END = 
			--	CASE WHEN b.third_quantity_from IS NULL THEN 0 ELSE b.third_quantity_from END
			--AND CASE WHEN a.third_quantity_to IS NULL THEN 0 ELSE a.third_quantity_to END = 
			--	CASE WHEN b.third_quantity_to IS NULL THEN 0 ELSE b.third_quantity_to END 

           --us
		   UPDATE b SET b.first_profit_coefficient = a.first_profit_coefficient*1.4*temp.series,
						 b.second_profit_coefficient = a.second_profit_coefficient*1.4*temp.series,
						 b.third_profit_coefficient = a.third_profit_coefficient*1.4*temp.series
			FROM dbo.ph_product AS a 
			JOIN dbo.us_product AS b ON a.product_id = b.product_id
			JOIN (SELECT  CASE WHEN t.volumeWeight IS NULL OR t.actualWeight = 0 THEN 1
							 WHEN t.volumeWeight / t.actualWeight <= 2 THEN 1
							 WHEN t.volumeWeight / t.actualWeight > 2 AND t.volumeWeight / t.actualWeight <= 5 THEN 1.3
							 WHEN t.volumeWeight / t.actualWeight > 5 THEN 1.5
							 ELSE 1
							END AS series,t.productId
					FROM    ( SELECT    b.id AS productId,CASE WHEN b.volume IS NOT NULL
											 THEN CEILING(b.volume * b.unit_quantity * 1.3) / 5
											 ELSE NULL
										END AS volumeWeight ,
										CEILING(b.weight * b.unit_quantity * 1.15) AS actualWeight
							  FROM      dbo.product AS b   
							) AS t) AS temp ON temp.productId = a.product_id
			WHERE a.category_series_id =@CategorySeriesId and
			  CASE WHEN a.first_quantity_from IS NULL THEN 0 ELSE a.first_quantity_from END = 
				CASE WHEN b.first_quantity_from IS NULL THEN 0 ELSE b.first_quantity_from END
			AND CASE WHEN a.first_quantity_to IS NULL THEN 0 ELSE a.first_quantity_to END = 
				CASE WHEN b.first_quantity_to IS NULL THEN 0 ELSE b.first_quantity_to END
			AND CASE WHEN a.second_quantity_from IS  NULL THEN 0 ELSE a.second_quantity_from END = 
				CASE WHEN b.second_quantity_from IS  NULL THEN 0 ELSE b.second_quantity_from END
			AND CASE WHEN a.second_quantity_to IS  NULL THEN 0 ELSE a.second_quantity_to END = 
				CASE WHEN b.second_quantity_to IS  NULL THEN 0 ELSE b.second_quantity_to END
			AND CASE WHEN a.third_quantity_from IS NULL THEN 0 ELSE a.third_quantity_from END = 
				CASE WHEN b.third_quantity_from IS NULL THEN 0 ELSE b.third_quantity_from END
			AND CASE WHEN a.third_quantity_to IS NULL THEN 0 ELSE a.third_quantity_to END = 
				CASE WHEN b.third_quantity_to IS NULL THEN 0 ELSE b.third_quantity_to END 
			
	       INSERT  INTO dbo.communication_log
					( command ,
					  object_id ,
					  status ,
					  create_time ,
					  operator ,
					  model_type   
					)
			SELECT  'UPDATE_US_SALE_PRICE',a.product_id,1,GETDATE(),0,'PRODUCT'
			FROM dbo.ph_product AS a 
			JOIN dbo.us_product AS b ON a.product_id = b.product_id
			--JOIN dbo.uk_domestic_product c ON c.id =b.id
			WHERE a.category_series_id  =@CategorySeriesId AND 
			 CASE WHEN a.first_quantity_from IS NULL THEN 0 ELSE a.first_quantity_from END = 
				CASE WHEN b.first_quantity_from IS NULL THEN 0 ELSE b.first_quantity_from END
			AND CASE WHEN a.first_quantity_to IS NULL THEN 0 ELSE a.first_quantity_to END = 
				CASE WHEN b.first_quantity_to IS NULL THEN 0 ELSE b.first_quantity_to END
			AND CASE WHEN a.second_quantity_from IS  NULL THEN 0 ELSE a.second_quantity_from END = 
				CASE WHEN b.second_quantity_from IS  NULL THEN 0 ELSE b.second_quantity_from END
			AND CASE WHEN a.second_quantity_to IS  NULL THEN 0 ELSE a.second_quantity_to END = 
				CASE WHEN b.second_quantity_to IS  NULL THEN 0 ELSE b.second_quantity_to END
			AND CASE WHEN a.third_quantity_from IS NULL THEN 0 ELSE a.third_quantity_from END = 
				CASE WHEN b.third_quantity_from IS NULL THEN 0 ELSE b.third_quantity_from END
			AND CASE WHEN a.third_quantity_to IS NULL THEN 0 ELSE a.third_quantity_to END = 
				CASE WHEN b.third_quantity_to IS NULL THEN 0 ELSE b.third_quantity_to END  

			SELECT  @ProductStr2 = @ProductStr2 + ',' + CAST(product_id AS VARCHAR)
			FROM    ( SELECT b.product_id
						FROM dbo.ph_product AS a 
						JOIN dbo.uk_product AS b ON a.product_id = b.product_id
						WHERE a.category_series_id = @CategorySeriesId
						AND CASE WHEN a.first_quantity_from IS NULL THEN 0 ELSE a.first_quantity_from END = 
							CASE WHEN b.first_quantity_from IS NULL THEN 0 ELSE b.first_quantity_from END
						AND CASE WHEN a.first_quantity_to IS NULL THEN 0 ELSE a.first_quantity_to END = 
							CASE WHEN b.first_quantity_to IS NULL THEN 0 ELSE b.first_quantity_to END
						AND CASE WHEN a.second_quantity_from IS  NULL THEN 0 ELSE a.second_quantity_from END = 
							CASE WHEN b.second_quantity_from IS  NULL THEN 0 ELSE b.second_quantity_from END
						AND CASE WHEN a.second_quantity_to IS  NULL THEN 0 ELSE a.second_quantity_to END = 
							CASE WHEN b.second_quantity_to IS  NULL THEN 0 ELSE b.second_quantity_to END
						AND CASE WHEN a.third_quantity_from IS NULL THEN 0 ELSE a.third_quantity_from END = 
							CASE WHEN b.third_quantity_from IS NULL THEN 0 ELSE b.third_quantity_from END
						AND CASE WHEN a.third_quantity_to IS NULL THEN 0 ELSE a.third_quantity_to END = 
							CASE WHEN b.third_quantity_to IS NULL THEN 0 ELSE b.third_quantity_to END
					) temp 
					
					
					 
			IF @ProductStr2 !=''
			BEGIN
				SET @ProductStr2 = RIGHT(@ProductStr2, LEN(@ProductStr2) - 1)
			END
	        
			INSERT  INTO dbo.communication_log
					( command ,
					  object_id ,
					  status ,
					  create_time ,
					  operator ,
					  model_type ,
					  execute_time    
					)
			VALUES  ( 'UPDATE_PH_SALE_PRICE' ,
					  @ProductStr ,
					  1 ,
					  GETDATE() ,
					  0 ,
					  'PRODUCT' ,
					  NULL 
					)
			--INSERT  INTO dbo.communication_log
			--		( command ,
			--		  object_id ,
			--		  status ,
			--		  create_time ,
			--		  operator ,
			--		  model_type ,
			--		  execute_time    
			--		)
			--VALUES  ( 'UPDATE_UK_SALE_PRICE' ,
			--		  @ProductStr2 ,
			--		  1 ,
			--		  GETDATE() ,
			--		  0 ,
			--		  'PRODUCT' ,
			--		  NULL 
			--		)  
         END          
        SET NOCOUNT OFF ;             
    END
go


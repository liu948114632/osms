
/*-----------------------------------------
描述:[统计]某个商品的在一段时间内的交易批量
创建人：FRH
------------------------------------------------*/
CREATE FUNCTION [dbo].[uf_Count_GetProductSaleQty]
(
	@ProductrId		Int,
	@StartTime		VARCHAR(100),
	@EndTime		VARCHAR(100)
)
RETURNS				DECIMAL(18,4)
AS
BEGIN
	DECLARE @qty	DECIMAL(18,4);

	SET @qty  = 0;
	
	SELECT @qty = Sum(T_OrderItem.Quantity*1.0/T_OrderItem.UnitQuantity) 
	FROM dbo.T_Order INNER JOIN dbo.T_OrderItem 
		ON T_Order.OrderId = T_OrderItem.OrderId
	WHERE
		T_Order.OrderStatus > 0 AND T_Order.OrderStatus < 132 
		AND T_OrderItem.Status < 12 
		And T_OrderItem.ProductId = @ProductrId
		And T_Order.OrderDate >  @StartTime 
		AND T_Order.OrderDate < @EndTime
		And T_OrderItem.Quantity > 0
	
	IF @qty IS NULL	SET @qty = 0;
	RETURN @qty;
END
go


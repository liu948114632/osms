--设置免运费的货运方式
CREATE PROC CRM_Delivery_SetFreeShippingDeliveryId
(
@FreeShippingDeliveryIds VARCHAR(MAX)
)
AS 
BEGIN
 DELETE dbo.T_FreeShippingDelivey

IF(@FreeShippingDeliveryIds>'')
BEGIN
	INSERT INTO dbo.T_FreeShippingDelivey
        ( DeliveyId )
SELECT Value FROM dbo.uf_Split(@FreeShippingDeliveryIds,',')  	
END
END
go


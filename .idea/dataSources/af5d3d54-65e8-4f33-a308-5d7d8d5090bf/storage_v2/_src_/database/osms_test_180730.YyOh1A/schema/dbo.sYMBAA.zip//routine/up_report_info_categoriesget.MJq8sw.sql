




/**************************************************************
[公共信息]
	获取类别列表，只包括大类和小类
**************************************************************/
CREATE PROCEDURE [dbo].[up_Report_Info_CategoriesGet] 
(
	@CategoryName	VARCHAR(100) = ''
)
AS
BEGIN
	SET NOCOUNT ON;
--	If @CategoryName > ''
--	Begin
--		Select 
--			CategoryId,
--			CategoryName,
--			ParentId,
--			(Select [Name] From T_Category Where categoryId = T_CategoryHelp.ParentId) As ParentName
--		From 
--			T_CategoryHelp 
--		Where 
--			[Type] = 1 And [Level] = 4 And Disabled = 0 
--			And ( CategoryName Like '%' + @CategoryName + '%'  Or ParentId In (Select CategoryId From T_Category Where [Name] Like '%' + @CategoryName + '%' ))
--		Order By 
--			ParentId,CategoryId
--	End
--	Else
--	Begin
--		Select 
--			CategoryId,
--			CategoryName,
--			ParentId,
--			(Select [Name] From T_Category Where categoryId = T_CategoryHelp.ParentId) As ParentName
--		From 
--			T_CategoryHelp 
--		Where 
--			[Type] = 1 And [Level] = 4 And Disabled = 0
--		Order By 
--			ParentId,CategoryId
--	End

	IF @CategoryName > '' 
	BEGIN
		SELECT CategoryId,
		   ParentId,
		   [Name] AS CategoryName,
		   (Select [Name] From dbo.T_Category Where categoryId = a.ParentId) As ParentName
		FROM dbo.T_Category a WHERE [Level] = 3 AND IsDisplay = 1 AND [Name] LIKE '%' + @CategoryName + '%' -- 只获取三级类别
		ORDER BY a.[Name];
	END	
	ELSE
	BEGIN
		SELECT CategoryId,
		   ParentId,
		   [Name] AS CategoryName,
		   (Select [Name] From dbo.T_Category Where categoryId = a.ParentId) As ParentName
		FROM dbo.T_Category a WHERE [Level] = 3 AND IsDisplay = 1
		ORDER BY a.[Name];
	END	

	
	
END


go


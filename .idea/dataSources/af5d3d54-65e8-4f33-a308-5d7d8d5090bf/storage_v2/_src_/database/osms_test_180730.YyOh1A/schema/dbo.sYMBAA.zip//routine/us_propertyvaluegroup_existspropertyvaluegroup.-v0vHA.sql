CREATE PROCEDURE [dbo].[US_PropertyValueGroup_ExistsPropertyValueGroup]
(
	@PropertyValueGroupId INT
)
AS
BEGIN 
	IF EXISTS (SELECT 1 FROM dbo.T_PropertyValueGroup_US WHERE PropertyValueGroupId=@PropertyValueGroupId AND IsDeleted=0)
		SELECT 1
    ELSE 
		SELECT 0 
END
go



CREATE PROC CRM_GetBankTransferRecordList
(
@CustomerName VARCHAR(50)='',
@OrderIds VARCHAR(200)='',
@CountryId INT=-1,
@CreateStartDate VARCHAR(20)='',
@CreateEndDate VARCHAR(20)='',
@AccountType INT=0,
@CreatorUserId INT=-1,
@ReceiptStartDate VARCHAR(20)='',
@ReceiptEndDate VARCHAR(20)='',
@PayUserInfo VARCHAR(200)='',
@TranNo VARCHAR(100)='',
@Type INT=0,
@Status INT=-1,
 @PageNo    INT    = 0,                              
 @PageSize  INT    = 100          
)
AS
 BEGIN
DECLARE                              
 @Sql       NVARCHAR(max),                              
 @CountSql     NVARCHAR(max),                              
 @Where      NVARCHAR(2000),                              
 @Parameters     NVARCHAR(1000), -- 动态参数                              
 @PageCount      INT,                              
 @RowCount      INT,                              
 @Start      INT, --每页的起始位置                              
 @End      INT  --每页的终止位置                              
BEGIN                              
 SET NOCOUNT ON                        

 SET @Where = ' WHERE 1=1';                            
 
 SET @Where=@Where+' and  Type=@pType';

 IF(LEN(@CustomerName)>0)
 BEGIN
		SET @CustomerName='%'+@CustomerName+'%';
 	  SET @Where=@Where+' and  CustomerName like @pCustomerName ';
 END

  IF(LEN(@OrderIds)>0)
  SET @Where=@Where+' and OrderId =@pOrderId';
  IF(@CountryId>0)
  SET @Where=@Where+' and CountryId=@pCountryId';
  IF(LEN(@CreateStartDate)>0)
  SET @Where=@Where+' and CreateTime>=@pCreateStartDate';           
    IF(LEN(@CreateEndDate)>0)
  SET @Where=@Where+' and CreateTime<@pCreateEndDate';
    IF(LEN(@ReceiptStartDate)>0)
  SET @Where=@Where+' and ReceiptTime>=@pReceiptStartDate';           
    IF(LEN(@ReceiptEndDate)>0)
  SET @Where=@Where+' and ReceiptTime<@pReceiptEndDate';        
  IF(@AccountType>0)
  SET @Where=@Where+' And AccountType=@pAccountType';
  IF(@CreatorUserId>0)
  SET @Where=@Where+' And CreatorUserId=@pCreatorUserId';
  IF(LEN(@PayUserInfo)>0)
  BEGIN
  			SET @PayUserInfo='%'+@PayUserInfo+'%';
			  SET @Where=@Where+' And PayUserInfo like @pPayUserInfo';
  END

  IF(LEN(@TranNo)>0)
  BEGIN
  SET @TranNo='%'+@TranNo+'%';
  	  SET @Where=@Where+' and TransactionNo like @pTranNo ';
  END

    IF(@Status>-1)
  SET @Where=@Where+' And Status=@pStatus';
                             
 -- 组合查询语句                              
 SET @CountSql = 'Select @pRowCount = Count(1) FROM dbo.T_BankTransferRecord a WITH(NOLOCK)';                              
                  
 SET @CountSql = @CountSql + @Where;                           
                               
 -- 拼凑动态参数                              
 SET @Parameters = N'@pRowCount INT OUT,@pType int,@pCustomerName nvarchar(100),@pOrderId NVARCHAR(200),@pCreateStartDate VARCHAR(20),@pCreateEndDate VARCHAR(20),@pCountryId INT,@pReceiptStartDate varchar(20),@pReceiptEndDate varchar(20) ,@pAccountType int,@pCreatorUserId int ,@pPayUserInfo NVARCHAR(200),@pTranNo  NVARCHAR(200),@pStatus int';                            
        
 -- 获取总记录数                              
 EXEC sp_executesql  @CountSql, @Parameters,@pRowCount = @RowCount OUT,@pType=@type, @pCustomerName =@CustomerName,@pOrderId = @OrderIds,@pCreateStartDate=@CreateStartDate,@pCreateEndDate=@CreateEndDate,@pCountryId=@CountryId,@pReceiptStartDate=@ReceiptStartDate,@pReceiptEndDate=@ReceiptEndDate,@pAccountType=@AccountType,@pCreatorUserId=@CreatorUserId,@pPayUserInfo=@PayUserInfo,@pTranNo=@TranNo,@pStatus=@Status;        
        
 -- 约定不分页                              
 if @PageSize = -1                              
 begin                              
  set @PageCount = 1                              
  set @start = 1            
  set @end = @RowCount                              
 end                              
 else                              
 begin                              
  -- 页数                              
  if isnull(@PageSize, 0) < 1                               
   set @PageSize = 30                              
  set @PageCount = (@RowCount + @PageSize - 1) / @PageSize
  if isnull(@pageNo, 0) < 1                               
   set @pageNo = 1                              
  else if isnull(@pageNo, 0) > @PageCount                              
   set @pageNo = @PageCount                              
                              
  -- 起始记录                              
  set @start = (@PageNo-1)*@PageSize + 1                              
                                
  -- 结束记录                              
  set @end = @PageNo*@PageSize                              
                               
 end                              
 -- 返回页数和总记录数                              
 Select @PageCount as PageCount,@RowCount as [RowCount];                              
        
 SET @Sql =                               
 'with cte as 
 (
 SELECT *, ROW_NUMBER() OVER(order by a.status asc, a.id desc) as RowNumber FROM dbo.T_BankTransferRecord a ' +@Where+'
 )
 select * from cte where RowNumber BETWEEN @pStart AND @pEnd
 '


 -- 拼凑动态参数                              
 SET @Parameters = N'@pType int, @pCustomerName nvarchar(100),@pOrderId NVARCHAR(200),@pCreateStartDate VARCHAR(20),@pCreateEndDate VARCHAR(20),@pCountryId INT,@pReceiptStartDate varchar(20),@pReceiptEndDate varchar(20) ,@pAccountType int,@pCreatorUserId int ,@pPayUserInfo NVARCHAR(200),@pTranNo  NVARCHAR(200),@pStatus int,@pStart int ,@pEnd int';             
        PRINT @sql;
 -- 获取结果                    
 EXEC sp_executesql @Sql,@Parameters,@pType=@type, @pCustomerName =@CustomerName,@pOrderId = @OrderIds,@pCreateStartDate=@CreateStartDate,@pCreateEndDate=@CreateEndDate,@pCountryId=@CountryId,@pReceiptStartDate=@ReceiptStartDate,@pReceiptEndDate=@ReceiptEndDate,@pAccountType=@AccountType,@pCreatorUserId=@CreatorUserId,@pPayUserInfo=@PayUserInfo,@pTranNo=@TranNo,@pStatus=@Status,@pStart = @Start,@pEnd = @End;

 END
 END


go



/**      
2014-11-06  
获得库存产品质量控制列表      
*/      
CREATE PROC [dbo].[CMS_Storage_StorageProductQualityControlList]          
(           
  @DepartmentId INT = NULL, --部门ID                     
  @CategoryId1 INT = NULL,--一级类别ID    
  @CategoryId2 INT = NULL,--二级类别ID    
  @CategoryId3 INT = NULL,--三级类别ID    
  @MaterialId INT = NULL,--材质ID      
  @AvailableStockCompareMode VARCHAR(2) = NULL, --比较有效库存时的模式：1、=,2、>3、<，4、>=,5、<=,6、!=    
  @AvailableStock INT = NULL, --有效库存量        
  @GuaranteePeriodCompareMode VARCHAR(2) = NULL, --比较剩余保质期时的模式：1、=,2、>3、<，4、>=,5、<=,6、!=    
  @GuaranteePeriod INT = NULL, --剩余保质期     
  @Position VARCHAR(MAX) = NULL,  --货架号      
  @ProductCode VARCHAR(MAX) = NULL,--商品编号      
  @ProductEnName VARCHAR(MAX) = NULL,--商品英文名称       
  @PhIsDispaly BIT = NULL,--ph是否显示    
  @PwIsDispaly BIT = NULL,--pw是否显示       
  @JlIsDispaly BIT = NULL,--jl是否显示  
  @ScatterStorage BIT = NULL,    
  @ProductCodeList VARCHAR(MAX)= NULL,
  @ProductSetCode VARCHAR(MAX) = NULL ,--商品集编号
  @ProductSetCodeList VARCHAR(MAX) = NULL , --产品集编号集合，多个编号用逗号隔开
  @UpdateTimeBegin VARCHAR(20) = NULL, --更新时间,开始
  @UpdateTimeEnd VARCHAR(20) = NULL, --更新时间,结束
  @IsProviderStorage BIT = NULL ,-- 是否供应商库存
  @StrategyId INT = NULL ,--策略
  @ProviderCode VARCHAR(MAX) = NULL,--供应商代码
  @OfflineStatus INT = NULL ,--下架状态
  @IsClearProduct BIT = NULL ,--是否清仓产品
  @IsBlackListProduct BIT = NULL ,--是否黑名单产品
  @QualityGuaranteePeriod INT = NULL,--保质期
  @PageSize INT = 50 ,  --页大小      
  @PageIndex INT = 1    --当前页号      
)            
AS            
BEGIN            
    SET NOCOUNT ON ;            
              
    DECLARE @SQL VARCHAR(max), 
			@type INT,     
            @CountSql NVARCHAR(MAX), --查询数量用      
            @FromSQL NVARCHAR(max), --查询表    
            @FromSQL2 NVARCHAR(max), --查询外部    
            @Column NVARCHAR(max), --查询字段    
            @Condition varchar(MAX), --条件
            @Condition2 varchar(MAX), --外部条件        
            @RowCount INT , @PageCount INT , @start INT ,@end INT ,      
            @IsQueryProduct BIT,@IsQueryPosition BIT,@IsQueryStrategy BIT,@IsQueryProvider BIT       
        
    --获得查询条件    
    SET @Condition = ' WHERE 1=1 ' 
    SET @Condition2 = ' WHERE 1=1 '       
    SET @IsQueryProduct  = 0        
    SET @IsQueryPosition = 0  
    SET @IsQueryStrategy = 0
    SET @IsQueryProvider = 0
    
    IF @DepartmentId IS NOT NULL       
    BEGIN       
       SET @Condition = @Condition + ' AND a.department_id=' + CONVERT(VARCHAR(10),@DepartmentId)      
    END         
    IF @AvailableStock IS NOT NULL AND @AvailableStockCompareMode IS NOT NULL     
    BEGIN       
       IF( @AvailableStockCompareMode = '!=' )    
       BEGIN    
          SET @Condition = @Condition + ' AND isnull(a.quantity,0) > isnull(a.lock_quantity,0) + ' + CONVERT(VARCHAR(10),@AvailableStock)      
          SET @Condition = @Condition + ' AND isnull(a.quantity,0) < isnull(a.lock_quantity,0) + ' + CONVERT(VARCHAR(10),@AvailableStock)      
       END     
       ELSE     
       BEGIN    
          SET @Condition = @Condition + ' AND isnull(a.quantity,0) ' + @AvailableStockCompareMode + ' isnull(a.lock_quantity,0) + ' + CONVERT(VARCHAR(10),@AvailableStock)      
       END     
    END
    IF @PwIsDispaly IS NOT NULL         
    BEGIN     
    SET @IsQueryProduct = 1        
       IF @PwIsDispaly = 1      
       BEGIN      
           SET @Condition = @Condition + ' AND b.is_display_pw =1'      
       END       
       ELSE      
       BEGIN      
            SET @Condition = @Condition + ' AND b.is_display_pw =0'      
       END       
    END      
    IF @PhIsDispaly IS NOT NULL         
    BEGIN         
    SET @IsQueryProduct = 1    
       IF @PhIsDispaly = 1      
       BEGIN      
    SET @Condition = @Condition + ' AND b.is_display_ph =1'     
       END       
       ELSE      
       BEGIN      
      SET @Condition = @Condition + ' AND b.is_display_ph =0'      
                 
       END       
    END         
    IF @JlIsDispaly IS NOT NULL         
    BEGIN         
    SET @IsQueryProduct = 1    
       IF @JlIsDispaly = 1      
       BEGIN      
    SET @Condition = @Condition + ' AND b.is_display_jl =1'     
       END       
       ELSE      
       BEGIN      
      SET @Condition = @Condition + ' AND b.is_display_jl =0'      
                 
       END       
    END 
        
    IF @ScatterStorage IS NOT NULL         
    BEGIN    
    SET @IsQueryProduct = 1    
       IF @ScatterStorage = 1      
       BEGIN      
		SET @Condition = @Condition + 'AND (isnull(a.quantity,0)- isnull(a.lock_quantity,0))>0  AND (isnull(a.quantity,0) - isnull(a.lock_quantity,0)) < b.unit_quantity'         
       END       
       ELSE      
       BEGIN      
          SET @Condition = @Condition + ' AND (isnull(a.quantity,0)- isnull(a.lock_quantity,0)) >=b.unit_quantity'    
       END       
    END        
    IF @GuaranteePeriod IS NOT NULL AND @GuaranteePeriodCompareMode IS NOT NULL     
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.guarantee_period-DATEDIFF(month,a.update_time,GETDATE())' + @GuaranteePeriodCompareMode + ' ' + CONVERT(VARCHAR(10),@GuaranteePeriod)      
    END     
    IF @ProductCode IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.code like ''' + @ProductCode + '%'''      
    END   
    IF @ProductCodeList IS NOT NULL               
    BEGIN      
    SET @IsQueryProduct = 1              
       SET @Condition = @Condition + ' AND b.code in (''' + REPLACE(@ProductCodeList,',',''',''') + ''')'              
    END              
    IF @ProductEnName IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.name like ''%' + @ProductEnName + '%'''      
    END    
    IF @CategoryId1 IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.category_id_1=' + CONVERT(VARCHAR(10),@CategoryId1)      
    END       
    IF @CategoryId2 IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.category_id_2=' + CONVERT(VARCHAR(10),@CategoryId2)      
    END       
    IF @CategoryId3 IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.category_id_3=' + CONVERT(VARCHAR(10),@CategoryId3)      
    END       
    IF @MaterialId IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.material_id=' + CONVERT(VARCHAR(10),@MaterialId)      
    END       
    IF @Position IS NOT NULL    
    BEGIN    
       SET @IsQueryPosition = 1    
       SET @Condition = @Condition + ' AND c.name like ''' + @Position + '%'''      
    END       
	IF @ProductSetCode IS NOT NULL 
    BEGIN
		SET @IsQueryProduct = 1;             
        SET @Condition = @Condition + ' AND ps.code like ''%' + @ProductSetCode + '%'''              
    END 
   
	IF @ProductSetCodeList IS NOT NULL 
    BEGIN
		SET @IsQueryProduct = 1;                       
        SET @Condition = @Condition + ' AND ps.code in (''' + REPLACE(@ProductSetCodeList, ',', ''',''') + ''')'              
    END
    --------------------------
    IF @UpdateTimeBegin IS NOT NULL
	BEGIN
		SET @Condition = @Condition + ' AND a.update_time >= '''+ CONVERT(VARCHAR(20),@UpdateTimeBegin)+'''' ;
	END
	IF @UpdateTimeEnd IS NOT NULL
	BEGIN
		SET @Condition = @Condition + ' AND a.update_time <= '''+ CONVERT(VARCHAR(20),@UpdateTimeEnd)+'''' ; 	
	END
	IF @IsProviderStorage IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1
       IF  @IsProviderStorage = 1
       BEGIN
		SET @Condition = @Condition + ' AND b.is_provider_stock = 1 ' ;
	   END
	   ELSE
	   BEGIN
		SET @Condition = @Condition + ' AND b.is_provider_stock = 0 ' ;
	   END 
    END
    IF @StrategyId IS NOT NULL       
    BEGIN
	   SET @IsQueryStrategy = 1       
       SET @Condition = @Condition + ' AND product_strategy.department_id =' + CONVERT(VARCHAR(10),@StrategyId)
    END 
    IF @OfflineStatus IS NOT NULL       
    BEGIN       
       SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.offline_status = ' + CONVERT(VARCHAR(10),@OfflineStatus);      
    END
    IF @IsBlackListProduct IS NOT NULL
    BEGIN
		IF @IsBlackListProduct = 1
		BEGIN
		SET @Condition = @Condition + ' AND exists (select id from dbo.blacklist_product WITH(NOLOCK) where blacklist_product.product_id = a.product_id )' ;  
		END
		ELSE
		BEGIN
		SET @Condition = @Condition + ' AND not exists (select id from dbo.blacklist_product WITH(NOLOCK) where blacklist_product.product_id = a.product_id )' ;  
		END  
    END
    IF @IsClearProduct IS NOT NULL
    BEGIN
		IF @IsClearProduct = 1
		BEGIN
		SET @Condition = @Condition + ' AND exists (select id from dbo.product_promote WITH(NOLOCK) where product_promote.type = 3 and product_promote.product_id = a.product_id  )' ;   
		END
		ELSE
		BEGIN
		SET @Condition = @Condition + ' AND not exists (select id from dbo.product_promote WITH(NOLOCK) where product_promote.type = 3 and product_promote.product_id = a.product_id  )' ; 
		END   
    END
    IF @ProviderCode IS NOT NULL
    BEGIN
		SET @IsQueryProvider = 1
		SET @Condition = @Condition + ' AND  provider.code like ''%' + @ProviderCode + '%''' 
    END
    IF @QualityGuaranteePeriod IS NOT NULL
    BEGIN
	   SET @IsQueryProduct = 1    
       SET @Condition = @Condition + ' AND b.guarantee_period = ' + CONVERT(VARCHAR(10),@QualityGuaranteePeriod); 
    END
    
    IF @DepartmentId IS NOT NULL
    BEGIN
		SELECT  @type = [type] FROM dbo.department WHERE id = @DepartmentId
		IF @type = 1
		BEGIN
			 SET @FromSQL =' FROM department_storage a WITH (NOLOCK)' 
			 SET @FromSQL2 =' INNER JOIN department_view_storage a WITH (NOLOCK) ON temp.id = a.id'    
		END
		ELSE IF @type =2
		BEGIN
		 SET @FromSQL =' FROM logistics_storage a WITH (NOLOCK)' 
		 SET @FromSQL2 =' INNER JOIN logistics_view_storage  a WITH (NOLOCK) ON temp.id = a.id'    
		END
		ELSE
		BEGIN
		 SET @FromSQL =' FROM storage a WITH (NOLOCK)' 
		  SET @FromSQL2 =' INNER JOIN view_storage a WITH (NOLOCK) ON temp.id = a.id'    
		end
	END
	ELSE
	BEGIN
	  --设置条件查询必须关联的表        
	 SET @FromSQL =' FROM storage a WITH (NOLOCK)'   
	  SET @FromSQL2 =' INNER JOIN view_storage a WITH (NOLOCK) ON temp.id = a.id'   
	END
    
    IF(@IsQueryProduct = 1)    
    BEGIN    
         SET @FromSQL = @FromSQL + ' INNER JOIN product b WITH(NOLOCK) ON b.id = a.product_id'    
    END       
    IF(@IsQueryPosition = 1)    
    BEGIN    
         SET @FromSQL = @FromSQL + ' INNER JOIN storage_position c WITH(NOLOCK) ON c.id = a.position_id'    
    END
    IF(@IsQueryStrategy = 1 OR @IsQueryProvider = 1)    
    BEGIN    
         SET @FromSQL = @FromSQL +' INNER JOIN product_strategy WITH ( NOLOCK ) ON product_strategy.product_id = a.product_id ' 
    END 
    IF(@IsQueryProvider = 1)    
    BEGIN    
        --SET @FromSQL = @FromSQL +' INNER JOIN product_strategy WITH ( NOLOCK ) ON product_strategy.product_id = a.product_id '
        SET @FromSQL = @FromSQL +' LEFT JOIN product_provider WITH ( NOLOCK ) ON product_provider.product_id = a.product_id AND product_provider.department_id = product_strategy.department_id '
        SET @FromSQL = @FromSQL +' LEFT JOIN provider WITH ( NOLOCK ) ON provider.id = product_provider.provider_id '
    END  
      
   IF @ProductSetCode IS NOT NULL OR @ProductSetCodeList IS NOT NULL
	BEGIN
		SET @FromSQL = @FromSQL + ' LEFT JOIN product_set as ps WITH(NOLOCK) on ps.id = b.product_set_id '
	END    
    --求符合条件的总数    
    SET @CountSql = ' SELECT @RowCount = count(a.id) ' + @FromSQL + @Condition      
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
          
--     SELECT @CountSql      
           
    IF ISNULL(@PageSize, 0) < 1             
        SET @PageSize = 50            
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize            
    IF ISNULL(@PageIndex, 0) < 1             
        SET @PageIndex = 1            
    ELSE             
    IF ISNULL(@PageIndex, 0) > @PageCount             
        SET @PageIndex = @PageCount            
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1            
    SET @end = @PageIndex * @PageSize         
        
    --设置取字段信息必须关联的表    
      
    SET @FromSQL2 = @FromSQL2 + ' INNER JOIN product b WITH(NOLOCK) ON b.id = a.product_id'    
    SET @FromSQL2 = @FromSQL2 + ' LEFT JOIN storage_position c WITH(NOLOCK) ON c.id = a.position_id'
    --SET @FromSQL2 = @FromSQL2 + ' LEFT JOIN product_unit_convert cunit WITH(NOLOCK) ON cunit.product_id = a.product_id'       
    SET @FromSQL2 = @FromSQL2 +' INNER JOIN  product_strategy WITH(NOLOCK) on product_strategy.product_id = a.product_id  '
    SET @FromSQL2 = @FromSQL2 +' left JOIN  product_provider WITH(NOLOCK) on product_provider.product_id = a.product_id and product_provider.department_id = product_strategy.department_id '
    SET @FromSQL2 = @FromSQL2 +' left JOIN provider WITH(NOLOCK) on provider.id = product_provider.provider_id'
    SET @FromSQL2 = @FromSQL2 +' left JOIN product_set WITH(NOLOCK) on product_set.id = b.product_set_id '    
        
    --设置需要取的字段信息     
    SET @Column = 'a.id,       
                   a.department_id as departmentId,    
       a.product_id AS productId,      
       a.quantity,    
       a.position_id AS positionId,      
       a.update_time AS updateTime,      
       a.quantity - isnull(a.lock_quantity,0) AS availableQuantity,      
       a.lock_quantity AS lockQuantity,      
       a.quality_remark as remark ,
       b.code AS productCode,    
       b.name AS productName,    
       b.original_name AS productOriginalName,    
       b.primary_picture_code AS primaryPictureCode,    
       b.color_card_picture_code AS colorCardPictureCode,    
       b.material_id AS materialId,    
       (Convert(varchar(10),b.unit_quantity)+'' '' + b.unit) AS productUnit,    
       b.guarantee_period AS guaranteePeriod,
       b.cost_price as productCostPrice,
       c.name AS position,
       --cunit.unit AS newProductUnit ,
      -- ROUND(cunit.convert_rate * (a.quantity - isnull(a.lock_quantity,0)),2) AS newStorageQty,
       b.is_provider_stock AS isProviderStock,
       provider.id as providerId,
       provider.code as providerCode,
       b.is_display_ph AS isDisplayPH,
       b.is_display_pw AS isDisplayPW,
       b.is_display_jl AS isDisplayJL,
       product_strategy.department_id as strategyDepartmentId ,
       product_set.code as productSetCode 
       '    
     
     
    --组装基本查询的SQL    
    SET @SQL= 'SELECT * from (        
                       SELECT  a.id,      
                       ROW_NUMBER() OVER(ORDER BY a.update_time DESC) rowIndex'        
            + @FromSQL +  @Condition + ') temp2         
      where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and ' + CAST(@end AS NVARCHAR(10))        
       
    --组装最终取数的SQL    
    SET @SQL= 'select ' + @Column + ' from (' + @SQL + ') temp ' + @FromSQL2    
               + ' ORDER BY rowIndex'    
--     SELECT @SQL      
    EXEC(@SQL);                
    PRINT @SQL;     
    select @RowCount          
END


go


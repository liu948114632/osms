

/*--------------------------------------------
  [备注]:  增加包裹
---------------------------------------------*/
CREATE PROC [dbo].[CRM_Order_PackageAdd]
(
	@OrderId			VARCHAR(20),
	@CustomerName		VARCHAR(50),
	@Email				VARCHAR(50),
	@DeliveryId			INT,
	@TraceNo			VARCHAR(200),
	@Status				INT,
	@Disabled			BIT,
	@DueDate			DATETIME,
	@Remark				VARCHAR(500)
)
AS
BEGIN	

	IF EXISTS(SELECT * FROM dbo.T_OrderPackage WHERE OrderId = @OrderId)
		RETURN;
		
	INSERT INTO dbo.T_OrderPackage (
		OrderId,
		TraceNo,
		CustomerName,
		Email,
		DeliveryId,
		[Status],
		[Disabled],
		DealStatus,
		QuestionStatus,
		IsSendMail,
		IsConfirm,
		DueDate,
		UpdateDate,
		Remark
	) VALUES ( 
		/* OrderId - VARCHAR(14) */ @OrderId,
		/* TraceNo - varchar(255) */ @TraceNo,
		/* CustomerName - varchar(100) */ @CustomerName,
		/* Email - varchar(100) */ @Email,
		/* DeliveryId - int */ @DeliveryId,
		/* Status - tinyint */ @Status,
		/* Disabled - bit */ @Disabled,
		/* DealStatus - tinyint */ 0,
		/* QuestionStatus - tinyint */ 0,
		/* IsSendMail - bit */ 0,
		/* IsConfirm - tinyint */ 0,
		/* DueDate - smalldatetime */ @DueDate,
		/* UpdateDate - smalldatetime */ @DueDate,
		/* Remark - varchar(255) */ @Remark ); 
END
go









/*----------------------------------------------------------------------------
报表统计-考核-前三个月新上传的商品在当月的平均积压库存
frh 创建
[dbo].[up_Report_Assess_NewProductsAvgOverstock] '2009-10-01','2009-11-01','gz'
-------------------------------------------------------------------------------*/
CREATE procEDURE [dbo].[up_Report_Assess_NewProductsAvgOverstock]
(
	@StartTime		DateTime,
	@EndTime		DateTime,
	@Stock			NVARCHAR(10)
)
As
Begin
	Declare @StockId INT;
	
	SET @StockId  = (SELECT ISNULL(Id,0) FROM dbo.C_Stock WHERE [Short] = @Stock);
	If (@StockId > 0)
	Begin
		-- 由当前月分转换为前三个月的时间，以统计前三个月上传的新商品
		Set @EndTime = @StartTime;
		Set @StartTime = dateadd(month,-3,@EndTime);
		
		/*
		with
		Items(UserId,ItemKeyId,BasePrice) as 
		(
			SELECT c.UserId,b.ItemKeyId,b.BasePrice FROM b_Item a
			JOIN t_item b ON a.ItemCode = b.ItemCode AND a.StockId = @StockId
			Left Join B_ItemStepTimeLog c On a.id = c.ItemId
			WHERE c.AddTime >= @StartTime AND c.AddTime <= @EndTime
		) ,  
		StorageToatlPrice (ProductId,Total) AS
		(
			SELECT 
				a.ProductId ,
				cast(Sum((a.StorageQty  - isnull(d.LockQty,0) - isnull(e.LockQtyByAssign,0) - isnull(f.LockQtyByTidyUp,0) - isnull(h.LockQtyByCrap,0)) * b.BasePrice) as Money) as Total 
			FROM b_Storage a 
				Join Items b on b.ItemKeyId = a.ProductId AND a.StorageQty > 0
				Left Join dbo.v_LockQty d on d.StockId = a.StockId and b.ItemKeyId = d.ProductId
				Left Join dbo.v_LockQtyByAssign e on e.StockId = a.StockId and b.ItemKeyId = e.ProductId
				Left Join dbo.v_LockQtyByTidyUp f on f.StockId = a.StockId and b.ItemKeyId = f.ProductId
				Left Join dbo.V_LockQtyByCrapProduct h ON h.StockId = a.StockId  AND b.ItemKeyId = h.ProductId
			WHERE 
				a.StorageQty  - isnull(d.LockQty,0) - isnull(e.LockQtyByAssign,0) - isnull(f.LockQtyByTidyUp,0) - isnull(h.LockQtyByCrap,0) > 0
			GROUP BY a.ProductId -- 可用库存
		)

		Select b.FirstName as UserName,a.NewCount,a.TotalPrice,Cast(a.TotalPrice/a.NewCount as Money) AvgOverstock
		From
		(
			Select a.UserId,ISNULL(Sum(b.Total),0) as TotalPrice,Count(1) as NewCount
			From Items a LEFT JOIN StorageToatlPrice b ON a.ItemKeyId = b.ProductId
			GROUP BY a.UserId
		) a
		LEFT JOIN b_User b On a.UserId = b.Id Order BY b.FirstName
		*/
		
		with
		Items(UserId,ProductDataId,BasePrice) AS 
		(
			SELECT c.UserId,b.ProductDataId,b.BasePrice FROM dbo.C_Product a WITH(NOLOCK)
			JOIN dbo.D_Product b WITH(NOLOCK) ON a.ItemCode = b.Code AND a.StockId = @StockId
			JOIN dbo.C_ProductStepTimeLog c WITH(NOLOCK) On a.id = c.ItemId
			WHERE c.AddTime >= @StartTime AND c.AddTime <= @EndTime
		) ,  
		StorageToatlPrice (ProductDataId,Total) AS
		(
			SELECT 
				a.ProductDataId,
				CAST((v1.StorageQty - ISNULL(v2.Quantity,0) - ISNULL(v3.Quantity,0) - ISNULL(v4.CrapQty,0) - ISNULL(v5.Quantity,0) - ISNULL(v6.Quantity,0))*a.BasePrice AS DECIMAL(18,4)) 
			FROM Items a 
				JOIN dbo.C_Storage v1 WITH(NOLOCK) ON a.ProductDataId = v1.ProductDataId AND v1.StorageQty > 0 AND v1.StockId = 4 -- 中心仓库积压库存
				LEFT JOIN dbo.V_CMS_StockOutPlanQtyNoOrder v2 -- 非订单出库的出库单冻结
					ON a.ProductDataId = v2.ProductDataId AND v2.StockId = 4
				LEFT JOIN dbo.V_CMS_TidyUpPlanQty v3  -- 中心仓库整理上架单占用的冻结数
					ON a.ProductDataId = v3.ProductDataId
				--LEFT JOIN dbo.C_StorageCrap v4 -- 中心仓库待报废商品冻结,即将生成报废出库单的
				--	ON a.ProductDataId = v4.ProductDataId
				LEFT JOIN dbo.V_CMS_LossProfitQty v4 WITH(NOLOCK) -- 损益商品冻结
					ON a.ProductDataId = v4.ProductDataId AND v4.StockId = 4 
				LEFT JOIN dbo.V_CMS_AssignmentPlanQty v5 -- 中心仓库预分配单占用冻结数
					ON a.ProductDataId = v5.ProductDataId
				LEFT JOIN dbo.V_CMS_OrderAssignQty v6 -- 中心仓库订单占用的冻结
					ON a.ProductDataId = v6.ProductDataId
			WHERE 
				v1.StorageQty - ISNULL(v2.Quantity,0) - ISNULL(v3.Quantity,0) - ISNULL(v4.CrapQty,0) - ISNULL(v5.Quantity,0) - ISNULL(v6.Quantity,0) > 0
		)

		-- 返回最终结果
		Select b.FirstName as UserName,a.NewCount,a.TotalPrice,Cast(a.TotalPrice/a.NewCount as Money) AvgOverstock
		From
		(
			Select a.UserId,ISNULL(Sum(b.Total),0) AS TotalPrice,Count(1) AS NewCount
			From Items a LEFT JOIN StorageToatlPrice b ON a.ProductDataId = b.ProductDataId
			GROUP BY a.UserId
		) a
		JOIN dbo.B_User b On a.UserId = b.Id 
		ORDER BY b.FirstName;
	End
End


go


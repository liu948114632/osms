
/*
*	如果订单中 多个需质检产品 对应不同的箱位
	显示形式：{箱位1，箱位2，….}
	如果订单中 所有需质检产品 对应相同的箱位
	显示形式：{箱位}
**/
CREATE function [dbo].[f_position_app_str](@ID int)
 returns varchar(8000)
 AS
 begin
   declare @ret varchar(8000)
   set @ret = ''
   select @ret = @ret+','+rtrim(position) from dbo.order_item_group where order_id = @ID GROUP BY position
   set @ret = case when len(@ret)>0 then stuff(@ret,1,1,'') else @ret end
   return @ret 
 end

go


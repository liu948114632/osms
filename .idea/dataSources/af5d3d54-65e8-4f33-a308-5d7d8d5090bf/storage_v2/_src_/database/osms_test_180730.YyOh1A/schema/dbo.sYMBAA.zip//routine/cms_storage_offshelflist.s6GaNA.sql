  
CREATE PROCEDURE CMS_Storage_OffShelfList(
     @Code varchar(30)= null,--下架单号
     @Status int = null, ---下架单状态
     @ProductCode varchar(max) = null,--产品编号
     @ProductCodeList varchar(max) = null,--产品编号列表
     @CreateUserID int = null,--创建人    
	 @CreateTimeBegin VARCHAR(20) = NULL,--创建时间始        
	 @CreateTimeEnd VARCHAR(20) = NULL,--创建时间止   
     @ConfirmUserId int = null,--校对人ID
	 @offShelfUserId INT = NULL ,--下架人
     @ConfirmTimeBegin varchar(20) = null,--下架时间起
     @ConfirmTimeEnd varchar(20) = null,--下架时间止
     @DepartmentId int = null,--部门ID
     @Type INT =NULL,
	 @IsVip INT = NULL ,
     @OrderCode VARCHAR(100) =NULL,
	 @PageSize INT = 50 ,            
	 @PageIndex INT = 1          
)
as
begin
	SET NOCOUNT OFF  
	DECLARE        
		@SQL VARCHAR(max),                        
		@CountSql NVARCHAR(MAX), --查询数量用                        
		@FromSQL NVARCHAR(max), --查询内表                      
		@Column NVARCHAR(max), --取的字段                      
		@Condition varchar(MAX), --条件                         
		@RowCount INT ,           
		@PageCount INT ,           
		@start INT ,          
		@end INT;     
	 
	      --设置查询条件        
	SET @Condition = ' WHERE 1=1 ';
	IF @IsVip  IS NOT NULL
    BEGIN
		set @Condition = @Condition + ' AND a.is_vip=' + convert(varchar(10), @IsVip);
    END
	if @Code is not null
	begin
		set @Condition = @Condition + ' AND a.code like ''%' + @Code + '%''';
	end 
	if @Status is not null
	begin
		set @Condition = @Condition + ' AND a.status=' + convert(varchar(10), @Status);
	end 
	if @ProductCode is not null
	begin
		set @Condition = @Condition + ' AND EXISTS(SELECT it.id FROM dbo.off_shelf_item it WITH(NOLOCK) LEFT JOIN dbo.product p WITH(NOLOCK) '
		 + 'ON it.product_id=p.id WHERE it.off_shelf_id=a.id and p.code LIKE '''+ @ProductCode+ '%'')';
	end 
	if @ProductCodeList is not null
	begin
		set @Condition = @Condition + ' AND EXISTS(SELECT it.id FROM dbo.off_shelf_item it WITH(NOLOCK) LEFT JOIN dbo.product p WITH(NOLOCK)  '
		 + 'ON it.product_id=p.id WHERE it.off_shelf_id=a.id and p.code in ('''+ REPLACE(@ProductCodeList,',',''',''')+ '''))';
	end 
	if @CreateUserID is not null
	begin
		set @Condition = @Condition + ' AND a.creator_id=' + convert(varchar(10), @CreateUserID);
	end 
	if @CreateTimeBegin is not null
	begin
		set @Condition = @Condition + ' AND a.create_time>=''' + CONVERT(VARCHAR(20), @CreateTimeBegin) + '''';
	end 
	if @CreateTimeEnd is not null
	begin
		set @Condition = @Condition + ' AND a.create_time<=''' + CONVERT(VARCHAR(20), @CreateTimeEnd) + '''';
	end 
	
	--校对人
	IF @ConfirmUserId is not null
	begin
		set @Condition = @Condition + ' AND  exists( select top 1 id from off_shelf_item it WITH(NOLOCK) where  it.off_shelf_id=a.id  and it.collect_user_id='+CONVERT(VARCHAR(10), @ConfirmUserId) +' )';
	end 
	IF @offShelfUserId is not null
	begin
		set @Condition = @Condition + ' AND  exists( select top 1 id from off_shelf_item it WITH(NOLOCK) where  it.off_shelf_id=a.id  and it.off_shelf_user_id='+CONVERT(VARCHAR(10), @offShelfUserId) +' )';
	end 

	if @ConfirmTimeBegin is not null
	begin
		set @Condition = @Condition + ' AND a.confirm_time>=''' + CONVERT(VARCHAR(20), @ConfirmTimeBegin) + '''';
	end 
	if @ConfirmTimeEnd is not null
	begin
		set @Condition = @Condition + ' AND a.confirm_time<=''' + CONVERT(VARCHAR(20), @ConfirmTimeEnd) + '''';
	end 
	if @DepartmentId is not null
	begin
		set @Condition = @Condition + ' AND a.department_id=' + convert(varchar(10), @DepartmentId);
	end 
	IF @Type IS NOT NULL
	BEGIN
		SET @Condition = @Condition+' And a.type='+ convert(varchar(10), @Type);
	END
	IF @OrderCode IS  NOT  NULL 
	BEGIN
		set @Condition = @Condition + ' AND EXISTS(SELECT it.id FROM dbo.off_shelf_item it WITH(NOLOCK) LEFT JOIN dbo.view_all_storage_task s WITH(NOLOCK) '
		 + 'ON it.storage_task_id=s.id LEFT JOIN dbo.[order] o WITH(NOLOCK) ON o.id = s.order_id WHERE it.off_shelf_id=a.id and o.code LIKE '''+ @OrderCode+ '%'')';
	END
	
	
	--设置查询列 
	set @Column = 'a.id,
				   a.code, 
				   a.item_count itemCount,
				   a.status,
				   a.type,
				   a.creator_id creatorId,
				   a.create_time createTime,
				   a.confirmor_id confirmorId,
				   a.is_quick_collect as isQuickCollect,
				   a.is_vip as isVip,
				   case when a.status<>20 and not exists(select top 1 id from off_shelf_item item where item.off_shelf_id=a.id and item.collate_quantity>0 ) then 1 else 0 end as canDelete,
				   a.confirm_time confirmTime';
	
	           
	--设置查询内表         
	SET @FromSQL = '';            
	SET @FromSQL = ' FROM off_shelf a with(nolock)';             
	--查询记录数          
	SET @CountSQL = '';          
	SET @CountSQL = 'SELECT @RowCountOUT=count(a.id) ' + @FromSQL + @Condition;          
	--print @CountSQL;          
	EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;                   

	--查询的分页条件          
	IF ISNULL(@PageSize, 0) < 1                                 
		SET @PageSize = 50                                
	SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
	IF ISNULL(@PageIndex, 0) < 1                                 
		SET @PageIndex = 1                                
	ELSE                                 
		IF ISNULL(@PageIndex, 0) > @PageCount                                 
	SET @PageIndex = @PageCount                                
	SET @Start = ( @PageIndex - 1 ) * @PageSize + 1          
	SET @End = @PageIndex * @PageSize      

	--组装查询语句          
	SET @SQL = 'SELECT a.id, ROW_NUMBER() OVER (ORDER BY a.status, a.create_time) RowIndex ' + @FromSQL + @Condition;          

	SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp left join off_shelf a with(Nolock) on temp.id=a.id WHERE RowIndex between ' 
		+ CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';          
	--PRINT @SQL          
	EXEC(@SQL);                                  
	SELECT @RowCount  
	  
	set nocount on
end
go



CREATE PROCEDURE CMS_Get_product_By_Codes
(
 @ProductCodes NVARCHAR(max) =null
)
AS 
BEGIN
 SET NOCOUNT ON;
 DECLARE  @SQL varchar(MAX)
	SET @SQL ='SELECT id,code FROM product WHERE';
	SET @SQL = @SQL +' code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')'  
	
	exec(@SQL)	
END

go


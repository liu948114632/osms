
/**
	@authoer whw
	@date 2016-5-30
	@desc 自动移除过期的促销

*/
CREATE PROC dbo.proc_auto_exit_product_promote    
AS     
    BEGIN        
        DECLARE @ProductStr VARCHAR(MAX) ;      
        SET @ProductStr = '' ;      
              
        IF OBJECT_ID('#temp_product_promote_exit_') IS NOT NULL     
            DROP TABLE #temp_product_promote_exit_ ;      
              
        SELECT  a.*  
        INTO    #temp_product_promote_exit_    
       FROM (        
		
			SELECT * FROM product_promote a  WHERE end_time<=DATEADD(hh,-15,GETDATE())
			) a
    
  INSERT INTO dbo.product_promote_ph_history  
                        ( product_id ,  
                          discount ,  
                          start_time ,  
                          end_time ,
                          Type ,  
                          is_bind_storage ,  
                          begin_storage ,  
                          join_user_id ,  
                          join_time ,  
                          is_promote ,
                          site_offshelf_time ,
                          promote_type,
						  end_promote_time
                        )   
                  SELECT product_id,  
					     discount,  
						 start_time,  
                         end_time ,  
                          type ,  
                          is_bind_storage ,  
                          begin_storage ,  
                          join_user_id ,  
                          join_time ,  
                          is_promote,
                          site_offshelf_time,
                          0 ,GETDATE()
                          FROM  #temp_product_promote_exit_  

	UPDATE dbo.ph_product SET is_promotional=0
		FROM dbo.ph_product INNER JOIN #temp_product_promote_exit_ 
		ON #temp_product_promote_exit_.product_id = ph_product.product_id
   --清除标示                                                 
          DELETE a FROM dbo.product_promote  AS a  
          INNER JOIN #temp_product_promote_exit_ b ON a.id = b.id                            
      
         --插入通讯日志   
         SELECT  @ProductStr = STUFF(( SELECT ','  
                                                + CONVERT(VARCHAR(50),id)   
                                                  FROM  #temp_product_promote_exit_   
                                     FOR XML PATH('')), 1, 1, '');           
       
            
        IF LEN(@ProductStr) > 0     
            BEGIN           
               INSERT  INTO dbo.communication_log  
                        ( command ,  
                          object_id ,  
                          status ,  
                          create_time ,  
                          operator ,  
                          model_type ,  
                          execute_time ,
                          promote_type   
               )  
                VALUES  ( 'PH_END_PROMOTE' ,  
                          @ProductStr ,  
                          1 ,  
                          GETDATE() ,  
                          0 ,  
                          'PROMOTE' ,  
                          NULL  ,
                          0 
                        )   
            END    
                                                                                               
        
         
        DROP TABLE #temp_product_promote_exit_ ;      
    END

go


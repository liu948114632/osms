/**
	@author whw
	@Date 2016-10-28
*/
CREATE PROC dbo.proc_search_fba_picking_count
(
	@pageSize INT=50,
	@currentPage INT=1,
	@department INT=NULL,
	@orderCode VARCHAR(MAX)=NULL,
	@status INT=NULL,
	@enableProcessDateBegin VARCHAR(100)=NULL,
	@enableProcessDateEnd VARCHAR(100)=NULL,
	@receiptGoodsDateBegin VARCHAR(100)=NULL,
	@receiptGoodsDateEnd VARCHAR(100)=NULL,
	@pickingUserId INT=NULL,
	@receiptGoodsUserId INT=NULL,
	@hasPosition INT=NULL,
	@position VARCHAR(100) =NULL,
	@productCode VARCHAR(MAX)=NULL,
	@pickingDateBegin VARCHAR(100)=NULL,
	@pickingDateEnd VARCHAR(100)=NULL,
	@checking INT=NULL,
	@all BIT=NULL
)
AS
BEGIN
	DECLARE @SQL VARCHAR(MAX) ,  
            @CountSql NVARCHAR(MAX) , --查询数量用                            
            @FromSQL NVARCHAR(MAX) , --查询表                          
            @Condition VARCHAR(MAX) , --条件                             
            @RowCount INT ,  
            @PageCount INT ,   
            @start INT ,  
            @end INT ,  
			@parmas VARCHAR(max)='',
			@sql2 VARCHAR(max)=''
	;
	SET @parmas=' where 1=1 '
	SET @sql='select f.* into #temp  FROM v_fba_order_picking f ';

	
		IF @hasPosition IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.has_position='+CONVERT(VARCHAR(100),@hasPosition)
		END

		IF @department IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.department_id='+CONVERT(VARCHAR(100),@department)
		END

		IF @orderCode IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.order_code LIKE ''%'+CONVERT(VARCHAR(100),@orderCode)+'%'''
		END

		IF @status IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.status='+CONVERT(VARCHAR(100),@status)
		END

		IF @enableProcessDateBegin IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.fba_enable_picking_date>='''+CONVERT(VARCHAR(100),@enableProcessDateBegin)+''''
		END

		IF @position IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.position LIKE ''%'+CONVERT(VARCHAR(100),@position)+'%'''
		END
		IF @enableProcessDateEnd IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.fba_enable_picking_date<='''+CONVERT(VARCHAR(100),@enableProcessDateEnd)+''''
		END

		IF @pickingUserId IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.picking_user_id='+CONVERT(VARCHAR(100),@pickingUserId)
		END

		IF @productCode IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.product_code LIKE ''%'+CONVERT(VARCHAR(100),@productCode)+'%'''
		END

		IF @receiptGoodsUserId IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.receipt_goods_user_id='+CONVERT(VARCHAR(100),@receiptGoodsUserId)
		END

		IF @receiptGoodsDateBegin IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.receipt_goods_date>='''+CONVERT(VARCHAR(100),@receiptGoodsDateBegin)+''''
		END


		IF @receiptGoodsDateEnd IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.receipt_goods_date<='''+CONVERT(VARCHAR(100),@receiptGoodsDateEnd)+''''
		END

		IF @pickingDateBegin IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.picking_date>='''+CONVERT(VARCHAR(100),@pickingDateBegin)+''''
		END


		IF @pickingDateEnd IS NOT NULL
		BEGIN
			SET @parmas=@parmas+' AND f.picking_date<='''+CONVERT(VARCHAR(100),@pickingDateEnd)+''''
		END

		IF @checking IS NOT NULL
		BEGIN
			SET @sql=@sql+' LEFT JOIN dbo.check_product cp ON cp.order_item_id=f.order_item_id '
			IF @checking>0
			BEGIN
				SET @parmas=@parmas+' AND cp.status=1 '
			END
			ELSE
			BEGIN
				SET @parmas=@parmas+' AND (cp.status IS NULL OR cp.status<>1) '
			END
		END


	
	--IF @currentPage=0 OR @currentPage IS NULL
	--BEGIN
	--    SET @currentPage=1
	--END

	--IF @pageSize IS NULL
	--BEGIN
	--    SET @pageSize=50
	--END


	--SET @start=(@currentPage-1)*@pageSize
	--SET @end=@pageSize


	 IF ISNULL(@PageSize, 0) < 1                         
  SET @PageSize = 50                        
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                        
    IF ISNULL(@currentPage, 0) < 1                         
        SET @currentPage = 1                        
    ELSE                         
    IF ISNULL(@currentPage, 0) > @PageCount                         
        SET @currentPage = @PageCount                        
    SET @Start = ( @currentPage - 1 ) * @PageSize + 1                        
    SET @End = @currentPage * @PageSize   

	SET @sql=@sql+@parmas+' ORDER BY f.status ASC,f.enable_process_date_sort ASC '
	EXEC (@sql)
	
	DECLARE @sql1 NVARCHAR(max)=@sql+'
	SELECT @RowCount=COUNT(DISTINCT order_code) from #temp
	'
	EXEC sp_executesql @sql1, N'@RowCount INT OUT', @RowCount OUT;

	--统计所有
	IF @all=1
	BEGIN
	    SET @End=@RowCount
	END

	DECLARE @column VARCHAR(max)=NULL;
	DECLARE @table VARCHAR(max)=NULL;
	SET @column='
		SELECT o.code AS orderCode,min(o.id) as orderId,min(o.fba_picking_remark)as fbaPickingRemark,min(o.fba_enable_picking_date) as fbaEnablePickingDate,
		MIN(o.picking_processing_group) as pickingProcessingGroup,
	MIN(o.department_id) AS department,
	SUM(CASE WHEN oi.order_quantity>ISNULL(oi.zcq_department_received_qty,0) AND oi.status<>12 and o.status<50  AND(co.status IS NULL OR  co.status<>1) 
	THEN 1 ELSE 0 END )AS inTheStock,  --备货中项数
	SUM(CASE WHEN oi.order_quantity<=ISNULL(oi.zcq_department_received_qty,0)  AND oi.status<>12 
		AND (cp.status IS NOT NULL OR oi.processing_status=20 OR oi.processing_status IS NULL)  OR co.status=1
		THEN 1 ELSE 0 END) AS checking, --待质检
	SUM(CASE WHEN f.status=2 AND oi.order_quantity<=ISNULL(oi.zcq_department_received_qty,0) AND oi.status=6
		AND cp.status IS  NULL AND oi.processing_status <>20 AND(co.status IS NULL OR  co.status<>1)
		 THEN 1 ELSE 0 END) AS canProcess , --	可处理
	SUM(CASE WHEN f.status=3 AND oi.status<>12 AND oi.order_quantity<=ISNULL(oi.zcq_department_received_qty,0)
	AND cp.status IS  NULL AND oi.processing_status <>20 
	 THEN 1 ELSE 0 END) AS Picked ,--	已取货
	SUM(CASE WHEN f.status=4 THEN 1 ELSE 0 END) AS complated  --已完成
	
	'
	
	SET @table='

	FROM dbo.[order] o WITH(NOLOCK)  
	INNER JOIN dbo.order_item oi WITH(NOLOCK) ON o.id=oi.order_id 
	LEFT JOIN dbo.check_product cp WITH(NOLOCK) ON cp.order_item_id=oi.id AND cp.status=1 
	LEFT JOIN dbo.fba_order_item_picking f WITH(NOLOCK) ON f.order_item_id=oi.id 
	LEFT JOIN dbo.check_order co ON co.order_id=o.id
	INNER JOIN 

	( SELECT order_code FROM 
	(
		SELECT order_code,ROW_NUMBER() OVER(ORDER BY order_code DESC) RowIndex FROM 
		(SELECT DISTINCT order_code FROM #temp) AS a 
	 ) s  WHERE  RowIndex BETWEEN '  + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + '  
	 ) t

	--(SELECT order_code FROM (SELECT DISTINCT order_code FROM #temp) AS a 
	--ORDER BY 1 OFFSET('+CONVERT(VARCHAR(10),@start)+') ROW FETCH NEXT '+CONVERT(VARCHAR(10),@end)+' rows only ) t 
	ON t.order_code=o.code
	GROUP BY o.code 
	
	--DROP TABLE #temp
	'
	IF @all =1
	BEGIN
	    SET @sql2=@sql+'
			SELECT count(*) as orderNum,
       SUM(l.inTheStock) as inTheStock,
       SUM(l.checking) as checking,
       SUM(l.canProcess) as canProcess,
       SUM(l.Picked) as Picked,
       SUM(l.complated) as complated FROM 
		(
		'+@column+@table+'
		 ) l 
			
		'
		EXEC (@sql2)
	END
	ELSE
	BEGIN
		SET @sql2=@sql+@column+@table
	   	EXEC (@sql2)
		SELECT  @RowCount;
	END
	PRINT @sql2 
END
go


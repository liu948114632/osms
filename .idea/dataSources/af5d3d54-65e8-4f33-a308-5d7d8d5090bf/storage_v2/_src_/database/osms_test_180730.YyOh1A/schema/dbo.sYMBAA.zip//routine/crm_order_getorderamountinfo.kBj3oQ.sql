


    
    
/*----------------------------------------------------  
[备注]:获取订单汇总信息：商品总金额、总重量（包括物理重量、体积重量）、总运费（包括偏远非）、总附加费、总已付款  
[创建人]:LXH  
[创建时间]:2012-10-20  
------------------------------------------------------*/  
CREATE PROC [dbo].[CRM_Order_GetOrderAmountInfo]   
(  
 @OrderId    VARCHAR(20) -- 订单编号  
)  
AS  
DECLARE   
 @DeliveryId    INT,            -- 货运方式  
 @CountryId    INT,            -- 货运国家  
 @IsRemote            BIT,            -- 是否偏远地区订单  
 @AddedAmount         DECIMAL(18,2),  -- 订单附加费总额  
 @OrderPaid           DECIMAL(18,2),  -- 订单总已付款  
  
 @PhysicalWeight   INT,            -- 订单所有商品物理总重量：即实际重量，算了装箱系数  
 @VolumeWeight   INT,            -- 订单所有商品体积总重量：即体积换算后的重量，算了装箱系数  
 @OrderWeight         INT,            -- 订单所有商品总重量：取物理重量和体积重量的最大值  
 @Freight          DECIMAL(18,2),  -- 订单所有商品总运费(包含偏远费)  
 @BaseFreight      DECIMAL(18,2),  -- 订单所有商品基本运费(不含偏远费)  
 @RemoteFreight     DECIMAL(18,2),  -- 订单所有商品偏远费  
 @ProductPrice        DECIMAL(18,2),  -- 订单所有商品总金额  
  
 @ReadyProductPrice   DECIMAL(18,2),  -- 订单到货商品总金额  
 @ReadyPhysicalWeight INT,            -- 订单到货商品物理重量：即实际重量，算了装箱系数  
 @ReadyVolumeWeight  INT,            -- 订单到货商品体积重量：即体积换算后的重量，算了装箱系数  
 @ReadyOrderWeight    INT,            -- 订单到货商品总重量：取物理重量和体积重量的最大值  
 @ReadyFreight     DECIMAL(18,2),  -- 订单到货商品总运费(包含偏远费)   
 @ReadyBaseFreight    DECIMAL(18,2),  -- 订单到货商品基本运费(不含偏远费)  
 @ReadyRemoteFreight  DECIMAL(18,2)   -- 订单到货商品偏远费  
BEGIN      
 SET @AddedAmount = 0;  
 SET @OrderPaid = 0;  
 SET @CountryId = 0;  
 SET @DeliveryId = 0;  
 SET @IsRemote = 0;   
 SET @PhysicalWeight = 0;   
 SET @VolumeWeight = 0;  
 SET @OrderWeight = 0;  
 SET @ProductPrice = 0;  
 SET @Freight = 0;  
 SET @BaseFreight = 0;  
 SET @RemoteFreight = 0;  
  
 SET @ReadyFreight = 0;  
 SET @ReadyBaseFreight = 0;  
 SET @ReadyRemoteFreight = 0;   
 SET @ReadyProductPrice = 0;  
 SET @ReadyPhysicalWeight = 0;  
 SET @ReadyVolumeWeight = 0;  
 SET @ReadyOrderWeight = 0;  
  
     --1、获取订单的货运方式和货运国家  
  Select @DeliveryId = DeliveryId,  
   @IsRemote = ISNULL(IsRemote,0),  
   @CountryId = ISNULL(Country,0)  
  From dbo.T_Order   
  LEFT JOIN dbo.T_OrderAddresses ON dbo.T_Order.ShipAddressId = dbo.T_OrderAddresses.AddressId  
  Where OrderId = @OrderId;  
  
  --2、获取订单物理重量  
  EXEC CRM_Price_OrderWeightGet @OrderId=@OrderId,@Weight=@PhysicalWeight OUT,@ReadyWeight=@ReadyPhysicalWeight OUT  
  
  --3、获取订单体积重量  
  EXEC CRM_Price_OrderVolumeWeightGet @OrderId=@OrderId,@Weight=@VolumeWeight OUT,@ReadyWeight=@ReadyVolumeWeight OUT  
  
  --4、得出订单总重量：取物理重量和体积重量的最大值  
  IF @VolumeWeight > @PhysicalWeight   
  BEGIN  
     SET @OrderWeight = @VolumeWeight  
  END   
  ELSE  
  BEGIN  
     SET @OrderWeight = ISNULL(@PhysicalWeight,0)  
  END   
  
  IF @ReadyVolumeWeight > @ReadyPhysicalWeight   
  BEGIN  
     SET @ReadyOrderWeight = @ReadyVolumeWeight  
  END   
  ELSE  
  BEGIN  
     SET @ReadyOrderWeight = ISNULL(@ReadyPhysicalWeight,0)  
  END   
  
--  --5、获取订单基本运费(不含偏远费):2012-10-20以后不再有X商品，因此这里的费用都不计算X商品运费  
--  IF (@OrderWeight > 0)  
--  BEGIN  
--      EXEC CRM_Price_FreightGet @DeliveryId=@DeliveryId,@CountryId=@CountryId,@Weight=@OrderWeight,@Freight=@BaseFreight OUT;  
--  END   
  IF (@ReadyOrderWeight > 0)  
  BEGIN  
   --EXEC CRM_Price_FreightGet @DeliveryId=@DeliveryId,@CountryId=@CountryId,@Weight=@ReadyOrderWeight,@Freight=@ReadyBaseFreight OUT;
   /* 到货运费暂时算单个订单 */
   EXEC CRM_Order_CalculateOrderFreightBySnapshot @OrderId=@OrderId, @Weight=@ReadyOrderWeight, @Freight=@ReadyBaseFreight OUT;
  END   
  
  --6、获取订单偏远费:2012-10-20以后不再有X商品，因此这里的费用都不计算X商品运费  
  IF @IsRemote = 1  
  BEGIN   
--   IF (@OrderWeight > 0)  
--   BEGIN  
--       EXEC CRM_Price_AddedFreightGet @DeliveryId=@DeliveryId,@Weight=@OrderWeight,@Freight=@RemoteFreight OUT;  
--   END   
   IF (@ReadyOrderWeight > 0)  
   BEGIN  
    EXEC CRM_Price_AddedFreightGet @DeliveryId=@DeliveryId,@Weight=@ReadyOrderWeight,@Freight=@ReadyRemoteFreight OUT;  
   END   
 END  
  
  --7、得出订单总运费：基本运费+偏远运费  
--  SET @Freight = ISNULL(@BaseFreight,0) + ISNULL(@RemoteFreight,0)  
  SET @ReadyFreight = ISNULL(@ReadyBaseFreight,0) + ISNULL(@ReadyRemoteFreight,0)  
  SELECT @Freight=ISNULL(dbo.T_Order.Freight,0), @RemoteFreight = ISNULL(dbo.T_OrderPrice.AddedCost,0) 
  FROM dbo.T_Order LEFT JOIN dbo.T_OrderPrice ON dbo.T_OrderPrice.OrderId=dbo.T_Order.OrderId       
  WHERE dbo.T_Order.OrderId=@OrderId  
  
  --8、获取订单商品总金额  
  EXEC CRM_Price_OrderPriceGet @OrderId=@OrderId, @Price=@ProductPrice OUT, @ReadyPrice=@ReadyProductPrice OUT ;                
  
  --9、获取订单附加费  
  SELECT @AddedAmount = ISNULL(SUM(Surcharge),0)  
  FROM dbo.T_OrderSurcharge    
  WHERE dbo.T_OrderSurcharge.OrderId=@OrderId  
  
  --10、获取订单总已付款,其实这里存的都是美元，可以不用转换  
  Select @OrderPaid = ISNULL(Sum(a.PaySum/b.Rate),0)  
  From dbo.T_OrderPay a   
  INNER Join  T_Currency b ON a.CurrencyId = b.Id  
  WHERE a.OrderId=@OrderId  
  
  --总输出  
  SELECT @PhysicalWeight      AS PhysicalWeight,       --总物理重量  
         @ReadyPhysicalWeight AS ReadyPhysicalWeight,  --到货物理重量  
         @VolumeWeight        AS VolumeWeight,         --总体积重量  
         @ReadyVolumeWeight   AS ReadyVolumeWeight,    --到货体积重量  
         @OrderWeight         AS OrderWeight,          --总订单重量  
         @ReadyOrderWeight    AS ReadyOrderWeight,     --到货订单重量  
         @BaseFreight         AS BaseFreight,          --总基本运费(不含偏远费)  
         @ReadyBaseFreight    AS ReadyBaseFreight,     --到货基本运费(不含偏远费)  
         @RemoteFreight       AS RemoteFreight,       --总偏远费  
         @ReadyRemoteFreight  AS ReadyRemoteFreight,   --到货偏远费  
         @Freight             AS Freight,              --总运费  
         @ReadyFreight        AS ReadyFreight,       --到货运费                                        
         @ProductPrice        AS ProductPrice,       --总货物金额  
         @ReadyProductPrice   AS ReadyProductPrice,   --到货货物金额  
         @AddedAmount         AS AddedAmount,          --总附加费  
         @OrderPaid           AS OrderPaid             --总已付金额  
END
go


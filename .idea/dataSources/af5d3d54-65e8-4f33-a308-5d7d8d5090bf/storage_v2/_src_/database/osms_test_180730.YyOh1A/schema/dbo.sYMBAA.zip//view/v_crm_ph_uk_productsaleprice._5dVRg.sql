
CREATE VIEW V_CRM_PH_UK_ProductSalePrice            
AS             
SELECT             
b.CmsProductId,            
a.id AS WebProductId,            
CAST(ISNULL(c.is_promote,0) AS BIT) AS IsPromote,     
(100 - ISNULL(c.Discount,0)) AS Discount, --注意：uk_product_promote表中的Discount是降的折扣      
ISNULL(c.[type],0) AS PromoteType,  --促销类型     
CAST(ISNULL(c.is_bind_storage,0) AS BIT) AS IsBindStorage,  --是否绑定库存促销    
b.LastCostPrice AS CostPrice,            
b.UnitQuantity,            
8.2 AS ExchangeRate,            
a.first_profit_coefficient AS Profit1,        
a.first_quantity_from AS QuantityFrom1,        
a.first_quantity_to AS QuantityTo1,        
a.second_profit_coefficient AS Profit2,        
a.second_quantity_from AS QuantityFrom2,        
a.second_quantity_to AS QuantityTo2,        
a.third_profit_coefficient AS Profit3,        
a.third_quantity_from AS QuantityFrom3,        
a.third_quantity_to AS QuantityTo3,   
ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * first_profit_coefficient AS Decimal(18,2)),0) AS OriginalSalePrice,            
ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * (CASE WHEN c.discount > 0 THEN first_profit_coefficient ELSE second_profit_coefficient END) AS Decimal(18,2)),0) AS OriginalSalePrice2,           
ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * (CASE WHEN c.discount > 0 THEN first_profit_coefficient ELSE third_profit_coefficient END) AS Decimal(18,2)),0) AS OriginalSalePrice3,     
CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * first_profit_coefficient AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice,  
CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * (CASE WHEN c.discount > 0 THEN first_profit_coefficient ELSE second_profit_coefficient END) AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice2,       
CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * (CASE WHEN c.discount > 0 THEN first_profit_coefficient ELSE third_profit_coefficient END) AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice3,  
c.id AS PromoteId
FROM dbo.uk_product a WITH(NOLOCK)            
JOIN dbo.V_CRM_Base_Product b WITH(NOLOCK) ON a.product_id = b.CmsProductId            
LEFT JOIN uk_product_promote c WITH(NOLOCK) ON b.CmsProductId = c.product_id AND c.is_promote=1  AND  DATEADD(hh,-8,GETDATE())>=c.start_time AND DATEADD(hh,-8,GETDATE())<=c.end_time AND c.promote_type=0 --默认只取大促销


go



-- =============================================
-- Author:		HYD
-- Create date: 2010-06-10
-- Description:	获取订单的附加费，多个订单号用逗号隔开,按类别分组
-- Version：CRM 5.1.0
-- =============================================
CREATE PROCEDURE [dbo].[CRM_Order_OrderSurchargeGetByOrderId]
(
	@OrderIds VARCHAR(2000)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	WITH cte AS (
	SELECT SurchargeId,CategoryId,OrderId,Remark,Surcharge 
	FROM dbo.T_OrderSurcharge
	WHERE OrderId IN (
    SELECT [Value] FROM dbo.uf_Split(@orderids,',')))
    
    SELECT MAX(a.SurchargeId) AS SurchargeId,
    a.CategoryId,
    MAX(OrderId) AS OrderId,
    MAX(Remark) AS Remark,
    SUM(Surcharge) AS Surcharge,
    MAX(b.CategoryName) AS CategoryName 
    FROM cte a
		JOIN dbo.T_OrderSurchargeCategory b ON a.CategoryId = b.CategoryId
	GROUP BY a.CategoryId
    
END

go



CREATE VIEW V_CRM_ProductImages  
AS   
SELECT a.product_id AS CmsProductId,  
    a.picture_code AS pictureCode,  
    a.picture_name AS PictureName,  
    a.type,  
    a.order_index AS OrderIndex  
FROM dbo.product_picture_collection a WITH(NOLOCK)  
UNION   
SELECT a.id AS CmsProductId,  
       b.picture_code AS PictureCode,  
       b.picture_name AS PictureName,  
       3 AS TYPE,  
       1 AS OrderIndex  
FROM dbo.product a WITH(NOLOCK)  
INNER JOIN dbo.product_set_color_card b WITH(NOLOCK) ON a.product_set_color_card_id=b.id  
UNION   
SELECT a.id AS CmsProductId,  
       b.picture_code AS PictureCode,  
       b.picture_name AS PictureName,  
       100 AS TYPE,  
       1 AS OrderIndex  
FROM dbo.product a WITH(NOLOCK)  
INNER JOIN dbo.product_set_picture b WITH(NOLOCK) ON a.product_set_id=b.product_set_id  
WHERE b.is_primary=1
go


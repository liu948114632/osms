/*------------------------------------------            
备注:获得同票的相关订单            
创建人: LXH            
创建日期:2012-06-14            
------------------------------------------------------*/            
CREATE PROC dbo.CRM_Order_RelateOrdersGet            
(            
  @SendGroupId INT --同票订单ID        
)            
AS             
BEGIN         
     --获得该组的所有订单信息        
     SELECT   b.OrderId,            
     b.CustomerId,            
     b.Priority,        
     b.OrderIndustryType,        
     b.IsSend,            
     b.DisposeDate,            
     b.LastModifyTime,            
     b.DeliveryId,            
     b.PayStatus,            
     b.OrderStatus,            
     b.PostWeight,            
     b.IsActualInvoice,            
     b.IsInvoice,-- 是否已做发票            
     b.IsBalance,-- 是否已结算            
     b.IsAutoOrder,            
     b.HandlerId,            
     b.IsCommunicationCMS,
     b.AutoDelayDate AS AutoSendDate,        
    b.IsAutoBalance, 
    b.Freight, 
	f.IsPHClone,
 (SELECT ISNULL(MIN(ProcessingStatus),10) FROM dbo.T_OrderItem o1  WITH(NOLOCK)  WHERE o1.OrderId=b.OrderId AND ProcessingStatus>10) as ProcessingStatus,
     c.[Name] AS DeliveryName,-- 货运方式          
     (CASE WHEN e.UserId > 0             
     THEN             
      '[VIP]' + d.[Firstname] + ' ' + d.[Lastname]            
     ELSE            
      d.[Firstname] + '' + d.[Lastname]            
     END) AS CustomerName-- 要显示收货人名称，即寄货地址里面的名称               
     FROM dbo.T_Order b WITH(NOLOCK)         
     INNER JOIN dbo.T_Delivery c WITH(NOLOCK) ON b.DeliveryId = c.DeliveryId         
     INNER JOIN dbo.T_OrderAddresses d WITH(NOLOCK) ON b.ShipAddressId = d.AddressId          
	 INNER JOIN dbo.T_BusinessType f WITH(NOLOCK) ON f.BusinessTypeValue=b.OrderIndustryType
     LEFT JOIN dbo.T_CustomerVip e WITH(NOLOCK) ON b.CustomerId = e.UserId             
     WHERE SendGroupId = @SendGroupId  AND b.OrderStatus <132    
END
go


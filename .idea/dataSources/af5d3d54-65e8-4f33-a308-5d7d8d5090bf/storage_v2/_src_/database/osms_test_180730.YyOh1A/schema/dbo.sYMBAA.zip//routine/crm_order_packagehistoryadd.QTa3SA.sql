

/*---------------------------------------------------  
备注:增加package的历史操作  
创建人: FRH  
创建日期:2009-12-30  

-----------------------------------------------------*/  
CREATE PROCEDURE [dbo].[CRM_Order_PackageHistoryAdd]  
(  
 @UserId    INT = 0,  
 @OrderId   VARCHAR(20),  
 @Action    NVARCHAR(255)  
)  
AS  
BEGIN  
 INSERT INTO T_OrderPackagehistory(OrderId,userId,[Action])  
 VALUES(@OrderId,@UserId,@Action);  
END
go


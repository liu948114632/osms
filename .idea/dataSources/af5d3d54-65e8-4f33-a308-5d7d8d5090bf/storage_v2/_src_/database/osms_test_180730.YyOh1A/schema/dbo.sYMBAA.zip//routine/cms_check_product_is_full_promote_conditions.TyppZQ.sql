
/**
*判断当前产品是否满足促销活动条件
*/

CREATE PROCEDURE CMS_Check_product_is_full_promote_conditions
(
 @ProductCodes NVARCHAR(max) =null
)
AS 
BEGIN
 SET NOCOUNT ON;
   DECLARE  @SQL varchar(MAX)
    SET @SQL = 'SELECT b.value as code,a.id from product a '
    SET @SQL = @SQL + ' right join  dbo.tempuf_Split_char('''+@ProductCodes+''','','') as b on a.code =b.value'
    SET @SQL = @SQL + ' where (a.id is null or   ((status !=4 OR offline_status =2) AND a.is_delete =0  )' 
	SET @SQL = @SQL +'  OR ( is_delete =1 AND NOT EXISTS (SELECT z.id FROM dbo.product z where a.code = z.code AND z.is_delete = 0  AND z.status =4 and z.offline_status <>2 )  ) )'
PRINT 	@SQL
	exec(@SQL)
END

go


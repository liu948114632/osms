  
/*--------------------------------------------------------    
[备注]    
视图：获取订单到货商品个数    
--------------------------------------------------------------*/    
CREATE VIEW [dbo].[V_CRM_OrderReadyItemsCount] 
AS    
SELECT         
 [OrderId],    
 COUNT_BIG(*) AS Counts -- 到货商品总个数    
FROM dbo.T_OrderItem     
WHERE [Status] > 5 AND [Status] < 12  -- 非取消订单商品且备货状态后    
GROUP BY [OrderId]
go


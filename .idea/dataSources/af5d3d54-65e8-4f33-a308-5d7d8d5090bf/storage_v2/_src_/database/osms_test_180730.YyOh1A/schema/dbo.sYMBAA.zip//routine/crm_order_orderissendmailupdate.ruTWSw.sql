

-- =============================================
-- Author:		<HYD>
-- Create date: <2010-01-07>
-- Description:	<修改是否自动发送催款邮件的标识>
-- =============================================
CREATE PROCEDURE [dbo].[CRM_Order_OrderIsSendMailUpdate]
(
	@OrderId		NVARCHAR(20),
	@IsSendMail		BIT
)
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE
		T_Order
	SET
		IsSendMail = @IsSendMail 
	WHERE
		OrderId = @OrderId

END

go


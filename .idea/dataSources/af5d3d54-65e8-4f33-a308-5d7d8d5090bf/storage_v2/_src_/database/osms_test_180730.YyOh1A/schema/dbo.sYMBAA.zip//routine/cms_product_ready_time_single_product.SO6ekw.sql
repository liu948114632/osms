/*
	2014-07-04
	商品备货期
*/
CREATE PROCEDURE [dbo].[CMS_Product_Ready_Time_single_product] 
(
	@productId int = NULL --多个产品编号
) 
AS 
    BEGIN
		DECLARE @temp VARCHAR(100)
		DECLARE @beginDate DATETIME
		Declare @beginZeroDate DATETIME
		DECLARE @endDate DATETIME
		DECLARE  @readytime TABLE
			(id int,
			 readytime int
			 )		
		SELECT @temp =CONVERT(VARCHAR(100),GETDATE(),23);
		set @beginZeroDate = @temp +' 00:00:00.000';
		SET @beginDate =getdate()
		SET @endDate = getdate()
		;WITH firstreadyTime AS (
		SELECT c.id,15 AS readytime  FROM   dbo.order_item  a WITH (NOLOCK)
		JOIN dbo.[order] b WITH (NOLOCK) ON  a.order_id = b.id
		JOIN dbo.product c WITH (NOLOCK) ON c.id= a.product_id
		WHERE 
		a.product_id= @productId and
		--ph 订单
		b.type = 1 AND 
		--当天取消的订单商品项
		a .status = 12 AND  a.cancel_time >=@beginZeroDate AND a.cancel_time<=@endDate
		--客户要求取消”和“确认挑选替代品
		AND (a.cancel_reason =0 OR a.cancel_reason = 1 )
		--普通商品
		AND a.type =1
		--备货时间大于192
		AND  DATEDIFF(hh,a.order_time,ISNULL(a.ready_time,a.cancel_time))>192
		AND c.is_small_quantities <>1   AND c.is_delete =0 
		UNION
		 --b:已备货商品
		SELECT c.id,15  FROM   dbo.order_item  a WITH (NOLOCK)
		JOIN dbo.[order] b WITH (NOLOCK) ON  a.order_id = b.id
		JOIN dbo.product c WITH (NOLOCK) ON c.id= a.product_id
		WHERE 
		a.product_id= @productId and
		--ph 订单
		b.type = 1 AND 
		--当天取消的订单商品项
		a .status = 6 AND  a.order_time  BETWEEN  DATEADD(hh,-216,@beginDate) AND  DATEADD(hh,-192,@beginDate)
		--普通商品
		AND a.type =1
		--备货时间大于192
		AND  DATEDIFF(hh,a.order_time, a.ready_time )>192   
		AND c.is_small_quantities <>1   AND c.is_delete =0 
		AND  EXISTS 
		--上一个ph订单
		(
		SELECT  * FROM   dbo.order_item  a1 WITH (NOLOCK)
		JOIN dbo.[order] b1 WITH (NOLOCK) ON  a1.order_id = b1.id
		
		JOIN dbo.product f1 WITH (NOLOCK)  ON f1.id= a1.product_id
		WHERE 
		a1.product_id= @productId and
		--ph 订单
		b1.type = 1 
		AND f1.is_small_quantities <>1  AND f1.is_delete =0 
		--8 天前 至 半年前
		AND  a1.order_time  BETWEEN DATEADD(hh,-6*30*24,GETDATE())  AND DATEADD(hh,-216,GETDATE())
		--商品项来源
		
		--普通商品
		AND a1.type =1
		--订单商品项状态
		AND 1=(
				--取消订单 备货时间 超过 192小时
			CASE WHEN a1.status = 12 AND  DATEDIFF(hh,a1.order_time,ISNULL(a1.ready_time,a1.cancel_time))>192  THEN 1
				--备货中  
				 WHEN a1.status = 1 THEN 1 
				 --已备货 备货时间 超过 192小时
				 WHEN a1.status = 6 and DATEDIFF(hh,a1.order_time, a1.ready_time)>192
				 AND EXISTS (  SELECT *  FROM assigment_stay_product c1 WITH (NOLOCK)  
								JOIN  dbo.stock_out d1  WITH (NOLOCK) ON  d1.id = c1.stock_out_id 
								WHERE  c1.order_item_id = a1.id  AND d1.department_id IN (
			SELECT  id  FROM dbo.department  WITH (NOLOCK) WHERE name IN ('广州采购中心','义乌采购中心','佛山办事处','佛山加工部','佛山成品部','义乌成品部')
		))
				  THEN 1
				 ELSE 0 END)             
		AND a1.product_id = a.product_id
		 )
		 UNION
		 --备货中的商品项
		SELECT c.id,15 FROM   dbo.order_item  a WITH (NOLOCK)
		JOIN dbo.[order] b WITH (NOLOCK) ON  a.order_id = b.id
		JOIN dbo.product c  WITH (NOLOCK) ON c.id= a.product_id
		WHERE
		a.product_id= @productId and 
		--ph 订单
		b.type = 1 AND a.order_time  BETWEEN  DATEADD(hh,-216,@beginDate) AND  DATEADD(hh,-192,@beginDate) and
		a .status = 1
		AND c.is_small_quantities <>1   AND c.is_delete =0 
		--普通商品
		AND a.type =1
		AND  EXISTS 
		--上一个ph订单
		(
		SELECT  * FROM   dbo.order_item  a1 WITH (NOLOCK)
		JOIN dbo.[order] b1 WITH (NOLOCK) ON  a1.order_id = b1.id
		
		JOIN dbo.product f1 WITH (NOLOCK)  ON f1.id= a1.product_id
		WHERE 
		a1.product_id= @productId and
		--ph 订单
		b1.type = 1 
		AND f1.is_small_quantities <>1  AND f1.is_delete =0 
		--8 天前 至 半年前
		AND  a1.order_time  BETWEEN DATEADD(hh,-6*30*24,GETDATE())  AND DATEADD(hh,-216,GETDATE())
		--商品项来源
		
		--普通商品
		AND a1.type =1
		--订单商品项状态
		AND 1=(
				--取消订单 备货时间 超过 192小时
			CASE WHEN a1.status = 12 AND  DATEDIFF(hh,a1.order_time,ISNULL(a1.ready_time,a1.cancel_time))>192  THEN 1
				--备货中  
				 WHEN a1.status = 1 THEN 1 
				 --已备货 备货时间 超过 192小时
				 WHEN a1.status = 6 and DATEDIFF(hh,a1.order_time, a1.ready_time)>192
				 AND EXISTS (  SELECT *  FROM assigment_stay_product c1 WITH (NOLOCK)  
								JOIN  dbo.stock_out d1  WITH (NOLOCK) ON  d1.id = c1.stock_out_id 
								WHERE  c1.order_item_id = a1.id  AND d1.department_id IN (
			SELECT  id  FROM dbo.department  WITH (NOLOCK) WHERE name IN ('广州采购中心','义乌采购中心','佛山办事处','佛山加工部','佛山成品部','义乌成品部')
		))
				  THEN 1
				 ELSE 0 END)              
		AND a1.product_id = a.product_id
		 )
		UNION
		-- 小批量
		SELECT a.id, CASE WHEN  (d.original_product_id IS NULL 
							  OR ISNULL(f.quantity,0)-ISNULL(f.lock_quantity,0)<g.unit_quantity) THEN 15 ELSE 8 END		AS readytime
	  FROM dbo.product a  WITH (NOLOCK)
	 JOIN ph_product b  WITH (NOLOCK) ON a.id = b.product_id
	 LEFT JOIN dbo.storage c WITH (NOLOCK) ON a.id =c.product_id AND c.department_id IN(SELECT id FROM dbo.department WHERE type=3)
	 LEFT JOIN dbo.product_small_quantities d WITH (NOLOCK) ON a.id = d.product_id
	 LEFT JOIN  [view_product_all_storage_quantity_info] f WITH (NOLOCK) ON d.original_product_id =f.product_id
	  LEFT JOIN product g ON g.id = d.original_product_id
	 WHERE a.is_small_quantities = 1  AND b.is_on_shelf = 1 and a.id= @productId  
	),lastreadytime AS (
		SELECT c.id,8 AS readytime  FROM   dbo.order_item  a WITH (NOLOCK)
		JOIN dbo.[order] b  WITH (NOLOCK)ON  a.order_id = b.id
		JOIN dbo.product c  WITH (NOLOCK) ON c.id= a.product_id
		WHERE 
		a.product_id= @productId and
		--ph 订单
		b.type = 1 AND 
		a .status = 6
		AND DATEDIFF(hh,a.order_time,a.ready_time)<=192
		AND c.is_small_quantities <>1   AND c.is_delete =0 
		--普通商品
		AND a.type =1
		AND a.order_time  BETWEEN  DATEADD(hh,-216,@beginDate) AND  DATEADD(hh,-192,@beginDate)
		AND  (EXISTS 
		--上一个ph订单
		(
		SELECT * FROM   dbo.order_item  a1 WITH (NOLOCK)
		JOIN dbo.[order] b1  WITH (NOLOCK)ON  a1.order_id = b1.id
		JOIN  assigment_stay_product c1  WITH (NOLOCK) ON  c1.order_item_id = a1.id
		JOIN  dbo.stock_out d1 WITH (NOLOCK)  ON  d1.id = c1.stock_out_id
		JOIN dbo.product f1  WITH (NOLOCK) ON f1.id= a1.product_id
		WHERE 
		a1.product_id= @productId and
		--ph 订单
		b1.type = 1 
		AND f1.is_small_quantities <>1  AND f1.is_delete =0 
		--8 天前 至 半年前
		AND  a1.order_time  BETWEEN  DATEADD(hh,-6*30*24,@beginDate) AND DATEADD(hh,-216,@beginDate)
		--商品项来源
		AND d1.department_id IN (
			SELECT  id  FROM dbo.department WITH (NOLOCK) WHERE name IN ('广州采购中心','义乌采购中心','佛山办事处','佛山加工部','佛山成品部','义乌成品部')
		)
		--普通商品
		AND a1.type =1
		AND a1.status = 6 AND DATEDIFF(hh,a1.order_time, a1.ready_time)<=192     
		AND a1.product_id = a.product_id
		 )  OR NOT EXISTS (
		 --半年内没下单的ph上架上品（十五天转八天）
		SELECT product_id FROM dbo.order_item o WITH (NOLOCK) WHERE  
		o.order_time  BETWEEN DATEADD(hh,-6*30*24,@beginDate) AND  DATEADD(hh,-216,@beginDate)
		and o.product_id = a.product_id
		
		  ))
	),readytime as (	   
		select  *  from  	firstreadyTime where  id not in (select  id from lastreadytime)
		union 
		select *  from  lastreadytime
	)
	insert into @readytime select a.* from readytime a join product_ready_time  b on  a.id = b.product_id 
	where  a.readytime<>b.ready_time 
	
	--插入日志
	insert into  product_ready_time_log(product_id,operator_id,operator_log,operator_time) 
	select a.id,0,'备货期从'+ cast(b.ready_time as varchar(100))+'改为'+cast (a.readytime as varchar(100)),getdate()  from  @readytime a  join product_ready_time  b 
	on  a.id = b.product_id 

	--更新备货期
	update b set b.ready_time = a.readytime,b.last_updated_time = GETDATE() ,b.operator_id=0 from  @readytime a  join product_ready_time  b on  a.id = b.product_id  
	
	--通讯命令
	
	
	insert into communication_log([command],[object_id],[status],[create_time] ,[operator],[model_type])
	select 'SET_PRODUCT_READY_TIME',a.id,1,getdate(),0,'PRODUCT' from  @readytime a  join product_ready_time  b on  a.id = b.product_id 
	where  a.readytime<>b.ready_time
    END

go


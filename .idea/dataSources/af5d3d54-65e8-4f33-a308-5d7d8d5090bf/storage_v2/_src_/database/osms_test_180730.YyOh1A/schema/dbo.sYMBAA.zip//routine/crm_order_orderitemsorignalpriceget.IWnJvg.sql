



/*--------------------------------------------------    
[备注]    
 获取订单中折前正常商品的原始总价    
----------------------------------------------------*/    
CREATE PROCEDURE [dbo].[CRM_Order_OrderItemsOrignalPriceGet]
    (
      @OrderId NVARCHAR(20) ,
      @Price DECIMAL(18, 4) OUT ,
      @ReadyPrice DECIMAL(18, 4) OUT ,
      @ExcludePromote INT = 1     
    )
AS
    BEGIN    
 -- 样本卡费用    
        DECLARE @StylebookPrice DECIMAL(9, 2);    
        EXEC CRM_Price_StylebookSalePriceGet @OrderId, 0, @StylebookPrice OUT;    
    
 -- 样本卡到货费用    
        DECLARE @StylebookReadyPrice DECIMAL(9, 2);    
        EXEC CRM_Price_StylebookSalePriceGet @OrderId, 1,
            @StylebookReadyPrice OUT;    
    
        IF @ExcludePromote = 1
            BEGIN
                SELECT  @Price = CAST(SUM(Quantity * 1.0 / UnitQuantity
                                          * SalePrice) AS DECIMAL(18, 2)) ,
                        @ReadyPrice = CAST(SUM(ReadyQty * 1.0 / UnitQuantity
                                               * SalePrice) AS DECIMAL(18, 2))
                FROM    dbo.T_OrderItem
                WHERE   OrderId = @OrderId
                        AND [Status] < 12
                        AND ISPROMOTE = 0    
            END
        ELSE
            BEGIN
                SELECT  @Price = CAST(SUM(Quantity * 1.0 / UnitQuantity
                                          * SalePrice) AS DECIMAL(18, 2)) ,
                        @ReadyPrice = CAST(SUM(ReadyQty * 1.0 / UnitQuantity
                                               * SalePrice) AS DECIMAL(18, 2))
                FROM    dbo.T_OrderItem
                WHERE   OrderId = @OrderId
                        AND [Status] < 12    
            END
		
  
 -- 减去免费的样本卡钱    
        IF @StylebookPrice > 0
            AND @Price >= @StylebookPrice
            BEGIN    
                SET @Price = @Price - @StylebookPrice;    
            END     
 -- 减去免费的到货的样本卡钱    
        IF @StylebookReadyPrice > 0
            AND @ReadyPrice >= @StylebookReadyPrice
            BEGIN    
                SET @ReadyPrice = @ReadyPrice - @StylebookReadyPrice;    
            END     
    
        IF @Price IS NULL
            SET @Price = 0;    
        IF @ReadyPrice IS NULL
            SET @ReadyPrice = 0;    
    END
go


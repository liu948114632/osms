 
CREATE PROC [dbo].[CMS_ProductPackageWay_List]
    (
      @OperaterId INT = NULL ,
      @PackageWayId INT = NULL ,
      @PackagingCoefficient DECIMAL(18, 3) = NULL ,
      @OperateBeginDate VARCHAR(20) = NULL ,
      @OperateEndDate VARCHAR(20) = NULL ,
      @ProductCode VARCHAR(MAX) = NULL ,--商品编号  
      @ProductCodes VARCHAR(MAX) = NULL ,--多个商品编号
      @CateId1 INT = NULL , --一级类别ID      
      @CateId2 INT = NULL , --二级类别ID      
      @CateId3 INT = NULL , --三级类别ID 
      @PropertyId1 INT = NULL ,
      @PropertyId2 INT = NULL ,
      @PropertyId3 INT = NULL ,
      @PropertyValue1 INT = NULL ,
      @PropertyValue2 INT = NULL ,
      @PropertyValue3 INT = NULL ,
      @ProviderCodes NVARCHAR(MAX) = NULL ,
      @ProdSetCodes VARCHAR(MAX) = NULL ,
      @ProviderCode NVARCHAR(50) = NULL ,
      @ProductSetCode VARCHAR(50) = NULL ,
      @StrategyDepartmentId INT = NULL ,
      @ComplaintLevel INT = NULL ,
      @OfflineStatus INT = NULL ,
      @isValid INT = NULL ,
      @hasPackageWay INT = NULL ,
      @PageSize INT = 50 ,  --页大小                            
      @PageIndex INT = 1    --当前页号                            
    )
AS
    BEGIN                                  
        SET NOCOUNT ON;                                                           
        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用                            
            @FromSQL NVARCHAR(MAX) , --查询内表                          
            @FromSQL2 NVARCHAR(MAX) , --查询                          
            @Column NVARCHAR(MAX) , --取的字段                          
            @Condition VARCHAR(MAX) , --条件                             
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT 
                         
                                      
    --获得查询条件                          
        SET @Condition = ' WHERE b.review_status =2 and b.status=4 AND b.is_delete = 0   '                             
                               
        IF @OperaterId IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.last_operatr_id='
                    + CONVERT(VARCHAR(10), @OperaterId)                            
            END  
        IF @CateId1 IS NOT NULL
            BEGIN      
                SET @Condition = @Condition + ' AND b.category_id_1='
                    + CONVERT(VARCHAR(10), @CateId1);      
            END 
  
        IF @CateId2 IS NOT NULL
            BEGIN      
                SET @Condition = @Condition + ' AND b.category_id_2='
                    + CONVERT(VARCHAR(10), @CateId2);      
            END      
        IF @CateId3 IS NOT NULL
            BEGIN      
                SET @Condition = @Condition + ' AND b.category_id_3='
                    + CONVERT(VARCHAR(10), @CateId3);      
            END   
        IF @StrategyDepartmentId IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND c.department_id ='
                    + CONVERT(VARCHAR(10), @StrategyDepartmentId);   
            END
        IF @ComplaintLevel IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND f.level ='
                    + CONVERT(VARCHAR(10), @ComplaintLevel);  
            END
        IF @OfflineStatus IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND b.offline_status ='
                    + CONVERT(VARCHAR(10), @OfflineStatus);  
            END
        IF @isValid IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND isnull(a.is_valid,0) ='
                    + CONVERT(VARCHAR(10), @isValid);  
            END
        IF @hasPackageWay IS NOT NULL
            BEGIN
                IF @hasPackageWay = 1
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND package_way_id is not null and package_way_id <>0'  
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND ( package_way_id is null or package_way_id =0)'  
                    END
	
            END
        IF @PropertyId1 IS NOT NULL
            BEGIN
                IF @PropertyValue1 IS NOT NULL
                    BEGIN
                        SET @Condition = @Condition
                            + ' and  EXISTS (SELECT ppv.id FROM dbo.product_property_value AS ppv WITH(NOLOCK) WHERE ppv.product_id = b.id
  		 and property_id =' + CONVERT(VARCHAR(20), @PropertyId1)
                            + ' and property_value='
                            + CONVERT(VARCHAR(20), @PropertyValue1) + ')'
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' and  not  EXISTS (SELECT ppv.id FROM dbo.product_property_value AS ppv WITH(NOLOCK) WHERE ppv.product_id = b.id
  		 and property_id =' + CONVERT(VARCHAR(20), @PropertyId1) + ')'
                    END
            END 
        IF @PropertyId2 IS NOT NULL
            BEGIN
                IF @PropertyValue2 IS NOT NULL
                    BEGIN
                        SET @Condition = @Condition
                            + ' and  EXISTS (SELECT ppv.id FROM dbo.product_property_value AS ppv WITH(NOLOCK) WHERE ppv.product_id = b.id
  		 and property_id =' + CONVERT(VARCHAR(20), @PropertyId2)
                            + '  and property_value='
                            + CONVERT(VARCHAR(20), @PropertyValue2) + ')'
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' and  not  EXISTS (SELECT ppv.id FROM dbo.product_property_value AS ppv WITH(NOLOCK) WHERE ppv.product_id = b.id
  		 and property_id =' + CONVERT(VARCHAR(20), @PropertyId2) + ')'
                    END
            END   

        IF @PropertyId3 IS NOT NULL
            BEGIN
                IF @PropertyValue3 IS NOT NULL
                    BEGIN
                        SET @Condition = @Condition
                            + ' and  EXISTS (SELECT ppv.id FROM dbo.product_property_value AS ppv WITH(NOLOCK) WHERE ppv.product_id = b.id
  		 and property_id =' + CONVERT(VARCHAR(20), @PropertyId3)
                            + '  and property_value='
                            + CONVERT(VARCHAR(20), @PropertyValue3) + ')'
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' and  not  EXISTS (SELECT ppv.id FROM dbo.product_property_value AS ppv WITH(NOLOCK) WHERE ppv.product_id = b.id
  		 and property_id =' + CONVERT(VARCHAR(20), @PropertyId3) + ')'
                    END
            END  

        IF @PackageWayId IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.package_way_id='
                    + CONVERT(VARCHAR(10), @PackageWayId)     
            END
                     
        IF @OperateBeginDate IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.last_update_date >='''
                    + CONVERT(VARCHAR(20), @OperateBeginDate) + ''''                            
            END                             
        IF @OperateEndDate IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.last_update_date <='''
                    + CONVERT(VARCHAR(20), @OperateEndDate) + ''''                             
            END               
        IF @ProductCode IS NOT NULL
            BEGIN                             
                                      
                SET @Condition = @Condition + ' AND b.code like '''
                    + @ProductCode + '%'''                            
            END  
        IF @ProductCodes IS NOT NULL
            BEGIN                             
                                       
                SET @Condition = @Condition + ' AND b.code in ('''
                    + REPLACE(@ProductCodes, ',', ''',''') + ''')'                      
            END   
        IF @PackagingCoefficient IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.packaging_coefficient='
                    + CONVERT(VARCHAR(10), @PackagingCoefficient)     
            END
        IF @ProviderCodes IS NOT NULL
            BEGIN      
                SET @Condition = @Condition + ' AND e.code in ('''
                    + REPLACE(@ProviderCodes, ',', ''',''') + ''')';   
            END
        IF @ProdSetCodes IS NOT NULL
            BEGIN      
                SET @Condition = @Condition + ' AND PST.code in ('''
                    + REPLACE(@ProdSetCodes, ',', ''',''') + ''')';      
            END  
        IF @ProductSetCode IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND PST.code like '''
                    + @ProductSetCode + '%''';      
            END 
        IF @ProviderCode IS NOT NULL
            BEGIN        
                SET @Condition = @Condition + ' AND e.code=''' + @ProviderCode
                    + '''';      
            END
  --设置条件查询必须关联的表   大表                       
        SET @FromSQL = ' from  dbo.product b WITH(nolock)  
								left join  dbo.product_package_way a WITH(nolock) ON a.product_id =b.id 
								left JOIN dbo.product_strategy c WITH(nolock) ON c.product_id =b.id  
								left JOIN dbo.product_provider d WITH(nolock) ON d.product_id =c.product_id AND d.department_id =c.department_id 
								left JOIN provider e WITH(nolock) ON e.id =d.provider_id 
								LEFT JOIN dbo.complaint_product_level_ratio f  WITH(nolock) ON f.product_id =b.id  
								left join product_set PST  WITH (NOLOCK) on PST.id = b.product_set_id '  

        SET @FromSQL2 = ' from  dbo.product b WITH(nolock)  
								left join  dbo.product_package_way a WITH(nolock) ON a.product_id =b.id 
								left JOIN dbo.product_strategy c WITH(nolock) ON c.product_id =b.id  
								left JOIN dbo.product_provider d WITH(nolock) ON d.product_id =c.product_id AND d.department_id =c.department_id 
								left JOIN provider e WITH(nolock) ON e.id =d.provider_id 
								LEFT JOIN dbo.complaint_product_level_ratio f  WITH(nolock) ON f.product_id =b.id 
								left join product_set PST  WITH (NOLOCK) on PST.id = b.product_set_id  ' 
        
     
	
	             
                       
    --求符合条件的总数                          
        SET @CountSql = ''--此语句不要去掉，不然查询供应商时会有问题                        
        SET @CountSql = ' SELECT @RowCount = count(b.id) ' + @FromSQL
            + @Condition                     
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                           
                        
        IF ISNULL(@PageSize, 0) < 1
            SET @PageSize = 50                                  
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                  
        IF ISNULL(@PageIndex, 0) < 1
            SET @PageIndex = 1                                  
        ELSE
            IF ISNULL(@PageIndex, 0) > @PageCount
                SET @PageIndex = @PageCount                    
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                  
        SET @end = @PageIndex * @PageSize                           
                     
   
	   
        SET @Column = '                
       a.id,                            
       b.id as productId,                               
       a.join_user_id as joinUserId, 
	   a.join_date as joinDate,                           
       a.last_update_date as lastUpdateDate ,
	   a.last_operatr_id as lastOperatrId,                       
       a.package_way_id AS packageWayId,                            
       a.packaging_coefficient AS packagingCoefficient,                            
	   b.code AS productCode,                          
	   b.name AS name,                          
       b.primary_picture_code AS primaryPictureCode,                          
	   b.unit_quantity AS unitQuantity,
	   PST.code as productSetCode,
	   isnull(a.is_valid,0) as isPackage,
	   c.department_id as straceyDepartmentId,
	   e.code as providerCode,
		f.level as complaintLevel,   
		b.offline_status as offlineStatus,                   
	  b.unit'                              
    --组装基本查询的SQL                   
        SET @SQL = 'SELECT * from (                              
        SELECT  ' + @Column
            + ',ROW_NUMBER() OVER(ORDER BY a.last_update_date DESC,b.code asc) rowIndex'
            + @FromSQL + @Condition + ') temp2                               
      where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))                              
                      
        PRINT @SQL  
        EXEC(@SQL);                                      
                                
        SELECT  @RowCount                                
    END
go


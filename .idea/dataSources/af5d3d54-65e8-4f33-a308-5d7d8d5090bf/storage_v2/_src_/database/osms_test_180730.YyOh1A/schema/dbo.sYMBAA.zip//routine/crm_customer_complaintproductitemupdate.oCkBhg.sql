
/*
	修改投诉产品信息
*/
CREATE PROC CRM_Customer_ComplaintProductItemUpdate
(
	@Id INT,
	@Content VARCHAR(MAX),
	@Result VARCHAR(500),
	@Expense DECIMAL(9,2),
	@Tracer INT,
	@DutyUser INT,
	@Status INT,
	@Type INT,
	@Cause VARCHAR(2000),
	@Mend VARCHAR(2000),
	@AppealResult NVARCHAR(500)
)
AS
BEGIN
	UPDATE dbo.T_ComplaintProductItem SET [Content] = @Content,Result=@Result,
	Expense = @Expense, Tracer=@Tracer,
	DutyUser=@DutyUser,Status=@Status,[Type]=@Type,Cause=@Cause,Mend=@Mend,AppealResult=@AppealResult WHERE Id=@Id
END


go



CREATE VIEW V_CRM_PW_Product            
AS                    
SELECT             
a.id AS CmsProductId,            
b.id AS WebProductId,            
c.id AS ProductSetId,            
c.code AS ProductSetCode,            
c.name AS ProductSetName,    
a.product_set_color_card_id AS ProductSetColorCardId,            
a.product_set_specification_id AS ProductSetSpecificationId,            
d.name AS ColorCardName,           
d.code AS ColorCode,    
d.picture_name AS ColorImageName,     
e.name AS SpecficationName,            
e.minimum_quantity AS MinBatchQty,--这个是批量数            
a.code,                 
a.name,                    
a.unit_quantity AS UnitQuantity,                 
a.unit,             
a.weight,     
a.volume,                         
p.LastCostPrice AS BasePrice,        
(case when isnull(a.category_id_3,0) = 0 then (case when isnull(a.category_id_2,0) = 0 then a.category_id_1 else a.category_id_2 end) else a.category_id_3 end) AS CategoryId,            
a.category_id_1 AS CategoryId1,                 
a.category_id_2 AS CategoryId2,                 
a.category_id_3 AS CategoryId3,              
CAST(a.is_display_pw AS BIT) AS IsDisplay, 
a.offline_status AS offlineStatus,       
a.color_card_picture_code AS ColorCardPictureCode,            
a.primary_picture_code AS PrimaryPictureCode,            
CAST(ISNULL(g.is_promote,0) AS BIT) AS IsPromote,           
(100 - ISNULL(g.discount,0)) AS Discount,        
ISNULL(g.[type],0) AS PromoteType,         
CAST(ISNULL(g.is_bind_storage,0) AS BIT) AS IsBindStorage,      
CAST(ISNULL(h.id,0) AS BIT) AS IsProductPool,              
a.publish_status AS PublishStatus,            
CAST(a.is_gift AS BIT) AS IsGift,                
CAST(a.is_mix AS BIT) AS IsMix,     
f.Description,
b.publish_time AS  publishTime           
FROM dbo.pw_product b WITH(NOLOCK)             
INNER JOIN dbo.product a WITH(NOLOCK) ON a.id=b.product_id         
INNER JOIN dbo.V_CRM_ProductLastCostPrice p ON p.CmsProductId=a.id    
LEFT JOIN product_set c WITH(NOLOCK) ON a.product_set_id=c.id            
LEFT JOIN dbo.product_set_color_card d WITH(NOLOCK) ON a.product_set_color_card_id=d.id            
LEFT JOIN dbo.product_set_specification e WITH(NOLOCK) ON a.product_set_specification_id=e.id            
INNER JOIN dbo.product_description f WITH(NOLOCK) ON a.id=f.product_id            
LEFT JOIN dbo.product_promote_pw g WITH(NOLOCK) ON a.product_set_id = g.product_set_id AND g.is_promote=1    
LEFT JOIN dbo.product_pool AS h WITH(NOLOCK)  ON h.product_id = a.id      
WHERE (b.is_on_shelf=1) AND a.is_delete=0

go


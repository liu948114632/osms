
CREATE PROC [dbo].[CMS_ProviderStorageProduct_BuyingApplay]                              
(                               
  @DepartmentId INT = NULL ,--部门ID
  @ApplayCode VARCHAR(20)=NULL, --申请单号
  @FactoryCode VARCHAR(20)=NULL,--厂家编号 
  @ApplayUserId INT =NULL,--申请人          
  @ApplayTimeBegin VARCHAR(20) = NULL, --查询申请时间的开始时间                          
  @ApplayTimeEnd VARCHAR(20) = NULL, --查询申请时间的结束时间                                          
  @ProductCode VARCHAR(MAX) = NULL,--商品编号
  @ProductCodes VARCHAR(MAX) = NULL,--多个商品编号                                                   
  @ProviderCode VARCHAR(MAX) = NULL,--供应商编号
  @AuditUserId INT = NULL ,--审核人  
  @Status INT = NULL,--任务状态
  @PageSize INT = 50 ,  --页大小                          
  @PageIndex INT = 1    --当前页号                          
)                                
AS            
BEGIN                                
    SET NOCOUNT ON ;                                
                                  
    DECLARE @SQL VARCHAR(MAX),                          
            @CountSql NVARCHAR(MAX), --查询数量用                          
            @FromSQL NVARCHAR(MAX), --查询内表                        
                               
            @Column NVARCHAR(MAX), --取的字段                        
            @Condition VARCHAR(MAX), --条件                           
            @RowCount INT , @PageCount INT , @start INT ,@end INT                                         
                                    
    --获得查询条件                        
    SET @Condition = ' WHERE a.is_system=0 '                           
                            
    IF @DepartmentId IS NOT NULL                           
    BEGIN                           
       SET @Condition = @Condition + ' AND a.department_id=' + CONVERT(VARCHAR(10),@DepartmentId)                          
    END
                         
    IF @Status IS NOT NULL
    BEGIN
		 SET @Condition = @Condition + ' AND a.status=' + CONVERT(VARCHAR(10),@Status)  
    END
    
    IF @ApplayCode IS NOT NULL                           
    BEGIN                           
       SET @Condition = @Condition + ' AND a.code like ''%' + @ApplayCode + '%'''                        
    END
    
    IF @ApplayUserId IS NOT NULL
    BEGIN
		SET @Condition = @Condition + ' AND a.applay_user_id = ' + + CONVERT(VARCHAR(10),@ApplayUserId)   
    END
    
                  
    IF @ApplayTimeBegin IS NOT NULL                           
    BEGIN                           
       SET @Condition = @Condition + ' AND a.applay_time >=''' + CONVERT(VARCHAR(20),@ApplayTimeBegin) + ''''                          
    END                           
    IF @ApplayTimeEnd IS NOT NULL                           
    BEGIN                           
       SET @Condition = @Condition + ' AND a.applay_time <=''' + CONVERT(VARCHAR(20),@ApplayTimeEnd) + ''''                           
    END               
                 
    IF @ProductCode IS NOT NULL                           
    BEGIN                           
                          
       SET @Condition = @Condition + ' AND  exists ( select * from  dbo.provider_storage_product_buying_applay_item b WITH ( NOLOCK ) 
         JOIN dbo.product c WITH ( NOLOCK ) ON c.id = b.product_id  where b.applay_id = a.id and c.code like ''' + @ProductCode + '%'')'                          
    END
    IF @ProductCodes IS NOT NULL                           
    BEGIN                                             
       SET @Condition = @Condition + ' AND  exists ( select * from  dbo.provider_storage_product_buying_applay_item b WITH ( NOLOCK ) 
         JOIN dbo.product c WITH ( NOLOCK ) ON c.id = b.product_id  where b.applay_id = a.id and  c.code in ('''+ REPLACE(@ProductCodes, ',', ''',''') + '''))'                    
    END                        
    IF @FactoryCode IS NOT NULL                           
    BEGIN                           
                          
       SET @Condition = @Condition + 'AND  exists ( select * from  dbo.provider_storage_product_buying_applay_item b WITH ( NOLOCK ) 
         JOIN dbo.product c WITH ( NOLOCK ) ON c.id = b.product_id  where b.applay_id = a.id  AND c.provider_code like ''%' + @FactoryCode + '%'')'                          
    END     
                     
    IF @ProviderCode IS NOT NULL                           
    BEGIN                                             
       SET @Condition = @Condition + ' AND exists ( select * from provider_storage_product_buying_applay_item b WITH ( NOLOCK )
       join  dbo.product_strategy d WITH ( NOLOCK ) on b.product_id =d.product_id
        JOIN dbo.product_provider f WITH ( NOLOCK ) ON f.product_id = d.product_id
                                                       AND f.department_id = d.department_id
        JOIN dbo.provider p WITH ( NOLOCK ) ON p.id = f.provider_id  where b.applay_id = a.id  and  p.code  like ''%' + @ProviderCode + '%'')'                          
    END                          
    IF @AuditUserId IS NOT NULL
    BEGIN
		SET @Condition = @Condition + ' AND a.audit_user_id = ' + + CONVERT(VARCHAR(10),@AuditUserId) 
    END
    
   
       --设置条件查询必须关联的表 历史表                       
	  SET @FromSQL =' FROM dbo.provider_storage_product_buying_applay a WITH ( NOLOCK )'
                    
    
              
                        
    --求符合条件的总数                        
    SET @CountSql = ''--此语句不要去掉，不然查询供应商时会有问题                      
    SET @CountSql=' SELECT @RowCount = count(a.id) ' + @FromSQL + @Condition                      
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                         
                      
    IF ISNULL(@PageSize, 0) < 1                                 
        SET @PageSize = 50                                
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                
    IF ISNULL(@PageIndex, 0) < 1                                 
        SET @PageIndex = 1                                
    ELSE                                 
    IF ISNULL(@PageIndex, 0) > @PageCount                                 
        SET @PageIndex = @PageCount                                
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                
    SET @end = @PageIndex * @PageSize                         
                            
                   
                            
    --设置需要取的字段信息                          
    SET @Column = 'a.id,                   
       a.department_id AS departmentId, 
       a.code ,
       a.status,
       a.applay_user_id as applayUserId,
       a.applay_time as applayTime,
       a.submit_time as submitTime,
       a.audit_user_id as auditUserId,
       a.audit_time as auditTime,
       a.remark ,
       a.product_count as productCount,
       a.object_code as objectCode,
       a.plan_buying_lot_qty as planBuyingLotQty,
       a.plan_buying_amount as planBuyingAmount                      
      '             
                       
                            
    --组装基本查询的SQL                 
    SET @SQL= 'SELECT * from (                            
        SELECT  '+@Column+',ROW_NUMBER() OVER(ORDER BY a.status,a.applay_time desc) rowIndex'                            
            + @FromSQL +  @Condition + ') temp2                             
      where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and ' + CAST(@end AS NVARCHAR(10))                            
                    

    PRINT @SQL
    EXEC(@SQL);                                    
                              
    select @RowCount                              
END


go


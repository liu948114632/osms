
CREATE PROCEDURE DeleteColumn(@TableName VARCHAR(100),@ColumnName VARCHAR(100))
AS
BEGIN
    if exists(select * from syscolumns where id=object_id(@TableName) and name=@ColumnName) 
	BEGIN
	    --先删除约束
		declare @name varchar(200)
		select @name = b.name from sysobjects b join syscolumns a on 
		b.id = a.cdefault where a.id = object_id(@TableName) and a.name = @ColumnName

		IF( LEN(@name)>0 )
		BEGIN
		   EXEC('alter table '+@TableName + ' drop constraint ' + @name)
		END  

		EXEC('ALTER TABLE ' + @TableName + '  DROP COLUMN  '+@ColumnName)
	END  
END
go


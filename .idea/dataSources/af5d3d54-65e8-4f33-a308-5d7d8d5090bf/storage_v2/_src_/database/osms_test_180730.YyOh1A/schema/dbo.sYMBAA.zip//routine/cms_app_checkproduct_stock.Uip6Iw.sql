/*
	2014-07-04
	APP,订单中已加入待质检产品的产品
*/
 CREATE PROCEDURE [dbo].[CMS_APP_CheckProduct_stock]
	@orderId INT =NULL,
    @PageSize INT = 50 ,  --页大小                        
    @PageIndex INT = 1    --当前页号   
AS 
    BEGIN
	
        SET NOCOUNT ON;

        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用  
            @FromSQL NVARCHAR(MAX) , --查询表                                         
            @Column NVARCHAR(MAX) , --查询字段                       
            @Condition VARCHAR(MAX) , --条件                         
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ,
            @DistinctCode VARCHAR(10) 
            
        SET @DistinctCode = ' DISTINCT '   
        SET @FromSQL =' FROM dbo.[order] o 
						INNER JOIN dbo.order_item oi WITH (NOLOCK) ON o.id=oi.order_id
						INNER JOIN dbo.check_product cp WITH (NOLOCK) ON oi.product_id=cp.product_id AND oi.id=cp.order_item_id 
						INNER JOIN dbo.product p WITH (NOLOCK) ON p.id=oi.product_id '
		SET @Condition = ' WHERE 1=1 ' 
		             
        IF @orderId IS NOT NULL 
            BEGIN
                SET @Condition = @Condition + ' AND o.id='+CONVERT(VARCHAR(20),@orderId);
                 
            END 
           
          
    --设置需要取的字段信息                        
        SET @Column = ' oi.id,
						oi.order_id as orderId,
						oi.product_id as productId,
						oi.product_code as productCode,
						oi.order_quantity as orderQuantity,
						oi.prepared_quantity as preparedQuantity,
						oi.unit_quantity as unitQuantity,
						oi.status as status,
						oi.processing_status as processingStatus,
						p.unit as unit,
						cp.app_flag as appFlag '
								
		   			
        --求符合条件的总数                      
        SET @CountSql = ' SELECT @RowCount = count(' + @DistinctCode
            + ' oi.id) ' + @FromSQL + @Condition                 
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
                            
		
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                              
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                              
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                              
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                              
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                              
        SET @end = @PageIndex * @PageSize   
    
        SET @SQL = 'SELECT * from                      
       (                      
       SELECT *,ROW_NUMBER() OVER(ORDER BY temp.id ASC) rowIndex                      
       from (SELECT ' + @DistinctCode + @Column + @FromSQL + @Condition
            + ') temp                      
       ) temp2                           
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))    
            
       EXEC(@SQL);             
	   select @RowCount                
    END
go


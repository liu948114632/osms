
/*------------------------------------------------        
[备注]         
 生成未决订单        
  
修改人 ：HYD        
修改时间：2010-0413        
修改内容：去掉生成未决订单的判断，程序已调用CRM_Order_PendingOrderCreateCheck判断        
-------------------------------------------------*/        
CREATE PROC dbo.CRM_Order_PendingOrderCreate        
(        
 @OrderId     VARCHAR(20),        
 @Remark   VARCHAR(2000),        
 @ActionUserId INT = 0,          
 @PendingOrder VARCHAR(20) OUT -- 未决订单号         
)        
AS        
Declare         
	@Freight   DECIMAL(9,2), -- 修改后原订单的运费        
	@ReadyFreight  DECIMAL(9,2), -- 修改后原订单到货的运费        
	@PFreight DECIMAL(9,2),--P单的运费      
	@PReadyFreight DECIMAL(9,2)--P单到货运费      
BEGIN        

	-- 不记录行的变化         
	SET NOCOUNT ON;         

	-- CMS传的未决备注为空，所以必须取原始订单的未决备注        
	IF (@Remark = '')        
	BEGIN        
	SET @Remark = (SELECT ISNULL(PendingRemark,'') FROM dbo.T_OrderRemark WHERE OrderId = @OrderId)        
	END        

	--1、 增加未决订单        
	Exec CRM_Order_PendingOrderAdd @OrderId,@Remark,@PendingOrder OUT;        

	IF (@PendingOrder > '')        
	BEGIN          
	--2、将未到货的商品转移到未决订单        
	Exec CRM_Order_PendingOrderItemsAdd @OrderId,@PendingOrder;     

	--2.2检查未决的新订单是否符合原先的运费折扣，不符合则去掉运费折扣
	DECLARE @Result BIT
	EXEC CRM_Order_IsQualifiedFreightDiscount  @OrderId= @PendingOrder,@Result=@Result OUT 
	IF( @Result = 0 )
	BEGIN
		UPDATE dbo.T_Order SET FreightDiscount=0,DeliveryPromoteActivityId=NULL,FreeShipSurcharge=0
		WHERE OrderId=@PendingOrder
	    
		 EXEC CRM_Order_OrderHistoryAdd @UserId=0,@OrderId=@PendingOrder,@Remark='未决的新订单因不满足运费活动要求，不再享受运费折扣';    
	END    

	-- 3、更新原始订单运费        
	-- 获取修改后费用         
	--EXEC dbo.CRM_Price_OrderFreightGet @OrderId,@Freight OUT,@ReadyFreight OUT;
	--UPDATE dbo.T_Order SET Freight = @Freight WHERE OrderId = @OrderId;    
	
	/* 2014-12-20 mzc 如果没有快照，则使用当前数据作为快照 */
	IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.T_OrderDeliveryArea WHERE OrderId=@OrderId)
		BEGIN
			EXEC CRM_Order_UpdateFreightSnapshot @OrderId;
		END
		
	DECLARE @Action VARCHAR(100);
	SET @Action='订单' + @OrderId + '生成未决订单' + @PendingOrder;
	EXEC CRM_Order_UpdateGroupSendOrderFreight @OrderId=@OrderId, @UserId=@ActionUserId, @Action=@Action;

	--4、更新未决订单商品的X运费        
	--EXEC dbo.CRM_Price_OrderFreightGet @PendingOrder,@PFreight OUT,@PReadyFreight OUT; 
	--UPDATE dbo.T_Order SET Freight = @PFreight WHERE OrderId = @PendingOrder;        
	
	/* 2014-12-20 mzc 复制原单运费快照 */
	EXEC dbo.CRM_Order_CopyFreightSnapshot @OrderId, @PendingOrder; 
	SET @Action='从订单' + @OrderId + '生成未决订单';
	EXEC CRM_Order_UpdateGroupSendOrderFreight @OrderId=@PendingOrder, @UserId=@ActionUserId, @Action=@Action;
				

	--5、调整未决订单金额      
	EXEC CRM_Order_TransferOrderExcessPayment @OriginalOrderId=@OrderId,@TargetOrderId=@PendingOrder,@TransferAction='生成未决订单',@ActionUserId=@ActionUserId;         

	--6、调整原始订单状态        
	DECLARE @UpdatedStatus INT;        
	EXEC CRM_Order_OrderStatusCheck @OrderId,@UpdatedStatus OUT;        

	--7、记录订单历史      
	DECLARE @HistoryRemark VARCHAR(100),@PendingHistoryRemark VARCHAR(100)      
	SET @HistoryRemark = '生成未决订单' + @PendingOrder       
	SET @PendingHistoryRemark = '从订单' + @OrderId + '生成未决订单'      
	EXEC CRM_Order_OrderHistoryAdd @UserId=@ActionUserId,@OrderId=@OrderId,@Remark=@HistoryRemark      
	EXEC CRM_Order_OrderHistoryAdd @UserId=@ActionUserId,@OrderId=@PendingOrder,@Remark=@PendingHistoryRemark      

	EXEC dbo.CRM_Order_CheckNewOrderIsQualityInspection @OrderId =@OrderId, -- varchar(20)
	    @NewOrderId =@PendingOrder, -- varchar(20)
	    @ActionUserId =@ActionUserId, -- int
	    @Operate = '生成未决订单' -- varchar(200)
	

	END        
END
go


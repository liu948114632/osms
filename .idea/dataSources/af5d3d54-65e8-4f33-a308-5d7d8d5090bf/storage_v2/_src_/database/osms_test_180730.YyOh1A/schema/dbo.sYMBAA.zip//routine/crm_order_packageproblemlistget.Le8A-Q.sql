
CREATE PROC dbo.CRM_Order_PackageProblemListGet
    (
      @DeliveryId INT = -1 ,
      @PackageStatus INT = -1 ,
      @OrderIndustryType INT = 0 ,
      @CreatorUserName VARCHAR(20) = '' ,
      @HandlerId INT = 0 ,
      @DeliveryUserName VARCHAR(20) = '' ,
      @OrderId VARCHAR(20) = '' ,
      @CustomerName VARCHAR(50) = '' ,
      @TrackNo VARCHAR(50) = '' ,
      @Status INT = -1 ,
      @EmailId INT=-1,
      @UserId INT = 0 ,
      @Remark NVARCHAR(200)='' ,
      @Type INT = -1 ,
      @PageSize INT = 50 ,
      @PageIndex INT = 1
    )
AS
    BEGIN
        SET NOCOUNT ON;        
        DECLARE @sql NVARCHAR(MAX);        
        DECLARE @countSql NVARCHAR(MAX);        
        DECLARE @rowCount INT ,
            @pageCount INT ,
            @startPageIndex INT ,
            @endPageIndex INT;        
         
        SET @sql = N'SELECT 
		a.id,
		 a.IsRead ,
          a.Status ,
          a.OrderId ,
          a.OrderCodes ,
          a.CreatorUserName ,
          o.DeliveryUserName ,
          a.CreateTime ,
          a.CloseTime ,
          a.CloseUserId ,
          a.ContactTimes ,
          a.Remark ,
         a.type ,
          a.CRMProcessResult ,
          a.DMSProcessResult ,
          a.ProblemId ,
          a.IsFromDMS,
		 CASE WHEN IsRead=1 THEN ''否'' ELSE ''是'' END AS HasNoRead, 
		 o.TrackDate,
		 o.HandlerId,
		 o.DeliveryId,
		 (SELECT TOP 1 Name FROM dbo.T_Country WHERE CountryId=c.Country) AS CountryName,
		c.Firstname+'' ''+c.Lastname AS CustomerName, 
		b. DueDate,
		b.TraceNo,
		b.Status AS PackageStatus,
        ''电话:''+c.Phone+CASE WHEN c.Fax>'''' THEN ''/手机:''+c.Fax ELSE '''' END AS Phone,
        d.EmailId,
          d.GroupId AS GroupType,
         o.OrderStatus, 
         o.Lang,
         o.OrderIndustryType,
  ROW_NUMBER() OVER(ORDER BY a.IsRead,a.Status ASC,a.CreateTime DESC ) AS RowNo
FROM    dbo.T_PackageProblem a
        INNER JOIN dbo.T_Order o ON a.OrderId = o.OrderId
        LEFT JOIN T_OrderPackage b ON b.OrderId = o.OrderId
        INNER JOIN dbo.T_OrderAddresses c ON c.AddressId = o.ShipAddressId
        INNER JOIN dbo.T_Customer d ON d.UserID=o.CustomerId
WHERE   1 = 1';       
       
        IF ( @DeliveryId > -1 )
            BEGIN         
                SET @sql = @sql + ' AND o.DeliveryId=' + LTRIM(STR(@DeliveryId));        
            END;       

        IF ( @PackageStatus > -1 )
            BEGIN         
                SET @sql = @sql + ' AND b.Status=' + LTRIM(STR(@PackageStatus));        
            END;    
        IF ( @OrderIndustryType > 0 )
            BEGIN         
                SET @sql = @sql + ' AND o.OrderIndustryType='
                    + LTRIM(STR(@OrderIndustryType));        
            END;  
        IF ( @CreatorUserName > '' )
            BEGIN         
                SET @sql = @sql + ' AND CreatorUserName=''' + @CreatorUserName
                    + '''';
            END;  
        IF ( @HandlerId > 0 )
            BEGIN         
                SET @sql = @sql + ' AND o.HandlerId=' + LTRIM(STR(@HandlerId));        
            END;  
        IF ( @DeliveryUserName > '' )
            BEGIN         
                SET @sql = @sql + ' AND a.DeliveryUserName='''
                    + @DeliveryUserName + '''';
            END;  
        IF ( @OrderId > '' )
            BEGIN         
                SET @sql = @sql + ' AND a.OrderId like ''%' + @OrderId + '%''';     
            END;  
        IF ( @CustomerName > '' )
            BEGIN         
                SET @sql = @sql + ' AND c.Firstname+'' ''+c.Lastname like ''%'
                    + @CustomerName + '%''';        
            END;  
        IF ( @TrackNo > '' )
            BEGIN         
                SET @sql = @sql + ' AND TraceNo like ''%' + @TrackNo + '%''';             
            END;  
        IF ( @Status > -1 )
            BEGIN         
                SET @sql = @sql + ' AND a.Status=' + LTRIM(STR(@Status));        
            END;  
        IF ( @EmailId >0 )
            BEGIN
                SET @sql = @sql + ' And d.EmailId=' + LTRIM(STR(@EmailId));
            END;
        IF ( @Remark > '' )
            BEGIN
                SET @sql = @sql + ' And a.Remark like ''%' + @Remark + '%''';        
            END;
        IF ( @Type > 0 )
            BEGIN
                SET @sql = @sql + ' AND a.Type=' + LTRIM(STR(@Type));       
            END;
            
    
 --得到记录条数          
        SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql
            + ') AS Items';          
        EXEC sp_executesql @countSql,N'@rowCount INT OUT',@rowCount OUT;           
         
        IF ( @PageIndex < 1 )
            SET @PageIndex = 1;        
        SET @pageCount = ( @rowCount + @PageSize - 1 ) / @PageSize;          
        IF ISNULL(@PageIndex,0) < 1
            SET @PageIndex = 1;          
        ELSE
            IF @PageIndex > @pageCount
                SET @PageIndex = @pageCount;          
        SET @startPageIndex = ( @PageIndex - 1 ) * @PageSize + 1;          
        SET @endPageIndex = @PageIndex * @PageSize;         
              
        SET @sql = 'SELECT * FROM (' + @sql
            + ') AS Items WHERE RowNo BETWEEN ' + LTRIM(STR(@startPageIndex))
            + ' AND ' + LTRIM(STR(@endPageIndex))
            + ' ORDER BY IsRead,Status ASC,CreateTime DESC ';        
         
        PRINT @sql;        
        EXEC(@sql);         
         
        DECLARE @NotReadQty INT;
        SELECT  @NotReadQty = COUNT(1)
        FROM    dbo.T_PackageProblem a
                INNER JOIN dbo.T_Order o ON o.OrderId = a.OrderId
        WHERE   o.HandlerId = @UserId
                AND a.IsRead = 0;
         
        SELECT  @rowCount AS 'RowCount' ,
                @pageCount AS 'PageCount' ,
                @NotReadQty AS 'NotReadQty';
        
    END;

go


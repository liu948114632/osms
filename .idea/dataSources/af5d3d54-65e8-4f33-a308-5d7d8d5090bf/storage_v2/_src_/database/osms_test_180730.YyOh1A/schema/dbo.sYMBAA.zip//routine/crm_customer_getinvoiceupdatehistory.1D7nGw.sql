 
CREATE PROCEDURE [dbo].[CRM_Customer_GetInvoiceUpdateHistory]          
    (    
   @CustomerId INT
   )
   AS
   BEGIN
   	SELECT CustomerId,Content,CreateTime,CreatorId,b.name AS CreatorName FROM dbo.T_CustomerInvoiceHistory INNER JOIN dbo.[user] b
   ON b.id = T_CustomerInvoiceHistory.CreatorId
   	 WHERE CustomerId=@CustomerId
   	 ORDER BY  T_CustomerInvoiceHistory.Id DESC 
   END

go


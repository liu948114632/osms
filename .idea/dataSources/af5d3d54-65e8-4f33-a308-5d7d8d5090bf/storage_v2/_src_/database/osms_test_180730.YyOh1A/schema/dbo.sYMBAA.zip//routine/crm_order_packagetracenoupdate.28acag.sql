

/*--------------------------------------------------  
[备注]  
 订单重新发货更新跟踪单号  
----------------------------------------------------*/  
CREATE PROC [dbo].[CRM_Order_PackageTraceNOUpdate]  
 @OrderId			VARCHAR(20),  
 @TraceNo			VARCHAR(200),
 @ServiceLineType	VARCHAR(10) 
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  

  IF EXISTS(SELECT * FROM dbo.T_OrderPackage WHERE OrderId = @OrderId)  
  BEGIN  
   UPDATE dbo.T_OrderPackage 
   SET TraceNo = @TraceNo,ServiceLineType = @ServiceLineType,DueDate=GETDATE(),UpdateDate = GETDATE() ---HJJ add 重新发货时，增加了更新追踪时间  
   WHERE OrderId = @OrderId;  
  END  

  -- 重新发货时候更新发货清单  
 IF EXISTS(SELECT * FROM T_ConsignmentRemark WHERE OrderId = @OrderId)  
  BEGIN  
    UPDATE dbo.T_ConsignmentRemark  
    Set TraceNo = @TraceNo  
    Where OrderId = @OrderId;  
  END  
END
go


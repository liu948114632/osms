--设置商品显示状态
CREATE PROCEDURE [dbo].[US_Product_SetProductDisplayStatus]
(  
    @ProductId INT  ,
    @IsDisplay BIT 
)  
AS  
BEGIN   
     UPDATE T_Product_US SET Is_Display = @IsDisplay WHERE ProductId=@ProductId AND IsDeleted=0
END
go


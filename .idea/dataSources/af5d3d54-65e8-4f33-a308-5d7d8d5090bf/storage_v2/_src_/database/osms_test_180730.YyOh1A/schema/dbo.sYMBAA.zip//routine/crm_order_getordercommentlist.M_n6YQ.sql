---获取订单扣件列表
   CREATE PROC dbo.CRM_Order_GetOrderCommentList
   (
   @OrderId VARCHAR(MAX)='',
   @OrderIndustryType INT=0,
   @Lang INT=-1,
   @HandlerId int=0,
   @EmailId INT=-1,
   @StartDate VARCHAR(30)='',        
   @EndDate VARCHAR(30)='', 
   @qualityStar INT=0,
   @serviceStar INT=0,
   @shipmentStar INT=0,
   @PageSize INT=50,        
   @PageIndex INT=0
   )
   AS        
   BEGIN        
    SET NOCOUNT ON;        
    DECLARE @sql NVARCHAR(max)        
    DECLARE @countSql NVARCHAR(max)        
    DECLARE @rowCount int,@pageCount int, @startPageIndex int, @endPageIndex int 
    DECLARE @ExportOrderSql NVARCHAR(max),@ExportServerSql NVARCHAR(MAX)
            
    SET  @sql = N' 
   select a.id,a.OrderId,a.QualityScore,REPLACE(a.QualityComment,CHAR(10),'''') as QualityComment,a.ShipmentScore,REPLACE(a.ShipmentComment,CHAR(10),'''') as ShipmentComment,a.ServiceScore,REPLACE(a.ServiceComment,CHAR(10),'''') as ServiceComment,REPLACE(a.OtherComment,CHAR(10),'''') as OtherComment,a.UnRead,a.CommentTime,b.OrderIndustryType,b.OrderStatus,c.EmailId,
   b.OrderDate,AutoDelayDate AS AutoSendDate,d.DueDate,b.DeliveryId,b.HandlerId,
    ROW_NUMBER() OVER(ORDER BY Id desc ) AS RowNo 
     from T_OrderComment  a WITH(NOLOCK)
     INNER JOIN dbo.T_Order b WITH(NOLOCK) ON a.OrderId=b.OrderId
     INNER JOIN dbo.T_Customer c WITH(NOLOCK) ON c.UserID=b.CustomerId
     LEFT JOIN dbo.T_OrderPackage d WITH(NOLOCK) ON d.OrderId=a.OrderId
      where 1=1  '    
   
     -- 搜索相关订单及其未决订单                                                            
           IF @OrderId > ''
               BEGIN   
                   IF ( CHARINDEX(',',@OrderId,1) > 0 )
                       BEGIN  
                           SET @sql = @sql + ' AND a.OrderId IN ('''+ REPLACE(@OrderId,',',''',''') + ''')';     
                       END;   
                   ELSE
                       BEGIN                              
     -- 全订单号搜索时，用完全匹配                                                            
                           IF ( ISNUMERIC(@OrderId) = 1
                                AND LEN(@OrderId) = 12
                              )
                               BEGIN                                     
                                   SET @sql = @sql + ' AND (a.OrderId = '''+ @OrderId+ ''')';
                                   END;                                             
                  
                           ELSE
                               IF ( ISNUMERIC(@OrderId) = 1
                                    AND LEN(@OrderId) >= 6
                                    AND ISDATE(SUBSTRING(@OrderId,1,6)) = 1
                                  )
                                   OR ( ISNUMERIC(@OrderId) = 0
                                        AND LEN(@OrderId) >= 7
                                        AND ( ISDATE(SUBSTRING(@OrderId,2,6)) = 1
                                              OR ISDATE(SUBSTRING(@OrderId,3,6)) = 1
                                            )
                                      )
                                   BEGIN  --前匹配
                                       SET @sql = @sql
                                           + ' AND (a.OrderId LIKE ''' + @OrderId+ '%'')';        
                                   END;
                               ELSE
                                   BEGIN                                                            
                                       SET @sql = @sql
                                           + ' AND (CHARINDEX('''+ @OrderId+ ''',a.OrderId,0) > 0 )';           
                                   END;      
                       END;                                  
               END;                      
   
     IF(@OrderIndustryType>0)  
        BEGIN         
       SET @sql = @sql + ' AND OrderIndustryType='+ltrim(str(@OrderIndustryType))        
       END   
   
   	
     IF(@Lang>-1)        
    BEGIN        
        SET @sql = @sql + ' AND Lang='+ ltrim(str(@Lang))        
    END        
     
       IF(@HandlerId>0)        
    BEGIN        
        SET @sql = @sql + ' AND HandlerId='+ ltrim(str(@HandlerId))        
    END       
   
     IF(@EmailId>0)        
    BEGIN        
        SET @sql = @sql + ' AND c.EmailID='+ ltrim(str(@EmailId))        
    END 
	
	IF @serviceStar>0
	BEGIN
		        SET @sql = @sql + ' AND ServiceScore='+ ltrim(str(@serviceStar))        
	END       

	IF @qualityStar>0
	BEGIN
		        SET @sql = @sql + ' AND QualityScore='+ ltrim(str(@qualityStar))        
	END       
              

	IF @shipmentStar>0
	BEGIN
		        SET @sql = @sql + ' AND ShipmentScore='+ ltrim(str(@shipmentStar))        
	END       
              

      IF(@StartDate<>'')        
    BEGIN         
       SET @sql = @sql + ' AND DueDate>='''+ @StartDate+''''        
    END         
            
    IF(@EndDate<>'')        
    BEGIN         
       SET @sql = @sql + ' AND DueDate<='''+ @EndDate+''''        
    END         
     
   
      SET @ExportOrderSql=@sql;
      SET @ExportServerSql=@sql;
   
    --得到记录条数          
       SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql + ') AS Items'          
       EXEC sp_executesql  @countSql, N'@rowCount INT OUT', @rowCount OUT           
            
    IF(@PageIndex<1) SET @PageIndex=1        
       SET @pageCount = (@RowCount + @PageSize - 1) / @PageSize          
       IF ISNULL(@PageIndex, 0) < 1 SET @PageIndex = 1          
       ELSE IF @PageIndex > @pageCount  SET @PageIndex = @pageCount          
       SET @startPageIndex = (@PageIndex - 1) * @PageSize + 1          
       SET @endPageIndex = @PageIndex * @PageSize         
                 
    SET @sql = 'SELECT * FROM ('+@sql+') AS Items WHERE RowNo BETWEEN ' + ltrim(STR(@startPageIndex)) + ' AND ' + ltrim(STR(@endPageIndex))+' ORDER BY Id desc'        
            
       PRINT @sql        
       EXEC(@sql)         
            
       SELECT @rowCount   AS 'RowCount',@pageCount AS 'PageCount'  
   
   	SET @ExportServerSql='
   	WITH result as 
   	(
   	'+@ExportServerSql+'
   	), cte AS 
   (
   SELECT a.HandlerId,
   SUM(CAST(CASE WHEN a.ServiceScore=5 THEN 1 ELSE 0 END AS INT)) AS Five,
   SUM(CAST(CASE WHEN a.ServiceScore=4 THEN 1 ELSE 0 END AS INT))  AS Four,
   SUM(CAST(CASE WHEN a.ServiceScore=3 THEN 1 ELSE 0 END AS INT))  AS Three,
   SUM(CAST(CASE WHEN a.ServiceScore=2 THEN 1 ELSE 0 END AS INT))  AS Two,
   SUM(CAST(CASE WHEN a.ServiceScore=1 THEN 1 ELSE 0 END AS INT))  AS One,
   COUNT(1) AS qty
    FROM result  a
   GROUP BY a.HandlerId)
   SELECT b.name AS HandlerName,a.Five,a.Four,a.Three,a.Two,a.One,CAST((a.Five*5+a.Four*4+a.Three*3+a.Two*2+a.One)*1.0/a.qty AS DECIMAL(5,2)) AS AvgScore  FROM cte a 
   INNER JOIN dbo.[user] b ON a.HandlerId=b.id'
   
   	SET @ExportOrderSql='
   	WITH result as 
   	(
   	'+@ExportOrderSql+'
   	),cte AS 
   (
   SELECT 5 AS Star,
   SUM(CAST(CASE WHEN  QualityScore=5 THEN 1 ELSE 0 END AS INT))  产品质量评价 ,
   SUM(CAST(CASE WHEN  ShipmentScore= 5 THEN 1 ELSE 0 END AS INT)) 物流评价,
   SUM(CAST( CASE WHEN  ServiceScore=5 THEN 1 ELSE 0 END  AS INT)) 服务评价
    FROM result 
     UNION ALL 
    SELECT 4 AS Star,
   SUM(CAST(CASE WHEN  a.QualityScore=4 THEN 1 ELSE 0 END AS INT))  产品质量评价 ,
   SUM(CAST(CASE WHEN  a.ShipmentScore= 4 THEN 1 ELSE 0 END AS INT)) 物流评价,
   SUM(CAST( CASE WHEN  a.ServiceScore=4 THEN 1 ELSE 0 END  AS INT)) 服务评价
    FROM result a  
      UNION ALL 
    SELECT 3 AS Star,
   SUM(CAST(CASE WHEN  a.QualityScore=3 THEN 1 ELSE 0 END AS INT))  产品质量评价 ,
   SUM(CAST(CASE WHEN  a.ShipmentScore= 3 THEN 1 ELSE 0 END AS INT)) 物流评价,
   SUM(CAST( CASE WHEN  a.ServiceScore=3 THEN 1 ELSE 0 END  AS INT)) 服务评价
    FROM result a  
       UNION ALL 
    SELECT 2 AS Star,
   SUM(CAST(CASE WHEN  a.QualityScore=2 THEN 1 ELSE 0 END AS INT))  产品质量评价 ,
   SUM(CAST(CASE WHEN  a.ShipmentScore= 2 THEN 1 ELSE 0 END AS INT)) 物流评价,
   SUM(CAST( CASE WHEN  a.ServiceScore=2 THEN 1 ELSE 0 END  AS INT)) 服务评价
    FROM result a 
       UNION ALL 
     SELECT 1 AS Star,
   SUM(CAST(CASE WHEN  a.QualityScore=1 THEN 1 ELSE 0 END AS INT))  产品质量评价 ,
   SUM(CAST(CASE WHEN  a.ShipmentScore= 1 THEN 1 ELSE 0 END AS INT)) 物流评价,
   SUM(CAST( CASE WHEN  a.ServiceScore=1 THEN 1 ELSE 0 END  AS INT)) 服务评价
    FROM result a 
   )
   SELECT * FROM cte'
   
     EXEC(@ExportOrderSql)         
   
         EXEC(@ExportServerSql)         
   	  PRINT @ExportServerSql
   END
go



CREATE PROC CRM_Order_AddOrderResendRecord
    (
      @OrderId VARCHAR(15) ,
      @OrderStatus INT ,
      @ApplyType INT ,
      @OperatorId INT
    )
AS
    BEGIN

        IF EXISTS ( SELECT TOP 1
                            1
                    FROM    dbo.T_OrderResendRecord
                    WHERE   OrderId = @OrderId  AND ProcessStatus<>3)
            RETURN;

        INSERT  INTO dbo.T_OrderResendRecord
                ( OrderId ,
                  InitiateOrderStatus ,
                  ApplyType ,
                  CreateTime ,
                  OperatorId ,
                  ProcessStatus ,
                  ProcessTime
	            )
        VALUES  ( @OrderId , -- OrderId - nvarchar(15)
                  @OrderStatus , -- InitiateOrderStatus - int
                  @ApplyType , -- ApplyType - tinyint
                  GETDATE() , -- CreateTime - datetime
                  @OperatorId , -- OperatorId - int
                  1 , -- ProcessStatus - tinyint
                  NULL -- ProcessTime - datetime
	            );
    END;
go


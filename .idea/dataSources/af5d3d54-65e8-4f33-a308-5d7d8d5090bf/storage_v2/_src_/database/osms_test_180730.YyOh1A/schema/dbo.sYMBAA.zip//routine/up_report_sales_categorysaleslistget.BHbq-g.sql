





/*----------------------------------------------------
[销售]
	某段时间统计网站BeadsFindings大类销售批量数排行表
up_Report_Sales_CategorySalesListGet '2008-07-01','2008-09-01'	
------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Sales_CategorySalesListGet] 
(
	@StartTime		DateTime, 
	@EndTime		DateTime
)
AS
Begin
	SET NOCOUNT ON;

	/*
	Select e.CategoryName,Cast(Sum(a.Quantity) As Int) As Quantity
	From
		B_OrderItem a
		Join B_Order b On a.OrderId = b.OrderId
		Join T_Item  c On a.ProductId = c.ItemKeyId
		Join T_CategorySearch	d On c.CategoryId = d.LeafageId
		Join T_CategoryHelp e On d.ParentId = e.CategoryId 
			And e.[Type] = 1 And e.[Level] = 3 --  大类指三级类别
	Where
		a.Status < 12 And b.Status < 132 And e.CategoryId > 0 And a.Quantity > 0
		And b.OrderDate > @StartTime And b.OrderDate < @EndTime And e.Disabled = 0
	Group by 
		e.CategoryName 
	Order by
		Sum(a.Quantity) Desc

	*/
	
	WITH cte AS
	(	
		SELECT 
			c.SecondCategoryId AS CategoryId,
			CAST(SUM(b.Quantity*1.0/b.UnitQuantity) AS DECIMAL(18,2)) AS qty
		FROM dbo.T_Order a 
			INNER JOIN dbo.T_OrderItem b 
				ON a.OrderId = b.OrderId 
					AND a.OrderStatus > 0 AND a.OrderStatus < 132 AND b.[Status] < 12 -- 非取消商品
						AND a.OrderDate > @StartTime AND a.OrderDate < @EndTime  
			INNER JOIN dbo.V_CategoryProduct c 
				ON b.ProductId = c.ProductId
		GROUP BY c.SecondCategoryId -- 二级类别
	)	
	
	SELECT 
		b.[Name] AS CategoryName,-- 二级类别名称
		a.qty AS Quantity -- 销售批量次数
	FROM cte a JOIN dbo.T_Category b
		ON a.CategoryId = b.CategoryId	
	ORDER BY a.qty DESC;
End


go


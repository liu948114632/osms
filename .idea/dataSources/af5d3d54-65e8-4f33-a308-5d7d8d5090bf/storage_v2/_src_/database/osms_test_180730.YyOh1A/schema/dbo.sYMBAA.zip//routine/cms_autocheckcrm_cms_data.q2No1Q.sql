/*----------------------------------------------      
备注：定时检查CRM与CMS之间的数据问题，并补救    
创建人: LXH      
创建日期:2012-06-02      
-----------------------------------------------*/      
CREATE PROC [dbo].[CMS_AutoCheckCRM&CMS_Data]       
AS        
BEGIN      
    --1、检查订单商品项有问题的数据，并重新同步    
    INSERT INTO dbo.order_item_operator_log    
        ( operator_time, status, object_id )    
 SELECT GETDATE(),2,cmsId    
 FROM (    
 SELECT a.OrderId,a.OrderItemId,b.id AS cmsId,a.ProductId,b.product_id,a.UnitQuantity,a.Quantity,b.order_quantity,a.ReadyQty,b.prepared_quantity,a.Status crmStatus,b.status cmsStatus,f.OrderStatus crmOrderStatus,e.status cmsOrderStatus    
 ,(SELECT TOP 1 dbo.order_item_operator_log.operator_time    
 FROM dbo.order_item_operator_log WITH(NOLOCK) WHERE dbo.order_item_operator_log.object_id=b.id ORDER BY dbo.order_item_operator_log.operator_time DESC ) oTIME    
 ,(SELECT TOP 1 DATEDIFF(n,operator_time,GETDATE())    
 FROM dbo.order_item_operator_log WITH(NOLOCK) WHERE dbo.order_item_operator_log.object_id=b.id ORDER BY dbo.order_item_operator_log.operator_time DESC ) diff    
 FROM dbo.T_OrderItem a WITH(NOLOCK)    
 INNER JOIN dbo.T_Order f WITH(NOLOCK) ON a.OrderId=f.OrderId    
 INNER JOIN dbo.order_item b WITH(NOLOCK) ON a.OrderItemId = b.business_id    
 INNER JOIN dbo.[order] e WITH(NOLOCK) ON b.order_id=e.id    
 WHERE (a.Quantity != b.order_quantity OR  (a.ReadyQty != b.prepared_quantity AND a.Status !=12) OR a.Status != b.status)    
 AND a.Status !=12 AND b.status !=12     
 AND ((f.OrderStatus = e.status AND e.status NOT IN (64,128)) OR f.OrderStatus != e.status)    
 ) temp    
 WHERE diff > 2    
        
    --2、检查订单有问题的数据，并重新同步    
    INSERT INTO dbo.order_operator_log    
        ( operator_time, status, object_id )    
 SELECT GETDATE(),2, temp2.cmsid    
 FROM     
 (    
  SELECT *    
  ,(SELECT TOP 1 dbo.order_operator_log.operator_time    
  FROM dbo.order_operator_log WITH(NOLOCK) WHERE dbo.order_operator_log.object_id=cmsid ORDER BY dbo.order_operator_log.operator_time DESC ) oTIME    
  ,(SELECT TOP 1 DATEDIFF(n,operator_time,GETDATE())    
  FROM dbo.order_operator_log WITH(NOLOCK) WHERE dbo.order_operator_log.object_id=cmsid ORDER BY dbo.order_operator_log.operator_time DESC ) diff    
  FROM     
  (    
   SELECT dbo.T_Order.OrderId,dbo.T_Order.OrderDate,dbo.T_Order.OrderStatus AS crm_status,dbo.[order].status AS cms_status,    
   (SELECT COUNT(*) countItems FROM dbo.T_OrderItem WITH(NOLOCK) WHERE dbo.T_OrderItem.OrderId=T_Order.OrderId AND dbo.T_OrderItem.Status != 12) AS crmItems,    
   (SELECT COUNT(*) countItems FROM dbo.order_item WITH(NOLOCK) WHERE dbo.order_item.order_id=[order].id AND dbo.order_item.status != 12) AS cmsItems,    
   id AS cmsid,    
   dbo.[order].valid_order_count AS cmsItmes2    
   FROM dbo.T_Order WITH(NOLOCK)    
   LEFT JOIN dbo.[order] WITH(NOLOCK) ON dbo.[order].code=dbo.T_Order.OrderId    
   WHERE dbo.T_Order.OrderStatus>0    
  ) temp    
  WHERE crm_status != cms_status OR temp.crmItems != cmsItems OR (temp.cmsItems != temp.cmsItmes2 AND cms_status != 132)    
  ) temp2     
 WHERE temp2.diff > 2    
    
    --3同步跟单员    
    UPDATE a SET merchandiser_id = b.HandlerId     
 FROM dbo.[order] a WITH(NOLOCK)    
 INNER JOIN dbo.T_Order b WITH(NOLOCK) ON a.code=b.OrderId    
 WHERE  a.merchandiser_id!=b.HandlerId AND b.OrderStatus<=64    
   
 --4、重启通知P3异常命令  
 UPDATE dbo.communication_order_log SET status=1 WHERE dbo.communication_order_log.status=3  
    
END
go


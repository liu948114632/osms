

-- =============================================
-- Author:		HYD
-- Create date: 2010-06-10
-- Description:	删除单个订单的附加费
-- Version：CRM 5.1.0
-- =============================================
CREATE PROCEDURE [dbo].[CRM_Order_OrderSurchargeDeletByOrderId]
(
	@OrderId	VARCHAR(20)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DELETE FROM dbo.T_OrderSurcharge WHERE OrderId = @OrderId
                                                            
END

go


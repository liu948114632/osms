
/*-----------------------------------------    
 获取Cash提现记录
--------------------------------------------*/    
CREATE PROC dbo.CRM_Cash_GetCashWithdrawRecordList
(    
@EmailId INT=-1, 
@CustomerName VARCHAR(101)='' ,
 @WithdrawWayId int=0,  
 @StartTime  NVARCHAR(50)  = ' ',    
 @EndTime  NVARCHAR(50)  = ' ',  
 @HandleId   INT     =   0,       
@PageSize INT=50,        
@PageIndex INT=0  
)    
AS    
BEGIN        
 SET NOCOUNT ON; 
 DECLARE @sql NVARCHAR(max)        
 DECLARE @countSql NVARCHAR(max)        
 DECLARE @rowCount int,@pageCount int, @startPageIndex int, @endPageIndex int         
     
     SET @Sql = ' 
SELECT CustomerId,
tc.FullName as  customerName,
tc.EmailId,
tc.GroupId as grouptype,
WithdrawAmount, 
WithdrawCurrencyId, 
(SELECT  CONVERT( VARCHAR(10),RefundAmount)+'' ''+cy.Currency FROM dbo.T_Currency cy WHERE Id=WithdrawCurrencyId) AS  AmountCurrency,
RefundAmount, 
WithdrawWayId, 
TransactionId,
CustomerNo,
 Account, 
CustomerAddress, 
OrderCode,
Remark, 
HandlerId, 
CashId, 
BusinessTypeId,
u.Name as handlerName,
CreateDate,
CASE WHEN WithdrawWayId=1 or  WithdrawWayId=2
THEN TransactionId
WHEN WithdrawWayId=5 or  WithdrawWayId=6
THEN Account+'':''+CustomerNo
ELSE CustomerAddress
END
AS UnionInfo,   
     ROW_NUMBER() OVER(order by a.createDate) as RowNumber                              
 from T_CashWithdrawRecord a
INNER JOIN dbo.T_Customer tc ON a.CustomerId=tc.UserID  
INNER JOIN dbo.[user] u ON a.HandlerId=u.id ';     
     
 -- 条件     
 SET @sql =@sql+'  WHERE 1=1 ';    

 IF @EmailId>0
  SET @sql = @sql +  '    
  AND  tc.emailId ='+CONVERT( VARCHAR(50),@EmailId) ;    
  
   IF @CustomerName<>''    
  SET @sql = @sql +  '    
  AND a.CustomerId  IN (Select UserId From T_Customer Where CHARINDEX('''+@CustomerName+''',FullName,0) > 0 )  '
  
      
 IF @HandleId > 0    
  SET @sql = @sql +  '    
  AND a.HandlerId = '+CONVERT( VARCHAR(50),@HandleId) ;    
     
 IF @StartTime<>''      
  SET @sql = @sql + '      
  AND a.createDate >'''+@StartTime+'''' ;      
      
 IF @EndTime<>'' 
  SET @sql = @sql + '       
  AND a.createDate <'''+@EndTime+'''';      
    
 IF @WithdrawWayId >0   
  SET @sql = @sql + '     
  AND a.WithdrawWayId='+CONVERT( VARCHAR(50),@WithdrawWayId) ; 
     
 --得到记录条数          
    SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql + ') AS Items'          
    EXEC sp_executesql  @countSql, N'@rowCount INT OUT', @rowCount OUT           
         
 IF(@PageIndex<1) SET @PageIndex=1        
    SET @pageCount = (@RowCount + @PageSize - 1) / @PageSize          
    IF ISNULL(@PageIndex, 0) < 1 SET @PageIndex = 1          
    ELSE IF @PageIndex > @pageCount  SET @PageIndex = @pageCount          
    SET @startPageIndex = (@PageIndex - 1) * @PageSize + 1          
    SET @endPageIndex = @PageIndex * @PageSize         
              
 SET @sql = 'SELECT * FROM ('+@sql+') AS Items WHERE RowNumber BETWEEN ' + ltrim(STR(@startPageIndex)) + ' AND ' + ltrim(STR(@endPageIndex))+' ORDER BY createDate DESC'        
           
	PRINT @sql

    EXEC(@sql)                 
    SELECT @rowCount   AS 'RowCount',@pageCount AS 'PageCount'  ;
END


go


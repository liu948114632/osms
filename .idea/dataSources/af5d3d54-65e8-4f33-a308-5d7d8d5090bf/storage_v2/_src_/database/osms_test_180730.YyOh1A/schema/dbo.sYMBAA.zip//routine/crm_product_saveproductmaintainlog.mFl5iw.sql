CREATE PROC CRM_Product_SaveProductMaintainLog
(
@CmsProductId INT,
@OriginalContent VARCHAR(6000),
@ModifyContent VARCHAR(6000)
)
AS
BEGIN
	INSERT INTO dbo.T_ProductMaintainLog
	        ( 
			 CmsProductId ,
	          OriginalContent ,
	          ModifyContent ,
	          Status ,
	          JoinTime
	        )
	VALUES  (
	          @CmsProductId, -- CmsProductId - int
	          @OriginalContent, -- OriginalContent - varchar(6000)
	          @ModifyContent , -- ModifyContent - varchar(6000)
	          0 , -- Status - tinyint
	          GETDATE()  -- JoinTime - datetime
	        )
END
go


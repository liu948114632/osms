-- =============================================    
-- Description: <根据C3商品ID获得PH-UK商品信息>  
-- =============================================   
CREATE PROC [dbo].[CRM_Product_GetPH_UKProductByCMSProdutId]      
(      
 @CmsProductId INT   
)      
AS      
BEGIN  
 SELECT  *
 FROM dbo.V_CRM_PH_UK_Product   
 WHERE CmsProductId = @CmsProductId;  
END

go


CREATE PROC CRM_Role_EditRole
(
@Id INT ,
@Name VARCHAR(50),
@Description VARCHAR(100),
@RoleId INT OUTPUT
)
AS 
BEGIN

IF @Id>0
BEGIN
		IF EXISTS (SELECT TOP 1 1 FROM dbo.T_Role WHERE name=@Name AND @Id<>id)
		    RAISERROR ('<info>角色名重复</info>' , 16, 1) WITH NOWAIT;    

			UPDATE dbo.T_Role SET name=@Name,description=@Description WHERE id=@Id
END
ELSE
BEGIN
	IF EXISTS (SELECT TOP 1 1 FROM dbo.T_Role WHERE name=@Name)
	     RAISERROR ('<info>角色名重复</info>' , 16, 1) WITH NOWAIT;    
		 INSERT INTO dbo.T_Role
		         ( name,description )
		 VALUES  (@Name, -- name - varchar(50)
		           @Description  -- description - varchar(100)
		           )
				   SET @RoleId=@@IDENTITY
END
END

go


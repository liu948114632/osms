
CREATE VIEW [dbo].[V_CRM_OrderOutOfStockItemsCount] 
AS    
SELECT           
 [OrderId],      
 COUNT_BIG(*) AS Counts -- 订单商品总个数      
FROM dbo.T_OrderItem WITH(NOLOCK)       
WHERE [Status] = 4  -- 断货的订单商品      
GROUP BY [OrderId]
go


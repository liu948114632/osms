

--产品在中心仓库供应商货架上可用库存
CREATE VIEW [dbo].[view_product_provider_storage_quantity_info] AS 
SELECT a.product_id,
		ISNULL(b.quantity,0)-a.buying_quantity AS quantity,
		0 AS lock_quantity,
		ISNULL(b.quantity,0)-a.buying_quantity AS available_qty
FROM dbo.provider_storage_product a JOIN dbo.view_product_all_storage_quantity_info b ON a.product_id =b.product_id

go


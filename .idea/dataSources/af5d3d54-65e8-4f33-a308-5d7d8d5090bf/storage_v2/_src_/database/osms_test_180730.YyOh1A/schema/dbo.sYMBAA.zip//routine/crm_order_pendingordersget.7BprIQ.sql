

/* 2014-12-08 mzc 增加RateVersion */  
CREATE PROC dbo.CRM_Order_PendingOrdersGet  
    (  
      @OrderId VARCHAR(MAX) = '' ,  
      @HandlerId VARCHAR(500) ='' ,  
      @BeginOrderDate VARCHAR(20) ='',
      @EndOrderDate VARCHAR(20) ='',
      @CustomerName NVARCHAR(101) = '' ,  
      @DifferenceAmount DECIMAL(18, 2) = 0 , -- 差额                        
      @Status INT = -1 ,  
      @OrderIndustryTypes VARCHAR(MAX) = '' ,  
      @ShopTradeNo VARCHAR(50)='',
      @ShopCustomerName VARCHAR(50)='',
      @ShopId VARCHAR(50)='', 
      @PayStatus INT = 0 , -- 付款状态
      @PageNo INT = 0 ,  
      @PageSize INT = 25 
    )  
AS   
    DECLARE @Sql NVARCHAR(MAX) ,  
        @CountSql NVARCHAR(MAX) ,  
        @Where NVARCHAR(MAX) ,  
        @Parameters NVARCHAR(MAX) , -- 动态参数                        
        @PageCount INT ,  
        @RowCount INT ,  
        @Start INT , --每页的起始位置                        
        @End INT  --每页的终止位置                        
    BEGIN                         
 -- 不返回影响结果                        
        SET NOCOUNT ON;                        
                              
        SET @Where = ' Where a.[OrderType] in (1,2,4)'                      
                         
        IF ( CHARINDEX(',', @OrderId, 0) <= 0 )   
            BEGIN --查询多个订单号时不限制状态                      
       -- 组合条件语句(状态是Pending或取消的)                        
                SET @Where = @Where + ' AND a.OrderStatus In (0,132) ';                        
            END                       
                         
 -- 组合查询语句                        
        SET @CountSql = 'Select @pRowCount = Count(1)   FROM  dbo.T_Order a With(NoLock)';                         
                         
 -- 订单状态                        
        IF @Status > -1   
            BEGIN                        
                SET @Where = @Where + ' And a.OrderStatus = @pStatus';                        
            END       
            
      -- 跟单员                        
        IF @HandlerId<>'99999'  
            BEGIN                        
                SET @Where = @Where + ' And a.HandlerId in (select [Value] from dbo.uf_Split('''+@HandlerId+''','','')) ';           
				            
            END                    
                         
 -- 订单编号                        
        IF @OrderId > ''   
            BEGIN                        
                IF ( CHARINDEX(',', @OrderId, 0) > 0 )--查询多个订单号                      
                    BEGIN                      
                        SET @Where = @Where + ' AND a.OrderStatus IN(0,132)  And  a.OrderId in ('''  
                            + REPLACE(@OrderId, ',', ''',''') + ''')';                       
                    END                       
                ELSE   
                    BEGIN                       
                        SET @Where = @Where  
                            + ' And CHARINDEX(@pOrderId,a.OrderId,0) > 0';                       
                    END                        
            END                        
                         
 -- 客户名称                        
        IF @CustomerName > ''   
            BEGIN                        
                SET @Where = @Where  
                    + ' AND a.CustomerId IN( SELECT UserId FROM dbo.T_Customer WHERE CHARINDEX(@pCustomerName,FullName,0) > 0)';                          
            END                  
          
             IF @ShopCustomerName > ''   
            BEGIN                        
                SET @Where = @Where  
                    + ' AND a.OrderId IN( SELECT OrderId FROM dbo.T_ShopCustomer WHERE CHARINDEX('''+@ShopCustomerName+''',ShopCustomerName,0) > 0)';                          
            END            
          
              IF @ShopTradeNo > ''   
            BEGIN                        
                SET @Where = @Where  
                    + ' AND a.OrderId IN( SELECT OrderId FROM dbo.T_ShopCustomer WHERE CHARINDEX('''+@ShopTradeNo+''',ShopTradeNo,0) > 0)';                          
            END     
                        
 -- 应付款金额                        
        IF @DifferenceAmount > 0   
            BEGIN                        
                SET @Where = @Where  
                    + ' And DuePay = @pDifferenceAmount + RealPay';                        
            END                  
                          
                --订单的业务类型              
        IF @OrderIndustryTypes = ''   
            BEGIN              
                SET @Where = @Where + ' And 1=2';              
            END                
        ELSE   
            BEGIN              
                SET @Where = @Where  
                    + ' And a.OrderIndustryType in (select [Value] from dbo.uf_Split(@pOrderIndustryTypes,'',''))';              
            END         
            
                                                                         
 -- 订单付款状态                                                            
        IF @PayStatus > 0                                                             
        BEGIN                                                            
            SET @Where = @Where + ' AND a.[PayStatus] ='+ CONVERT(VARCHAR(10),@PayStatus); 
        END                                                           

        IF( LEN(@BeginOrderDate) > 0 )
        BEGIN
            SET @Where = @Where + ' And OrderDate >= ''' + @BeginOrderDate + '''';          
        END   
        IF( LEN(@EndOrderDate) > 0 )
        BEGIN
            SET @Where = @Where + ' And OrderDate <= ''' + @EndOrderDate + '''';             
        END    
                         
        SET @CountSql = @CountSql + @Where;                        
                         
 -- 拼凑动态参数                        
        SET @Parameters = N'@pRowCount INT OUT,@pOrderId VARCHAR(13),@pCustomerName NVARCHAR(101),@pStatus INT,@pDifferenceAmount DECIMAL(9,2),@pOrderIndustryTypes varchar(max)';                        
                         
 -- 获取总记录数                        
        EXEC sp_executesql @CountSql, @Parameters, @pRowCount = @RowCount OUT,  
            @pOrderId = @OrderId, @pCustomerName = @CustomerName,  
            @pStatus = @Status, @pDifferenceAmount = @DifferenceAmount,  
            @pOrderIndustryTypes = @OrderIndustryTypes;                        
                        
 -- 分页参数设置                        
        IF ISNULL(@PageSize, 0) < 1   
            SET @PageSize = 20;                        
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize;                        
        SET @pageNo = @PageNo + 1;                        
        IF ISNULL(@pageNo, 0) < 1   
            SET @pageNo = 1;                        
        ELSE   
            IF ISNULL(@pageNo, 0) > @PageCount   
                SET @pageNo = @PageCount;                        
        SET @Start = ( @PageNo - 1 ) * @PageSize + 1;                        
        SET @End = @PageNo * @PageSize;                        
                          
 -- 返回页数和总记录数                        
        SELECT  @PageCount AS PageCount ,  
                @RowCount AS [RowCount];        
                      
                         
        SET @Sql = '                         
 With cte As                        
 (                        
 Select                         
   a.OrderId,                        
   a.CustomerId,                        
   null AS PayType,                        
   a.OrderDate,                        
   a.OrderStatus,         
  a.PayStatus,                
   a.IsSendMail,                        
   a.ShipAddressId,                        
   a.HandlerId,                     
dbo.CRM_Fun_Order_GetOrderDuePayAmount(a.OrderId)   As DuePay,                        
   ISNULL(
     (Select  Convert(decimal(18,2),Sum(op.PaySum/cu.Rate))                    
   From dbo.T_OrderPay op WITH(NOLOCK)                    
    INNER Join  T_Currency cu WITH(NOLOCK) On op.OrderId = a.OrderId AND op.CurrencyId = cu.Id)                    
   ,0) AS RealPay,                    
   a.DeliveryId,    
   a.IsFreeShipping,                         
   a.IsRemote,                      
   a.OrderIndustryType,        
   a.SubType,    
      isnull(a.FreightDiscount,0) AS FreightDiscount,
   ROW_NUMBER() OVER(ORDER BY a.OrderStatus,a.OrderDate DESC) AS RowNumber,  
   a.RateVersion ,
   a.IsSend,
   a.sendgroupId      
  From                        
   dbo.T_Order a With(NoLock)                     
  ' + @Where  
            + '                        
 ),cteOrders AS                        
 (                        
  SELECT                        
   OrderId, CustomerId, PayType,  OrderDate, OrderStatus,   PayStatus, ShipAddressId,  HandlerId,                       
   DuePay, RealPay,IsSendMail,DeliveryId,  
   IsFreeShipping,IsRemote,OrderIndustryType,SubType,sendgroupId,
   RowNumber,  
   RateVersion,
   FreightDiscount ,
   IsSend          
  From cte                         
  Where RowNumber BETWEEN @pStart AND @pEnd                        
 )                        
                         
 Select                         
  a.OrderId,      
  h.[ShopTradeNo],                    
  a.CustomerId,                        
  a.PayType,                        
  a.OrderDate,                        
  a.OrderStatus,    
  a.PayStatus,                      
  a.DuePay,                  
  a.RealPay,                    
  (ISNULL(a.DuePay,0) - ISNULL(a.RealPay,0)) AS DifferenceAmount,                      
  ISNULL((Select  Convert(decimal(18,2),Sum(op.PaySum/cur.Rate))                        
   FROM dbo.T_OrderPay OP WITH(NOLOCK)                     
   INNER Join  T_Currency cur WITH(NOLOCK) On OP.OrderId = a.OrderId AND OP.CurrencyId = cur.Id AND OP.PayType=3)                     
  ,0) AS CashPay,                      
  ISNULL((Select  Convert(decimal(18,2),Sum(op.PaySum/cur.Rate))                        
   FROM dbo.T_OrderPay OP WITH(NOLOCK)            
   INNER Join  T_Currency cur WITH(NOLOCK) On OP.OrderId = a.OrderId AND OP.CurrencyId = cur.Id AND OP.PayType=4)                     
  ,0) AS CouponPay,                     
  '''' AS PayId,                    
  b.OrderRemark As Remark,                        
  c.EmailId,                        
  a.IsSendMail,                       
  (CASE WHEN EXISTS(SELECT * FROM dbo.T_CustomerVip WHERE UserId = a.CustomerId)                         
  THEN                         
   ''[VIP]'' + c.FullName                        
  ELSE                        
   c.FullName                        
  END) AS CustomerName,-- 客户名称                        
  ISNULL(d.CompanyName,'''') + '' '' + d.Address1 + '' '' + ISNULL(d.Address2,'''') + '' '' +  d.City + '' '' + d.State                        
  + '' '' + e.[Name] + '','' + d.Zip As Address, -- 订单地址信息                         
  ISNULL(f.name,'''') AS Handler, --跟单员                        
  ISNULL(f.english_name,'''') AS HandlerName, --跟单员英文名称                        
  a.DeliveryId,     a.IsFreeShipping,    g.Name AS DeliveryName,     a.IsRemote,  
  a.OrderIndustryType,    
  a.SubType,    
  a.RateVersion,
  a.FreightDiscount,
    a.IsSend ,
	   a.sendgroupId,
(CASE WHEN d.Country=103  AND EXISTS (SELECT TOP 1 1 FROM dbo.T_OrderItem i INNER JOIN dbo.T_OverseasWarehouseProduct op
 ON i.CmsProductId=op.CMSProductId  WHERE i.OrderId=a.OrderId AND op.WarehouseId IN (1,2))
 THEN ''True''
WHEN  d.Country IN (24,34,35,44,50)  AND EXISTS (SELECT TOP 1 1  FROM dbo.T_OrderItem i INNER JOIN dbo.T_OverseasWarehouseProduct op
 ON i.CmsProductId=op.CMSProductId  WHERE i.OrderId=a.OrderId AND op.WarehouseId=3)
THEN ''True'' 
ELSE
''False''
END )  AS ExitWarehouseProduct  ,
h.ShopCustomerName,
c.SuspicionMarking,
cast(isnull(k.IsCashOrder,0) as bit) as IsCashOrder
 From                         
  cteOrders a                        
  INNER JOIN dbo.T_OrderRemark b  On a.OrderId=b.OrderId                        
  INNER JOIN dbo.T_Customer c  On a.CustomerId=c.UserId                        
  LEFT JOIN dbo.T_OrderAddresses d  On a.ShipAddressId=d.AddressId          
  LEFT JOIN dbo.T_Country e ON   d.Country=e.CountryId                        
  LEFT JOIN [user] f ON a.HandlerId=f.Id                        
  LEFT JOIN T_Delivery g  ON a.DeliveryId=g.DeliveryId    
  LEFT JOIN dbo.[T_ShopCustomer] h ON h.[OrderId]=a.[OrderId]  
  LEFT JOIN dbo.T_OrderExtend k WITH(NOLOCK) ON a.OrderId=k.OrderId
  Order By a.RowNumber';                        
                        
 -- 拼凑动态参数                        
        SET @Parameters = N'@pStart INT ,@pEnd INT,@pOrderId VARCHAR(13),@pCustomerName NVARCHAR(101),@pStatus INT,@pDifferenceAmount DECIMAL(9,2),@pOrderIndustryTypes varchar(max)';              
                  
 -- 获取总记录数                        
        EXEC sp_executesql @Sql, @Parameters, @pStart = @Start, @pEnd = @End,  
            @pOrderId = @OrderId, @pCustomerName = @CustomerName,  
            @pStatus = @Status, @pDifferenceAmount = @DifferenceAmount,  
            @pOrderIndustryTypes = @OrderIndustryTypes;                        
                  
        SELECT  @Sql       
        PRINT @Sql
    END


go


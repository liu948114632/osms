CREATE PROC  CMS_Storage_GetphProductStorage   
    (              
      @StartTime DATETIME = NULL , -- 开始时间                      
      @EndTime DATETIME = NULL  -- 结束时间                 
    )          
AS           
    BEGIN                            
        SET NOCOUNT ON ; 
		 
		 SELECT b.id AS id , c.product_id AS productId , c.id AS phProductId
		  ,CASE WHEN f.id IS NULL THEN  d.phStorageQuantity ELSE 0 END  AS availableQuantity
		  
		 FROM (
			 SELECT a.object_id  FROM  storage_operator_log a  
			 WHERE a.operator_time >= @StartTime
			 AND a.operator_time <= @EndTime  GROUP BY a.[status],a.[object_id]  
		 ) temp 
		 INNER JOIN dbo.storage AS b ON temp.object_id=b.id 
		 INNER JOIN view_business_department_storage d ON d.product_id = b.product_id
		 INNER JOIN dbo.ph_product AS c ON c.product_id=b.product_id  AND c.is_on_shelf=1
		 LEFT JOIN dbo.customize_product f ON f.product_id =b.product_id
        SET NOCOUNT OFF ;                      
    END
go


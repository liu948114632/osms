
/**
判断商品是否为海外仓商品
*/
CREATE PROC CRM_Order_IsOverseasWarehouseProduct
(
  @CmsProductId INT,
  @Result   BIT Out 
)
AS
begin
     IF EXISTS(SELECT CmsProductId FROM T_OverseasWarehouseProduct WHERE CMSProductId = @CmsProductId)
     begin
        SET @Result = 1
     END 
     ELSE 
     begin
        SET @Result = 0
     END      
END
go


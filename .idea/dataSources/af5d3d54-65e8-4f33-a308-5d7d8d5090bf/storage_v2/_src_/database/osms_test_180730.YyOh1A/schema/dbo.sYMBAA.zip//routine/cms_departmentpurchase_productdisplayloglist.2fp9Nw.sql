

    
/**                  
2012-08-16           
获得办事处屏蔽产品操作日志  
* 2013-01-27 增加下架状态条件 
*2016年7月19日增加商品池商品查询	              
*/     
CREATE PROCEDURE [dbo].[CMS_DepartmentPurchase_ProductDisplayLogList]    
(                 
  @DepartId INT = NULL, --部门ID           
  @ProductCode VARCHAR(24) = NULL,--商品Code            
  @OperTimeBegin VARCHAR(24) = NULL,--操作时间开始    
  @OperTimeEnd VARCHAR(24) = NULL,--操作时间结束      
  @ProviderCode VARCHAR(24) = NULL,  --供应商        
  @Cause INT = NULL, -- 原因  
  @IsProductPool BIT=NULL,
  @PageSize INT = 50 ,  --页大小            
  @PageIndex INT = 1    --当前页号            
)         
AS    
BEGIN    
 SET NOCOUNT ON;    
 DECLARE     
  @SQL NVARCHAR(MAX),    
  @CountSQL NVARCHAR(MAX),    
  @FromSQL NVARCHAR(MAX),    
  @FromSQL2 NVARCHAR(MAX),    
  @Column NVARCHAR(max),    
  @Condition NVARCHAR(MAX),    
  @RowCount INT,    
  @PageCount INT,    
  @Start INT,    
  @End INT    
 --查询显示列    
 SET @Column = ' L.id,    
       L.product_id productId,    
       L.department_id departmentId,    
       L.operator_id operatorId,    
       L.operator_time operateTime,    
       L.cause,    
       L.remark,    
       P.is_display isDisplayProduct,    
       L.provider_code providerCode,    
       L.update_user_id updateUserId,    
       L.update_time updateTime,    
       S.quantity as availableStorageQuantity,    
       P.code productCode,    
       PS.code productSetCode,    
       P.name productName,    
       P.original_name originalName,    
       P.unit_quantity unitQuantity,    
       P.unit,    
       P.cost_price costPrice,    
       PR.[level] providerLevel,    
       P.publish_status publishStatus,    
       p.is_display_ph isDisplayPH,    
       p.is_display_pw isDisplayPW,    
       p.is_display_jl isDisplayJl,
       P.color_card_picture_code colorCardPictureCode,    
       P.primary_picture_code primaryPictureCode,
       P.offline_status offlineStatus,
       (select case when COUNT(ssp.id) >0 then 1 else 0 end
        from dbo.stay_shield_product AS ssp WITH (NOLOCK) where ssp.product_id = P.id and ssp.is_shield = 1 and ssp.status = 1) as isShieldProduct,
        case when ppl.id is not null then 1 else 0 end as isProductpool';    
 --查询条件    
    SET @Condition = 'WHERE 1=1 ';    
    IF @DepartId IS NOT NULL    
    BEGIN    
  SET @Condition = @Condition + ' AND L.department_id= ' + CONVERT(VARCHAR(10), @DepartId);    
 END    
 IF @ProductCode IS NOT NULL    
 BEGIN    
  SET @Condition = @Condition + ' AND P.code LIKE ''' + @ProductCode + '%'' ';    
 END    
 IF @OperTimeBegin IS NOT NULL     
 BEGIN     
  SET @Condition = @Condition + ' AND L.operator_time >= ''' + @OperTimeBegin + '''';    
 END     
 IF @OperTimeEnd IS NOT NULL     
 BEGIN    
  SET @Condition = @Condition + ' AND L.operator_time <= ''' + @OperTimeEnd + '''';    
 END;    
 IF @ProviderCode IS NOT NULL    
 BEGIN    
  SET @Condition = @Condition + ' AND L.provider_code = ''' + @ProviderCode + '''';    
 END    
IF @Cause IS NOT NULL    
 BEGIN    
  SET @Condition = @Condition + ' AND L.cause = ' + CONVERT(VARCHAR(10), @Cause);   
 END 
 
 IF @IsProductPool IS NOT NULL    
 BEGIN    
	IF @IsProductPool=1
	BEGIN
	     SET @Condition = @Condition + ' AND ppl.id is not null ';   
	END
	ELSE
	BEGIN
		SET @Condition = @Condition + ' AND ppl.id is null ';  
	END
 
 END    
     
 --查询记录数    
 SET @CountSQL = '';    
 SET @CountSQL = 'SELECT @RowCountOUT=count(L.id) FROM ' + @FromSQL + @Condition;    
 --print @CountSQL;    
 EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;    
     
 --查询的分页条件    
 IF ISNULL(@PageSize, 0) < 1                           
  SET @PageSize = 50                          
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                          
    IF ISNULL(@PageIndex, 0) < 1                           
        SET @PageIndex = 1                          
    ELSE                           
    IF ISNULL(@PageIndex, 0) > @PageCount                           
        SET @PageIndex = @PageCount                          
    SET @Start = ( @PageIndex - 1 ) * @PageSize + 1                          
    SET @End = @PageIndex * @PageSize                   
     
 --查询主表    
 SET @FromSQL = ' FROM department_product_display_log L WITH (NOLOCK)     
    LEFT JOIN dbo.product P WITH (NOLOCK) ON P.id = L.product_id 
     left join dbo.product_pool ppl on ppl.product_id=L.product_id ';    
 --取字段表    
 SET @FromSQL2 = 'LEFT JOIN department_product_display_log L WITH (NOLOCK) ON temp.id=L.id    
      LEFT JOIN dbo.product P WITH (NOLOCK) ON P.id = L.product_id    
      LEFT JOIN view_product_generalized_storage S WITH (NOLOCK) ON L.product_id=S.product_id 
      LEFT JOIN product_set PS WITH(NOLOCK) ON P.product_set_id=PS.id   
      LEFT JOIN product_provider PP WITH(NOLOCK) ON PP.product_id=P.id AND L.department_id = PP.department_id    
      LEFT JOIN Provider PR WITH(NOLOCK) ON PP.provider_id=PR.id 
      left join dbo.product_pool ppl on ppl.product_id=L.product_id ';    
          
 --查询记录数        
 SET @CountSQL = '';        
 SET @CountSQL = 'SELECT @RowCountOUT=count(L.id) ' + @FromSQL + @Condition;          
 --print @CountSQL;        
 EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;        
          
 --组装查询语句        
  SET @SQL = 'SELECT L.id, ROW_NUMBER() OVER (ORDER BY L.id desc) RowIndex '         
     + @FromSQL + @Condition;        
         
  SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp ' + @FromSQL2 + ' where RowIndex between '        
     + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';       
 print @SQL;    
     
 EXEC(@SQL);    
 SELECT @RowCount;    
END


go


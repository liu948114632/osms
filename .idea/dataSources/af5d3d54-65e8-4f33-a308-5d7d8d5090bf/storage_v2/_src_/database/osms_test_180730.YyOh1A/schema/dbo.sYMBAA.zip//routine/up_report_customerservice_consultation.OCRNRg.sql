
/**************************************************************  
  备注：月客户新产品成功率统计表  
指标：月客户新产品成功率=新产品咨询成功找到/月客户新产品咨询数  
up_Report_CustomerService_Consultation '2008-01-01','2009-01-01'  
**************************************************************/  
CREATE PROCEDURE [dbo].[up_Report_CustomerService_Consultation]   
 @StartTime Datetime,   
 @EndTime Datetime  
AS  
BEGIN  
 SET NOCOUNT ON  
   
 DECLARE @ConsultationCount DECIMAL(18,2)  
 DECLARE @FinishCount  DECIMAL(18,2)  
  
 SET @ConsultationCount = 0  
 SET @FinishCount = 0  
  
 SET @ConsultationCount =(  
 SELECT COUNT(1) FROM dbo.T_Consultation   
 WHERE CreateDate >=  @StartTime AND CreateDate <=  @EndTime);  
  
 -- 已关闭的  
 SET @FinishCount =(  
 SELECT COUNT(1) FROM dbo.T_Consultation   
 WHERE CreateDate >=  @StartTime AND CreateDate <=  @EndTime AND [Status] = 80 AND Result > 1);  
  
 SELECT LTRIM(CAST((@FinishCount/(CASE WHEN @ConsultationCount = 0 THEN 1 ELSE @ConsultationCount END)) * 100 AS DECIMAL(18,2))) + '%' As Rate;  
END
go




-- =============================================
-- Author:		<HYD>
-- Create date: <2010-01-07>
-- Description:	<更新第一次的问题包裹主题和货代>
-- =============================================
CREATE PROCEDURE [dbo].[CRM_Order_PackageRelateUpdate]
(
	@OrderId		VARCHAR(20),
	@Subject 	    nvarchar(500),
	@Agent			nvarchar(200)
)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @Id INT;

	SELECT Top(1) @Id = Id
    FROM T_OrderPackageRelate
	WHERE OrderId = @OrderId
	ORDER BY AddTime ASC;

	UPDATE T_OrderPackageRelate 
	SET	[Subject] = @Subject,Agent = @Agent 
	WHERE Id = @Id;
END
go


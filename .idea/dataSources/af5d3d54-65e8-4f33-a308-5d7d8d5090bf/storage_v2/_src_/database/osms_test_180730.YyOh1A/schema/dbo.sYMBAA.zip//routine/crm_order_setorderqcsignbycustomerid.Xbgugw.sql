--根据客户的质检标识设置客户对应订单的质检标识
CREATE PROC dbo.CRM_Order_SetOrderQCSignByCustomerId
(
@CustomerId INT,
@IsQC BIT=0,
@OrderIds VARCHAR(MAX)='' OUT--返回订单号，多个用逗号分隔，通讯C3
)
AS 
BEGIN
SET @OrderIds='';
IF(@IsQC=0)
	RETURN;

DECLARE @CheckRemak NVARCHAR(500)='',@ISCheckCategory BIT ,@ISCheckProduct bit ;

SELECT TOP 1 @CheckRemak=CheckRemark,@ISCheckCategory=ISCheckCategory,@ISCheckProduct=ISCheckProduct FROM T_CustomerSpecial WHERE CustomerId=@CustomerId


 DECLARE   @TempOrder TABLE
 (
 OrderId VARCHAR(15),
 CheckRemark VARCHAR(max)
 );

  DECLARE   @TempOrderProduct TABLE
 (
 OrderId VARCHAR(15),
 ProductId INT,
 CheckRemark NVARCHAR(500)
 );

				   ---如果客户没有设置质检类别,和质检商品，则订单默认就是需质检
					 IF  (@ISCheckCategory=0 AND @ISCheckProduct=0)
						 BEGIN	 						
										;
                                        WITH    cte
                                                  AS ( SELECT DISTINCT
                                                              o.OrderId
                                                       FROM   dbo.T_Order o
                                                              WITH ( NOLOCK )
                                                       WHERE  o.OrderStatus <40
                                                              AND o.IsQualityInspection = 0
                                                              AND o.OverseasWarehouseStatus = 0
                                                              AND o.OrderIndustryType <> 5
                                                              AND o.OrderIndustryType <> 6
                                                              AND o.CustomerId = @CustomerId
                                                     )
                                   INSERT INTO @TempOrder
                                           ( OrderId,CheckRemark )
							    SELECT cte.OrderId,@CheckRemak  FROM cte
								
									UPDATE a SET a.OrderRemark=ISNULL(a.OrderRemark,'')+';'+ISNULL(b.CheckRemark,'') FROM dbo.T_OrderRemark a
									INNER JOIN @TempOrder b ON a.OrderId=b.OrderId

									UPDATE a SET a.IsQualityInspection=1,a.CSRemark=ISNULL(a.CSRemark,'')+';全面质检' FROM dbo.T_OrderItem a 
									INNER JOIN  @TempOrder b ON a.OrderId=b.OrderId
									WHERE a.Status<12

								SELECT  @OrderIds = @OrderIds + ',' + cte.OrderId FROM    @TempOrder cte;  
									
						 END
					 ELSE 
						 BEGIN
						 ----客户设置了质检类别，如果客户的订单商品在所选的类别内，则设置为质检
					 			 IF @ISCheckCategory=1 AND  EXISTS(SELECT TOP 1 1 FROM dbo.T_CustomerCheckCategory WHERE CustomerId=@CustomerId)
								 BEGIN							 	
                                     WITH   cte AS ( 
												SELECT DISTINCT
                                                       b.OrderId,ISNULL(d.Remark,'') AS CheckRemark,b.CmsProductId
                                                   FROM     dbo.T_Order o WITH ( NOLOCK ) 
												   INNER JOIN dbo.T_OrderItem b  WITH ( NOLOCK ) ON o.OrderId = b.OrderId AND b.IsGoOverseasWarehouse = 0
                                                    INNER JOIN dbo.T_Customer c    WITH ( NOLOCK ) ON c.UserID = o.CustomerId
                                                    INNER JOIN dbo.T_CustomerCheckCategory d WITH ( NOLOCK ) ON d.CustomerId = c.UserID
                                                     INNER JOIN dbo.product p  WITH ( NOLOCK ) ON p.id = b.CmsProductId
                                                              AND ISNULL(p.category_id_1,0) = ISNULL(d.CategoryId1,0)
                                                              AND (ISNULL(p.category_id_2,  0) = ISNULL(d.CategoryId2,0) OR ISNULL(d.CategoryId2,0)=0)
                                                              AND (ISNULL(p.category_id_3,0) = ISNULL(d.CategoryId3,0) OR ISNULL(d.CategoryId3,0)=0)
                                                   WHERE    o.OrderStatus < 40
                                                            AND o.IsQualityInspection = 0
                                                            AND o.OverseasWarehouseStatus = 0
                                                            AND o.OrderIndustryType <> 5
                                                            AND o.OrderIndustryType <> 6
                                                            AND o.CustomerId = @CustomerId
															AND b.Status<12
                                                 )
												 --,cte2 AS 
												 --(
													-- SELECT cte.orderId,(SELECT a.CheckRemark+';' FROM cte a WHERE a.OrderId=cte.orderid FOR XML PATH('')) AS CheckRemark FROM cte  GROUP BY cte.OrderId
												 --)
                                          INSERT INTO @TempOrderProduct
                                           ( OrderId,CheckRemark,ProductId )
							    SELECT a.OrderId,a.CheckRemark,a.CmsProductId FROM cte a	

								SELECT  @OrderIds = @OrderIds + ',' + cte.OrderId FROM    @TempOrderProduct cte;  
								--修改订单备注，订单备注+质检备注+质检类别备注
							UPDATE a SET a.OrderRemark=ISNULL(a.OrderRemark,'')+';'+ISNULL(@CheckRemak,'')+';'+(SELECT DISTINCT t.CheckRemark+';' FROM @TempOrderProduct t WHERE t.OrderId=a.orderid FOR XML PATH('')) FROM dbo.T_OrderRemark a
							INNER JOIN @TempOrderProduct b ON a.OrderId=b.OrderId


							--设置商品质检标示
							--;WITH   cte AS ( 
							--					SELECT DISTINCT
       --                                                b.OrderId,b.CmsProductId
       --                                            FROM     dbo.T_Order o WITH ( NOLOCK ) 
							--					   INNER JOIN dbo.T_OrderItem b  WITH ( NOLOCK ) ON o.OrderId = b.OrderId AND b.IsGoOverseasWarehouse = 0
       --                                             INNER JOIN dbo.T_Customer c    WITH ( NOLOCK ) ON c.UserID = o.CustomerId
       --                                             INNER JOIN dbo.T_CustomerCheckCategory d WITH ( NOLOCK ) ON d.CustomerId = c.UserID
       --                                              INNER JOIN dbo.product p  WITH ( NOLOCK ) ON p.id = b.CmsProductId
       --                                                       AND ISNULL(p.category_id_1,0) = ISNULL(d.CategoryId1,0)
       --                                                       AND (ISNULL(p.category_id_2,  0) = ISNULL(d.CategoryId2,0) OR ISNULL(d.CategoryId2,0)=0)
       --                                                       AND (ISNULL(p.category_id_3,0) = ISNULL(d.CategoryId3,0) OR ISNULL(d.CategoryId3,0)=0)
       --                                            WHERE    o.OrderStatus <= 31
       --                                                     AND o.IsQualityInspection = 0
       --                                                     AND o.OverseasWarehouseStatus = 0
       --                                                     AND o.OrderIndustryType <> 5
       --                                                     AND o.OrderIndustryType <> 6
       --                                                     AND o.CustomerId = @CustomerId
       --                                          )
												UPDATE a  SET a.IsQualityInspection=1,a.CSRemark=ISNULL(a.CSRemark,'')+';'+CASE WHEN ISNULL(b.CheckRemark,'')>'' THEN  ISNULL(b.CheckRemark,'') ELSE '全面质检' END  FROM  dbo.T_OrderItem a 
												INNER JOIN @TempOrderProduct b  ON  a.OrderId=b.OrderId AND a.CmsProductId=b.ProductId
												WHERE a.IsGoOverseasWarehouse=0

							 END
							 IF @ISCheckProduct=1 AND  EXISTS (SELECT TOP 1 1 FROM dbo.t_CustomercheckProduct WHERE CustomerId=@CustomerId)
							 BEGIN					
							 	              WITH   cte AS ( 
												SELECT DISTINCT
                                                            b.OrderId,b.CmsProductId,ISNULL(d.Remark,'') AS CheckRemark
                                                   FROM     dbo.T_Order o WITH ( NOLOCK ) 
												   INNER JOIN dbo.T_OrderItem b  WITH ( NOLOCK ) ON o.OrderId = b.OrderId AND b.IsGoOverseasWarehouse = 0
                                                    INNER JOIN dbo.T_Customer c    WITH ( NOLOCK ) ON c.UserID = o.CustomerId
                                                    INNER JOIN dbo.T_CustomercheckProduct d WITH ( NOLOCK ) ON d.CustomerId = c.UserID AND d.ProductId=b.CmsProductId
                                                   WHERE    o.OrderStatus <= 31
                                                            AND o.IsQualityInspection = 0
                                                            AND o.OverseasWarehouseStatus = 0
                                                            AND o.OrderIndustryType <> 5
                                                            AND o.OrderIndustryType <> 6
                                                            AND o.CustomerId = @CustomerId
                                                 )
                                      INSERT INTO @TempOrderProduct
                                           ( OrderId,ProductId,CheckRemark )
									    SELECT cte.OrderId,cte.CmsProductId,cte.CheckRemark FROM cte
										WHERE NOT EXISTS (SELECT TOP 1 1 FROM @TempOrderProduct a WHERE  a.OrderId=cte.OrderId AND cte.CmsProductId=a.ProductId)
                                        

									SELECT  @OrderIds = @OrderIds + ',' + cte.OrderId FROM    @TempOrderProduct cte;  

								--修改订单备注，订单备注+质检备注,如果类别质检备注中已经设置了备注，则质检商品中不在组合备注
								;WITH cte  AS (SELECT DISTINCT OrderId FROM @TempOrderProduct)
								UPDATE a SET a.OrderRemark=ISNULL(a.OrderRemark,'')+';'+ISNULL(@CheckRemak,'') FROM dbo.T_OrderRemark a
								INNER JOIN cte b ON a.OrderId=b.OrderId
								AND NOT EXISTS(SELECT TOP 1 1 FROM @TempOrder t WHERE t.OrderId=b.OrderId)

									---修改商品客户备注，质检商品备注要带入对应订单商品的客服备注中
								UPDATE b SET b.CSRemark=
										--ISNULL(b.CSRemark,'')+'; '+ISNULL(c.CheckRemark,''), 
											CASE -- WHEN REPLACE(@remark,';','')>'' THEN ISNULL(b.CSRemark, '')+ISNULL(c.CheckRemark, '')
														WHEN ISNULL(c.CheckRemark, '')=''  THEN REPLACE(ISNULL(b.CSRemark, ''),'全面质检','')+'全面质检' 
														WHEN ISNULL(c.CheckRemark, '')>'' THEN REPLACE(ISNULL(b.CSRemark, ''),'全面质检','')+ISNULL(c.CheckRemark, '')
														END,
								b.IsQualityInspection=1
								 FROM  dbo.T_OrderItem b  WITH ( NOLOCK ) 
								 INNER JOIN @TempOrderProduct c  ON c.OrderId=b.OrderId AND c.ProductId=b.CmsProductId
								 WHERE b.IsGoOverseasWarehouse=0
							 END

						 END

						 --根据质检类别修改订单的需质检标示
							 UPDATE o SET o.IsQualityInspection=1 FROM dbo.T_Order o WITH(NOLOCK)
								INNER JOIN @TempOrder b ON o.OrderId=b.OrderId
								WHERE  o.IsQualityInspection=0
							--根据质检商品修改订单质检标示
							UPDATE o SET o.IsQualityInspection=1 FROM dbo.T_Order o WITH(NOLOCK)
								INNER JOIN @TempOrderProduct b ON o.OrderId=b.OrderId
								AND o.IsQualityInspection=0

								--插入日志
                                     IF ( LEN(@OrderIds) > 0 )
                                        BEGIN						 	
                                            UPDATE  o
                                            SET     o.IsQualityInspection = 1
                                            FROM    dbo.T_Order o WITH ( NOLOCK )
                                                    INNER JOIN ( SELECT
                                                              *
                                                              FROM
                                                              dbo.uf_Split(@OrderIds,
                                                              ',')
                                                              ) a ON o.OrderId = a.Value;

                                            INSERT  INTO dbo.order_history
                                                    ( order_code ,
                                                      operator_id ,
                                                      operator_time ,
                                                      process
							                        )
                                                    SELECT  Value ,
                                                            0 ,
                                                            GETDATE() ,
                                                            '设置客户质检标识，自动设置客户订单需质检为是'
                                                    FROM    dbo.uf_Split(@OrderIds,
                                                              ',')
                                                    WHERE   Value > '';
                                        END;
						 
 END


go


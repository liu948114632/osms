
/* -------------------------
	删除特殊报警数据
-----------------------------------*/
CREATE Procedure [dbo].CMS_Delete_Sale_Price_Alarm

AS
BEGIN	
DELETE FROM dbo.ph_product_sale_price_alarm WHERE  product_id
IN(
388615,
2161,
4344,
63755,
63756
) AND type=2
 
END
go


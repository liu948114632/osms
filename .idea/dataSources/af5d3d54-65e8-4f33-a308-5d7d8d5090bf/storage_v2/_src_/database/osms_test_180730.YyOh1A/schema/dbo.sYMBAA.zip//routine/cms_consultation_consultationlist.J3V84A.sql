

CREATE PROC dbo.CMS_Consultation_ConsultationList  
(  
 @ConsultationCode VARCHAR(MAX) = NULL , --咨询编号  
 @ConsultationCodes VARCHAR(max)=NULL,
 @ConsultationName VARCHAR(MAX) = NULL , --咨询名称  
 @ConsultationStatus INT = NULL , --客服咨询状态  
 @DepartmentConsultationStatus INT = NULL , --办事处咨询状态  
 @ConsultationUserId INT = NULL , --咨询录入人  
 @IsFound INT = NULL,--是否找到  
 @DepartmentId INT = NULL , --部门  
 @ConsultationTrackerUserId INT = NULL , --咨询跟进人  
 @ConsultationType INT = NULL , --咨询类型  
 @ProductDeveloperId INT = NULL , --产品开发人
 @CreateTimeBegin VARCHAR(20) = NULL , --咨询开始时间  
 @CreateTimeEnd VARCHAR(20) = NULL , --咨询结束时间  
 @ProductCode VARCHAR(MAX) = NULL,--咨询商品编号  
 @ListProductCode VARCHAR(MAX) = NULL,--商品编号批量  
 @QuoteTimeBegin VARCHAR(20) = NULL , --咨询报价开始时间  
 @QuoteTimeEnd VARCHAR(20) = NULL , --咨询报价结束时间  
 @IsPerformance INT = NULL,--是否绩效 
 @isVip INT = NULL,
 @PageSize INT = 50 ,  --页大小     
 @isExpiry INT=NULL,      --是否逾期                    
 @PageIndex INT = 1,    --当前页号  
 @FeedbackTimeBegin VARCHAR(20) = NULL , --咨询开始时间  
 @FeedbackTimeEnd VARCHAR(20) = NULL , --咨询结束时间  
 @AuditTimeBegin VARCHAR(20) = NULL , --咨询开始时间  
 @AuditTimeEnd VARCHAR(20) = NULL  --咨询结束时间  
)  
AS  
BEGIN  
 DECLARE @SQL NVARCHAR(MAX) ,  
            @FromSQL NVARCHAR(MAX) ,  
            @FromSQL2 NVARCHAR(MAX) ,    
            @Column NVARCHAR(MAX) ,  
            @Condition NVARCHAR(MAX) ,  
            @CountSQL NVARCHAR(MAX) ,   
            @RowCount INT ,  
            @PageCount INT ,     
            @Start INT ,  
            @End INT ,  
            @IsQueryProduct BIT;  
              
    SET @IsQueryProduct = 0 ;  
                  
 SET @Condition = ' WHERE 1 = 1 AND a.parent_consultation_id is not null AND ((a.status IS NOT NULL AND a.status <> 90) OR a.status IS NULL) ';  
   
 IF @ConsultationCode IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and t.code like ''%' + @ConsultationCode + '%''' ;    
  END 
 IF @ConsultationCodes IS NOT NULL
 BEGIN
	 SET @Condition = @Condition + ' and t.code in (''' + REPLACE(@ConsultationCodes, ',', ''',''') + ''')'; 
 END 
 IF @ConsultationName IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and t.name like ''%' + @ConsultationName + '%''' ;    
  END  
 IF @ConsultationStatus IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and t.status = ' + CONVERT(VARCHAR(10),  @ConsultationStatus) ;  
  END  
 IF @DepartmentConsultationStatus IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and a.status = ' + CONVERT(VARCHAR(10),  @DepartmentConsultationStatus) ;  
  END  
 IF @IsFound IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.is_found = ' + CONVERT(VARCHAR(10),  @IsFound) ;  
  END  

  IF @isExpiry IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and isNULL(a.is_expiry,0) = ' + CONVERT(VARCHAR(10),  @isExpiry) ;  
  END 
 IF @IsPerformance IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and  isnull(a.is_performance,0) = ' + CONVERT(VARCHAR(10),  @IsPerformance) ;  
  END  
 IF @ConsultationUserId IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and t.user_id = ' + CONVERT(VARCHAR(10),  @ConsultationUserId) ;  
  END    
 IF @DepartmentId IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.department_id = ' + CONVERT(VARCHAR(10),  @DepartmentId);  
  END  
  IF @ProductDeveloperId IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.product_developer_id = ' + CONVERT(VARCHAR(10),  @ProductDeveloperId);  
  END 
  
 IF @ConsultationTrackerUserId IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.tracker_user_id = ' + CONVERT(VARCHAR(10),  @ConsultationTrackerUserId) ;  
  END  
 IF @ConsultationType IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and t.type = ' + CONVERT(VARCHAR(10),  @ConsultationType) ;  
  END  
    
 IF @CreateTimeBegin IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.crate_time >=''' + @CreateTimeBegin + ''''  
  END  
 IF @CreateTimeEnd IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.crate_time <=''' + @CreateTimeEnd + ''''  
  END  
    
  IF @FeedbackTimeBegin IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and t.feedback_time >=''' + @FeedbackTimeBegin + ''''  
  END  
 IF @FeedbackTimeEnd IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and t.feedback_time <=''' + @FeedbackTimeEnd + ''''  
  END  
    
 IF @AuditTimeBegin IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.audit_time >=''' + @AuditTimeBegin + ''''  
  END  
 IF @AuditTimeEnd IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.audit_time <=''' + @AuditTimeEnd + ''''  
  END  
    
 IF @ProductCode IS NOT NULL  
  BEGIN  
   SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and d.code like ''' + '%' +  @ProductCode + '%''' ;  
  END  
 IF @ListProductCode IS NOT NULL  
    
  BEGIN  
   SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and d.code in (''' + REPLACE(@ListProductCode, ',', ''',''') + ''')';  
  END  
 IF @QuoteTimeBegin IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.quote_time >=''' + @QuoteTimeBegin + ''''   
  END  
 IF @QuoteTimeEnd IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.quote_time <=''' + @QuoteTimeEnd + ''''  
  END  
 IF @isVip IS NOT NULL 
 BEGIN
 SET @Condition = @Condition + ' and a.is_vip = ' + CONVERT(VARCHAR(10),  @isVip) ; 
 END   
 SET @FromSQL = ' FROM    dbo.consultation AS a WITH ( NOLOCK )  
       JOIN ( SELECT   status ,  
           id,  
           code,  
           name,  
           type,  
           user_id,  
           crate_time,  
           feedback_time,
		   is_valid 
           FROM     dbo.consultation WITH ( NOLOCK )  
           WHERE    parent_consultation_id IS NULL  
         ) AS t ON a.parent_consultation_id = t.id ';  
 IF @IsQueryProduct = 1  
 BEGIN  
  SET @FromSQL = @FromSQL + 'LEFT JOIN dbo.consultation_item AS c WITH(NOLOCK) ON a.id = c.consultation_id     
          LEFT JOIN dbo.product AS d WITH(NOLOCK) ON d.id = c.product_id ';  
 END        
--获取符合条件的总记录数            
   SET @CountSQL = ' SELECT @RowCount = count(a.id) ' + @FromSQL + @Condition                      
   EXEC sp_executesql @CountSQL, N'@RowCount INT OUT', @RowCount OUT             
     
   --设置分页参数(一定要放在取记录数的后面)            
   IF ISNULL(@PageSize, 0) < 1   
    SET @PageSize = 50                            
   SET   
 @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                            
   IF ISNULL(@PageIndex, 0) < 1   
    SET @PageIndex = 1    
                           
   ELSE   
    IF ISNULL(@PageIndex, 0) > @PageCount   
     SET @PageIndex = @PageCount                     
       
   SET @Start = ( @PageIndex - 1 ) * @PageSize + 1                            
   SET @End = @PageIndex * @PageSize       
        
  SET @Column = '   
    a.id ,  
    t.code ,  
    a.parent_consultation_id as parentConsultationId,  
          t.status AS status ,  
          a.status as departmentStatus,  
          t.type ,  
          t.name ,  
          a.is_found as isFound ,
		  t.is_valid as isValid,  
          t.user_id as userId,  
          a.department_id as departmentId,  
          a.tracker_user_id as trackerUserId,  
          a.crate_time as crateTime,  
          a.quote_time as quoteTime,  
          a.is_performance as isPerformance ,  
          t.feedback_time as feedbackTime,  
          a.audit_time as auditTime,  
          a.consultation_remark as consultationRemark,  
          a.code as departmentCode,  
          a.is_expiry as isExpiry  ,
		  a.content,
		  a.is_vip as isVip,
		  a.office_remark as officeRemark,
		  a.product_developer_id as productDeveloperId
  ' ;   
       
   --组装查询语句                
           
 SET @SQL = 'SELECT ' + @Column + ', ROW_NUMBER() OVER (ORDER BY t.status asc ,t.crate_time desc) RowIndex '  
    + @FromSQL + @Condition ;      
                         
 SET @SQL = 'SELECT temp.*   
  FROM (' + @SQL + ') temp WHERE RowIndex between '  
  + CONVERT(VARCHAR(10), @Start) + ' AND '  
  + CONVERT(VARCHAR(10), @End) + ' order by RowIndex' ;      
                       
 --SELECT @SQL  
 PRINT @SQL   
 EXEC(@SQL) ;                                        
 SELECT  @RowCount  
END
go


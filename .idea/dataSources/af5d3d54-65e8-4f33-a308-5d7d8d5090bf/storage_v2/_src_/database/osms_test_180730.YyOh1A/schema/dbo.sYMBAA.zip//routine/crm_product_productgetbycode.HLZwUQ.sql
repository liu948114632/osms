

-- =============================================    
-- Author:  HYD    
-- Create date: 2011-10-18    
-- Description: 根据产品编号获取产品信息    
-- =============================================    
CREATE PROC dbo.CRM_Product_ProductGetByCode    
 @Code VARCHAR(200)    
AS    
BEGIN    
 -- SET NOCOUNT ON added to prevent extra result sets from    
 -- interfering with SELECT statements.    
 SET NOCOUNT ON;    
 DECLARE @ProductId INT    
 SET @ProductId = 0;    
     
 --IF (@Code = 'TBSC')    
 -- SET @ProductId = 63755    
 --IF (@Code = 'JFSC')    
 -- SET @ProductId = 63756    
 --  IF (@Code = 'TOOL-285X210-2017')    
 -- SET @ProductId = 3319409    

  SELECT @ProductId=ProductId FROM dbo.T_StylebookProduct
      
 IF(@ProductId > 0)    
 BEGIN    
  SELECT * FROM dbo.V_CRM_Base_Product WHERE CmsProductId = @ProductId    
 END    
 ELSE    
 BEGIN    
  SELECT * FROM dbo.V_CRM_Base_Product WHERE code = @Code    
 END     
END
go


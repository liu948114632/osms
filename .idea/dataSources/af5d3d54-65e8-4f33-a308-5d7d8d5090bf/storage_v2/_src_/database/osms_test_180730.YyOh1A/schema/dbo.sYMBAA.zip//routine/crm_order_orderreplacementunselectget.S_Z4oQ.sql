
-- =============================================  
-- Author:  HYD  
-- Create date: 2011-06-14  
-- Description: 获取超过X+5天未选替代品的订单列表  
-- =============================================  
CREATE PROC dbo.CRM_Order_OrderReplacementUnSelectGet  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
  
  
 SELECT  a.OrderId ,  
            a.HandlerId ,  
            c.english_name AS HandlerName ,  
            a.CustomerId ,  
            b.FullName AS CustomerName ,  
            --b.Email AS CustomerMail,
			AutoDelayDate  
    FROM t_Order a  
            JOIN dbo.T_Customer b ON a.CustomerId = b.UserID  
            LEFT JOIN [user] c ON a.HandlerId = c.Id  
			 LEFT JOIN dbo.T_BusinessType d WITH(NOLOCK) ON a.OrderIndustryType=d.BusinessTypeValue
 WHERE a.OrderStatus = 1  
                        AND (a.OrderIndustryType = 1 OR d.IsPHClone=1) -- 只处理PH的订单  
                        AND a.OrderType IN ( 1, 2 )  
      AND DATEDIFF(DAY,a.AutoDelayDate,GETDATE())  = 5  
      AND a.DelayStatus = 3  AND a.IsAutoDelay = 1
END


go


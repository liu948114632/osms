CREATE PROC [dbo].[CMS_InitProcessingItemDepartment]     
AS  
BEGIN 
	--清空历历史记录
	DELETE FROM processing_item_picking_department
	--计算配件使用部门
	SELECT * INTO #temp_processingDepartment FROM (
	SELECT DISTINCT b.product_id,a.department_id  FROM   dbo.processing a WITH(NOLOCK)
	JOIN dbo.processing_item b WITH(NOLOCK) ON a.id =b.processing_id
	WHERE a.department_id IN (7,9) AND DATEDIFF(mm,a.stock_out_time,GETDATE())<=3 AND b.status <>4
	)z

	INSERT INTO dbo.processing_item_picking_department
	        ( product_id, department_ids )
	SELECT 
	a.product_id,
	(SELECT  CAST(b.department_id AS VARCHAR(20)) +',' FROM  #temp_processingDepartment b  WHERE b.product_id =a.product_id FOR XML PATH('') )
	 FROM (
		SELECT DISTINCT product_id FROM  #temp_processingDepartment
	)a  
	DROP TABLE #temp_processingDepartment

 END
go


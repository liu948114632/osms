CREATE PROCEDURE CMS_Check_product_has_product_stragegy
(
 @ProductCodes NVARCHAR(max) =null
)
AS 
BEGIN
 SET NOCOUNT ON;
 DECLARE  @SQL varchar(MAX)
	SET @SQL ='SELECT id FROM product WHERE';
	SET @SQL = @SQL +' code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')'  
	SET @SQL = @SQL +' and is_delete = 0 '
	SET @SQL = @SQL + 'except  select product_id from product_strategy '
	exec(@SQL)	
END
go


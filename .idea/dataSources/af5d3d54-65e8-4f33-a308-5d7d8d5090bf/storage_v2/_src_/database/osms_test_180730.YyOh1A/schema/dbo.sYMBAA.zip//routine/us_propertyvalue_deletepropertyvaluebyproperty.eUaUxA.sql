CREATE PROCEDURE [dbo].[US_PropertyValue_DeletePropertyValueByProperty]
(
	@PropertyId INT
)
AS
BEGIN 
	UPDATE dbo.T_PropertyValue_US SET IsDeleted=1 WHERE PropertyId=@PropertyId
END
go


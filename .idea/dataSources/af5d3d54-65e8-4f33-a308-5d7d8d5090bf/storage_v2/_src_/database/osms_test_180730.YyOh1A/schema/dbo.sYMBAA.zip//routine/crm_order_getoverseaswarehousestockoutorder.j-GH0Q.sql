  
/**    
获取订单的海外仓出库单    
*/    
CREATE PROC CRM_Order_GetOverseasWarehouseStockOutOrder    
(    
  @OrderId VARCHAR(20)    
)    
AS    
BEGIN      
    SELECT OrderId,    
           StockOutCode,    
           (CASE WHEN d.id IS NOT NULL THEN d.LogisticsCarriersCode ELSE ExpressService END)  AS ExpressServiceCode,    
           (CASE WHEN d.id IS NOT NULL THEN d.LogisticsCarriersName ELSE ExpressServiceName END) AS ExpressServiceName,    
           (CASE WHEN d.id IS NOT NULL THEN d.TrackingUrl ELSE c.TrackingUrl END) AS  TrackingUrl,    
           Warehouse AS WarehouseCode,
           WarehouseName,    
           a.STATUS AS StockOutOrderStatus,  
           ISNULL((select COUNT(*) FROM dbo.T_OverseasWarehouseStockOutOrderItem WHERE StockOutCode = a.StockOutCode),0) AS ItemCount,    
           ISNULL((select TOP 1 PackageCode FROM dbo.T_OverseasWarehousePackage WHERE StockOutCode = a.StockOutCode),'') AS PackageCode,--暂时取一个    
           ISNULL((select TOP 1 TrackingNumber FROM dbo.T_OverseasWarehousePackage WHERE StockOutCode = a.StockOutCode),'') AS TrackingNumber ,
          Remark ,
		  a.IsTransshipment 
    FROM dbo.T_OverseasWarehouseStockOutOrder a WITH(NOLOCK)    
    LEFT JOIN dbo.T_OverseasWarehouse b ON a.Warehouse =b.WarehouseCode    
    LEFT JOIN dbo.T_OverseasWarehouseExpressService c ON a.ExpressService = c.ExpressServiceCode
    LEFT JOIN dbo.T_OverseasWarehouseLogisticsCarriers d ON a.LogisticsCarriersId = d.id
    WHERE OrderId= @OrderId     
	ORDER BY a.CreateTime
END

go


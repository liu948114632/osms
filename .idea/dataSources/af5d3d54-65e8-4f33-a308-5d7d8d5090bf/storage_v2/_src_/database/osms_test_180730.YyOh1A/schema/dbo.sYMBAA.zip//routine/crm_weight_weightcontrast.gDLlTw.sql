 
/*----------------------------------------------------          
[备注]:订单重量和发货重量对比    
------------------------------------------------------*/          
CREATE PROC [dbo].[CRM_Weight_WeightContrast]           
(          
 @Weight   INT, -- 订单重量    
 @PostWeight  DECIMAL(18,2), -- 发货重量    
 @OrderIndustryType INT, -- 订单业务线(1:PH 2:PW)    
 @WeightType  INT OUT -- 1：订单重量 2：发货重量    
)          
AS     
BEGIN        
 SET NOCOUNT ON;     
 SET @WeightType = 1;    
 --如果是PW的订单,使用PW的规则,JL订单采用跟PW一样的规则    
 IF @OrderIndustryType = 16 OR @OrderIndustryType = 17    
 BEGIN        
	  -- 订单重量与发货重量    
	  IF @PostWeight > @Weight * 1.1       
	  BEGIN     
		   SET @WeightType = 2;    
	  END    
	  ELSE    
	  BEGIN    
	   IF @PostWeight * 1.1 < @Weight AND @PostWeight > 0    
	   BEGIN    
		SET @WeightType = 2;    
	   END    
	  END     
 END       
 ELSE IF  @OrderIndustryType = 5  --UK独立仓订单国内商品不参加运费计算，因此国内发货重量也不参加计算        
 BEGIN    
	   SET @WeightType = 1;    
 END        
 ELSE --其他的使用PH的规则        
 BEGIN    
  -- 订单重量与发货重量    
  IF @Weight > @PostWeight * 1.1 AND @PostWeight > 0    
  BEGIN    
   SET @Weight = @PostWeight;    
   SET @WeightType = 2;    
  END      
 END       
END

go


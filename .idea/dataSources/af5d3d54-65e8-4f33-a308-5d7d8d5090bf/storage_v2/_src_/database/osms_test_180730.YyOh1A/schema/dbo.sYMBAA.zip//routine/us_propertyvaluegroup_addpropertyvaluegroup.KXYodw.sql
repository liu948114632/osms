CREATE PROCEDURE [dbo].[US_PropertyValueGroup_AddPropertyValueGroup]
(
	@PropertyValueGroupId INT
)
AS
BEGIN 
	IF NOT EXISTS (SELECT 1 FROM dbo.T_PropertyValueGroup_US WHERE PropertyValueGroupId=@PropertyValueGroupId)
	BEGIN
		INSERT INTO dbo.T_PropertyValueGroup_US (
			PropertyValueGroupId,
			IsDeleted,
			CreateDate,
			LastUpdateDate
		) VALUES ( 
			@PropertyValueGroupId,
			0,
			GETDATE(),
			GETDATE() ) 
	END
	ELSE
	BEGIN
		UPDATE dbo.T_PropertyValueGroup_US SET IsDeleted=0,LastUpdateDate=GETDATE() WHERE PropertyValueGroupId=@PropertyValueGroupId
	END
END
go


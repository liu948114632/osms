/**  
更新商品池的备货量  
*/  
CREATE PROCEDURE CMS_ProductPool_RefreshPrepareQuantity3  
(  
  @EndDate DATETIME --统计的结束日期  
)  
AS   
BEGIN  
DECLARE @BeginDate DATETIME
                                            
--开始统计日期默认是结束日期的前90天  
SET @BeginDate = DATEADD(Day,-90,@EndDate)  

--计算每个商品的非促销90天的开始日期  
SELECT a.product_id,   
     dbo.Fu_CMS_GetNotPromoteBeginDate(a.product_id,@EndDate,90) AS BeginDate  
INTO #temp_ProductComputeBeginDate  
FROM dbo.product_pool a WITH(NOLOCK)  
     
 --更新商品备货量  
 SELECT temp2.product_id,
  prepare_quantity = (CASE WHEN(product_pool.min_quantity >= 
                                  (CASE WHEN CEILING(SaleQty / 3.0 * 2) >= 3 
                                        THEN CEILING(SaleQty / 3.0 * 2) * dbo.product.unit_quantity 
                                        ELSE 3 * unit_quantity 
                                        END)
                                  ) 
							  THEN  product_pool.min_quantity 
							  ELSE (CASE WHEN CEILING(SaleQty / 3.0 * 2) >= 3 
							             THEN CEILING(SaleQty / 3.0 * 2) * dbo.product.unit_quantity 
							             ELSE 3 * unit_quantity 
							        END)
							  END ) 
FROM (  
  SELECT product_id,  
         SUM(temp1.sale_quantity) AS SaleQty  
  FROM (  
	 --1、统计PH3订单销售  
	 SELECT b.product_id,  
	        b.sale_quantity           
	 FROM product_pool a  
	 JOIN view_product_pool_order_sale_info  AS b WITH(NOLOCK) ON a.product_id = b.product_id  
	 WHERE b.order_status < 132 -- 排除取消订单  
	   AND b.order_item_status <>12  
	   AND b.type = 3   
  	   AND b.order_time >= CONVERT(VARCHAR(100),@BeginDate,20) -- 录单时间  
	   AND b.order_time < CONVERT(VARCHAR(100),@EndDate,20)
	 --统计PH订单销售  
	UNION ALL  
	SELECT b.product_id,  
		   b.sale_quantity        
	FROM #temp_ProductComputeBeginDate a  
	JOIN view_product_pool_order_sale_info AS b WITH(NOLOCK) ON a.product_id = b.product_id  
	WHERE b.order_status < 132 -- 排除取消订单  
      AND b.order_item_status <>12  
      AND b.type = 1   
	  AND b.order_time >=  CONVERT(VARCHAR(100),a.BeginDate,20)  -- 录单时间  
	  AND b.order_time <  CONVERT(VARCHAR(100),@EndDate,20)    
     --2、统计毛坯配件任务   
     UNION ALL   
     SELECT b.product_id, 
		    b.rought_sale_quantity as sale_quantity
	 FROM product_pool a WITH(NOLOCK)
	 JOIN view_product_pool_rought_unit_sale_info b WITH(NOLOCK) ON a.product_id = b.product_id 
	 JOIN view_all_purchasing_management_task c ON b.rought_task_id = c.id
	 WHERE c.transmit_time >= CONVERT(VARCHAR(100),@BeginDate,20) --任务到达时间     
	   AND c.transmit_time < CONVERT(VARCHAR(100),@EndDate,20) 
		
  ) temp1  
  GROUP BY temp1.product_id  
 ) temp2  
 JOIN dbo.product_pool WITH(NOLOCK) ON temp2.product_id = dbo.product_pool.product_id  
 JOIN dbo.product WITH(NOLOCK) ON dbo.product_pool.product_id = dbo.product.id  
 WHERE dbo.product_pool.product_id NOT IN ( SELECT product_id FROM constant_product_pool_prepare_product)  
   
 DROP TABLE #temp_ProductComputeBeginDate  
END
go


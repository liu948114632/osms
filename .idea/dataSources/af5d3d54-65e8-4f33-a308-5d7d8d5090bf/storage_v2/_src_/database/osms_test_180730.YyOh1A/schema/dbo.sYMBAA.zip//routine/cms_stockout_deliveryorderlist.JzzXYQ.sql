
/*
*2012-08-03
*发货单查询列表
*2012-08-23
*按状态升序再按创建时间倒序
*/
CREATE PROCEDURE CMS_StockOut_DeliveryOrderList
(
	@Code VARCHAR(MAX) = NULL, -- 发货单号
	@Status INT = NULL, -- 状态
	@DeliveryUserId INT = NULL, -- 发货人
	@CreateTimeBegin VARCHAR(20) = NULL, --创建时间起
	@CreateTimeOver VARCHAR(20) = NULL, --创建时间止
	@DeliveryTimeBegin VARCHAR(20) = NULL, --发货时间起
	@DeliveryTimeOver VARCHAR(20) = NULL, --发货时间止
	@ReceiveTimeBegin VARCHAR(20) = NULL, --收货时间起
	@ReceiveTimeOver VARCHAR(20) = NULL, --收货时间止
	@PageSize INT = 50 ,  --页大小      
	@PageIndex INT = 1    --当前页号      
)
AS
BEGIN
	SET NOCOUNT ON ; 
    DECLARE @SQL VARCHAR(max),      
            @CountSql NVARCHAR(MAX), --查询数量用      
            @FromSQL NVARCHAR(max), --查询表 
            @FromSQL2 NVARCHAR(MAX), --取字段关联表   
            @Condition varchar(MAX), --条件
            @Column NVARCHAR(MAX), --字段       
            @RowCount INT , @PageCount INT , @start INT ,@end INT 
    
    SET @Condition = ' WHERE 1=1 '  	
    IF @Code IS NOT NULL 
    BEGIN
		SET @Condition = @Condition + ' AND A.code = ''' + @Code + '''';
	END
	IF @Status IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND A.status = ' + CONVERT(VARCHAR(10), @Status);
	END
	IF @DeliveryUserId IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND A.delivery_user_id = ' + CONVERT(VARCHAR(10), @DeliveryUserId);
	END
	IF @CreateTimeBegin IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND A.create_time >=''' + @CreateTimeBegin + ''''; 
	END
	IF @CreateTimeOver IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND A.create_time <=''' + @CreateTimeOver + '''';
	END
	IF @DeliveryTimeBegin IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND A.delivery_time >=''' + @DeliveryTimeBegin + ''''; 
	END
	IF @DeliveryTimeOver IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND A.delivery_time <=''' + @DeliveryTimeOver + '''';
	END
	IF @ReceiveTimeBegin IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND A.receive_time >=''' + @ReceiveTimeBegin + ''''; 
	END
	IF @ReceiveTimeOver IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND A.receive_time <=''' + @ReceiveTimeOver + '''';
	END
	
	SET @FromSQL = ' delivery_order a WITH(NOLOCK) '
	SET @FromSQL2 = ' LEFT JOIN delivery_order a WITH(NOLOCK) ON temp.id = a.id '
	
	SET @CountSql = ' SELECT @RowCount = count(a.id) from ' + @FromSQL + @Condition       
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT    
    --PRINT @CountSql
    
    IF ISNULL(@PageSize, 0) < 1             
        SET @PageSize = 50           
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize            
    IF ISNULL(@PageIndex, 0) < 1             
        SET @PageIndex = 1            
    ELSE             
    IF ISNULL(@PageIndex, 0) > @PageCount             
        SET @PageIndex = @PageCount            
    SET @start = ( @PageIndex - 1 ) * @PageSize + 1            
    SET @end = @PageIndex * @PageSize    
    
    SET @Column = ' a.id, 
					a.code, 
					a.status, 
					a.delivery_user_id deliveryUserId,
					a.delivery_time deliveryTime,
					a.receive_time receiveTime,
					a.create_time createTime,
					a.remark ';
 --组装查询语句    
  SET @SQL = 'SELECT a.id, ROW_NUMBER() OVER (ORDER BY a.status asc, a.create_time desc) RowIndex from '     
     + @FromSQL + @Condition;    
     
  SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp ' + @FromSQL2 + ' where RowIndex between '    
     + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';  
  --print @SQL      
  EXEC(@SQL);                
  select @RowCount          
END

go


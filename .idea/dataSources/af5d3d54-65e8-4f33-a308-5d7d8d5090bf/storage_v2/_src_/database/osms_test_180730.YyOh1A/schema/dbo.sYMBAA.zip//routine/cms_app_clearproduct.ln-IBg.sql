/*
*2014-07-04
*APP,清仓产品列表
*/
CREATE PROCEDURE CMS_APP_ClearProduct
    @position VARCHAR(50) =NULL,
    @isCheck BIT =NULL,
    @PageSize INT = 50 ,  --页大小                        
    @PageIndex INT = 1    --当前页号   
AS 
    BEGIN
	
        SET NOCOUNT ON;

        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用  
            @FromSQL NVARCHAR(MAX) , --查询表                                         
            @Column NVARCHAR(MAX) , --查询字段                       
            @Condition VARCHAR(MAX) , --条件                         
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT 
            
        SET @FromSQL = ' FROM dbo.product_promote pp WITH (NOLOCK)
					JOIN dbo.product p WITH (NOLOCK) ON pp.product_id=p.id
					LEFT JOIN clear_product_check as x WITH (NOLOCK) on x.product_id =pp.product_id   
					LEFT JOIN dbo.storage c WITH (NOLOCK) ON c.product_id = pp.product_id  AND c.department_id = 4
					LEFT JOIN dbo.storage_position d WITH (NOLOCK) ON d.id = c.position_id '     
		SET @Condition = ' WHERE type = 3 ' 			         
        IF @position IS NOT NULL 
            BEGIN
                SET @Condition = @Condition + ' AND d.name LIKE ''%' +@position+ '%'''  
            END 
        IF @isCheck IS NOT NULL
        BEGIN
        	IF @isCheck =1
        	BEGIN
        		SET @Condition=@Condition+' AND x.check_time IS NOT NULL '
        	END
        	
        	IF @isCheck=0
        	BEGIN
        		SET @Condition=@Condition+' AND x.check_time IS NULL '
        	END
        END    
    --设置需要取的字段信息                        
        SET @Column = ' pp.product_id as id,
       					 p.code as code,
       					 ISNULL(c.quantity, 0) - ISNULL(c.lock_quantity, 0) AS quantity ,
       					 d.name AS positionName,
       					 d.id as positionId,
       					 CASE WHEN x.check_time IS NULL THEN 0 ELSE 1 END AS isCheck,
       					 x.check_time AS checkTime '
						
				
		   			
        --求符合条件的总数                      
        SET @CountSql = ' SELECT @RowCount = count(p.id) ' + @FromSQL + @Condition                 
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
                            
		
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                              
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                              
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                              
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                              
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                              
        SET @end = @PageIndex * @PageSize   
    
        SET @SQL = 'SELECT * from                      
       (                      
       SELECT *,ROW_NUMBER() OVER(ORDER BY temp.positionName ASC ,temp.isCheck asc , temp.checkTime desc) rowIndex                      
       from (SELECT ' +@Column + @FromSQL + @Condition
            + ') temp                      
       ) temp2                           
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))    
            
        EXEC(@SQL);             
        SELECT  @RowCount                
    END
go


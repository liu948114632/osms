
/*--------------------------------------------
[描述]
	得到投诉统计的环比值
-----------------------------------------------*/
CREATE FUNCTION [dbo].[uf_GetComplaintAnnularRate]
(
	@date		datetime,
	@categoryid	int,
	@num		int,
	@type		int -- 1,上个月；2,上个季度
)
RETURNS nvarchar(20)
AS
BEGIN
	declare 
	@rate decimal(18,3),@result nvarchar(20),@preNum int,@year int,@quarter int

	if (@type = 1)
	begin
		if @categoryId = 0
		begin
			select @preNum = count(1) from dbo.T_ComplaintProductItem 
			where CONVERT(VARCHAR(7),CreateTime,126) = CONVERT(VARCHAR(7),dateadd(mm,-1,@date),126)
		end
		else
		begin
			select @preNum = count(1) from dbo.T_ComplaintProductItem  
			where [Type] = @categoryId and CONVERT(VARCHAR(7),CreateTime,126) = CONVERT(VARCHAR(7),dateadd(mm,-1,@date),126)
		end
	end
	else
	begin
		set @quarter = DATEPART(q,@date)
		set @year = year(@date)
		set @quarter = @quarter -1 -- 上个季度
		if @quarter = 0
		begin
			set @quarter = 4
			set @year = @year -1
		end

		if @categoryId = 0
		begin
			select @preNum = count(1) from dbo.T_ComplaintProductItem  
			where year(CreateTime) = @year and DATEPART(quarter,CreateTime) = @quarter
		end
		else
		begin
			select @preNum = count(1) from dbo.T_ComplaintProductItem   
			where [Type] = @categoryId and year(CreateTime) = @year and DATEPART(quarter,CreateTime) = @quarter
		end
	end

	if @prenum = 0 or @num = 0
	begin
		set @result = '0%'
	end
	else
	begin
		set @rate = ((@num - @prenum)*100.000000)/@prenum
		set @result = cast(@rate as nvarchar(20)) + '%'
	end


	return @result
END

go


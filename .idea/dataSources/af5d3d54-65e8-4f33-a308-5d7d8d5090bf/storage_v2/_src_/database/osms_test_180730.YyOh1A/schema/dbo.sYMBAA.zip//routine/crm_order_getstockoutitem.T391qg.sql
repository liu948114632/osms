
/**
获取海外仓出库单的出库项
*/
CREATE PROC CRM_Order_GetStockOutItem
(  
  @StockOutCode VARCHAR(30) --出库单号
)
AS
begin
      SELECT b.*
      FROM dbo.T_OverseasWarehouseStockOutOrderItem a
      JOIN dbo.T_OrderItem b ON a.OrderItemId = b.OrderItemId
      WHERE a.StockOutCode = @StockOutCode
END
go


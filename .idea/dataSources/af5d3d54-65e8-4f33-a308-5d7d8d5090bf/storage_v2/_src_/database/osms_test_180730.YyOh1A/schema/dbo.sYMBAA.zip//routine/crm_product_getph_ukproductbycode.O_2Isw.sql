
-- =============================================      
-- Description: <根据C3商品Code获得PH-UK商品信息>    
-- =============================================     
CREATE PROC [dbo].[CRM_Product_GetPH_UKProductByCode]        
(        
 @Code VARCHAR(50)    
)        
AS        
BEGIN    
 SELECT *
 FROM dbo.V_CRM_PH_UK_Product     
 WHERE code = @Code;    
END

go


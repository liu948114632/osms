

     
CREATE PROC [dbo].[CMS_CheckProduct_CheckBlackStorages]          
(           
  @ProductIds VARCHAR(max) = NULL --产品Id
)            
AS            
BEGIN            
    SET NOCOUNT ON ;            
               
    SELECT a.department_id AS storageDepartmentId, a.product_id AS productId,
    a.quantity AS quantity, a.update_time AS updateTime,(a.quantity - a.lock_quantity) AS availableQuantity,
    a.lock_quantity AS lockQuantity,d.code AS productCode,'' AS  positionName
    FROM dbo.storage AS a WITH(NOLOCK) 
    INNER JOIN dbo.uf_Split(@ProductIds,',') AS temp ON a.product_id = temp.value 
    INNER JOIN dbo.product AS d ON d.id = a.product_id
    WHERE a.quantity > 0 AND a.department_id IN (SELECT id FROM dbo.department WHERE type = 3 AND is_random_storage = 1) 
    UNION
    SELECT a.department_id AS storageDepartmentId, a.product_id AS productId,
    a.quantity AS quantity, a.update_time AS updateTime,(a.quantity - a.lock_quantity) AS availableQuantity,
    a.lock_quantity AS lockQuantity,d.code AS productCode,e.name AS  positionName
    FROM dbo.storage AS a WITH(NOLOCK) 
    INNER JOIN dbo.uf_Split(@ProductIds,',') AS temp ON a.product_id = temp.value 
    INNER JOIN dbo.product AS d ON d.id = a.product_id
     INNER JOIN dbo.logistics_storage_detail f ON f.storage_id =a.id
    LEFT JOIN dbo.storage_position AS e WITH(NOLOCK) ON e.id = f.position_id
    
    WHERE a.quantity > 0 AND a.department_id IN (SELECT id FROM dbo.department WHERE type = 3 AND is_random_storage = 0) 
    UNION
    SELECT a.department_id AS storageDepartmentId, a.product_id AS productId,
    a.quantity AS quantity, a.update_time AS updateTime,(a.quantity - a.lock_quantity) AS availableQuantity,
    a.lock_quantity AS lockQuantity,d.code AS productCode,e.name AS  positionName
    FROM dbo.department_storage AS a WITH(NOLOCK) 
    INNER JOIN dbo.uf_Split(@ProductIds,',') AS temp ON a.product_id = temp.value 
    INNER JOIN dbo.product AS d ON d.id = a.product_id
    INNER JOIN dbo.department_storage_detail f ON f.storage_id =a.id
    LEFT JOIN dbo.storage_position AS e WITH(NOLOCK) ON e.id = f.position_id
    WHERE a.quantity > 0
    UNION
     SELECT a.department_id AS storageDepartmentId, a.product_id AS productId,
    a.quantity AS quantity, a.update_time AS updateTime,(a.quantity - a.lock_quantity) AS availableQuantity,
    a.lock_quantity AS lockQuantity,d.code AS productCode,e.name AS  positionName
    FROM dbo.logistics_storage AS a WITH(NOLOCK) 
    INNER JOIN dbo.uf_Split(@ProductIds,',') AS temp ON a.product_id = temp.value 
    INNER JOIN dbo.product AS d ON d.id = a.product_id
    INNER JOIN dbo.logistics_storage_detail f ON f.storage_id =a.id
    LEFT JOIN dbo.storage_position AS e WITH(NOLOCK) ON e.id = f.position_id
    WHERE a.quantity > 0
    
    SET NOCOUNT OFF;            
END


go


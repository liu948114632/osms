

/**************************************************************
		备注：月投诉率统计
提高产品的质量，减少投诉，从而提高客户的满意度。
指标：月投诉率＝月投诉商品项/月总的订单发出项
投诉的商品项的数量除以订单发货商品项（即使有跨月的因素在内也不考虑，该数据基本不准确，仅作参考用）
up_Report_CustomerService_ComplaitRate '2008-12-01','2010-03-01'
**************************************************************/
CREATE PROCEDURE [dbo].[up_Report_CustomerService_ComplaitRate] 
(
	@StartTime		DateTime, 
	@EndTime		DateTime
)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @OrderItemCount DECIMAL(18,2);
	DECLARE @ComplaintCount DECIMAL(18,2);

	SET @OrderItemCount = 1;
	SET @ComplaintCount = 0;

	--SET @StartTime = @StartTime + ' 00:00:00';
	--SET @EndTime = @EndTime + ' 23:59:59';

	/*
	SET @OrderItemCount = (
	SELECT COUNT(1) FROM b_OrderItem WHERE OrderId IN(
	SELECT OrderId FROM b_Package
	WHERE DueDate >= @StartTime AND DueDate <= @EndTime)
	AND Status < 12)

	declare @t table (ItemCode NVARCHAR(100))

	declare
	@ItemCode varchar(200),
	@Code	varchar(100)

	declare myCursor cursor for select ItemCode from dbo.C_Complaint 
	where itemCode is not null AND itemCode > '' AND CreateDate >= @StartTime AND CreateDate <= @EndTime
	open myCursor
		fetch next from myCursor into @ItemCode
		while @@fetch_status = 0
			begin   
			if @@error <> 0 break
			begin			
					declare myCursor2 cursor for select value from dbo.uf_Split(@ItemCode,',')
					open myCursor2
						fetch next from myCursor2 into @Code
						while @@fetch_status = 0
							begin   
							if @@error <> 0 break
							begin			
								
							INSERT INTO @t Values(rtrim(ltrim(@Code)))

							end
						fetch next from myCursor2 into @Code
					end
					close myCursor2
					deallocate myCursor2
			end
		fetch next from myCursor into @ItemCode
	end
	close myCursor
	deallocate myCursor

	SET @ComplaintCount = (SELECT COUNT(1) FROM @t)
	
	*/
	
	-- 订单发出项
	SET @OrderItemCount = (
	SELECT COUNT(1) FROM dbo.T_OrderItem WHERE OrderId IN(
	SELECT OrderId FROM dbo.T_OrderPackage
	WHERE DueDate > @StartTime AND DueDate < @EndTime)
	AND [Status] < 12);
	
	-- 收集投诉商品编号 
	DECLARE @allItemCode VARCHAR(MAX);
	SET @allItemCode = '';
	SELECT @allItemCode = @allItemCode + ',' + b.[Code]
	FROM dbo.T_Complaint a 
		JOIN dbo.T_ComplaintRelatedProduct b 
			ON a.Id = b.ComplaintId
	WHERE a.CreateDate > @StartTime AND a.CreateDate < @EndTime;

	SET @allItemCode =  SUBSTRING(@allItemCode,2,LEN(@allItemCode) -1);
	
	-- 统计商品总个数
	SELECT @ComplaintCount = COUNT(1) FROM dbo.uf_Split(@allItemCode,',') WHERE [Value] > '';

	SELECT ltrim(CAST(CAST(@ComplaintCount/@OrderItemCount AS Decimal(18,5)) * 100  AS Decimal(18,3))) + '%' AS Rate;
END


go


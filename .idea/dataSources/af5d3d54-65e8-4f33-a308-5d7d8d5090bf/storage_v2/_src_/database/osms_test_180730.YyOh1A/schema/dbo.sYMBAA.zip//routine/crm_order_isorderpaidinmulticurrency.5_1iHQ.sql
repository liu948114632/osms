
CREATE PROCEDURE [dbo].[CRM_Order_IsOrderPaidInMultiCurrency]
    (
      @orderIdString VARCHAR(1000) ,
      @isMultiCurrency INT OUTPUT
    )
AS 
    BEGIN				
        SELECT  @isMultiCurrency = 1
        FROM    T_OrderPay t1
                JOIN T_orderPay t2 ON t1.id <> t2.id
                                      AND t1.orderid = t2.orderId
        WHERE   t1.orderId IN (SELECT Value FROM uf_Split(@orderIdString, ',')) 
        GROUP BY t1.orderid
        HAVING  COUNT(*) > 1
                AND COUNT(DISTINCT t1.CurrencyId) > 1

        PRINT @isMultiCurrency
        
		IF (@isMultiCurrency IS NULL)
			SET @isMultiCurrency = 0;
    END
go


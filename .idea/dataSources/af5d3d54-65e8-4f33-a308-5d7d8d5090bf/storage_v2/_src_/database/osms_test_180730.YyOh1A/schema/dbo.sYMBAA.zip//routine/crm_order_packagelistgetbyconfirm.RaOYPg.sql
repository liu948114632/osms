
/*------------------------------------------------------
[备注] 获取需要确认的包裹
只针对Air,Surface和4px三种货运方式不可跟踪的包裹发送邮件

修改人：HYD
版本：CRM 5.0.4.0
修改时间：2010-04-21
修改内容：包裹确认时候增加获取 airport to airport，port to port两种货运方式
--------------------------------------------------------*/

-- =============================================
-- modify:		HYD
-- Create date: 2010-06-08
-- Description:	获取在途包裹b.[Status] = 1 改为 b.[Status] = 10
-- Version:CRM 5.1
-- =============================================
CREATE PROC dbo.CRM_Order_PackageListGetByConfirm
AS
BEGIN
	SELECT 
		b.OrderId,
		b.CustomerName AS Customer,
		b.DueDate,
		a.[Name],
		a.Days
	FROM 
		dbo.T_Delivery a JOIN dbo.T_OrderPackage b 
			ON a.DeliveryId = b.DeliveryId
	WHERE a.DeliveryId IN(10,12,21,22,23) AND b.[Status] = 10
		AND b.IsSendMail = 0 
			AND DATEDIFF(d,b.DueDate,GETDATE()) > a.Days;
END


go


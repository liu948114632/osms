 

CREATE
 PROC [dbo].[CMS_Service_OrderItemPrepareQty] ( @AssigmentId INT)
AS
    BEGIN                      
        SET NOCOUNT ON;         
		  IF OBJECT_ID('#temp_order_item_prepare') IS NOT NULL 
            DROP TABLE #temp_order_item_prepare ; 
        SELECT  CASE WHEN ( temp.quantity + temp.prepareLockQuantity
                            + temp.taskQty + temp.stockOutQty
                            + prepareLockQty2+currentAssignQuantity ) > temp.order_quantity
                     THEN  temp.order_quantity
                     ELSE ( temp.quantity + temp.prepareLockQuantity
                            + temp.taskQty + temp.stockOutQty
                            + prepareLockQty2+currentAssignQuantity )
                END AS assignQuantity ,
                temp.* 
                INTO #temp_order_item_prepare
        FROM    ( SELECT    i.id ,
                            i.product_code ,
                            o.code ,
                            i.prepared_quantity ,
                            i.order_quantity,(ISNULL(i.zcq_department_received_qty,
                                                    0)
                                             + ISNULL(i.hdq_department_received_qty,
                                                      0)
                                             + ISNULL(i.zfq_department_received_qty,
                                                      0)) AS quantity ,
                            ISNULL(( SELECT SUM(a.assign_quantity)
                                     FROM   dbo.assignment_item a
                                            INNER JOIN dbo.assignment b ON a.assignment_id = b.id
                                                              AND a.order_item_id = i.id
                                                              AND b.status IN (
                                                              1 ) AND b.id<>@AssigmentId
                                   ), 0) AS prepareLockQuantity , --预分配单
							ISNULL(( SELECT SUM(a.assign_quantity)
                                     FROM   dbo.assignment_item a
                                            INNER JOIN dbo.assignment b ON a.assignment_id = b.id
                                                              AND a.order_item_id = i.id
                                                              AND b.id=@AssigmentId
                                   ), 0) AS currentAssignQuantity,    
                            ISNULL(( SELECT SUM(t.wait_quantity)
                                     FROM   dbo.storage_task t
                                     WHERE  t.type IN ( 1, 4, 8 )
                                            AND t.status IN ( 1, 2 )
                                            AND t.order_id = o.id
                                            AND t.order_item_id = i.id
                                   ), 0) AS taskQty , --出库任务    
                            ISNULL(( SELECT SUM(soi.quantity)
                                     FROM   dbo.stock_out_item soi
                                            INNER JOIN dbo.stock_out o ON soi.stock_out_id = o.id
                                            INNER JOIN dbo.stock_out_ref_storage_task ot ON soi.id = ot.stock_out_item_id
                                            INNER JOIN dbo.view_all_storage_task st ON st.id = ot.storage_task_id
                                     WHERE  o.is_received = 0
                                            AND o.receive_department_id = 37
                                            AND st.order_id = i.order_id
                                            AND st.order_item_id = i.id
                                   ), 0) AS stockOutQty , --出库单    
                            ISNULL(( SELECT SUM(sp.assign_quantity)
                                     FROM   dbo.assigment_stay_product AS sp
                                     WHERE  sp.order_item_id = i.id
                                            AND sp.status IN (1 )
                                   ), 0) AS prepareLockQty2
                  FROM      order_item AS i
                            INNER JOIN [order] AS o ON o.id = i.order_id
							INNER JOIN assignment_item item ON item.order_item_id =i.id
                  WHERE     i.id IN ( SELECT order_item_id
                                     FROM   dbo.assignment_item
                                     WHERE  assignment_id = @AssigmentId
                                   )
                ) temp
                JOIN order_item z ON z.id = temp.id
        WHERE   ( temp.quantity + temp.prepareLockQuantity + temp.taskQty
                  + temp.stockOutQty + prepareLockQty2+currentAssignQuantity ) <> ISNULL(temp.prepared_quantity,0);
 
		SELECT DISTINCT b.id AS orderItemId,a.assignQuantity-ISNULL(b.prepared_quantity,0) AS assignQuantity
		 FROM  #temp_order_item_prepare a JOIN dbo.order_item b ON a.id =b.id WHERE a.assignQuantity<>ISNULL(b.prepared_quantity,0)
                  
    END;

go


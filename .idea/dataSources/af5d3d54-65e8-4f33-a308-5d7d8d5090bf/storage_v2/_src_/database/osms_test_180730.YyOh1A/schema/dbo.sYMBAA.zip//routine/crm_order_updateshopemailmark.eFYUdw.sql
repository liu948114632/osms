CREATE PROC CRM_Order_UpdateShopEmailMark
(
@OrderIds VARCHAR(MAX),
@IsSet BIT 
)
AS
BEGIN
	UPDATE dbo.T_ShopCustomer
	SET T_ShopCustomer.IsAutoSendConfirmArrivalEmail=@IsSet
	 FROM dbo.uf_Split(@OrderIds,',') b
	 WHERE b.Value=T_ShopCustomer.OrderId	
END
go


CREATE
 PROCEDURE CMS_GET_ProcessingDepartment_ASSIGNMENT_STAY_PRODUCT
	@stockOutId VARCHAR(50) = NULL
AS 
	 BEGIN
		 SET NOCOUNT ON;
		 DECLARE @SQL VARCHAR(MAX)
		 SET @SQL = 'SELECT a.[id] AS id
					,a.[order_item_id] AS orderItemId
					,a.[order_code] AS orderCode
					,a.[product_id] AS productId
				  ,a.[assign_quantity] AS assignQuantity
				  ,a.[product_unit] AS productUnit
				  ,a.[order_id] AS orderId
				  ,a.[status] AS status
				  ,a.[stock_out_id] AS stockOutId
				  ,a.[stock_out_code] AS stockOutCode
				  ,a.[stock_collate_user_id] AS stockCollateUserId
				  ,a.[create_time] AS createTime
				  ,a.[department_id] AS departmentId
				  ,a.[product_code] AS productCode
				  ,a.[assignment_code] AS assigmentCode
				  ,c.[number] AS position,us.name AS assignPersion
				  ,a.[order_item_group_id] AS orderItemGroupId
					FROM [dbo].[assigment_stay_product] a  with(nolock)
					join processing b  with(nolock) on b.id =a.order_id
					left join processing_processor_code c  with(nolock) on b.processor_id=c.processor_id 
					LEFT JOIN dbo.[user] us ON us.id =c.processor_id
					WHERE a.stock_out_id = '+@stockOutId+' AND a.STATUS = 0'
        EXEC (@SQL) ;  
	 END


go


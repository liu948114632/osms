/*----------------------------------------- 
[描述]
	报表统计，订单处理指标，完货率，按商品项数统计
------------------------------------------------*/
create  PROCEDURE [dbo].[Report_Count_OrerDealRateGetByItems]
(
	@Start	DATETIME,
	@End	DATETIME,
	@Days	INT,
	@Price1 DECIMAL(18,2),
	@Price2 DECIMAL(18,2),
	@Rate	DECIMAL(9,6) OUT
)
AS
BEGIN
	/*统计该月订单金额*/
	WITH cte AS 
	(
		SELECT  a.OrderId,
			CAST(SUM(b.Quantity*1.0*b.ItemPrice/b.UnitQuantity) AS DECIMAL(9,2)) AS Price,
			--SUM(Quantity) AS Qty
			count(*) AS counts -- 商品项个数
		FROM dbo.T_Order
		a JOIN dbo.T_OrderItem b 
		ON a.OrderId = b.OrderId
		AND a.OrderStatus > 0 AND a.OrderStatus < 132
		AND a.OrderDate > @Start
		AND a.OrderDate < @End
		AND b.[Status] < 12
		GROUP BY a.OrderId
	),cteOrders  AS -- 锁定价格区的订单
	(
		SELECT OrderId,Counts
		FROM cte 
		WHERE Price > @Price1 AND Price <= @Price2
	),cteOrderItems AS -- 锁定这个价格区的订单商品
	(
		SELECT a.OrderItemDataId,b.OrderId
		FROM dbo.C_OrderItem a
		JOIN cteOrders b 
		ON a.OrderId = b.OrderId AND a.Status < 12
	),cteOrderItemsStart AS -- 目标订单第一次备货时间
	(
		SELECT c.OrderId,MIN(a.AssignTime) AS FirstReadyTime
		FROM dbo.C_Assignment a
		JOIN dbo.C_AssignmentItem b
		ON a.AssignmentId = b.AssignmentId
		AND a.[Status] > 1
		JOIN cteOrderItems c
		ON b.OrderItemDataId = c.OrderItemDataId
		GROUP BY c.OrderId
	),cteRate AS -- 订单完货率
	(
		SELECT 
		a.OrderId,
		a.FirstReadyTime,
		b.Counts,
		--[dbo].[uf_Report_ComleteRateByDay](a.OrderId,b.Qty,DATEADD(DAY,@Days,a.FirstReadyTime)) AS rate
		[dbo].[uf_Report_ComleteRateByDay2](a.OrderId,b.counts,DATEADD(DAY,@Days,a.FirstReadyTime)) AS rate
		FROM cteOrderItemsStart a 
		JOIN cteOrders b
		ON a.OrderId = b.OrderId 
	)

	SELECT @Rate = CASE WHEN SUM(Rate)*1.0/COUNT(*) > 1 THEN 1 ELSE SUM(Rate)*1.0/COUNT(*) END   FROM cteRate;
END
go


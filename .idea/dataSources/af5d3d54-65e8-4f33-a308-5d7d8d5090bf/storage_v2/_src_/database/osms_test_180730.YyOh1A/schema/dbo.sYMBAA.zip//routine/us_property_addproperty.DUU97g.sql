CREATE PROCEDURE [dbo].[US_Property_AddProperty]
(
	@PropertyId INT
)
AS
BEGIN 
	IF NOT EXISTS (SELECT 1 FROM dbo.T_Property_US WHERE PropertyId = @PropertyId)
	BEGIN
		INSERT INTO dbo.T_Property_US (
			PropertyId,
			IsDeleted,
			CreateDate,
			LastUpdateDate
		) VALUES ( 
			@PropertyId,
			0,
			GETDATE(),
			GETDATE() ) 
	END
	ELSE
	BEGIN
		UPDATE dbo.T_Property_US SET IsDeleted = 0,LastUpdateDate = GETDATE() WHERE PropertyId = @PropertyId
	END
END
go


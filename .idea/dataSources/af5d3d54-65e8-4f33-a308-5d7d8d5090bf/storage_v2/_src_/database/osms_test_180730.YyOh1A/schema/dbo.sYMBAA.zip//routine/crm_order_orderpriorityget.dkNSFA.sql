
/*-------------------------------------------
[描述]
	获取用户的订单默认优先级
--------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_OrderPriorityGet]
(
	@UserId				INT,
	@Priority			INT OUT
)
AS
DECLARE
	@Type				INT,
	@num				INT;
BEGIN
	-- 默认普通
	SET @Priority = 1;

	-- 获取客户等级
	SELECT @Type = [Type] FROM T_Customer WHERE UserId = @UserId;

	-- 老老客户默认高级
	IF @Type = 2
	begin
		SET @Priority = 4;
	end
	ELSE if @Type = 0
	BEGIN
		-- 第一次下单
		SELECT @num = COUNT(1) FROM dbo.T_Order WHERE CustomerId = @UserId;
		IF @num = 1
		begin
			SET @Priority = 2;
		end
	END 
END


go


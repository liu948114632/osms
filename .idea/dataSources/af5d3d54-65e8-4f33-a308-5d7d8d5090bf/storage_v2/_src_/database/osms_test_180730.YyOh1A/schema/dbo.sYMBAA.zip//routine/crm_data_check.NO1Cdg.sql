CREATE PROC dbo.CRM_Data_Check
AS 
BEGIN
DECLARE @Subject VARCHAR(100)='',@Body VARCHAR(MAX)='';

SET @Subject= 'CRM数据监控：订单在C3系统不存在';
SELECT @Body=@Body+a.OrderId+',' FROM dbo.T_Order a WITH(NOLOCK)	
INNER JOIN dbo.T_OrderExtend c WITH(NOLOCK) ON c.OrderId=a.OrderId
LEFT JOIN dbo.[order] b WITH(NOLOCK)	 ON a.OrderId=b.code 
WHERE 1=1
AND  a.OverseasWarehouseStatus<30
AND a.OrderStatus>0
AND a.OrderStatus<132
AND c.IsCashOrder=0
AND b.id IS NULL
AND a.OrderDate>=DATEADD(DAY,-3,GETDATE())
AND a.OrderDate<DATEADD(HOUR,-3,GETDATE())
SELECT @Subject AS Subject,@Body AS Body

SET @Body='';

SET @Subject= 'CRM数据监控：最近一次收取邮件时间';
SELECT TOP 1 @Body='收取时间：'+CONVERT(VARCHAR(100),CreateTime,25)+';邮件主题:'+Subject FROM Test1_bmsTicket.dbo.C_Mail 
WITH(NOLOCK) WHERE ToEmailId=516559
AND CreateTime>DATEADD(DAY,-2,GETDATE())
ORDER BY id DESC 

SELECT @Subject+'-->'+@Body AS Subject,@Body AS Body

SET @Body='';
--SET @Subject= 'CRM数据监控：订单状态跟C3系统不一致';
--SELECT @Body=@Body+a.code+','
--FROM dbo.[order] a WITH(NOLOCK)
--JOIN dbo.T_Order b WITH(NOLOCK) ON a.code= b.OrderId
--WHERE a.status != b.OrderStatus AND b.OverseasWarehouseStatus !=30
--AND b.OrderDate>=DATEADD(DAY,-10,GETDATE())
--SELECT @Subject AS Subject,@Body AS Body

SET @Subject= 'CRM数据监控：订单状运费为0';
SELECT @Body=@Body+a.OrderId+',' FROM dbo.T_Order a WITH(NOLOCK)
WHERE  a.DeliveryId NOT IN (0,17,21,22,116,117,118,119,120,121,122,127,128,129,130,13)--排除没运费表的货运方式
AND a.OrderStatus>0
AND a.OrderStatus<132
AND a.Freight=0
AND a.OrderIndustryType<>5
AND a.OrderDate>=DATEADD(DAY,-3,GETDATE())
SELECT @Subject AS Subject,@Body AS Body

SET @Body='';

SET @Subject= 'CRM数据监控：订单绩效误差';

SELECT @Body=@Body+'订单号：'+temp3.OrderId+',订单实付款:'+LTRIM(temp3.price1)+';订单绩效：'+LTRIM(temp3.PerformanceMoney)+','
		  FROM (
		  SELECT *,ABS(temp2.price1 - temp2.PerformanceMoney) AS tt,CASE WHEN price1 > 0 THEN ABS(temp2.price1 - temp2.PerformanceMoney)  / temp2.price1 ELSE 0 end AS t2
		  from (
		  SELECT OrderId,(temp.productPrice + temp.Freight-temp.SpecialOffer-temp.FrightOffer+temp.Surcharge- CashCoupon-DiscountForReplace) AS price1 ,temp.PerformanceMoney
		  FROM (
		  SELECT a.OrderId,(SELECT SUM(b1.ItemPrice * b1.Quantity / b1.UnitQuantity) FROM dbo.T_OrderItem b1 WHERE b1.OrderId=a.orderid AND b1.Status<12) AS productPrice,
		  a.Freight,
		  ISNULL((SELECT SUM(Amount) FROM dbo.T_OrderSpecialOffer b2 WITH(NOLOCK) WHERE b2.OrderId=a.orderid ),0) AS SpecialOffer,
		  ISNULL((SELECT SUM(Amount) FROM dbo.T_OrderFrightOffer b2 WITH(NOLOCK) WHERE b2.OrderId=a.orderid AND b2.IsDelete=0 ),0) AS FrightOffer,
		  ISNULL((SELECT SUM(Surcharge) FROM dbo.T_OrderSurcharge b2 WITH(NOLOCK) WHERE b2.OrderId=a.orderid ),0) AS Surcharge,
		  ISNULL((SELECT SUM(Value) FROM dbo.T_CashCoupon b2 WITH(NOLOCK) WHERE b2.OrderId=a.orderid ),0) AS CashCoupon, 
		  (SELECT SUM(CASE WHEN b3.Type = 2 THEN -PerformanceMoney ELSE PerformanceMoney end) 
		  FROM dbo.T_PerformanceCheck b3 WITH(NOLOCK) WHERE b3.SourceId=a.orderid ) AS PerformanceMoney,
		  ISNULL(b.DiscountForReplace,0) AS DiscountForReplace
		  FROM dbo.T_Order a WITH(NOLOCK)
		  LEFT JOIN dbo.T_OrderPrice b WITH(NOLOCK) ON a.OrderId=b.OrderId
		  WHERE (a.OrderIndustryType=1 OR a.OrderIndustryType=16) AND a.OrderStatus>0 AND a.balanceDate<132 AND a.balanceDate>=DATEADD(DAY,-3,GETDATE())
		 )temp 
		 ) temp2
		 WHERE temp2.price1 != temp2.PerformanceMoney
		 )temp3
		 ORDER BY temp3.t2 DESC 
SELECT @Subject AS Subject,@Body AS Body

SET @Body='';

--SET @Subject= 'CRM数据监控：ＯＳＭＳ订单监控';

--SET @Body='<table  style="width:100%;" cellpadding="2" cellspacing="0" border="1" bordercolor="#000000">'
--SELECT @Body=@Body+'<tr><td>'+remark+'</td><td>'+CONVERT(CHAR(25), last_updated_after,25)+'</td><td> '+serviceURL+'</td></tr>' FROM OSMS.dbo.shop_dev_info WHERE pause=0
--SET @Body=@Body+'</table>' 
--SELECT @Subject AS Subject,@Body AS Body
END
go


CREATE PROC dbo.CRM_User_GetUsers  
AS   
BEGIN  
 SELECT Id,    
     Code,    
     [Name],    
     EnglishName,  
     Email,  
  CAST(IsValid AS BIT) AS IsValid
 FROM dbo.V_CRM_UserInfo  
 WHERE IsValid=1
 ORDER BY Name ASC 
END
go


		 

-- =============================================            
-- Author:  HYD            
-- Create date: 2011-06-17            
-- Description: 客户确认替代品后            
--              更新订单跟踪状态，更新订单运费，更新可发货标识            
-- 2012-02-28修改：确认替代品后，不再自动发货        
-- 2014-08-18 mzc 更新报关运费百分比                      
-- =============================================            
CREATE PROCEDURE [dbo].[CRM_Order_OrderReplacementOrderUpdate]  
    @OrderId VARCHAR(20) ,  
    @Freight DECIMAL(18, 4) ,  
    @IsRemote BIT ,  
    @CPFCode NVARCHAR(200) ,  --税号    
    @CCP DECIMAL(18, 4) ,  
    @IsSend BIT OUT  
AS  
    DECLARE @Price DECIMAL(18, 2) ,  
        @ReadyPrice DECIMAL(18, 2) ,  
        @OrderPrice DECIMAL(18, 2) , -- 订单应付款            
        @Pay DECIMAL(18, 2)--订单实付款            
            
    BEGIN            
   -- SET NOCOUNT ON added to prevent extra result sets from            
   -- interfering with SELECT statements.            
        SET NOCOUNT ON;            
             
        SET @IsSend = 0;            
        SELECT  @IsSend = isSend  
        FROM    dbo.T_Order  
        WHERE   OrderId = @OrderId;            
             
  -- 更新订单的跟踪状态及运费\税号    
        UPDATE  dbo.T_Order  
        SET     DelayStatus = 5 ,  
                DelayUpdateDate = GETDATE() ,  
                LastModifyTime = GETDATE() ,  
                Freight = @Freight ,  
                IsAutoDelay = 0 ,  
                IsConfirmReplace = 1 ,  
                ConfirmReplaceDate = GETDATE() ,  
                CPFCode = @CPFCode ,  
                IsRemote = @IsRemote ,  
                CustomsClearanceProportion = @CCP  
        WHERE   OrderId = @OrderId;            
            
  --/*      计算订单的应付款与实付款，如果应付款-实付款>1USD时，将发货标识改为否          */  
  ---- 获取该订单商品和到货商品的价值            
  --      EXEC CRM_Price_OrderPriceGet @OrderId, @Price OUT, @ReadyPrice OUT;            
         
  ----获取订单附加费  
  --      DECLARE @Surcharge DECIMAL(18, 2)  
  --      SELECT  @Surcharge = ISNULL(SUM(ISNULL(Surcharge, 0)), 0)  
  --      FROM    T_OrderSurcharge  
  --      WHERE   OrderId = @OrderId;   
  --PRINT @Surcharge;  
    
  ----获取其他折扣  
  --      DECLARE @CashCoupon DECIMAL(18, 2) ,  
  --          @SpecialOffer DECIMAL(18, 2) ,  
  --          @ReplaceDiscount DECIMAL(18, 2) ,
		--	@FrightOffer DECIMAL(9,2)
  --      EXEC CRM_Order_GetDiscounts @OrderId, @CashCoupon OUT, @SpecialOffer OUT, @ReplaceDiscount OUT,@FrightOffer OUT
    
  --PRINT '@CashCoupon'  
  --PRINT @CashCoupon;  
    
  --PRINT '@SpecialOffer'  
  --PRINT @SpecialOffer;  
    
  --PRINT '@ReplaceDiscount'  
  --PRINT @ReplaceDiscount;  
    
  ----计算应付款  
  --      SET @OrderPrice = @Price + @Freight + @Surcharge - @CashCoupon  
  --          - @SpecialOffer - @ReplaceDiscount;            
          
  --PRINT '@OrderPrice'  
  --     PRINT @OrderPrice;         
         
          
  ----获取订单实付款            
  --      EXEC CRM_Order_OrderPaymentGet @OrderId, @Pay OUT;            
          
  --PRINT '@Pay'  
  --     PRINT @Pay;  
         


	EXEC dbo.CRM_Order_OrderPaymentInfoGet @OrderId =@OrderId, -- varchar(20)
	    @DuePay = @OrderPrice OUT, -- decimal
	    @RealPay = @Pay OUT -- decimal		

	 PRINT '@OrderPrice - @Pay'  
       PRINT @OrderPrice - @Pay;           
          
        --如果应付款-实付款>1USD时，将发货标识改为否   
        IF ( @OrderPrice - @Pay > 1 )  
            BEGIN            
                SET @IsSend = 0;            
                  
                UPDATE  dbo.T_Order  
                SET     IsSend = @IsSend  
                WHERE   OrderId = @OrderId;        
                
                EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int
                    @OrderId = @OrderId, -- varchar(14)
                    @Remark = '确认替代品后欠款，修改可发货标识为否' -- varchar(5000)
                                            
            END            
    END

go


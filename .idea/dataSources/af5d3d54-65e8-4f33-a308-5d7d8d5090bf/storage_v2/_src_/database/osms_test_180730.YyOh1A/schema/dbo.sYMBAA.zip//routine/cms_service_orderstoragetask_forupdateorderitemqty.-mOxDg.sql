 

CREATE PROC [dbo].[CMS_Service_OrderStorageTask_ForUpdateOrderItemQty]
(
	@OrderItemId INT,
	@OrderQty int
)
AS 
    BEGIN                      
        SET NOCOUNT ON ;         
        IF OBJECT_ID('#temp_order_item_demand2') IS NOT NULL 
            DROP TABLE #temp_order_item_demand2 ;    
     
        SELECT  temp.id AS orderItemId ,
                temp.order_id AS orderId ,
                temp.code AS orderCode ,
                temp.product_id AS productId ,
                ( temp.quantity) AS assignQuantity ,
                CONVERT(VARCHAR(20), temp.unit_quantity) + ' ' + temp.unit AS productUnit ,
                temp.orderType AS orderType ,
                temp.department_id AS departmentId ,
                temp.is_pool
        INTO    #temp_order_item_demand2
        FROM    ( SELECT    i.id ,
                            ( @OrderQty - i.prepared_quantity ) AS quantity ,
                            i.product_id ,
                            o.code ,
                            o.valid_Order_Count ,
                            o.prepared_Count ,
                            o.priority_Level ,
                            o.order_Time ,
                            i.unit_quantity ,
                            i.unit ,
                            i.order_id ,
                            o.department_id ,
                            o.type AS orderType ,
                            i.is_pool
                  FROM      order_item AS i
                            INNER JOIN [Order] AS o ON o.id = i.order_Id
                  WHERE     i.status < 6 AND o.status = 1 AND i.is_customize = 0 
                 
                  AND i.id = @OrderItemId
                ) temp
      
        ORDER BY ( temp.valid_Order_Count - temp.prepared_Count ) ,
                temp.priority_Level DESC ,
                temp.order_Time DESC          
  
        DELETE  a
        FROM    #temp_order_item_demand2 AS a
                INNER JOIN product_pool AS b ON a.productid = b.product_Id
        WHERE   a.orderType = 2   
  
        SELECT  a.*
        FROM    #temp_order_item_demand2 AS a
                INNER JOIN dbo.[view_product_all_storage_quantity_info] AS s ON a.productId = s.product_id
                                             
        WHERE   ( s.quantity - s.lock_quantity ) >= a.assignQuantity    AND a.assignQuantity>0
   
    
        SET NOCOUNT OFF ;       
        DROP TABLE #temp_order_item_demand2    
    END


go


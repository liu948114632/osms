  
  
    
CREATE PROCEDURE [dbo].[CMS_Order_IsOrderInfoLimited] ( @OrderId VARCHAR(100) )
AS
    BEGIN    
 /*1.获取订单基本信息的限制条件*/    
        DECLARE @CountryId INT = NULL;    
        DECLARE @DeliveryId INT = NULL;    
        DECLARE @CmsProductIds VARCHAR(MAX);  
        DECLARE @cmsOrderId INT;  
        DECLARE @errorMsg VARCHAR(200);  
        DECLARE @returnValue INT;
        DECLARE @source INT    
        SELECT  @CountryId = t3.CountryId ,
                @DeliveryId = t2.delivery_id ,
                @cmsOrderId = t2.id,
                @source =t2.source
        FROM    shipping_address t1
                INNER JOIN dbo.[order] t2 ON t1.id = t2.id
                                             AND t2.code = @OrderId
                INNER JOIN dbo.T_Country t3 ON t1.country_id = t3.CountryId;    
                  
     
        SET @CmsProductIds = STUFF(( SELECT ','
                                            + CAST(product_id AS VARCHAR(10))
                                     FROM   dbo.order_item
                                     WHERE  order_id = @cmsOrderId
                                            AND status <> 12
                                   FOR
                                     XML PATH('')
                                   ), 1, 1, '');    
        
       
  --自提订单不要任何限制  
        IF ( @DeliveryId = 17 )
            RETURN;  
  
    --DECLARE @tbLimits TABLE  
    --        (  
    --          Id INT ,  
    --          CountryId INT ,  
    --          DeliveryId INT ,  
    -- Category1_Id INT,  
    -- Category2_Id INT,  
    -- Category3_Id INT,  
    -- PropertyId INT ,  
    -- PropertyValueId INT,  
    --          RowIndex INT  
    --        )  
   --INSERT INTO @tbLimits  
   --        ( Id ,  
   --          CountryId ,  
   --          DeliveryId ,  
   --          Category1_Id ,  
   --          Category2_Id ,  
   --          Category3_Id ,  
   --          PropertyId ,  
   --          PropertyValueId ,  
   --          RowIndex  
   --        )  
    --SELECT  a.Id ,  
    --      CountryId ,  
    --      DeliveryId ,  
    --         b.Category1_Id,  
    --      b.Category2_Id,  
    --      b.Category3_Id,  
    --      b.PropertyId,  
    --      b.PropertyValueId,  
    --      ROW_NUMBER() OVER ( ORDER BY a.Id ) AS RowIndex  
    --    FROM    dbo.T_OrderLimit a WITH(NOLOCK)  
    --    INNER JOIN dbo.T_OrderItemLimit b WITH(NOLOCK) ON a.Id=b.OrderLimitId  
    --    WHERE   (DeliveryId = @DeliveryId OR  DeliveryId IS NULL)   
    --    AND (CountryId = @CountryId OR CountryId IS NULL)  
  --IF (@@ROWCOUNT = 0)  
  --BEGIN  
  -- SET @ReturnValue = 0;  
  -- RETURN @ReturnValue; /*RETURN 0表示无匹配 1表示有匹配*/  
  --END  
   ;  
  
   --    DECLARE @tbLimits2 TABLE  
   --         (  
   --ProductId INT,  
   --Code VARCHAR(50),  
   --           CountryId INT ,  
   --           DeliveryId INT  
   --   );  
  
        WITH    cte_ppp
                  AS ( SELECT   p1.id AS productId ,
                                p1.code ,
                                p1.category_id_1 ,
                                CASE WHEN p1.category_id_2 = 0 THEN NULL
                                     ELSE p1.category_id_2
                                END AS category_id_2 ,
                                CASE WHEN p1.category_id_3 = 0 THEN NULL
                                     ELSE p1.category_id_3
                                END AS category_id_3 ,
                                p2.property_id ,
                                p2.property_value AS property_value_id
                       FROM     dbo.product p1 WITH ( NOLOCK )
                                INNER JOIN dbo.product_property_value p2 WITH ( NOLOCK ) ON p1.id = p2.product_id
                       WHERE    p1.id IN (
                                SELECT  Value
                                FROM    dbo.uf_Split(@CmsProductIds, ',') )
                     )
            --INSERT INTO @tbLimits2--插入最终的货运限制  
     -- SELECT cte_ppp.productId,cte_ppp.code,cte_limit.CountryId,cte_limit.DeliveryId FROM  ( SELECT  a.Id ,  
     --     CountryId ,  
     --     DeliveryId ,  
     --        b.Category1_Id,  
     --     b.Category2_Id,  
     --     b.Category3_Id,  
     --     b.PropertyId,  
     --     b.PropertyValueId,  
     --     ROW_NUMBER() OVER ( ORDER BY a.Id ) AS RowIndex  
     --   FROM    dbo.T_OrderLimit a WITH(NOLOCK)  
     --   INNER JOIN dbo.T_OrderItemLimit b WITH(NOLOCK) ON a.Id=b.OrderLimitId  
     --   WHERE   (DeliveryId = @DeliveryId OR  DeliveryId IS NULL)   
     --   AND (CountryId = @CountryId OR CountryId IS NULL)) cte_limit  
     --   INNER JOIN cte_ppp   
     --          ON  ( cte_limit.Category1_Id IS NULL  
     --          OR cte_limit.Category1_Id = cte_ppp.category_id_1  
     --           )  
     --          AND ( cte_limit.Category2_Id IS NULL  
     --          OR cte_limit.Category2_Id = cte_ppp.category_id_2  
     --           )  
     --          AND ( cte_limit.Category3_Id IS NULL  
     --          OR cte_limit.Category3_Id = cte_ppp.category_id_3  
     --           )  
     --          AND  (cte_limit.PropertyId IS NULL OR cte_limit.PropertyId = cte_ppp.property_id)  
     --          AND (cte_limit.PropertyValueId IS NULL OR cte_limit.PropertyValueId = cte_ppp.property_value_id)                 
            
            
        SELECT TOP 1
                '商品' + a.code + '不支持'
                + CASE WHEN a.CountryId > 0
                            AND a.DeliveryId > 0
                       THEN '货运国家' + b.Name + ',货运方式' + c.Name
                       WHEN a.CountryId > 0 THEN '货运国家' + b.Name
                       WHEN a.DeliveryId > 0 THEN '货运方式' + c.Name
                  END
        FROM    ( SELECT    cte_ppp.productId ,
                            cte_ppp.code ,
                            cte_limit.CountryId ,
                            cte_limit.DeliveryId
                  FROM      ( SELECT    a.id ,
                                        @CountryId AS CountryId ,
                                        @DeliveryId AS DeliveryId ,
                                        b.Category1_Id ,
                                        b.Category2_Id ,
                                        b.Category3_Id ,
                                        b.PropertyId ,
                                        b.PropertyValueId ,
                                        ROW_NUMBER() OVER ( ORDER BY a.id ) AS RowIndex
                              FROM      dbo.T_OrderLimit a WITH ( NOLOCK )
                                        INNER JOIN dbo.T_OrderItemLimit b WITH ( NOLOCK ) ON a.id = b.OrderLimitId
                              WHERE     a.is_delete = 0 AND (a.source IS NULL  OR a.source =@source)
                                        AND ( ( a.limiteDeliveryType = 2
                                                AND DeliveryId LIKE '%,'
                                                + CAST(@DeliveryId AS VARCHAR(100))
                                                + ',%'
                                                AND ( CountryId IS NULL
                                                      OR ( CountryId LIKE '%,'
                                                           + CAST(@CountryId AS VARCHAR(100))
                                                           + ',%'
                                                           AND a.limiteCountryType = 2
                                                         )
                                                      OR a.limiteCountryType = 1
                                                    )
                                              )
                                              OR ( a.limiteDeliveryType = 1
                                                   AND DeliveryId NOT  LIKE '%,'
                                                   + CAST(@DeliveryId AS VARCHAR(100))
                                                   + ',%'
                                                   AND ( CountryId IS NULL
                                                         OR ( CountryId LIKE '%,'
                                                              + CAST(@CountryId AS VARCHAR(100))
                                                              + ',%'
                                                              AND a.limiteCountryType = 2
                                                            )
                                                         OR ( a.limiteCountryType = 1 )
                                                       )
                                                 )
                                              OR ( a.limiteDeliveryType = 1
                                                   AND DeliveryId LIKE '%,'
                                                   + CAST(@DeliveryId AS VARCHAR(100))
                                                   + ',%'
                                                   AND ( ( CountryId LIKE '%,'
                                                           + CAST(@CountryId AS VARCHAR(100))
                                                           + ',%'
                                                           AND a.limiteCountryType = 2
                                                         )
                                                         OR ( CountryId NOT  LIKE '%,'
                                                              + CAST(@CountryId AS VARCHAR(100))
                                                              + ',%'
                                                              AND a.limiteCountryType = 1
                                                            )
                                                       )
                                                 )
                                              OR ( DeliveryId IS NULL
                                                   AND ( CountryId IS NULL
                                                         OR ( CountryId LIKE '%,'
                                                              + CAST(@CountryId AS VARCHAR(100))
                                                              + ',%'
                                                              AND a.limiteCountryType = 2
                                                            )
                                                         OR ( CountryId NOT  LIKE '%,'
                                                              + CAST(@CountryId AS VARCHAR(100))
                                                              + ',%'
                                                              AND a.limiteCountryType = 1
                                                            )
                                                       )
                                                 )
                                            )
                            ) cte_limit
                            INNER JOIN cte_ppp ON ( cte_limit.Category1_Id IS NULL
                                                    OR cte_limit.Category1_Id = cte_ppp.category_id_1
                                                  )
                                                  AND ( cte_limit.Category2_Id IS NULL
                                                        OR cte_limit.Category2_Id = cte_ppp.category_id_2
                                                      )
                                                  AND ( cte_limit.Category3_Id IS NULL
                                                        OR cte_limit.Category3_Id = cte_ppp.category_id_3
                                                      )
                                                  AND ( cte_limit.PropertyId IS NULL
                                                        OR cte_limit.PropertyId = cte_ppp.property_id
                                                      )
                                                  AND ( cte_limit.PropertyValueId IS NULL
                                                        OR cte_limit.PropertyValueId = cte_ppp.property_value_id
                                                      )
                ) a
                LEFT JOIN dbo.T_Country b WITH ( NOLOCK ) ON a.CountryId = b.CountryId
                LEFT JOIN dbo.T_Delivery c WITH ( NOLOCK ) ON a.DeliveryId = c.DeliveryId;  
  
      
    END;


go


CREATE PROCEDURE [dbo].[US_PropertyValue_DeletePropertyValue]
(
	@PropertyValueId INT
)
AS
BEGIN 
	UPDATE dbo.T_PropertyValue_US SET IsDeleted=1 WHERE PropertyValueId=@PropertyValueId
END
go


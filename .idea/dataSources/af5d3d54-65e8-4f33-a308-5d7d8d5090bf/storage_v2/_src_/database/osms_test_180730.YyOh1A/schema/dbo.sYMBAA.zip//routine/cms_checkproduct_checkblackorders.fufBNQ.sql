  
CREATE PROC [dbo].[CMS_CheckProduct_CheckBlackOrders]          
(           
  @ProductIds VARCHAR(max) = NULL --产品Id
)            
AS            
BEGIN            
    SET NOCOUNT ON ;             
    SELECT b.product_id AS productId,
        b.product_code AS productCode,
		a.code AS orderCode,
		b.prepared_quantity AS preparedQuantity,--已备量
		b.order_quantity AS orderQuantity,--订购量
		a.status AS orderStatus,
		c.position AS orderPosition,
		a.department_id AS orderDepartmentId
	FROM  dbo.[order] AS a WITH(NOLOCK) 
    INNER JOIN dbo.order_item AS b WITH(NOLOCK) ON a.id = b.order_id
    INNER JOIN dbo.uf_Split(@ProductIds,',') AS temp ON b.product_id = temp.value 
    INNER JOIN dbo.order_item_group AS c WITH (NOLOCK) ON c.id = b.order_item_group_id
     
    WHERE a.status < 60 AND b.status = 6 AND b.prepared_quantity > 0
    SET NOCOUNT OFF;            
END
go


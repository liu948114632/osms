CREATE PROC CRM_Customer_DeleteCustomerInfoShare
(
@Id INT
)
AS 
BEGIN
	DELETE dbo.T_CustomerInfoShareHandler WHERE ShareId=@Id

	DELETE dbo.T_CustomerInfoShareTimeQuantum WHERE ShareId=@Id

	DELETE dbo.T_CustomerInfoShare WHERE Id=@Id
END

go


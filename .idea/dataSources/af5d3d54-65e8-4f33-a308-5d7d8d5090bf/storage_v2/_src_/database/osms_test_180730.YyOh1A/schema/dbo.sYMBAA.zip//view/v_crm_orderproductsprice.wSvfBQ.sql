  
/*--------------------------------------------------------    
[备注]    
 获取每个订单的订单商品价值    
-------------------------------------------------------------*/    
CREATE VIEW [dbo].[V_CRM_OrderProductsPrice]  
AS    
SELECT    
 OrderId,     
 SUM(Quantity*ItemPrice*1.0/UnitQuantity) AS OrderPrice,    
 COUNT_BIG(*) AS Counts    
FROM dbo.T_OrderItem b    
WHERE [Status] < 12    
GROUP BY OrderId;
go



/*----------------------------------------------------    
[备注]    
 获取订单发货运费    
按实际称出来的重量来计算运费    
一般是在网站重量写大了，造成多收客户运费钱，    
这种情况按实际称重的一个比值来算运费    
------------------------------------------------------*/    
CREATE PROCEDURE [dbo].[CRM_Price_OrderPostFreightGet]     
(    
 @OrderId VARCHAR(20),   
 @Weight INT,   
 @Freight DECIMAL(18,2) OUT   
)    
AS    
DECLARE     
 @CountryId   INT,    
 @DeliveryId  INT,    
 @IsRemote  BIT,    
 @AddedFreight DECIMAL(18,2) -- 附加费用    
    
BEGIN    
 SET @Freight = 0;    
 SET @CountryId = 0;    
     
 -- 获取该订单的货运方式和偏远地区标志,发货重量    
 SELECT    
  @DeliveryId = DeliveryId,    
  @IsRemote = [IsRemote]   
 FROM dbo.T_Order     
 WHERE OrderId = @OrderId;    
    
 -- 获取该订单所在的国家    
 EXEC [CRM_Customer_CountryIdGetByOrder] @OrderId,@CountryId OUT;    
      
 -- 判断是否海运PortToPort    
 IF @DeliveryId = 22    
 BEGIN    
  EXEC CRM_Price_FreightGetByPortToPort @CountryId,@Freight OUT;    
 END    
 ELSE IF @Weight > 0    
 BEGIN    
  -- 获取运费    
  EXEC CRM_Price_FreightGet @DeliveryId,@CountryId,@Weight,@Freight OUT;    
    
  -- 偏远地区运费    
  IF @IsRemote = 1    
  BEGIN    
   -- 附加费用    
   EXEC CRM_Price_AddedFreightGet @DeliveryId,@Weight,@AddedFreight OUT;    
    
   IF @AddedFreight > 0    
   BEGIN    
    SET @Freight = @Freight + @AddedFreight;    
   END    
  END    
 END        
END
go


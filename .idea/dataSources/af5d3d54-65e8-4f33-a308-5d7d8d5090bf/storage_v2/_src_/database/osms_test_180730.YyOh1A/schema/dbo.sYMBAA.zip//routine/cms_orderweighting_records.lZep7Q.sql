

/*
*获取未称重的订单称重记录
*/
CREATE PROCEDURE [dbo].[CMS_OrderWeighting_Records]
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @OrderRefWeighingRecord TABLE
	(
		weighingRecordId INT, 
		orderId INT
	);
	--计算打包中和已打包 订单对应的称重记录id
	INSERT INTO @OrderRefWeighingRecord 
	SELECT MAX(weighing_record_id) AS weighingRecordId,o.id AS orderId 
	FROM  dbo.order_ref_order_weighing_record a 
	JOIN  dbo.[order] o ON a.order_id = o.id 
	JOIN order_weighing_record b ON a.weighing_record_id = b.id 
	WHERE o.status =50 AND b.complete_status=0  GROUP BY o.id 
	UNION
	SELECT MAX(weighing_record_id) AS weighingRecordId,o.id AS orderId 
	FROM  dbo.order_ref_order_weighing_record a 
	JOIN  dbo.[order] o ON a.order_id = o.id 
	WHERE o.status =55 GROUP BY o.id 
	;WITH  orderweight AS(
		SELECT SUM(website_weight) AS websiteWeight,SUM(actual_weight) AS actualWeight,SUM(volume_weight) AS						volumeWeight,SUM(order_volume_weight) AS orderVolumeWeight,MIN(barcode) AS  barcode,orderId,
				COUNT(*) AS weightedBoxCount
		FROM dbo.order_weighing_record_item c JOIN @OrderRefWeighingRecord b ON c.weighing_record_id = b.					weighingRecordId WHERE barcode IS NOT NULL  GROUP BY b.orderId
	),orderBoxCount AS (SELECT 	COUNT(*) AS boxCount,orderId
		FROM dbo.order_weighing_record_item c JOIN @OrderRefWeighingRecord b ON c.weighing_record_id = b.					weighingRecordId   GROUP BY b.orderId)
	 
	SELECT b.id AS orderId,b.code AS orderCode,b.delivery_id AS deliveryId,
	b.country_id AS countryId,b.send_group_id AS sendGroupId,c.websiteWeight,c.actualWeight,c.volumeWeight,
	c.orderVolumeWeight,c.barcode,c.weightedBoxCount,d.boxCount,b.[source]
	   FROM @OrderRefWeighingRecord a JOIN dbo.[order] b ON a.orderId = b.id 
	   JOIN orderweight c ON c.orderId = a.orderId
	   JOIN orderBoxCount d ON d.orderId =a.orderId
END

go


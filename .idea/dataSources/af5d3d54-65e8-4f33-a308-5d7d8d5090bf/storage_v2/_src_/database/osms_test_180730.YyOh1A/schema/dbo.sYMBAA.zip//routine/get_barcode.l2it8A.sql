/**
获得客户的商品条形码
*/
CREATE FUNCTION [dbo].[Get_BarCode]  
    (  
      @ProductBarId int
    )  
RETURNS VARCHAR(13)  
AS  
    BEGIN  
        DECLARE @ProductBarIdString VARCHAR(5),@ProductBarCode VARCHAR(13) 
        SET @ProductBarIdString = CONVERT(VARCHAR(5),@ProductBarId)
        
        WHILE (LEN(@ProductBarIdString)<5)
        BEGIN
           SET @ProductBarIdString = '0' + @ProductBarIdString
        END 
        
        SET @ProductBarCode = '6902184' + @ProductBarIdString
        
        SELECT @ProductBarCode =dbo.Get_CheckCode(@ProductBarCode)
        
        RETURN @ProductBarCode
    END
go




/************************************************************************
		备注:
			库存规模=库存里所有库存的金额总和,
			统计中心仓库库存数大于的(商品库存数*商品基准成本价)的总和
*************************************************************************/
CREATE PROCEDURE [dbo].[up_Report_Stock_StorageSumPrice]
(
	@SumPrice DECIMAL(18,2) OUT
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

--	SET @SumPrice = 0
--	SET @SumPrice = (
--	select cast(SUM(a.StorageQty * b.BasePrice) as decimal(18,2)) from b_Storage a
--	left join t_item b ON a.ProductId  = b.ItemKeyId 
--	where stockId = 4 AND StorageQty > 0)
	
	
	SELECT @SumPrice = CAST(SUM(a.StorageQty * b.BasePrice) AS DECIMAL(18,2))
	FROM	dbo.C_Storage a JOIN dbo.D_Product b 
		ON a.StockId = 4 
			AND a.ProductDataId = b.ProductDataId
				AND a.StorageQty > 0;
				
	IF @SumPrice IS NULL SET @SumPrice = 0;				
	
END


go


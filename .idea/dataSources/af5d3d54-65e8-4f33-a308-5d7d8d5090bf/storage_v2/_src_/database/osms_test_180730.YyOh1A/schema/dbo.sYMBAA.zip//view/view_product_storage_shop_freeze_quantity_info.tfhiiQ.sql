CREATE VIEW [dbo].[view_product_storage_shop_freeze_quantity_info] AS 

SELECT  product_id ,
        department_id ,
        SUM(ISNULL(l.freeze_quantity, 0))AS freezeQuantity
FROM    dbo.storage_freeze_log AS l WITH ( NOLOCK )
        JOIN dbo.department AS d WITH ( NOLOCK ) ON l.department_id = d.id
WHERE   d.type = 3
        AND l.operator_type = 17
GROUP BY product_id ,
        department_id

go


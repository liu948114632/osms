


CREATE procedure [dbo].[CMS_findUnDoReimburseAppaly_pageList](
	@DepartmentId INT = NULL,
	@Type INT = NULL,
	@Status INT =NULL,
	@ApplayTimeBEGIN VARCHAR(20) = NULL,
	@ApplayTimeEND VARCHAR(20) = NULL,
	@ObjectCode VARCHAR(30) =NULL,
	@ApplayUserId INT = NULL,
	@PageSize INT = 50 ,  --页大小                            
    @PageIndex INT = 1    --当前页号 
)
AS     
    BEGIN                                  
        SET NOCOUNT ON ; 
  DECLARE @SQL VARCHAR(MAX) ,    
            @CountSql NVARCHAR(MAX) , --查询数量用                            
            @FromSQL NVARCHAR(MAX) , --查询表                                                  
            @Column NVARCHAR(MAX) , --查询字段                           
            @Condition VARCHAR(MAX) , --条件                              
            @RowCount INT ,    
            @PageCount INT ,    
            @start INT ,    
            @end INT     
  SET @Condition = ' WHERE 1=1 '  
      IF @DepartmentId IS NOT NULL     
            BEGIN                             
                SET @Condition = @Condition + ' AND a.department_id=' + CONVERT(VARCHAR(10), @DepartmentId)                             
            END 
      IF @Type is not NULL
			BEGIN
				SET @Condition = @Condition + ' and a.type =' +CONVERT(VARCHAR(10),@Type)      
			END
	 IF @Status is not NULL	
			BEGIN 
				SET @Condition = @Condition + ' and a.status = '+ CONVERT(VARCHAR(10),@Status)
			END
	IF @ApplayTimeBEGIN is not NULL
			BEGIN
				 SET @Condition = @Condition + ' AND a.applay_time >=''' + CONVERT(VARCHAR(30), @ApplayTimeBEGIN) + ''''   
			END
	IF @ApplayTimeEND is not NULL
			BEGIN
				SET @Condition = @Condition + ' AND a.applay_time <=''' + CONVERT(VARCHAR(30), @ApplayTimeEND) + ''''  	
			END
	IF @ObjectCode is not NULL
			BEGIN
				   SET @Condition = @Condition + ' AND a.object_code like ''%' + @ObjectCode + '%'''  	
			END
	IF @ApplayUserId is not NULL
			BEGIN
				   SET @Condition = @Condition + ' and a.applay_user_id =' +CONVERT(VARCHAR(10),@ApplayUserId)  
			END

		SET @FromSQL = ' FROM un_do_reimburse_appaly a WITH (NOLOCK) '
	    SET @CountSql = ' SELECT @RowCount = count(a.id) ' + @FromSQL + @Condition      
        
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT         
                                                               
        IF ISNULL(@PageSize, 0) < 1     
            SET @PageSize = 50                                  
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                  
        IF ISNULL(@PageIndex, 0) < 1     
            SET @PageIndex = 1                                  
        ELSE     
            IF ISNULL(@PageIndex, 0) > @PageCount     
                SET @PageIndex = @PageCount                                  
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                  
        SET @end = @PageIndex * @PageSize 	
        
        SET @Column = 'temp2.id,
					   temp2.type,
					   temp2.object_id AS objectId,
					   temp2.applay_time AS	applayTime,
					   temp2.applay_user_id AS applatUserId,
					   temp2.process AS processing,
					   temp2.status ,
					   temp2.audit_time AS auditTime,
					   temp2.audit_advice AS auditAdvice,
					   temp2.cause,
					   temp2.department_id AS departmentId,
					   temp2.object_code AS objectCode,
					   temp2.audit_id AS auditId					
					'
        SET @SQL= '(      
                      SELECT  a.* ,     
                      ROW_NUMBER() OVER(ORDER BY a.status,a.applay_time DESC) rowIndex'      
            + @FromSQL +  @Condition + ') temp2       
		where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and ' + CAST(@end AS NVARCHAR(10))
		SET @SQL = 'SELECT '+@Column+' FROM '+ @SQL   
        prINT @sql;                                                                  
        EXEC(@SQL) ;                 
        SELECT @RowCount                                
    END


go


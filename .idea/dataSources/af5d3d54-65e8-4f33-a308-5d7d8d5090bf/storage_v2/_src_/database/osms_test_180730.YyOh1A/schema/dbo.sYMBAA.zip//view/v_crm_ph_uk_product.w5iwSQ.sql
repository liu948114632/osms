
 
CREATE VIEW [dbo].[V_CRM_PH_UK_Product]  
AS  
    SELECT  a.id AS CmsProductId ,  
            b.id AS WebProductId ,  
            a.code ,  
            a.name ,  
            a.unit_quantity AS UnitQuantity ,  
            a.unit ,  
            a.weight ,  
            a.volume ,  
            a.offline_status AS offlineStatus ,  
            p.LastCostPrice AS BasePrice ,  
            ( CASE WHEN ISNULL(a.category_id_3, 0) = 0  
                   THEN ( CASE WHEN ISNULL(a.category_id_2, 0) = 0  
                               THEN a.category_id_1  
                               ELSE a.category_id_2  
                          END )  
                   ELSE a.category_id_3  
              END ) AS CategoryId ,  
            a.category_id_1 AS CategoryId1 ,  
            a.category_id_2 AS CategoryId2 ,  
            a.category_id_3 AS CategoryId3 ,  
            CAST(a.is_display_uk AS BIT) AS IsDisplay ,  
            a.color_card_picture_code AS ColorCardPictureCode ,  
            a.primary_picture_code AS PrimaryPictureCode ,  
            CAST(ISNULL(b.is_pool, 0) AS BIT) AS IsProductPool ,  
            a.publish_status AS PublishStatus ,  
            CAST(a.is_gift AS BIT) AS IsGift ,  
            CAST(a.is_mix AS BIT) AS IsMix ,  
            c.Description ,  
            CAST(ISNULL(d.is_promote, 0) AS BIT) AS IsPromote ,  
            ( 100 - ISNULL(d.discount, 0) ) AS Discount ,  
            ISNULL(d.[type], 0) AS PromoteType ,  
            CAST(ISNULL(d.is_bind_storage, 0) AS BIT) AS IsBindStorage  
    FROM    dbo.product a WITH ( NOLOCK )  
            INNER JOIN dbo.uk_product b WITH ( NOLOCK ) ON a.id = b.product_id  
			INNER JOIN dbo.V_CRM_ProductLastCostPrice p ON p.CmsProductId=a.id
            LEFT JOIN dbo.product_description c WITH ( NOLOCK ) ON a.id = c.product_id  
          LEFT JOIN dbo.uk_product_promote d WITH ( NOLOCK ) ON a.id = d.product_id AND d.is_promote = 1 AND DATEADD(hh, -8, GETDATE()) >= d.start_time  
            AND DATEADD(hh, -8, GETDATE()) <= d.end_time AND d.promote_type=0  --默认只取大促销
    WHERE   b.is_on_shelf = 1  
            AND a.is_delete = 0  AND b.is_overseas=1

go


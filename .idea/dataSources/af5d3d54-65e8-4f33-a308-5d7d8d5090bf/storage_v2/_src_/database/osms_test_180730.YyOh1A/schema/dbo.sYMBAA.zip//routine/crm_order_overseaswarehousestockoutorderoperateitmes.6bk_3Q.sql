
CREATE PROC CRM_Order_OverseasWarehouseStockOutOrderOperateItmes
(
@OrderId VARCHAR(20),
@OrderItemId INT ,
@Qty INT,--订购量
@OperateType INT, --操作类型，1添加，2修改，3删除
@WarehouseId int 
)
AS
 BEGIN

IF NOT EXISTS (SELECT TOP 1 1 FROM dbo.T_Order WHERE OrderId=@OrderId AND OrderStatus>0)
RETURN;

DECLARE @StockOutCode VARCHAR(50)
SELECT @StockOutCode=StockOutCode FROM dbo.T_OverseasWarehouseStockOutOrder WHERE OrderId=@OrderId;
 
IF(@OperateType=1) 
BEGIN
 		   INSERT into dbo.T_OverseasWarehouseStockOutOrderItem    
			 ( OrderItemId ,    
			   StockOutCode ,    
			   StockOutQty,
			   StorageNo    
			 )    
		   SELECT @OrderItemId,@StockOutCode,@Qty,c.CK1StorageNo
		   FROM dbo.T_OrderItem a     
		
   JOIN dbo.T_OverseasWarehouseProduct c ON a.CmsProductId=c.CMSProductId AND a.OrderItemId=@OrderItemId AND WarehouseId = @WarehouseId AND c.IsDelete=0 
 END
IF ( @OperateType = 2 )
    BEGIN
        UPDATE  dbo.T_OverseasWarehouseStockOutOrderItem
        SET     StockOutQty = @Qty
        WHERE   StockOutCode = @StockOutCode
                AND OrderItemId = @OrderItemId 
    END
IF ( @OperateType = 3 )
    BEGIN
        DELETE  dbo.T_OverseasWarehouseStockOutOrderItem
        WHERE   StockOutCode = @StockOutCode
                AND OrderItemId = @OrderItemId 
    END
END

go





/*----------------------------------------------------  
[备注]:获取不走海外仓的订单商品的价值  
------------------------------------------------------*/  
CREATE PROC [dbo].[CRM_Price_GOCMSProductPriceGet]   
(  
 @OrderId   VARCHAR(MAX), -- 订单编号  
 @Price   DECIMAL(18,2) OUT, -- 商品价值  
 @ReadyPrice  DECIMAL(18,2) OUT -- 备货商品价值  
)  
AS  
BEGIN  
	-- 样本卡费用  
	DECLARE @StylebookPrice DECIMAL(9,2);  
	EXEC CRM_Price_StylebookPriceGet @OrderId,0,@StylebookPrice OUT;  

	-- 样本卡到货费用  
	DECLARE @StylebookReadyPrice DECIMAL(9,2);  
	EXEC CRM_Price_StylebookPriceGet @OrderId,1,@StylebookReadyPrice OUT;  
	
	-- 用来缓存所有订单      
	DECLARE @Orders TABLE(OrderId VARCHAR(20));
	      
	INSERT INTO @Orders(OrderId)      
	SELECT [Value]       
	FROM dbo.uf_Split(@OrderId,',');
  
	SELECT   
		@Price = SUM(Quantity*1.0*ItemPrice/UnitQuantity),  
		@ReadyPrice = SUM(ReadyQty*1.0*ItemPrice/UnitQuantity)  
	FROM @Orders 
	JOIN dbo.T_OrderItem ON [@Orders].OrderId = dbo.T_OrderItem.OrderId
	WHERE Status < 12 AND IsGoOverseasWarehouse = 0;-- 排除取消商品  

	IF @Price IS NULL SET @Price = 0;  
	IF @ReadyPrice IS NULL SET @ReadyPrice = 0;  

	-- 减去免费的样本卡钱  
	IF @StylebookPrice > 0 AND @Price >= @StylebookPrice  
	BEGIN  
		SET @Price = @Price - @StylebookPrice;  
	END   
	IF @StylebookReadyPrice > 0 AND @ReadyPrice >= @StylebookReadyPrice  
	BEGIN  
		SET @ReadyPrice = @ReadyPrice - @StylebookReadyPrice;  
	END 
	
	SET @Price = ISNULL(@Price,0)  
	SET @ReadyPrice = ISNULL(@ReadyPrice,0)
END
go


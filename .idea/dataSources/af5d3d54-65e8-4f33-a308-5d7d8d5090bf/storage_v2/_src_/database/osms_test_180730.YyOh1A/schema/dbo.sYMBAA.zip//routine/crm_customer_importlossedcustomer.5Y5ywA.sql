 
---导入流失客户信息
CREATE PROC CRM_Customer_ImportLossedCustomer
(
@CustomerId INT,
@EmailId INT ,
@RedeemStatus INT ,
@RedeemLevel INT,
@OperatorId INT 
)
AS 
BEGIN
IF  EXISTS (SELECT TOP 1  1 FROM dbo.T_LossedCustomer WHERE CustomerId=@CustomerId)
BEGIN
DECLARE @Message VARCHAR(50);
 SET @Message='<info>'+CAST(@EmailId AS VARCHAR(10))+'为已经导入的流失客户！</info>';
	   RAISERROR (@Message, 16, 1) WITH NOWAIT;      
   RETURN;  
END

INSERT INTO dbo.T_LossedCustomer
        ( CustomerId ,
          RedeemStatus ,
          RedeemLevel ,
          ContactSituation ,
          FirstRespondWay ,
          HasValidInfo ,
          ContactNum ,
          SendFirstEmailTime ,
          LastContactTime ,
          ImportTime
        )
VALUES  (@CustomerId , -- CustomerId - int
          @RedeemStatus , -- RedeemStatus - int
          @RedeemLevel , -- RedeemLevel - int
          0, -- ContactSituation - int
          NULL, -- FirstRespondWay - int
          0, -- HasValidInfo - int
          0, -- ContactNum - int
          NULL , -- SendFirstEmailTime - smalldatetime
          NULL , -- LastContactTime - smalldatetime
          GETDATE()  -- ImportTime - smalldatetime
        )
        
        DECLARE @phone VARCHAR(50)
        
        SELECT @phone=b.Phone FROM dbo.T_CustomerAddresses a INNER JOIN 
        dbo.T_Addresses b ON a.AddressID=b.AddressID AND a.UserID=@CustomerId AND a.Type IN (1,3)
        
        INSERT INTO dbo.T_LossedCustomerRedeemDtl
                ( CustomerId ,
                  Phone ,
                  Lang ,
                  JoinVipTime ,
                  IsSatisfaction ,
                  IsHasOtherSupplier ,
                  IsFreightHigh ,
                  IsManageVeer ,
                  IsFreightCycleLong ,
                  IsNowNoOrderPlan ,
                  IsCoupon ,
                  IsStockUpCycleLong ,
                  IsNowHasOrderPlan ,
                  IsLevelChange ,
                  IsRecommendPW ,
                  IsHasComplainHistory ,
                  SupplierInfo ,
                  CustomerOtherFacebook ,
                  RedeemWayDesc
                )
        VALUES  (@CustomerId, -- CustomerId - int
                  @phone , -- Phone - nvarchar(50)
                  NULL , -- Lang - int
                  NULL , -- JoinVipTime - smalldatetime
                  NULL , -- IsSatisfaction - bit
                  NULL , -- IsHasOtherSupplier - bit
                  NULL , -- IsFreightHigh - bit
                  NULL , -- IsManageVeer - bit
                  NULL , -- IsFreightCycleLong - bit
                  NULL , -- IsNowNoOrderPlan - bit
                  NULL , -- IsCoupon - bit
                  NULL , -- IsStockUpCycleLong - bit
                  NULL , -- IsNowHasOrderPlan - bit
                  NULL , -- IsLevelChange - bit
                  NULL , -- IsRecommendPW - bit
                  NULL , -- IsHasComplainHistory - bit
                  N'' , -- SupplierInfo - nvarchar(200)
                  N'' , -- CustomerOtherFacebook - nvarchar(200)
                  N''  -- RedeemWayDesc - nvarchar(500)
                )
               
            INSERT INTO dbo.T_LossedCustomerOperateLog
                    ( CustomerId ,
                      CreateTime ,
                      Content ,
                      CreatorId
                    )
            VALUES  (@CustomerId , -- CustomerId - int
                      GETDATE() , -- CreateTime - smalldatetime
                      N'导入流失客户' , -- Content - nvarchar(500)
                      @OperatorId -- Creator - int
                    ) 
END

go


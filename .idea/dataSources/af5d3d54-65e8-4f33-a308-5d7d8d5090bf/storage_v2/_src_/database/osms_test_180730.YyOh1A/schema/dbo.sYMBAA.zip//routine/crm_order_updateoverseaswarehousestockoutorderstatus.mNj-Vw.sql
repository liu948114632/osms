
/**
更新出口易出库单状态
*/
CREATE PROC CRM_Order_UpdateOverseasWarehouseStockOutOrderStatus
(
  @StockOutCode VARCHAR(30),
  @StockOutStauts INT --最新出库单状态
)
AS
begin
      UPDATE dbo.T_OverseasWarehouseStockOutOrder
      SET Status = @StockOutStauts
      WHERE  StockOutCode=@StockOutCode
      
      INSERT INTO dbo.T_OverseasWarehouseStockOutOrderLog
              ( StockOutCode, Remark, OperateTime )
      VALUES  ( @StockOutCode, -- StockOutCode - varchar(30)
                '出库单状态变为' + CONVERT(VARCHAR(5),@StockOutStauts), -- Remark - varchar(100)
                GETDATE()  -- OperateTime - datetime
                )
END
go


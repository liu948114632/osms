
    
    
/*-----------------------------------------    
备注:获取实际订单商品列表    
创建人: FRH    
创建日期:2009-12-30    
-------------------------------------------------*/    
    
/*-----------------------------------------    
创建人: HJJ    
创建日期:2010-06-07    
备注:批量数及总价保留四位小数    
-------------------------------------------------*/    
    
CREATE PROC [dbo].[DDS_Order_OrderItemListGet]    
(    
 @Type    INT,    
 @OrderId   VARCHAR(255)    
)    
AS    
DECLARE    
 @Remark    VARCHAR(50);    
BEGIN    
    
 -- 创建表变量,用来缓存各个结算的订单    
 DECLARE @Orders  TABLE(OrderId VARCHAR(20));    
    
 -- 记录订单    
 INSERT INTO @Orders(OrderId)    
 SELECT [Value]     
 FROM dbo.uf_Split(@OrderId,',');    
    
 IF @Type = 1 -- 取全部商品    
 BEGIN    
  SELECT    
   a.OrderId,    
   c.Code,    
   c.[Name] AS ProductName,     
   CAST(b.Quantity*1.0/b.UnitQuantity AS DECIMAL(18,4)) AS Quantity, -- 取批量数    
   LTRIM(b.UnitQuantity) + ' ' + b.Unit AS Unit,    
   b.ItemPrice,    
   b.CustomerRemark AS Remark,    
   CAST(b.ItemPrice*b.Quantity*1.0/b.UnitQuantity AS DECIMAL(18,4)) AS Price    
  FROM    
   @Orders a     
    INNER JOIN dbo.T_OrderItem b     
     ON a.OrderId = b.OrderId AND b.[Status] < 12    
    INNER JOIN dbo.V_CRM_Base_Product c     
     ON b.CmsProductId = c.CmsProductId    
  ORDER BY     
   a.OrderId,c.[Name];    
 END    
     
    
END

go


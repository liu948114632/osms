

CREATE FUNCTION [dbo].[uf_GetSumPurchasePrice]
(
	@StockId	INT = 0,			-- 仓库
	@CreatorId	INT = 0,			-- 采购员
	@CheckTime	VARCHAR(7) = '',	-- 报销时间
	@CheckType	INT = 0 			-- 类型 1按月 2按季度
)
RETURNS DECIMAL(18, 6)
AS
BEGIN
	DECLARE @SUMPurchasePriceTotal DECIMAL(18, 6)	
		
	-- 按年查询
	IF LEN(@CheckTime) = 5
	BEGIN		
		DECLARE @CheckYear INT;
		SET @CheckYear = CAST(LEFT('2010-', 4) AS INT) - 1;

		IF @StockId > 0
		BEGIN
			SELECT 
				@SUMPurchasePriceTotal = SUM(b.TotalPrice * b.DueQty)
			FROM dbo.C_Purchase a 
				JOIN dbo.C_PurchaseItem b 
			ON a.PurchaseId = b.PurchaseId	
				AND a.[Status] = 8 -- 已报销的采购单
				AND b.[Status] = 2 -- 采购完成
				AND a.StockId = @StockId
				AND a.CreatorId = @CreatorId
				AND YEAR(a.FinishTime) = @CheckYear;
		END
		ELSE
		BEGIN
			SELECT 
				@SUMPurchasePriceTotal = SUM(b.TotalPrice * b.DueQty)
			FROM dbo.C_Purchase a 
				JOIN dbo.C_PurchaseItem b 
			ON a.PurchaseId = b.PurchaseId	
				AND a.[Status] = 8 -- 已报销的采购单
				AND b.[Status] = 2 -- 采购完成
				AND a.CreatorId = @CreatorId
				AND YEAR(a.FinishTime) = @CheckYear;
		END
	END
	ELSE	
	BEGIN
		-- 按月查询
		IF @CheckType = 1
		BEGIN
			SET @CheckTime = CONVERT(VARCHAR(7),DATEADD(MM,-1,CONVERT(DATETIME,@CheckTime + '-01')),25);

			IF @StockId > 0
			BEGIN
				SELECT 
					@SUMPurchasePriceTotal = SUM(b.TotalPrice * b.DueQty)
				FROM dbo.C_Purchase a 
					JOIN dbo.C_PurchaseItem b 
				ON a.PurchaseId = b.PurchaseId	
					AND a.[Status] = 8 -- 已报销的采购单
					AND b.[Status] = 2 -- 采购完成
					AND a.StockId = @StockId
					AND a.CreatorId = @CreatorId
					AND CONVERT(VARCHAR(7), a.FinishTime, 25) = @CheckTime;
			END
			ELSE
			BEGIN
				SELECT 
					@SUMPurchasePriceTotal = SUM(b.TotalPrice * b.DueQty)
				FROM dbo.C_Purchase a 
					JOIN dbo.C_PurchaseItem b 
				ON a.PurchaseId = b.PurchaseId	
					AND a.[Status] = 8 -- 已报销的采购单
					AND b.[Status] = 2 -- 采购完成
					AND a.CreatorId = @CreatorId
					AND CONVERT(VARCHAR(7), a.FinishTime, 25) = @CheckTime;
			END
		END
		-- 按季度查询
		ELSE IF @CheckType = 2
		BEGIN
			DECLARE 
				@CheckTimeStart SMALLDATETIME,
				@CheckTimeEnd	SMALLDATETIME

			SET @CheckTimeStart = DATEADD(MM,-3,CONVERT(SMALLDATETIME, @CheckTime + '-01'));
			SET @CheckTimeEnd = CONVERT(SMALLDATETIME, @CheckTime + '-01');

			IF @StockId > 0
			BEGIN
				SELECT 
					@SUMPurchasePriceTotal = SUM(b.TotalPrice * b.DueQty)
				FROM dbo.C_Purchase a 
					JOIN dbo.C_PurchaseItem b 
				ON a.PurchaseId = b.PurchaseId	
					AND a.[Status] = 8 -- 已报销的采购单
					AND b.[Status] = 2 -- 采购完成
					AND a.StockId = @StockId
					AND a.CreatorId = @CreatorId
					AND a.FinishTime >= @CheckTimeStart AND a.FinishTime < @CheckTimeEnd;
			END
			ELSE
			BEGIN
				SELECT 
					@SUMPurchasePriceTotal = SUM(b.TotalPrice * b.DueQty)
				FROM dbo.C_Purchase a 
					JOIN dbo.C_PurchaseItem b 
				ON a.PurchaseId = b.PurchaseId	
					AND a.[Status] = 8 -- 已报销的采购单
					AND b.[Status] = 2 -- 采购完成
					AND a.CreatorId = @CreatorId
					AND a.FinishTime >= @CheckTimeStart AND a.FinishTime < @CheckTimeEnd;
			END
		END	
	END

	RETURN @SUMPurchasePriceTotal;
END


go


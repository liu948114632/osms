CREATE PROC dbo.CMS_storage_exception_order         
    (          
      @receiveDepartmentId INT =NULL,
	  @warehouseAreaId INT=NULL,
	  @type INT=NULL,
	  @code VARCHAR(100)=NULL,
	  @codes VARCHAR(max) =NULL,
	  @orderCode VARCHAR(100)=NULL,
	  @orderCodes VARCHAR(max)=NULL,
	  @dealUserId INT=NULL,
	  @status INT=NULL,
	  @exceptionTimeBegin DATETIME=NULL,
	  @exceptionTimeEnd DATETIME=NULL,  
	  @exceptionReason INT=NULL,        
      @PageSize INT = 50 ,  --页大小                      
      @PageIndex INT = 1    --当前页号                      
    )          
AS           
    BEGIN                            
        SET NOCOUNT ON ;                                    
        DECLARE @SQL VARCHAR(MAX) ,          
            @CountSql NVARCHAR(MAX) , --查询数量用                      
            @FromSQL NVARCHAR(MAX) , --查询表                    
            @Condition VARCHAR(MAX) , --条件           
            @PriceCondition VARCHAR(MAX) ,--外查询条件          
            @RowCount INT ,          
            @PageCount INT ,          
            @start INT ,          
            @end INT ,          
            @Column VARCHAR(MAX)                     
                              
        SET @FromSQL = '      FROM  dbo.exception_storage_order ex WITH(NOLOCK)
					INNER JOIN dbo.storage_order so WITH(NOLOCK) ON ex.storage_order_id=so.id and so.is_deleted=0
					LEFT JOIN dbo.[order] o WITH(NOLOCK) ON o.id=so.order_id '                       
                          
        SET @Condition = ' WHERE 1=1 '            
                     
                      
	IF @warehouseAreaId IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND so.warehouse_area_id = ' + CONVERT(VARCHAR(20),@warehouseAreaId)
	END



	IF @dealUserId IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND ex.deal_user_id = ' + CONVERT(VARCHAR(20),@dealUserId)
	END

	IF @status IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND ex.status = ' + CONVERT(VARCHAR(20),@status)
	END
	ELSE
    BEGIN
       SET @Condition =  @Condition + ' AND ex.status >0 ' --0是未激活状态，界面不显示
	END 

	IF @exceptionReason IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND ex.exception_reason = ' + CONVERT(VARCHAR(20),@exceptionReason)
	END

	IF @receiveDepartmentId IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND ex.new_receive_department_id = ' + CONVERT(VARCHAR(20),@receiveDepartmentId)
	END
	--直发区子单任务=1, 合单区子单任务=2, 暂存区子单任务=3, 需加工子单任务=4
	IF @type IS NOT NULL
	BEGIN
		IF @type=1
		BEGIN
		    SET @Condition =  @Condition + ' AND ex.old_receive_department_id = 35 '
		END
		IF @type=2
		BEGIN
		     SET @Condition =  @Condition + ' AND ex.old_receive_department_id =36 '
		END
		IF @type=3
		BEGIN
		     SET @Condition =  @Condition + ' AND ex.old_receive_department_id  in (37,9) '
		END
		IF @type=4
		BEGIN
		     SET @Condition =  @Condition + ' AND ex.old_receive_department_id =9 '
		END
	END
      
	IF @code IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND so.code  LIKE ''%' + @code + '%'''  
	END 

	IF @codes IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND so.code IN (''' + REPLACE(@codes,',',''',''') + ''')'    
	END

	IF @orderCode IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND o.code  LIKE ''%' + @orderCode + '%'''  
	END 

	IF @orderCodes IS NOT NULL
	BEGIN
		SET @Condition =  @Condition + ' AND o.code IN (''' + REPLACE(@orderCodes,',',''',''') + ''')'    
	END

	IF @exceptionTimeBegin IS NOT NULL
		BEGIN
			SET @Condition =  @Condition +' AND so.exception_time >=''' + CONVERT(VARCHAR(20),@exceptionTimeBegin) + ''''
		END	
	IF @exceptionTimeEnd IS NOT NULL
		BEGIN
			SET @Condition =  @Condition +' AND so.exception_time <=''' + CONVERT(VARCHAR(20),@exceptionTimeEnd) + ''''
		END	

	SET @CountSql = ' SELECT @RowCount = count(ex.id) ' + @FromSQL + @Condition            
    EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                           
                          
        --SELECT  @CountSql           
                           
        IF ISNULL(@PageSize, 0) < 1           
           SET @PageSize = 50                            
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                            
        IF ISNULL(@PageIndex, 0) < 1           
            SET @PageIndex = 1                            
  ELSE           
            IF ISNULL(@PageIndex, 0) > @PageCount           
                SET @PageIndex = @PageCount                            
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                            
        SET @end = @PageIndex * @PageSize                     


    --设置需要取的字段信息            
    SET @Column = '
		   ex.id ,
		   ex.storage_order_id AS storageOrderId,
		   ex.new_receive_department_id AS newReceiveDepartmentId,
		   ex.old_receive_box_postion_id AS newReceiveBoxPostionId,
		   ex.old_receive_box_postion_name AS newReceiveBoxPostionName,
		   ex.exception_time AS exceptionTime,
		   ex.deal_user_id AS dealUserId,
		   ex.deal_time AS dealTime,
		   ex.exception_reason AS exceptionReason,
		   ex.status,
		   so.code ,
		   o.code AS orderCode,
		   so.warehouse_area_id as warehouseAreaId
	 '                                           
                          
	    --组装基本查询的SQL                     
		 SET @SQL = 'SELECT * from                      
		          (                      
		          SELECT *,ROW_NUMBER() OVER(ORDER BY status asc, exceptionTime DESC ) rowIndex                      
		          from (SELECT ' +@Column + @FromSQL + @Condition
		               + ') temp                      
		          ) temp2                           
		          where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
		               + CAST(@end AS NVARCHAR(10))                     
        EXEC(@SQL) ;                                
         PRINT @SQL                 
        SELECT  @RowCount                          
    END

go


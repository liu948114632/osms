

/*------------------------------------------                  
备注:获取订单的子箱数(包含同票订单)          
创建人: LXH                  
创建日期:2012-12-29                  
------------------------------------------------------*/                  
CREATE PROC [dbo].[CRM_Order_GetBoxCount]                  
(                  
  @OrderId VARCHAR(20)      
)                  
AS                   
BEGIN  
 DECLARE @Str VARCHAR(MAX)
 DECLARE @SendGroupId INT  
 
 SELECT @SendGroupId = SendGroupID FROM T_Order WITH(NOLOCK) WHERE OrderID = @OrderId;  
 SET @SendGroupId = ISNULL(@SendGroupId,0)
 
 IF @SendGroupId > 0
 BEGIN
	SELECT @Str = STUFF((SELECT ',' + x.Box
	FROM (SELECT b.Box FROM dbo.T_Order a WITH(NOLOCK)   
	JOIN dbo.T_OrderItem b WITH(NOLOCK) ON b.OrderId = a.OrderId 
	WHERE a.SendGroupID = @SendGroupId AND b.Status != 12) x
	FOR XML PATH('')),1,1,'')
 END 
 ELSE 
 BEGIN
	SELECT @Str = STUFF((SELECT ',' + x.Box
	FROM (SELECT b.Box FROM dbo.T_OrderItem b WITH(NOLOCK) 
	WHERE b.OrderId = @OrderId AND b.Status != 12) x
	FOR XML PATH('')),1,1,'')
 END 
 
 SELECT COUNT(DISTINCT Value) FROM dbo.uf_Split(@Str,',')
END
go


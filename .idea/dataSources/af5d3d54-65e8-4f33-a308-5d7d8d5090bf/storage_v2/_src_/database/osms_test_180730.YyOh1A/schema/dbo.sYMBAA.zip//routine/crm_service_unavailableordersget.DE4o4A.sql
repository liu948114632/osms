

-- =============================================            
-- Author:  <Author,,刘杨>            
-- Create date: <Create Date,,2010-09-24>            
-- Description: <Description,,获取待取消订单，需求完成数大于等于85%，备货中的订单>            
            
-- Author:  <Author,,HYD>            
-- Create date: <Create Date,,2010-06-14>            
-- Description: <Description,,获取订单预计到货时间X+11 ，待取消订单列表。用于取消未到货商品>            
-- =============================================            
CREATE PROC dbo.CRM_Service_UnavailableOrdersGet            
AS             
BEGIN            
-- SET NOCOUNT ON added to prevent extra result sets from            
-- interfering with SELECT statements.            
    SET NOCOUNT ON ;            
            
 SELECT OrderId FROM T_Order a WITH(NOLOCK)
 INNER JOIN dbo.T_BusinessType b WITH(NOLOCK) ON a.OrderIndustryType=b.BusinessTypeValue
 WHERE OrderStatus = 1            
                        AND (OrderIndustryType = 1  OR b.IsPHClone=1)-- 只处理PH的订单            
                        AND OrderType IN ( 1, 2 )            
                        AND IsAutoDelay = 1            
      AND DATEDIFF(DAY,dbo.fn_CalcAutoDelayDateForPost(AutoDelayDate,DisposeDate),GETDATE()) IN (11,12)            
      AND DelayStatus IN (3,5)            
END
go


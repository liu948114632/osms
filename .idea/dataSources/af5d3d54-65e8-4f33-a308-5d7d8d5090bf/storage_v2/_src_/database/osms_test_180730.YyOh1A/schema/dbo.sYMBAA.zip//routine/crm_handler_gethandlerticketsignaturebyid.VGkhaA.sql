CREATE PROC CRM_Handler_GetHandlerTicketSignatureById
(
@HandlerId INT,
@BusinessType INT
)
AS 
BEGIN

IF(@BusinessType=5 OR @BusinessType=6)
SET @BusinessType=1

	SELECT a.TicketSignature FROM dbo.T_Handler a WITH(NOLOCK)
	WHERE a.HandlerId=@HandlerId AND (a.BusinessType=@BusinessType OR @BusinessType=0 AND a.TicketSignature>'');
END
go



CREATE PROC dbo.CRM_Customer_EditCustomerInfoShare
(
@Id INT,
@ShareBusinessType INT,
@ShareByHandlerId INT,
@ShareToHandler VARCHAR(500)='',
@ShareTimeQuantum VARCHAR(100),
@ShareWay INT,
@CreateUserId INT,
@shareId INT OUT
)
AS 
BEGIN
SET @shareId=@Id;
IF @Id=0
BEGIN	
	IF EXISTS (SELECT TOP 1 1 FROM dbo.T_CustomerInfoShare WHERE ShareByHandlerId=@ShareByHandlerId AND @ShareBusinessType=ShareBusinessType)
	BEGIN
						RAISERROR ('<info>当前客服的共享数据已存在，请勿重复共享！</info>' , 16, 1) WITH NOWAIT;      
	END
INSERT INTO dbo.T_CustomerInfoShare
        ( ShareByHandlerId ,
       ShareToHandler ,
          ShareTimeQuantum ,
          ShareWay ,
          CreateUserId ,
          CreateDate ,
          ShareBusinessType
        )
VALUES  (@ShareByHandlerId , -- ShareByHandlerId - int
        0, -- ShareToHandler - varchar(500)
          @ShareTimeQuantum , -- ShareTimeQuantum - varchar(100)
          @ShareWay, -- ShareWay - int
          @CreateUserId , -- CreateUserId - int
          GETDATE() , -- CreateDate - datetime
          @ShareBusinessType  -- ShareBusinessType - int
        )
		SET @shareId=@@IDENTITY;
		END
		ELSE
		BEGIN
			UPDATE dbo.T_CustomerInfoShare
			SET ShareByHandlerId=@ShareByHandlerId,
			--ShareToHandler=@ShareToHandler,
			ShareTimeQuantum=@ShareTimeQuantum,
			ShareWay=@ShareWay,
			ShareBusinessType=@ShareBusinessType
			WHERE Id=@Id
		END
END


go





/**************************************************************
		备注：采购员月采购金额及占办事处总采购金额的比率
采购员月采购金额比例＝某采购员月采购金额 / 本办事处本月采购总金额
采购员月采购金额＝某采购员月采购的总金额。
[dbo].[up_Report_Stock_PurchaseTotalPriceRate] '2009-11-01','2010-03-18','YW'
**************************************************************/
CREATE PROCEDURE [dbo].[up_Report_Stock_PurchaseTotalPriceRate] 
	@StartTime			Datetime, 
	@EndTime			Datetime,
	@Stock				VARCHAR(10)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @StockId	INT;
	DECLARE @UserPurchseTotal Table (UserId INT,TotalPrice DECIMAL(18,2));
	DECLARE @StockTotal  DECIMAL(18,2);

	SET @StockTotal = 0;
	SET @StockId = 0;

	-- 获取仓库Id
	SELECT @StockId = Id  FROM dbo.C_Stock WHERE Short = @Stock;

	
	IF @StockId > 0
	BEGIN
		/*
		INSERT INTO @UserPurchseTotal 
		SELECT b.UserId, SUM(a.TotalPrice * a.DueQty) FROM b_PurchaseItem a
		LEFT JOIN b_Purchase b ON a.PurchaseId = b.Id
		WHERE b.Status = 8 AND b.CompleteDate >= @StartTime AND b.CompleteDate <= @EndTime AND StockId = @StockId
				AND a.PurchaseStatus = 1
		GROUP BY b.UserId
		
		SET @StockTotal = (SELECT SUM(TotalPrice) FROM @UserPurchseTotal)

		SELECT c.FirstName AS UserName, a.TotalPrice, @StockTotal AS StockTotalPrice,
			LTRIM(CAST((a.TotalPrice/@StockTotal) * 100 AS DECIMAL(18,2))) + '%' as Rate 
		FROM @UserPurchseTotal a
		LEFT JOIN b_User c ON a.UserId = c.Id
		ORDER by c.FirstName
		*/
		
		INSERT INTO @UserPurchseTotal(UserId,TotalPrice)
		SELECT 
			b.CreatorId,
			CAST(SUM(a.TotalPrice*a.DueQty) AS DECIMAL(18,2)) AS Price
		FROM dbo.C_PurchaseItem a 
		JOIN dbo.C_Purchase b 
		ON a.PurchaseId = b.PurchaseId
		AND b.[Status] = 8 -- 采购单已报销的
		AND b.StockId = @StockId -- 指定办事处
		AND b.FinishTime > @StartTime AND b.FinishTime < @EndTime
		AND a.[Status] = 2 -- 商品采购完的
		GROUP BY b.CreatorId;
		
		-- 总报销金额
		SELECT @StockTotal = SUM(TotalPrice) FROM @UserPurchseTotal;

		SELECT c.FirstName AS UserName, a.TotalPrice, @StockTotal AS StockTotalPrice,
			LTRIM(CAST((a.TotalPrice/@StockTotal) * 100 AS DECIMAL(18,2))) + '%' AS Rate 
		FROM @UserPurchseTotal a
			JOIN dbo.B_User c ON a.UserId = c.Id
		ORDER by c.FirstName;
		
	END
	ELSE
	BEGIN
		SELECT '' AS UserName,0 AS TotalPrice,0 AS StockTotalPrice,'' AS Rate;
	END
		
	
END


go


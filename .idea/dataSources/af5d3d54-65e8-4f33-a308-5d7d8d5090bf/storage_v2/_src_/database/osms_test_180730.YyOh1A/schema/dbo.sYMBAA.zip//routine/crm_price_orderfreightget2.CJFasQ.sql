
    
CREATE PROC [dbo].[CRM_Price_OrderFreightGet2]           
(          
 @OrderId  VARCHAR(MAX), -- 订单编号多个用,号相隔    
 @Freight  DECIMAL(18,2) OUT, -- 商品运费          
 @ReadyFreight  DECIMAL(18,2) OUT -- 备货商品运费          
)          
AS     
BEGIN        
 SET NOCOUNT ON;     
 DECLARE @Weight INT, @WeightType INT, @ReadyWeight INT, @ReadyWeightType INT,     
   @CountryId INT, @DeliveryId INT, @IsRemote BIT,  @IsFreeShipping BIT,     
   @TempFreight DECIMAL(18,2), @TempReadyFreight DECIMAL(18,2), @TempWeight INT, @TempReadyWeight INT    
     
 -- 用来缓存所有订单          
 DECLARE @Orders TABLE(OrderId VARCHAR(20));    
           
 INSERT INTO @Orders(OrderId)          
 SELECT [Value]           
 FROM dbo.uf_Split(@OrderId,',');    
     
 -- 获取第一个订单号    
 DECLARE @FirstOrderId VARCHAR(20);    
 SELECT TOP 1 @FirstOrderId = OrderId  
 FROM @Orders;      
   
  
  --  获得重量    
  EXEC CRM_Weight_OrderWeightOrPostWeightGet @OrderId, @Weight OUT, @WeightType OUT, @ReadyWeight OUT, @ReadyWeightType OUT;    
      
  -- 获得CountryId, DeliveryId, IsRemote    
  SELECT @CountryId = Country, @DeliveryId = DeliveryId, @IsRemote = IsRemote     
  FROM dbo.T_Order JOIN dbo.T_OrderAddresses ON dbo.T_Order.ShipAddressId = dbo.T_OrderAddresses.AddressId     
  WHERE OrderId = @FirstOrderId;    
      
  -- 获取运费    
  EXEC CRM_Freight_FreightGet @CountryId, @DeliveryId, @IsRemote, @Weight, @Freight OUT;    
  -- 如果按发货重量计算运费    
  IF @WeightType = 2     
  BEGIN    
   -- 获得订单重量    
   EXEC CRM_Price_OrderValidWeightGet @OrderId, @TempWeight OUT, @TempReadyWeight OUT;     
   -- 获得订单运费    
   EXEC CRM_Freight_FreightGet @CountryId, @DeliveryId, @IsRemote, @TempWeight, @TempFreight OUT;    
   -- 发货运费 > 订单运费    
   IF @Freight > @TempFreight    
   BEGIN    
    SET @Freight = @TempFreight;    
   END     
  END     
      
  -- 获得到货运费    
  EXEC CRM_Freight_FreightGet @CountryId, @DeliveryId, @IsRemote, @ReadyWeight, @ReadyFreight OUT;    
  -- 如果按发货重量计算运费    
  IF @ReadyWeightType = 2    
  BEGIN    
   -- 获得订单到货重量    
   EXEC CRM_Price_OrderValidWeightGet @OrderId, @TempWeight OUT, @TempReadyWeight OUT;     
   -- 获得订单到货运费    
   EXEC CRM_Freight_FreightGet @CountryId, @DeliveryId, @IsRemote, @TempReadyWeight, @TempReadyFreight OUT;    
   -- 发货运费 > 订单到货运费    
   IF @ReadyFreight > @TempReadyFreight    
   BEGIN    
    SET @ReadyFreight = @TempReadyFreight;    
   END     
  END     
     
 SET @Freight = ISNULL(@Freight,0)    
 SET @ReadyFreight = ISNULL(@ReadyFreight,0)    
END
go


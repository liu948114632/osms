

/*-----------------------------------------------      
备注：保存订单信息      
创建人: FRH      
创建日期:2010-01-14      
  
修改人：HYD      
修改时间：2010-05-10      
修改内容：修改可发货标识时候增加判断      
--------------------------------------------------      
修改人：LY      
修改时间：2010-11-18      
修改内容：在订单详细里面修改、保存巴西税号      
--------------------------------------------------      
修改人：LY      
修改时间：2010-12-03      
修改内容：在订单详细里面修改、保存需加工标识      
--------------------------------------------------      
修改人：LY      
修改时间：2011-03-28      
修改内容：在订单详细里面修改、保存发票金额是否包含运费和百分比      
--------------------------------------------------*/      
CREATE PROC dbo.CRM_Order_OrderUpdate      
    (      
      @OrderId NVARCHAR(20) ,      
      @PayStatus INT ,      
      @Priority INT ,      
      @IsInvoice BIT , -- 是否已做发票      
      @IsSend BIT ,      
      @HandlerId INT ,      
      @Remark NVARCHAR(2000) ,      
      @PrintRemark NVARCHAR(2000) ,      
      @PendingRemark NVARCHAR(2000) ,      
      @IsActuallInvoice BIT ,      
      @IsRemote BIT ,      
      @CPFCode NVARCHAR(200) ,      
      @TaxCodeType INT ,  
      @IsNeedProcessing BIT ,      
      @IsQualityInspection BIT ,   
      @IsIncludeShippingFee BIT ,      
      @SubTotalPercent DECIMAL(9, 2)     ,
      @CustomsClearanceProportion DECIMAL(18, 4) ,
      @IsAutoBalance BIT,
     @DmsInvoiceRemark NVARCHAR(500) ,
	 @ServiceRemark NVARCHAR(500),
	 @InvoiceValue DECIMAL(12,2),
	 @FrightInvoiceValue DECIMAL(12,2),
	 @IsFixSubTotalPercent BIT,
     @IsFixCustomsChargePercent BIT,
	 @IsModifSendMark BIT=0,
	 @PackingRequirement NVARCHAR(2000)='',
	 @CustomsCurrencyId INT=1
    )      
AS       
    BEGIN      
  
        SET NOCOUNT ON ;      
 /*2010-05-10 新增*/      
  
        DECLARE @CollateStatus INT -- 订单校对状态      
        DECLARE @OrderStatus INT -- 订单状态      
        DECLARE @OldIsSend BIT -- 是否可发货      
		DECLARE @SendGroupId INT
		DECLARE @CurrencyCode VARCHAR(3)=''
  
        SET @CollateStatus = 0 ;      
        SET @OrderStatus = 0 ;      
        SET @OldIsSend = 0      
  
        SELECT  @CollateStatus = CollateStatus ,      
                @OrderStatus = OrderStatus ,      
                @OldIsSend = IsSend,
				@SendGroupId=ISNULL(SendGroupID,0)
        FROM    dbo.T_Order      
        WHERE   OrderId = @OrderId      
  
        IF @OrderStatus >= 60      
            AND @OldIsSend <> @IsSend       
            BEGIN      
                RAISERROR('提示：订单已出库后，不能修改可发货标识,请联系物流中心校对人员!', 16, 1) WITH NOWAIT ;      
            END      
  
  
 /*2010-05-10 新增*/      
  
        UPDATE  dbo.T_Order      
        SET     PayStatus = @PayStatus ,      
                Priority = @Priority ,      
                LastModifyTime = GETDATE() ,      
                HandlerId = @HandlerId ,      
                IsSend = @IsSend ,      
                IsInvoice = @IsInvoice ,      
                IsRemote = @IsRemote ,      
                IsActualInvoice = @IsActuallInvoice ,      
                CPFCode = @CPFCode ,      
                IsNeedProcessing = @IsNeedProcessing ,      
                IsIncludeShippingFee = @IsIncludeShippingFee ,      
                SubTotalPercent = @SubTotalPercent ,  
                TaxCodeType = @TaxCodeType,
                IsQualityInspection = @IsQualityInspection,
                CustomsClearanceProportion = @CustomsClearanceProportion,
                IsAutoBalance=@IsAutoBalance,
               DmsInvoiceRemark=@DmsInvoiceRemark 
        WHERE   OrderId = @OrderId ;      
  
        UPDATE  dbo.T_OrderRemark      
        SET     OrderRemark = @Remark ,      
                PrintRemark = @PrintRemark ,      
                PendingRemark = @PendingRemark ,
				ServiceRemark=@ServiceRemark,
				PackingRequirement=@PackingRequirement
        WHERE   OrderId = @OrderId ;      


		---修改同票订单的报关币种
		IF(@SendGroupId>0)
		BEGIN

		IF  EXISTS (SELECT TOP 1 1 FROM dbo.T_OrderExtend WITH(NOLOCK) WHERE OrderId=@OrderId AND  ISNULL(CustomsCurrencyId,0)<>@CustomsCurrencyId)
		BEGIN			
				     SELECT @CurrencyCode=Currency FROM dbo.T_Currency WITH(NOLOCK) WHERE Id=@CustomsCurrencyId

					UPDATE b SET b.CustomsCurrencyId=@CustomsCurrencyId FROM dbo.T_Order a WITH(NOLOCK)
					INNER JOIN dbo.T_OrderExtend b  WITH(NOLOCK) ON a.OrderId=b.OrderId
					WHERE a.SendGroupID=@SendGroupId

						INSERT INTO dbo.order_history
								( order_code ,
								  operator_id ,
								  operator_time ,
								  process
								)
						SELECT a.OrderId,0,GETDATE(),'同票订单'+@OrderId+'修改报关币种为=>'+ISNULL(@CurrencyCode,'') FROM  dbo.T_Order a WITH(NOLOCK)
						INNER JOIN dbo.T_OrderExtend b  WITH(NOLOCK) ON a.OrderId=b.OrderId
						WHERE a.SendGroupID=@SendGroupId AND a.OrderId<>@OrderId	
				END

		IF  EXISTS (SELECT TOP 1 1 FROM dbo.T_Order WITH(NOLOCK) WHERE SendGroupID=@SendGroupId AND  OrderId<>@OrderId AND  ISNULL(IsIncludeShippingFee,0)<>@IsIncludeShippingFee)
		BEGIN			
					UPDATE  dbo.T_Order  SET IsIncludeShippingFee=@IsIncludeShippingFee
					WHERE SendGroupID=@SendGroupId AND OrderId<>@OrderId

						INSERT INTO dbo.order_history
								( order_code ,
								  operator_id ,
								  operator_time ,
								  process
								)
						SELECT a.OrderId,0,GETDATE(),'同票订单'+@OrderId+'修改是否报运费=>'+CASE WHEN @IsIncludeShippingFee=1 THEN '是' ELSE '否' END FROM  dbo.T_Order a WITH(NOLOCK)
						WHERE a.SendGroupID=@SendGroupId AND a.OrderId<>@OrderId	
				END
			END		

		IF EXISTS(SELECT TOP 1 1 FROM dbo.T_OrderExtend WHERE OrderId=@OrderId)
		BEGIN
			UPDATE dbo.T_OrderExtend SET InvoiceValue=@InvoiceValue,
			IsFixCustomsChargePercent=@IsFixCustomsChargePercent,
			IsFixSubTotalPercent=@IsFixSubTotalPercent,
			FrightInvoiceValue=@FrightInvoiceValue,
			IsModifSendMark=@IsModifSendMark,
			CustomsCurrencyId=@CustomsCurrencyId
			WHERE OrderId=@OrderId
		END
		ELSE
		BEGIN
			INSERT INTO dbo.T_OrderExtend
			        ( OrderId ,
			          OrderPayIsCommunicationCMS ,
			          TraceNo ,
			          IsCashOrder,
					  InvoiceValue,
					  IsFixSubTotalPercent,
					  IsFixCustomsChargePercent,
					  FrightInvoiceValue,
					  IsModifSendMark
			        )
			VALUES  (@OrderId , -- OrderId - varchar(15)
			          0 , -- OrderPayIsCommunicationCMS - bit
			          '' , -- TraceNo - varchar(50)
			          0,  -- IsCashOrder - bit
					  @InvoiceValue,
					  @IsFixSubTotalPercent,
					  @IsFixCustomsChargePercent,
					  @FrightInvoiceValue,
					  @IsModifSendMark
			        )
		END
    END

go


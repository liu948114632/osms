
/**
获取订单当前可以享受的最优惠的运费促销活动，优先获取免运费活动
*/
CREATE PROC CRM_Order_GetCurrentBestFreightPromoteActivityByOrder
(  
  @OrderId VARCHAR(20) , --订单ID
  @IsDhlRemote BIT = 0, --货运地址在DHL是否偏远
  @PromoteActivityId INT OUT, --返回最优的活动ID
  @ProcedureCost DECIMAL(18,2) OUT, --返回免运费的手续费 
  @FreightDiscount DECIMAL(18,2) OUT, --返回运费折扣
  @BestDeliveryId INT OUT,--返回最优的货运方式
  @DeliveryRange VARCHAR(500) OUT--返回免运费货运方式的范围
)  
AS   
BEGIN  
   DECLARE @CrmCustomerId INT,--CRM客户ID
           @ShipCountryId INT ,--货运地址国家ID
           @ShipCity VARCHAR(500), --货运地址城市
           @ShipZip VARCHAR(200), --货运地址邮编
           @CustomerRatingId INT, --客户等级ID
           @CustomerType  INT, --客户类型
           @DeliveryID  INT, --货运方式ID
           @ProductPrice DECIMAL(18,2) , --商品折前总价
           @OrderWeight DECIMAL(18,2)--订单重量
           
     --取订单基本信息
     SELECT @CrmCustomerId = CustomerId,
            @ShipCountryId = Country,
            @ShipCity = City,
            @ShipZip = Zip,
            @DeliveryID = DeliveryId
     FROM dbo.T_Order a
     JOIN dbo.T_OrderAddresses b ON a.ShipAddressId=b.AddressId
     WHERE OrderId =@OrderId
     
     --取客户信息
     SELECT @CustomerRatingId = RatingId,
            @CustomerType = ISNULL(PHActivityLevel,0)
     FROM dbo.T_Customer
     LEFT JOIN dbo.T_CustomerActivityLevel ON UserID=CustomerId
     WHERE UserID=@CrmCustomerId
     
     --商品折前总价
     EXEC CRM_Order_GetOrderOriginalProductPrice @OrderId=@OrderId,@OriginalProductPrice = @ProductPrice OUT ;
     
     --获取订单重量                                
     DECLARE @ReadyWeight DECIMAL(18,2)
     EXEC CRM_Price_OrderValidWeightGet @OrderId=@OrderId, @Weight=@OrderWeight OUT,@ReadyWeight=@ReadyWeight OUT ; 
     
     EXEC CRM_Order_GetCurrentBestFreightPromoteActivity @CrmCustomerId=@CrmCustomerId,@ShipCountryId=@ShipCountryId,@ShipCity=@ShipCity,@ShipZip=@ShipZip,@IsDhlRemote=@IsDhlRemote,@CustomerRatingId=@CustomerRatingId,@CustomerType=@CustomerType,@DeliveryId = @DeliveryID,@ProductPrice=@ProductPrice,@OrderWeight=@OrderWeight,@PromoteActivityId = @PromoteActivityId OUT,@ProcedureCost = @ProcedureCost OUT, @BestDeliveryId = @BestDeliveryId OUT,@DeliveryRange=@DeliveryRange OUT,@FreightDiscount=@FreightDiscount OUT 
     
END
go


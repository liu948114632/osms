
-- =============================================      
--update Author:  <ll>      
-- Create date: <2014-09-11>      
-- Description: <添加分配资金项>      
-- =============================================      
CREATE PROCEDURE [dbo].[CRM_AddAssignedMoneyItem] 
(
	@AssignId int,
	@OrderId varchar(20),
   @CurrencyStr varchar(50) ,
   	@DueMoney decimal(18, 2) ,
	@ActualMoney decimal(18, 2) ,
	@AssignCurrencyMoney decimal(18, 2),
	@AssignUSDMoney decimal(18, 2)
)
AS      
BEGIN      
INSERT INTO dbo.T_AssignedMoneyItem
        ( AssignId ,
          OrderId ,
          CurrencyStr ,
          DueMoney,
          ActualMoney ,
          AssignCurrencyMoney ,
          AssignUSDMoney
        )
VALUES  (@AssignId , -- AssignId - int
          @OrderId, -- OrderId - varchar(15)
          @CurrencyStr , -- CurrencyStr - varchar(50)
          @DueMoney,
          @ActualMoney ,
          @AssignCurrencyMoney , -- AssignCurrencyMoney - decimal
          @AssignUSDMoney  -- AssignUSDMoney - decimal
        )       
END
go


/*------------------------------------------------  
[备注]   
 获取客户的order列表  
  
  
修改人：HYD  
修改日期：2010-02-21  
修改内容：去掉只有@CustomerId > 0才增加CustomerId的查询条件，否则默认则查出了所有  
  
  
修改人：HYD  
版本：CRM 5.0.4.0  
修改时间：2010-04-21  
修改内容：增加获取订单的录单时间  
-------------------------------------------------*/  
CREATE PROC dbo.CRM_Order_OrdersGetByCustomer  
(  
 @CustomerIds  VARCHAR(MAX),  
 @Sort    NVARCHAR(100) = '',  
 @PageNo   INT = 0,  
 @PageSize   INT = 10  
)  
AS  
DECLARE  
 @Sql     NVARCHAR(MAX),  
 @CountSql   NVARCHAR(MAX),  
 @Where    NVARCHAR(2000),  
 @Parameters   NVARCHAR(1000), -- 动态参数  
 @PageCount    INT,  
 @RowCount    INT,  
 @Start    INT, --每页的起始位置  
 @End    INT  --每页的终止位置  
  
BEGIN  
 -- 不返回影响结果  
 SET NOCOUNT ON;  
  
 -- 组合条件语句  
 Set @Where = ' Where OrderStatus > 0';  
   
 -- 组合查询语句  
 SET @CountSql = 'Select @pRowCount = Count(1) FROM  
 dbo.T_Order With(NoLock)  
 ' ;  

 SET @CountSql = @CountSql + @Where;  

 IF LEN(@CustomerIds) > 0  
 BEGIN  
  SET @CountSql = @CountSql + '   
  And CustomerId in (SELECT value FROM dbo.uf_Split(@pCustomerIds,'',''))';  
END   
   
   PRINT @CountSql
 -- 拼凑动态参数  
 SET @Parameters = N'@pRowCount INT OUT, @pCustomerIds nvarchar(max)' ;  
   
 -- 获取总记录数  
 EXEC sp_executesql  @CountSql, @Parameters, @pRowCount = @RowCount OUT,@pCustomerIds = @CustomerIds;  

 -- 分页参数设置  
 IF ISNULL(@PageSize, 0) < 1   
  Set @PageSize = 20;  
 Set @PageCount = (@RowCount + @PageSize - 1) / @PageSize;  
 Set @pageNo = @PageNo + 1;  
 IF ISNULL(@pageNo, 0) < 1   
  Set @pageNo = 1;  
 ELSE IF ISNULL(@pageNo, 0) > @PageCount  
  Set @pageNo = @PageCount;  
 Set @Start = (@PageNo-1)*@PageSize + 1;  
 Set @End = @PageNo*@PageSize;  
    
 -- 返回页数和总记录数  
 Select @PageCount as PageCount,@RowCount as [RowCount];  
   
 SET @Sql = '   
 With cte As  
 (  
  Select   
   T_Order.OrderId,  
   PayType,  
   CustomerId,  
   OrderStatus,  
   PayStatus,  
   OrderDiscount,  
   DeliveryId,  
   OrderDate,  
   DisposeDate, 
   Lang, 
   DeliveryUserName,
   SendGroupID,
   c.EmailId,
   ROW_NUMBER() OVER(ORDER BY a.Id asc,OrderDate DESC) AS RowNumber  
  From  
   dbo.T_Order With(NoLock)  
INNER JOIN (SELECT * FROM dbo.uf_Split(@pCustomerIds,'','')) a
ON t_order.CustomerId=a.Value
left join T_OrderExtend c With(NoLock)  on c.OrderId=T_Order.OrderId
  '  + @Where + '  
 ),cteOrders AS  
 (  
  SELECT  
   OrderId,  
   PayType,  
   CustomerId,  
   OrderStatus,  
   PayStatus,  
   OrderDiscount,  
   DeliveryId,  
   OrderDate,  
   DisposeDate,  
   Lang, 
   DeliveryUserName,
   SendGroupID,
   EmailId,
   RowNumber
  From cte   
  Where RowNumber BETWEEN @pStart AND @pEnd  
 )  
   
 Select   
  a.OrderId,  
  a.PayType,  
  a.CustomerId,  
  isnull(a.EmailId,e.EmailId) as EmailId,
  a.OrderStatus AS Status,  
  a.PayStatus,  
  a.OrderDiscount,  
  a.DeliveryId,  
  a.OrderDate,  
  a.DisposeDate, 
  a.Lang,  
  b.DueDate,  
  b.TraceNo,  
  b.Status As PackageStatus,  
  c.[Name] as DeliveryName ,
  DeliveryUserName,
  a.SendGroupID,
  d.ShipmentComment,d.ShipmentScore,d.QualityComment,d.QualityScore,d.ServiceComment,d.ServiceScore,d.OtherComment
 From   
  cteOrders a  
  LEFT Join dbo.T_OrderPackage b  
   On a.OrderId = b.OrderId  
  LEFT Join dbo.T_Delivery c  
   On a.DeliveryId = c.DeliveryId  
   	LEFT JOIN dbo.T_OrderComment d WITH(NOLOCK) ON a.OrderId=d.OrderId
	LEFT JOIN dbo.T_Customer e WITH(NOLOCK) ON e.UserId=a.CustomerId
 Order By a.RowNumber';  
  
 -- 拼凑动态参数  
 SET @Parameters = N'@pStart INT ,@pEnd INT,@pCustomerIds nvarchar(max)';  
   
   PRINT @Sql

 -- 获取总记录数  
 EXEC sp_executesql  @Sql, @Parameters, @pStart = @Start,@pEnd = @End,@pCustomerIds = @CustomerIds;  
END


go


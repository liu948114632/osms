
/**    
获取货运国家的海外仓库   
*/    
CREATE PROC [dbo].[CRM_Order_GetCanGoWarehouseByCountry]    
(    
  @CountryId int
)    
AS    
begin    
      SELECT a.id,
             a.WarehouseCode,
             a.WarehouseName,
             b.CountryId  ,
             a.[Index]
      FROM dbo.T_OverseasWarehouse a
      INNER JOIN T_OverseasWarehouseCountry b
      ON a.WarehouseCode=b.WarehouseCode
      WHERE b.CountryId=@CountryId 
      ORDER BY a.[Index]
END

go


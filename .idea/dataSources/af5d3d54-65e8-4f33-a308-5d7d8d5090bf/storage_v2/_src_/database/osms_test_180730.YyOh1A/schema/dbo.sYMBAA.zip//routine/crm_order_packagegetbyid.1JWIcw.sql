    
	
  
/*-------------------------------------------------   
备注:获取单个包裹信息  
创建人: FRH  
创建日期:2009-12-30  
   
------------------------------------------------------*/  
CREATE PROCEDURE [dbo].[CRM_Order_PackageGetById]  
(  
 @OrderId  VARCHAR(20) -- 订单编号  
)  
AS  
  
BEGIN  
 SELECT  
  OrderId,  
  TraceNo,  
  CustomerName,  
  DeliveryId,  
  [Status],  
  [Disabled],  
  DealStatus,  
  QuestionStatus,  
  IsSendMail,  
  IsConfirm,  
  DueDate,  
  UpdateDate,  
  Remark,
  ServiceLineType,
  ServiceLineName,
  ServiceCompany
 FROM   
  dbo.T_OrderPackage   
 WHERE  
  OrderId = @OrderId;   
END

go


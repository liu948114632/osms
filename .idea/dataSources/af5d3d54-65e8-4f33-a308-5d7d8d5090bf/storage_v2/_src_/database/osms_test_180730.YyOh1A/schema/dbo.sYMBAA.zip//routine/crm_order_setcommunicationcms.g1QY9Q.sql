
/**
设置订单已通讯到CMS
*/
CREATE PROC CRM_Order_SetCommunicationCMS
(  
  @OrderId VARCHAR(20) --订单号
)
AS
begin
      UPDATE dbo.T_Order
      SET IsCommunicationCMS = 1
      WHERE OrderId = @OrderId
END
go


create function uf_calc_product_operate_cost_price(
	@cost_price decimal(18,6),
	@package_cost_price decimal(18,6),
	@proccing_cost_price decimal(18,6),
	@unit_qty int
)
returns decimal(18,6) 
as 
begin
	  return convert(decimal(18,2),(isnull(@cost_price,0) + 
	  ( isnull(@proccing_cost_price,0) + 
	  isnull(@package_cost_price,0) )/isnull(@unit_qty, 1)  ))        
end

go


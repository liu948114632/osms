
-- Stored Procedure

/*-------------------------------------------          
[备注]:            
 获取符合条件的包裹列表          
--------------------------------------------*/          
CREATE PROC dbo.CRM_Order_PackagesGet          
(          
 @EmailId   INT=-1,          
 @GoodsCode  VARCHAR(200) = '',  --货代号        
 @DeliveryId  INT = -1,          
 @BusinessType  VARCHAR(200) = '',  --行业类型,多个之间用逗号隔开        
 @Status   INT = 0,          
 @Disabled   INT = -1,          
 @OrderId   VARCHAR(200) = '',-- 订单编号          
 @CustomerName  VARCHAR(200) = '',-- 客户名称          
 @TraceNo   VARCHAR(200) = '',-- 货运单号          
 @Remark   VARCHAR(200) = '',-- 备注          
 @DealStatus  INT = 0,          
 @QuestionStatus INT = 0,          
 @PageNo   INT = 0,          
 @PageSize   INT = 25          
)          
AS          
DECLARE          
 @Sql     NVARCHAR(MAX),          
 @CountSql   NVARCHAR(MAX),          
 @Where    NVARCHAR(2000),          
 @Parameters   NVARCHAR(1000), -- 动态参数          
 @PageCount    INT,          
 @RowCount    INT,          
 @Start    INT, --每页的起始位置          
 @End    INT  --每页的终止位置          
begin           
 -- 不返回影响结果          
 SET NOCOUNT ON;          

 -- 组合查询语句          
 SET @CountSql = 'Select @pRowCount = Count(1)   
 FROM dbo.T_OrderPackage  With(NoLock)  
 inner join T_Order b with(Nolock) on  T_OrderPackage.OrderId = b.OrderId                 
 ' ;          

 -- 组合条件语句          
 Set @Where = '  Where 1=1';          

 IF @EmailId >0          
 BEGIN          
  SET @Where = @Where + '           
  AND EmailId=@pEmailId';          
 END          

 IF @GoodsCode > ''          
 BEGIN          
  SET @Where = @Where + '           
  AND charindex(@pGoodsCode,GoodsCode,0) > 0';          
 END          

 IF @DeliveryId > -1           
 BEGIN            
  SET @Where = @Where + '           
  AND dbo.T_OrderPackage.[DeliveryId] = @pDeliveryId';          
 END          

 IF @Disabled > -1          
 BEGIN          
  SET @Where = @Where + '           
  AND [Disabled] = @pDisabled';          
 END          

 IF @Status  > 0          
 BEGIN           
  SET @Where = @Where + '           
  AND [Status] = @pStatus';          
 END          

 IF @OrderId  > ''           
 BEGIN          
  SET @Where = @Where + '           
  AND CharIndex(@pOrderId,b.OrderId,0) > 0 ';          
 END           

 IF @CustomerName  > ''          
 BEGIN          
  SET @Where = @Where + '           
  AND CharIndex(@pCustomerName,CustomerName,0) > 0 ';          
 END          

 IF @TraceNo  > ''          
 BEGIN          
  SET @Where = @Where + '           
  AND CharIndex(@pTraceNo,TraceNo,0) > 0 ';          
 END          

 IF @Remark  > ''          
 BEGIN          
  SET @Where = @Where + '           
  AND CharIndex(@pRemark,Remark,0) > 0 ';          
 END          

 IF @DealStatus > 0          
 BEGIN          
  SET @Where = @Where + '           
  And DealStatus = @pDealStatus';          
 END          

 IF @QuestionStatus > 0          
 BEGIN          
  SET @Where = @Where + '           
  And QuestionStatus = @pQuestionStatus';          
 END         

 IF @BusinessType  > ''          
 BEGIN          
  SET @Where = @Where + ' AND b.OrderIndustryType in ('+ @BusinessType + ')';          
 END          

 SET @CountSql = @CountSql + @Where;          

 -- 拼凑动态参数          
 SET @Parameters = N'@pRowCount INT OUT,@pEmailId int,@pGoodsCode VARCHAR(200),@pDeliveryId INT,@pStatus INT,@pDisabled INT,@pOrderId VARCHAR(200),@pCustomerName VARCHAR(200),@pTraceNo VARCHAR(200),@pRemark VARCHAR(200),@pDealStatus INT,@pQuestionStatus INT';          

 -- 获取总记录数          
 EXEC sp_executesql  @CountSql, @Parameters, @pRowCount = @RowCount OUT,@pEmailId =@EmailId, @pGoodsCode = @GoodsCode,@pDeliveryId = @DeliveryId,@pStatus = @Status,@pDisabled = @Disabled,@pOrderId = @OrderId,@pCustomerName=@CustomerName,@pTraceNo=@TraceNo,@pRemark=@Remark,@pDealStatus = @DealStatus,@pQuestionStatus = @QuestionStatus;          

 -- 分页参数设置          
 IF ISNULL(@PageSize, 0) < 1           
  Set @PageSize = @RowCount;          
 Set @PageCount = (@RowCount + @PageSize - 1) / @PageSize;          
 Set @pageNo = @PageNo + 1;          
 IF ISNULL(@pageNo, 0) < 1           
  Set @pageNo = 1;          
 ELSE IF ISNULL(@pageNo, 0) > @PageCount          
  Set @pageNo = @PageCount;          
 Set @Start = (@PageNo-1)*@PageSize + 1;          
 Set @End = @PageNo*@PageSize;          

 -- 返回页数和总记录数          
 Select @PageCount as PageCount,@RowCount as [RowCount];          

 SET @Sql = '           
 With cte As          
 (          
  Select           
   T_OrderPackage.OrderId,          
   T_OrderPackage.GoodsCode,          
   T_OrderPackage.TraceNo,          
   T_OrderPackage.EmailId,          
   T_OrderPackage.DeliveryId,    
   b.CustomerId,   
   b.ShipAddressId,       
   T_OrderPackage.[Status],          
   T_OrderPackage.[Disabled],          
   T_OrderPackage.DealStatus,          
   T_OrderPackage.QuestionStatus,          
   T_OrderPackage.IsSendMail,          
   T_OrderPackage.IsConfirm,          
   T_OrderPackage.DueDate,          
   T_OrderPackage.UpdateDate,          
   T_OrderPackage.Remark,          
   ROW_NUMBER() OVER(ORDER BY [Status],[DueDate] DESC,[TraceNo] asc ) AS RowNumber          
  From          
   dbo.T_OrderPackage With(NoLock)   
   Inner Join dbo.T_Order b With(NoLock) On T_OrderPackage.OrderId = b.OrderId            
  '  + @Where + '          
 ),cteOrders AS     (          
  SELECT          
   OrderId,          
   GoodsCode,          
   TraceNo,          
   EmailId,          
   DeliveryId,          
   [Status],          
   [Disabled],          
   DealStatus,          
   QuestionStatus,          
   IsSendMail,          
   IsConfirm,          
   DueDate,          
   UpdateDate,          
   Remark,          
   RowNumber,  
   CustomerId,   
   ShipAddressId              
  From cte           
  Where RowNumber BETWEEN @pStart AND @pEnd          
 )          

 Select           
  a.OrderId,          
  a.GoodsCode,          
  a.TraceNo,          
  a.EmailId,          
  CAST(a.DeliveryId AS INT) AS DeliveryId,          
  a.[Status],          
  a.[Disabled],          
  a.DealStatus,          
  a.QuestionStatus,          
  a.IsSendMail,          
  a.IsConfirm,          
  a.DueDate,          
  a.UpdateDate,          
  a.Remark,          
  (CASE WHEN EXISTS(SELECT * FROM dbo.T_CustomerVip With(NoLock) WHERE UserId = CustomerId)           
  THEN           
   ''[VIP]'' + c.FullName          
  ELSE          
   c.FullName          
  END) AS CustomerName,-- 客户名称          
  e.[Name] AS CountryName,          
  a.CustomerId AS UserId          
 From           
  cteOrders a       
  Inner Join dbo.T_Customer c With(NoLock)        
   On a.CustomerId = c.UserId          
  Inner Join dbo.T_OrderAddresses d With(NoLock)         
   On a.ShipAddressId = d.AddressId          
  Inner Join dbo.T_Country e With(NoLock)         
   ON d.Country = e.CountryId          
 Order By a.RowNumber';          

 -- 拼凑动态参数          
 SET @Parameters = N'@pStart INT ,@pEnd INT,@pEmailId int,@pGoodsCode VARCHAR(200),@pDeliveryId INT,@pStatus INT,@pDisabled INT,@pOrderId VARCHAR(200),@pCustomerName VARCHAR(200),@pTraceNo VARCHAR(200),@pRemark VARCHAR(200),@pDealStatus INT,@pQuestionStatus INT';                

 -- 获取总记录数          
 EXEC sp_executesql  @Sql, @Parameters, @pStart = @Start,@pEnd = @End,@pEmailId=@EmailId,@pGoodsCode = @GoodsCode,@pDeliveryId = @DeliveryId,@pStatus = @Status,@pDisabled = @Disabled,@pOrderId = @OrderId,@pCustomerName=@CustomerName,@pTraceNo=@TraceNo,@pRemark=@Remark,@pDealStatus = @DealStatus,@pQuestionStatus = @QuestionStatus;                 
END

go


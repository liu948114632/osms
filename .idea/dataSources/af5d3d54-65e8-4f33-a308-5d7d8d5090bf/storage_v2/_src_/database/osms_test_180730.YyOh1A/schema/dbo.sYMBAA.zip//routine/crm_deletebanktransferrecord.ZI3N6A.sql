
CREATE PROC dbo.CRM_DeleteBankTransferRecord
 (
 @Ids VARCHAR(max)
 )
 AS
 BEGIN

 IF EXISTS(SELECT TOP 1 1 FROM  dbo.T_BankTransferRecord a
	INNER JOIN (SELECT * FROM dbo.uf_Split(@Ids,',')) b
	ON a.Id=b.Value
	WHERE a.Status=1 AND a.Type=1
	)
	BEGIN
                RAISERROR ('<info>已入账的收款记录不允许删除！</info>' , 16, 1) WITH NOWAIT          
                RETURN  
	END

	DELETE a FROM  dbo.T_BankTransferRecord a
	INNER JOIN (SELECT * FROM dbo.uf_Split(@Ids,',')) b
	ON a.Id=b.Value

 END

go




-- Stored Procedure

-- =============================================  
-- modify:  HJJ  
-- Create date: 2011-03-02  
-- Description: 原先判断包裹是否确认IF @Status = 4 改为 IF @Status = 90  
-- =============================================  
CREATE PROCEDURE [dbo].[CRM_Order_PackageUpdateForDMS]  
(  
 @OrderId   VARCHAR(20),  
 @CustomerName  VARCHAR(50),  
 @Email    VARCHAR(50),  
 @DeliveryId   INT,  
 @GoodsCode   VARCHAR(200),  --货代号
 @TraceNo   VARCHAR(200),  
 @Status    INT,  
 @DealStatus   int,  
 @Disabled   BIT,  
 @Remark    NVARCHAR(500)  
)  
AS  
BEGIN  
 UPDATE    
  dbo.T_OrderPackage  
 SET    
  CustomerName = @CustomerName,  
  Email   = @Email,  
  DeliveryId  = @DeliveryId,  
  GoodsCode      = @GoodsCode,  
  TraceNo   = @TraceNo,  
  [Status]  = @Status,  
  DealStatus  = @DealStatus,  
  Remark   = @Remark,  
  UpdateDate  = GETDATE()  
 WHERE   
  [OrderId]  = @OrderId;  

 -- 包裹状态为确认时，更新订单状态为完成  
 IF @Status = 90  
 BEGIN  
  -- 更新订单状态     
  UPDATE dbo.T_Order   
  SET [OrderStatus] = 128,LastModifyTime = GETDATE()  
  WHERE OrderId = @OrderId;  


  -- 完成订单项  
  UPDATE dbo.T_OrderItem  
  SET [Status] = 10  
  WHERE OrderId = @OrderId And [Status] < 10;  
 END   

END
go


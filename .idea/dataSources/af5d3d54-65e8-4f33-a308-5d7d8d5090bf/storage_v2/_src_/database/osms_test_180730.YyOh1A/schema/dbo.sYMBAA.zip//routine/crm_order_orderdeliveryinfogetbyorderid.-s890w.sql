/*---------------------------------------------------
备注:获取订单的发货信息
创建人: FRH
创建日期:2009-12-30
	
-----------------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_OrderDeliveryInfoGetByOrderId] 
(
	@OrderId				NVARCHAR(20) = ''
)
AS
DECLARE
	@CustomerId				INT,
	@DeliveryId				INT,
	@HandlerId				INT,
	@CustomerName			NVARCHAR(101),
	@HandlerUserName		NVARCHAR(50),
	@Email					NVARCHAR(50)
BEGIN
	SET @DeliveryId = 0;
	SET @Email  = '';
	SET @CustomerName  = '';
	SET @HandlerUserName = '';
	SET @CustomerId = 0;
	SET @HandlerId = 0;

	SELECT
		@CustomerId = CustomerId,
		@DeliveryId = DeliveryId,
		@HandlerId = HandlerId
	FROM
		dbo.T_Order
	WHERE
		OrderId = @OrderId;

	SELECT 
		@Email = Email,
		@CustomerName = FullName
	FROM
		T_Customer
	WHERE
		UserId = @CustomerId;

	SELECT 
		@HandlerUserName = ISNULL(english_name ,'')
	FROM 
		[user] 
	WHERE id = @HandlerId

	SELECT @DeliveryId AS DeliveryId,@CustomerName AS CustomerName,@Email AS Email,@HandlerUserName AS HandlerUserName,@CustomerId AS CustomerId ,@HandlerId AS HandlerId ;
END

go


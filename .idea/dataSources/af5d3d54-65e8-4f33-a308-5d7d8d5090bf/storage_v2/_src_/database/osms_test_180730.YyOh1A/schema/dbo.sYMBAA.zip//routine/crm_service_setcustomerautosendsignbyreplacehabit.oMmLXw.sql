

Create PROCEDURE CRM_Service_SetCustomerAutoSendSignByReplaceHabit
AS
BEGIN
     insert into T_SystemLog(module,[object_id],[content],creator_id)
     SELECT 'SetCustomerAutoSendSignByReplaceHabit',a.customerID,
	 '取消客户的自动发货标记，当前开启替代品订单数为：' + convert(varchar(10),OpenReplace) + '，拒绝替代品数量为：'+ convert(varchar(10),RefuseReplace),0
	 FROM dbo.T_CustomerSelectReplaceHabit a
	 join T_Customer b on a.customerID=b.UserId
	 WHERE OpenReplace>=3 AND RefuseReplace*1.0/OpenReplace>=0.65 and b.IsAutoDelay=1

	 --取消经常拒绝替代品的客户标记
	 update b set IsAutoDelay = 0
	 FROM dbo.T_CustomerSelectReplaceHabit a
	 join T_Customer b on a.customerID=b.UserId
	 WHERE OpenReplace>=3 AND RefuseReplace*1.0/OpenReplace>=0.65 and b.IsAutoDelay=1
END

go


CREATE PROC CRM_Order_PackageProblem_AddAttachment
(
@ObjectId int ,
@FileName varchar(255),
@OriginalFileName varchar(255),
@LocalUrl varchar(255)
)
AS   
BEGIN 
INSERT  INTO  dbo.T_PackageProblemAttachment(ObjectId,[FileName],OriginalFileName,LocalUrl) VALUES(@ObjectId,@FileName,@OriginalFileName,@LocalUrl)
END

go


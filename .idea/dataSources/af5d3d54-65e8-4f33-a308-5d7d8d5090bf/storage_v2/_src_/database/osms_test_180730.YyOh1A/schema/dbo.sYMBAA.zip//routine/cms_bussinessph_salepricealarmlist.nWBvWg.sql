--[CMS_BussinessPH_SalePriceAlarmList] @productCode ='IFIN-WH0001-02A'

CREATE PROCEDURE [dbo].[CMS_BussinessPH_SalePriceAlarmList](          
 @CategoryID1 INT = NULL,--一级类别          
 @CategoryID2 INT = NULL,--二级类别          
 @CategoryID3 INT = NULL,--三级类别          
 @SeriesId INT = NULL,--系列          
 @PropValueID1 INT = NULL,--属性1          
 @PropValueID2 INT = NULL,--属性2          
 @PropValueID3 INT = NULL,--属性3          
 @Status INT = NULL,--状态          
 @IsPromotion INT = NULL,--是否促销       
 @IsBestSellers INT = NULL, --是否畅销品      
 @IsCompetitorBestSellers INT = NULL,--是否竞争对手畅销       
 @IsPool INT = NULL, -- 是否商品池      
 @Type INT = NULL,--报警类型          
 @Casuse VARCHAR(MAX) = NULL,--原因          
 @CostMode VARCHAR(MAX) = NULL,--调整条件式          
 @CostAdjust VARCHAR(MAX) = NULL,--调整条件标的          
 @CreateTimeBegin VARCHAR(20) = NULL,--创建时间始          
 @CreateTimeOver VARCHAR(20) = NULL,--创建时间止          
 @ProductCode VARCHAR(MAX) = NULL,--产品Code    
 @ProductCodes VARCHAR(MAX) = NULL,--产品Code         
 @ProductSetCode VARCHAR(MAX) = NULL,--产品集Code          
 @ProductName VARCHAR(MAX) = NULL,--产品名称          
 @currRate DECIMAL(9, 4) = NULL, --汇率   
 @IsAldi INT = NULL, --是否阿尔迪          
 @IsBigPurchase int = NULL, --是否大采购   
 @IsSmallQuantities INT = NULL,--小批量 v3.9.1 add
 @isQueryPHFinalGood BIT=NULL ,--v3.9.28 add by whw ph成品部商品  
 @isBoutique INT=NULL, -- 是否精品
 @PageSize INT = 50 ,              
 @PageIndex INT = 1            
)          
AS           
BEGIN          
 SET NOCOUNT OFF           
 DECLARE          
  @SQL VARCHAR(max),                          
        @CountSql NVARCHAR(MAX), --查询数量用                          
        @FromSQL NVARCHAR(max), --查询内表                        
        @Column NVARCHAR(max), --取的字段                        
        @Condition varchar(MAX), --条件                           
        @RowCount INT ,             
        @PageCount INT ,             
        @start INT ,           
        @end INT;          
               
     --设置查询条件          
 SET @Condition = ' WHERE 1=1 ';   
 -- AND P.is_ts <> 1 AND P.id NOT IN (SELECT product_id FROM fn_getProoductIdByProviderCode(''sz''))
  IF @isQueryPHFinalGood IS NOT NULL
 BEGIN
	IF @isQueryPHFinalGood=1
	BEGIN
	     SET @Condition = @Condition + ' AND P.is_ph_final_good=1 '  
	END
	ELSE
	BEGIN
	    SET @Condition = @Condition + ' AND (P.is_ph_final_good is null or P.is_ph_final_good=0) '
	END
 END        
   IF @CategoryID1 IS NOT NULL           
   BEGIN          
 SET @Condition = @Condition + ' AND P.category_id_1 = ' + CONVERT(VARCHAR(10), @CategoryID1);          
   END          
   IF @CategoryID2 IS NOT NULL           
   BEGIN          
 SET @Condition = @Condition + ' AND P.category_id_2 = ' + CONVERT(VARCHAR(10), @CategoryID2);          
   END          
   IF @CategoryID3 IS NOT NULL           
   BEGIN          
   SET @Condition = @Condition + ' AND P.category_id_3 = ' + CONVERT(VARCHAR(10), @CategoryID3);          
   END          
   IF @SeriesId IS NOT NULL           
   BEGIN          
  SET @Condition = @Condition + ' AND B.category_series_id = ' + CONVERT(VARCHAR(10), @SeriesId);          
   END           
   IF @PropValueID1 IS NOT NULL           
   BEGIN          
     SET @Condition = @Condition + ' AND exists (select d.id from product_property_value d with(NOLOCK)          
     where d.product_id=p.id and d.property_value=' + CONVERT(VARCHAR(10), @PropValueID1) + ')';          
  END           
  IF @PropValueID2 IS NOT NULL           
  BEGIN          
    SET @Condition = @Condition + ' AND exists (select d.id from product_property_value d with(NOLOCK)         
    where d.product_id=p.id and d.property_value=' + CONVERT(VARCHAR(10), @PropValueID2) + ')';          
  END           
  IF @PropValueID3 IS NOT NULL           
  BEGIN          
    SET @Condition = @Condition + ' AND exists (select d.id from product_property_value d with(NOLOCK)          
    where d.product_id=p.id and d.property_value='+ CONVERT(VARCHAR(10), @PropValueID3) + ')';          
  END          
  IF @Status IS NOT NULL           
  BEGIN          
   SET @Condition = @Condition + ' AND a.status = ' + CONVERT(VARCHAR(10), @Status);          
  END          
  IF @IsPromotion IS NOT NULL           
  BEGIN          
   IF @IsPromotion = 1           
   SET @Condition = @Condition + ' AND px.is_promote = 1 ';         
   ELSE        
   SET @Condition = @Condition + ' AND px.id is NULL ';         
  END        
        
  IF @IsBestSellers IS NOT NULL           
  BEGIN          
   IF @IsBestSellers = 1           
  SET @Condition = @Condition + ' AND b.is_best_sellers = 1 ';         
   ELSE        
  SET @Condition = @Condition + ' AND b.is_best_sellers = 0 ';         
  END      
        
  IF @IsPool IS NOT NULL           
   BEGIN          
    IF @IsPool = 1           
   SET @Condition = @Condition + ' AND b.is_pool = 1 ';         
    ELSE        
   SET @Condition = @Condition + ' AND b.is_pool = 0 ';         
  END       
        
  IF @IsCompetitorBestSellers IS NOT NULL           
  BEGIN          
 IF @IsCompetitorBestSellers = 1           
  SET @Condition = @Condition + ' AND b.is_competitor_best_sellers = 1 ';         
 ELSE        
  SET @Condition = @Condition + ' AND b.is_competitor_best_sellers = 0 ';         
  END             
            
  IF @Type IS NOT NULL           
  BEGIN          
 SET @Condition = @Condition + ' AND a.type=' + CONVERT(VARCHAR(10), @Type);          
  END           
  IF @Casuse IS NOT NULL           
  BEGIN          
   SET @Condition = @Condition + ' AND a.cause=''' + @Casuse + '''';          
  END          
  IF @CostMode IS NOT NULL AND @CostAdjust IS NOT NULL           
  BEGIN          
 SET @Condition = @Condition + ' AND a.cost_price_range' + @CostMode + @CostAdjust;          
  END           
  IF @CreateTimeBegin IS NOT NULL          
  BEGIN          
   SET @Condition = @Condition + ' AND a.create_time >=''' + CONVERT(VARCHAR(20), @CreateTimeBegin) + '''';          
  END          
  IF @CreateTimeOver IS NOT NULL           
  BEGIN          
 SET @Condition = @Condition + ' AND a.create_time <=''' + CONVERT(VARCHAR(20), @CreateTimeOver) + '''';          
  END           
  IF @ProductCode IS NOT NULL           
  BEGIN          
   SET @Condition = @Condition + ' AND p.code like ''' + @ProductCode + '%''';          
  END   
  IF @ProductCodes IS NOT NULL  
 BEGIN  
  SET @Condition = @Condition + ' AND p.code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')'     
 END         
  IF @ProductSetCode IS NOT NULL           
  BEGIN          
  SET @Condition = @Condition + ' AND exists (select c.id from product_set c with(nolock) where c.id=p.product_set_id and c.code like ''' + @ProductSetCode + '%'')'          
  END           
  IF @ProductName IS NOT NULL           
  BEGIN          
   SET @Condition = @Condition + ' AND p.[name] like ''' + @ProductName + '%''';          
  END                   
  IF @IsAldi IS NOT NULL           
  BEGIN          
   SET @Condition = @Condition + ' AND isnull(p.aldi, 0)=' + CONVERT(VARCHAR(20), @IsAldi);  
  END           
  IF @IsBigPurchase IS NOT NULL           
  BEGIN          
   SET @Condition = @Condition + ' AND isnull(p.is_big_purchase, 0)=' + CONVERT(VARCHAR(20), @IsBigPurchase);          
  END 
  IF @IsSmallQuantities IS NOT NULL
  BEGIN
	IF @IsSmallQuantities = 1 
		SET @Condition = @Condition + ' AND p.is_small_quantities = 1 ';         
	ELSE        
		SET @Condition = @Condition + ' AND p.is_small_quantities = 0 ';
  END
 IF @isBoutique IS NOT NULL
	BEGIN
		IF @isBoutique =1 
			BEGIN
				SET @Condition = @Condition + ' AND p.is_Boutique = 1 '; 
			END
		ELSE 
			BEGIN
				SET @Condition = @Condition + ' AND p.is_Boutique = 0 '; 
			END	
	END
	 
--设置查询列            
  SET @Column ='a.id,
	 b.category_series_id as categorySeriesId,
	 ps.name as seriesName,
	 p.is_small_quantities as isSmallQuantities,
     a.product_id productId,          
     a.type,          
     a.status,          
     a.cause,          
     a.cost_price_range costPriceRange,          
     a.create_time createTime,          
     p.code productCode,          
     p.name productName,          
     p.original_name productOriginalName,          
     convert(decimal(18,2),p.operating_cost_price) costPrice,          
     p.color_card_picture_code colorCardPictureCode,          
     p.primary_picture_code primaryPictureCode,          
     p.product_set_id productSetId,          
     case when p.category_id_3 > 0 then p.category_id_3           
     else (case when p.category_id_2 > 0 then p.category_id_2          
     else (case when p.category_id_1 > 0 then p.category_id_1 else 0 end) end) end categoryId,          
     b.order_count OrderCount,          
     b.browse_count browseCount,          
     b.publish_time publishTime,      
     b.is_pool AS isPool,      
     p.aldi isAldi,  
     p.is_big_purchase bigPurchase,  
     IsNULL(b.is_competition,0) as isCompetition,    
     CASE WHEN  b.is_best_sellers = 1 THEN 2       
  WHEN  b.is_competitor_best_sellers = 1 THEN 3 ELSE 0 END AS bestSellers,      
     b.first_profit_coefficient firstProfitCoefficient,          
     b.current_cost_price adjustedCostPrice,          
     b.reference_cost_price originalCostPrice,      
     CASE WHEN px.is_promote = 1 THEN 1 ELSE 0 END AS isPromotional,      
     CASE WHEN px.is_promote = 1 THEN  px.discount ELSE 0 END AS promoteDiscount,
     p.is_Boutique as isBoutique,        
     convert(varchar(10), p.unit_quantity) + '' '' + p.unit productUnit,';          
  IF @currRate IS NULL          
 SELECT @currRate= 8.2;         
  IF @currRate < 0.0001          
  BEGIN          
 SET @Column = @Column + '0 firstSalePrice, 0 secondSalePrice, 0 thirdSalePrice, 0 referenceFirstProfitCoefficient ';          
  END           
  ELSE          
  BEGIN          
   SET @Column = @Column +       
   'convert(decimal(18,2),p.operating_cost_price * isnull(p.unit_quantity, 0) / '+ CONVERT(VARCHAR(10), @currRate)           
   + ' * isnull(b.first_profit_coefficient,0)) firstSalePrice,  
           
   convert(decimal(18,2),p.operating_cost_price * isnull(p.unit_quantity, 0) / '+ CONVERT(VARCHAR(10), @currRate)          
   + ' * isnull(b.second_profit_coefficient,0)) secondSalePrice, 
            
    convert(decimal(18,2),p.operating_cost_price * isnull(p.unit_quantity, 0) / '+ CONVERT(VARCHAR(10), @currRate)           
   + ' * isnull(b.third_profit_coefficient,0)) thirdSalePrice, 
             
   convert(decimal(18,2),p.operating_cost_price* isnull(p.unit_quantity, 0) / '+ CONVERT(VARCHAR(10), @currRate)            
   + ' * isnull(b.first_profit_coefficient,0) / (isnull(b.reference_cost_price, 0) * isnull(p.unit_quantity, 0) / '          
   + CONVERT(VARCHAR(10), @currRate) +')) referenceFirstProfitCoefficient ';           
             
  END              
  --设置查询内表           
  SET @FromSQL = '';              
  SET @FromSQL = ' FROM dbo.ph_product_sale_price_alarm a with(nolock)         
       INNER JOIN dbo.ph_product b with(nolock)  ON a.product_id=b.id       
       INNER JOIN product p with(nolock) ON b.product_id=p.id ';  
  
  IF @IsPromotion IS NOT NULL 
  BEGIN     
      SET @FromSQL = @FromSQL + ' LEFT  JOIN product_promote AS px WITH(NOLOCK) ON p.id = px.product_id and px.is_promote=1 '
  END 
                  
  --查询记录数            
  SET @CountSQL = '';            
  SET @CountSQL = 'SELECT @RowCountOUT=count(a.id) ' + @FromSQL + @Condition;            
  --print @CountSQL;            
  EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;                     
            
  --查询的分页条件            
  IF ISNULL(@PageSize, 0) < 1                                   
  SET @PageSize = 50                                  
  SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                  
     IF ISNULL(@PageIndex, 0) < 1                                   
        SET @PageIndex = 1                                  
     ELSE                                   
     IF ISNULL(@PageIndex, 0) > @PageCount                                   
        SET @PageIndex = @PageCount                                  
     SET @Start = ( @PageIndex - 1 ) * @PageSize + 1            
     SET @End = @PageIndex * @PageSize            
               
  --组装查询语句            
  SET @SQL = 'SELECT a.id, ROW_NUMBER() OVER (ORDER BY a.id) RowIndex ' + @FromSQL + @Condition;            
              
  SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp         
   INNER JOIN ph_product_sale_price_alarm a WITH(NOLOCK) on a.id=temp.id          
   INNER JOIN ph_product b WITH(NOLOCK) ON a.product_id=b.id         
   INNER JOIN product p WITH(NOLOCK) ON b.product_id=p.id         
   LEFT  JOIN product_promote AS px WITH(NOLOCK) ON p.id = px.product_id and px.is_promote=1 
   LEFT JOIN ph_category_series AS ps     WITH(NOLOCK) ON ps.id = b.category_series_id 
   WHERE RowIndex between ' + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';            
  PRINT @SQL            
  EXEC(@SQL);                                    
  SELECT @RowCount                  
END


go



CREATE PROCEDURE CRM_Order_GetOrderResendRecordList
    @OrderIndustryType INT = -1 ,
    @OrderId VARCHAR(15) = '' ,
    @ApplyType INT = -1 ,
    @startDate VARCHAR(20) = '' ,
    @endDate VARCHAR(20) = '' ,
	@Initiator INT =-1,
    @PageNo INT = 0 ,
    @PageSize INT = 50
AS
    BEGIN
        DECLARE @Sql NVARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) ,
            @Where NVARCHAR(MAX) ,
            @Parameters NVARCHAR(1000) , -- 动态参数                                                            
            @PageCount INT ,
            @RowCount INT ,
            @Start INT , --每页的起始位置                                                            
            @End INT;  --每页的终止位置                                                            
        BEGIN                                                            
            SET NOCOUNT ON;                                                            
                                                             
   -- 条件，显示确认的网站订单或所有邮件订单                                                            
            SET @Where = ' WHERE a.ApplyType<>3 ';                                                            
                                                             
  -- 组合查询语句                                                            
            SET @CountSql = ' Select @pRowCount=Count(1)  FROM dbo.T_OrderResendRecord a With(NoLock) 
INNER JOIN t_order b WITH(NOLOCK) ON a.OrderId=b.OrderId ';      
            IF ( @OrderIndustryType > 0 )
                SET @Where = @Where
                    + ' and  b.OrderIndustryType=@pOrderIndustryType';
            IF ( LEN(@OrderId) > 0 )
                SET @Where = @Where + ' and a.OrderId=@pOrderId';
            IF ( @ApplyType > 0 )
                SET @Where = @Where + ' and  a.applyType=@pApplyType';   
            IF ( LEN(@startDate) > 0 )
                SET @Where = @Where + ' and a.CreateTime>=@pStartTime';
            IF ( LEN(@endDate) > 0 )
                SET @Where = @Where + ' and a.CreateTime<@pEndTime';
			IF(@Initiator>0)
			SET @Where=@Where+'  And OperatorId=@pInitiator'

            SET @CountSql = @CountSql + @Where;   
            SET @Parameters = N'@pRowCount INT OUT,@pOrderIndustryType int,@pOrderId VARCHAR(20),@pApplyType int ,@pStartTime nvarchar(20),@pEndTime nvarchar(20),@pInitiator int';			
            EXEC sp_executesql @CountSql,@Parameters,
                @pRowCount = @RowCount OUT,
                @pOrderIndustryType = @OrderIndustryType,@pOrderId = @OrderId,
                @pApplyType = @ApplyType,@pStartTime = @startDate,
                @pEndTime = @endDate,@pInitiator=@Initiator;

            EXEC [dbo].[CRM_PageCountGet] @PageNo,@PageSize,@RowCount,
                @Start OUT,@End OUT;   

            SET @Sql = ' with cte as 
			(Select b.OrderIndustryType,a.OrderId,a.InitiateOrderStatus,a.ApplyType,a.CreateTime,case when isnull(u.id,0)=0 then ''系统'' else u.name end as OperatorName,a.ProcessStatus,
			(SELECT name+'','' FROM dbo.department WHERE id IN( SELECT value FROM dbo.uf_Split(a.ReceivedepartmentIds,'','')) FOR XML PATH('''')) as ReceivingDepartment,
				 ROW_NUMBER() OVER(ORDER BY processStatus,CreateTime desc) AS RowNumber  
				FROM dbo.T_OrderResendRecord a With(NoLock) 
				INNER JOIN t_order b WITH(NOLOCK) ON a.OrderId=b.OrderId
				left JOIN dbo.[user] u WITH(NOLOCK) ON u.id=a.OperatorId';
            SET @Where = @Where + ')';

            SET @Where = @Where
                + 'select * from cte  where RowNumber BETWEEN @pStart AND @pEnd 
order by RowNumber ';
            SET @Sql = @Sql + @Where;      
				
            SET @Parameters = N'@pStart INT ,@pEnd INT,@pOrderIndustryType int,@pOrderId VARCHAR(20),@pApplyType int ,@pStartTime nvarchar(20),@pEndTime nvarchar(20),@pInitiator int';				
            EXEC sp_executesql @Sql,@Parameters,@pStart = @Start,@pEnd = @End,
                @pOrderIndustryType = @OrderIndustryType,@pOrderId = @OrderId,
                @pApplyType = @ApplyType,@pStartTime = @startDate,
                @pEndTime = @endDate,@pInitiator=@Initiator;
            PRINT @Sql;
        END
    END


go



---添加客服在线咨询列表
CREATE PROC CRM_Customer_AddOnlineServicerConsultInfo
(
	@EmailId int ,
	@CustomerName varchar(100) ,
	@CustomerSource INT ,
	@CustomerPhone varchar(50) ,
	@OrderId varchar(20) ,
	@DealTime VARCHAR(20),
	@IsSolve bit ,
	@IsPriority bit ,
	@ConsultContent nvarchar(500) ,
	@FollowUpExplain nvarchar(500) ,
	@ChattingRecords text ,
	@HandlerId int ,
	@DealUserId int ,
	@lang int ,
	@CountryId INT,
	@id int OUT 
)
AS        
BEGIN        
INSERT INTO T_OnlineServiceConsult
(
	EmailId ,
	CustomerName  ,
	CustomerSource ,
	CustomerPhone  ,
	OrderId  ,
	DealTime  ,
	IsSolve  ,
	IsPriority  ,
	ConsultContent  ,
	FollowUpExplain ,
	ChattingRecords  ,
	Status  ,
	HandlerId  ,
	DealUserId  ,
	lang  ,
	CountryId
)
VALUES
(
	@EmailId ,
	@CustomerName  ,
	@CustomerSource ,
	@CustomerPhone  ,
	@OrderId  ,
	@DealTime  ,
	@IsSolve  ,
	@IsPriority  ,
	@ConsultContent  ,
	@FollowUpExplain ,
	@ChattingRecords  ,
	0,
	@HandlerId  ,
	@DealUserId  ,
	@lang  ,
	@CountryId 
)
	  SET @Id=@@IDENTITY  ;
END


go


CREATE PROCEDURE [dbo].[US_Property_DeleteProperty]
(
	@PropertyId INT
)
AS
BEGIN 
	UPDATE dbo.T_Property_US SET IsDeleted=1 WHERE PropertyId=@PropertyId
END
go


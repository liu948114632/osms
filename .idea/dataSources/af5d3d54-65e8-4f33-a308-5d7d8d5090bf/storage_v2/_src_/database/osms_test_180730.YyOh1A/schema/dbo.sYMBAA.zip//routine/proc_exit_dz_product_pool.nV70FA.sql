/**
	@desc 退出电子业务备货商品
	@date 2016-05-18
	@author whw	
*/ 
CREATE PROC proc_exit_dz_product_pool(
	@EndDate DATETIME, --统计的结束日期
	@process_product_provider VARCHAR(max)=NULL --子膜供应商
)
AS
BEGIN
	WITH dz_product_ AS (
		SELECT d.*,p.offline_status,p.category_id_1,p.is_provider_stock
		 FROM dbo.dz_product_pool d WITH(NOLOCK)
		INNER JOIN dbo.product p WITH(NOLOCK) ON p.id =d.product_id
	
	) 	
	,exit_ AS (
		--2个月内没有订单，且永不退出标记为“否”的自动退出，排除原模产品
		SELECT d.product_id AS productId FROM dz_product_ d
		LEFT JOIN dbo.dz_count_order_product_sale_info(@EndDate,60) t ON t.product_id = d.product_id
		WHERE ( t.product_id IS NULL AND  d.is_forever_exit=0 AND d.pool_type=1)
		--所有永久下架，且永不退出标记为“否”的产品自动退出，包含原模产品
			OR( d.is_forever_exit=0 AND d.offline_status=2 )
		UNION
		SELECT d.product_id AS productId FROM dz_product_ d
    		LEFT JOIN dbo.category c WITH(NOLOCK) ON d.category_id_1=c.id AND c.type<>2		
			LEFT JOIN dbo.product_inventory i WITH(NOLOCK) ON i.product_id=d.product_id				
			LEFT JOIN dbo.product_pool ppl WITH(NOLOCK) ON ppl.product_id=d.product_id					
			LEFT JOIN dbo.product_ready_sell prs WITH(NOLOCK) ON prs.product_id=d.product_id	
			AND prs.is_ready_sell=1												
			WHERE i.id IS NOT  NULL										--非电子
				OR c.id IS NOT NULL										--非小批量
				or ppl.id IS NOT NULL									--非商品池
				OR prs.id IS NOT NULL									--非备货销售
				or d.is_provider_stock=1								--非供应商
				
	
		UNION
		--子模
		SELECT d.product_id AS productId FROM dz_product_ d
		LEFT JOIN  dbo.product_strategy ps WITH(NOLOCK)
		ON ps.product_id=d.product_id
		LEFT JOIN product_provider pp WITH(NOLOCK)
		ON ps.department_id=pp.department_id AND pp.product_id = ps.product_id
		LEFT JOIN storage_product_processing_accessories sppa WITH(NOLOCK) ON sppa.original_product_id=d.product_id
		
		WHERE sppa.id IS NULL AND  pp.provider_id IN (ISNULL(@process_product_provider,0))  --排除原膜
		
	)
	
	SELECT DISTINCT * FROM exit_
	
END
go


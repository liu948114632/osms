


/*------------------------------------------------------
报表统计-考核-新商品上传数理
frh 创建
up_Report_Assess_NewProductsCount '2008-01-01','2010-01-01','YW'
------------------------------------------------------*/
CREATE procedure [dbo].[up_Report_Assess_NewProductsCount]
(
	@StartTime		Datetime, 
	@EndTime		Datetime,
	@Stock			VARCHAR(10)
)
As
Begin
	SET NOCOUNT ON
	
	Declare @StockId INT;
	SET @StockId  = (SELECT ISNULL(Id,0) FROM dbo.C_Stock WHERE Short = @Stock);
	
	IF @StockId > 0
		BEGIN
			SELECT b.FirstName as UserName ,a.NewCount 
			From(
					SELECT COUNT(1) AS NewCount,b.UserId 
					FROM dbo.C_Product a
					Join dbo.C_ProductStepTimeLog b  On a.id = b.ItemId 
					WHERE a.StockId = @StockId AND b.AddTime > @StartTime AND b.AddTime < @EndTime
					GROUP BY UserId
			) a LEFT JOIN dbo.B_User b 
				ON a.UserId = b.Id 
			Order by b.FirstName
		END
	
End


go



/*匹配订单对应的嫌疑客户地址
2、嫌疑客户，订单的账单地址，也纳入判断。即 A 客户被设置为嫌疑，则 
2.1 当B客户的订单，货运地址 与 A的 历史订单货运地址或 历史订单账单地址 的 国家+电话 相同，则 提醒B 有嫌疑 
2.2 当B客户的订单，账单地址 与 A的 历史订单货运地址或 历史订单账单地址 的 国家+电话 相同，则 提醒B 有嫌疑
*/
CREATE PROC dbo.CRM_Order_GetSuspicionMarkingAddress
(
@OrderId VARCHAR(20)
)
AS
BEGIN
SELECT TOP 1 b.OrderId
FROM  dbo.T_OrderAddresses  a  WITH(NOLOCK)
INNER JOIN dbo.T_Order b WITH(NOLOCK) ON a.AddressId=b.ShipAddressId
INNER JOIN dbo.T_OrderAddresses a2 WITH(NOLOCK) ON a2.AddressId=b.BillAddressId
INNER JOIN dbo.T_Customer c WITH(NOLOCK) ON b.CustomerId=c.UserID AND c.SuspicionMarking=1
WHERE EXISTS(SELECT TOP 1 1  FROM   dbo.T_Order o 
INNER JOIN dbo.T_OrderAddresses oa ON o.ShipAddressId=oa.AddressId  
INNER JOIN dbo.T_OrderAddresses oa2 ON o.BillAddressId=oa2.AddressId  
WHERE 1=1
AND 
(
a.Country=oa.Country  AND a.Phone=oa.Phone 
OR a2.Country=oa.Country  AND a2.Phone=oa.Phone 

OR a.Country=oa2.Country AND a.Phone=oa2.Phone 
OR a2.Country=oa2.Country AND a2.Phone=oa2.Phone 
)
AND  o.OrderId=@OrderId AND c.UserID<>o.CustomerId 
)
ORDER BY b.OrderId
END
go



CREATE VIEW view_ph_product_best_seller_operation_department   
AS 
SELECT   ROW_NUMBER() OVER (ORDER BY c.id ASC) AS row_id  
,c.id AS id   
,c.product_id AS product_id     
,cmsp.category_id_1 AS category_id_1   
,cmsp.category_id_2 AS category_id_2   
,cmsp.category_id_3 AS category_id_3    
,(SELECT name FROM dbo.category  WHERE id = cmsp.category_id_1) AS category_Name_1    
,(SELECT name FROM dbo.category  WHERE id = cmsp.category_id_2) AS category_Name_2    
,(SELECT name FROM dbo.category  WHERE id = cmsp.category_id_3) AS category_Name_3    
,cmsp.code AS product_code
,cmsp.name AS  product_Name
,cmsp.original_name AS product_original_name    
,cmsp.unit_quantity AS product_quantity 
,cmsp.unit AS unit
,p.current_cost_price AS cost_price    
,c.competitor_type AS competitor_id 
,c.product_code AS competitor_code 
,c.batch_quantity AS competitor_quantity    
,c.estimate_cost_price AS competitor_cost_price
,c.sale_price AS competitor_sale_price    
,c.profit_coefficient AS competitor_profit_coefficient    
,c.link_address AS competitor_link,c.user_id AS competitor_creator_id    
,c.create_time AS competitor_create_time,c.update_time AS competitor_update_time    
,p.is_best_sellers AS is_best_sellers    
,p.is_competitor_best_sellers AS is_competitor_best_sellers 
,cast(round(c.batch_quantity/cmsp.unit_quantity,2)as numeric(18,2))AS  quantityContrast
,cast(round(c.sale_price /(cmsp.cost_price/8.2*p.first_profit_coefficient),2)as numeric(18,2)) AS unitSalePriceContrast
,cast(round((c.estimate_cost_price / cmsp.cost_price),2)as numeric(18,2)) AS cost_price_range 
,(p.current_cost_price*cmsp.unit_quantity/8.2*p.first_profit_coefficient) AS phSalePrice
,p.first_profit_coefficient AS phFirstProfitCoefficient
FROM dbo.ph_product_best_seller a WITH(NOLOCK)
INNER JOIN dbo.ph_product p WITH(NOLOCK) ON a.product_id=p.product_id 
INNER JOIN dbo.ph_product_competitor c WITH(NOLOCK) ON c.product_id=p.product_id
LEFT JOIN dbo.product cmsp WITH(NOLOCK) ON cmsp.id=p.product_id
WHERE a.type=1
go


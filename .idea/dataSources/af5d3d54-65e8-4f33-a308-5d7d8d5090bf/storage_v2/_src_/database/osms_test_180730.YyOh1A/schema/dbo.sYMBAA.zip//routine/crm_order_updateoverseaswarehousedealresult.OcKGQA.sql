


/**    
保存海外仓订单处理结果    
*/    
CREATE PROC dbo.CRM_Order_UpdateOverseasWarehouseDealResult    
(    
  @OrderId VARCHAR(20),    
  @IsGoOverseasWarehouse BIT,--订单是否走海外仓    
  @GoOverseasWarehouseItemIds VARCHAR(max),--走海外仓的订单项ID,多个用逗号隔开    
  @StockOutCode VARCHAR(MAX), --海外仓出库单单号    
  @Warehouse VARCHAR(20), --出库仓库    
  @ExpressService VARCHAR(20), --海外仓的快递服务    
  @Log VARCHAR(max), --日志信息
@LogisticsCarriersCode VARCHAR(50)=''  --物流服务商ID
)    
AS    
BEGIN      
    DECLARE @OrderItems TABLE(OrderItemId INT );
    DECLARE @WarehouseId INT;    
	DECLARE @pRemark VARCHAR(500);
	DECLARE @LogisticsCarriersId INT;
    
    --取仓库ID
    SELECT @WarehouseId = ID
    FROM dbo.T_OverseasWarehouse
    WHERE WarehouseCode = @Warehouse
SELECT @LogisticsCarriersId=id FROM dbo.T_OverseasWarehouseLogisticsCarriers WHERE LogisticsCarriersCode=@LogisticsCarriersCode AND WarehouseId=@WarehouseId

	 INSERT INTO @OrderItems(OrderItemId)          
	 SELECT [Value]           
	 FROM dbo.uf_Split(@GoOverseasWarehouseItemIds,',');    
	   
     IF @IsGoOverseasWarehouse = 1    
     BEGIN    
	         IF @Warehouse='USEA'
			 BEGIN
	 			  SET @pRemark=N'提交订单商品到USA海外仓成功';
			 END
			 ELSE
             BEGIN
                 SET @pRemark=N'提交订单商品到'+@Warehouse+'海外仓成功';
			 END 
		
SET @pRemark=@pRemark+';出库单号:'+@StockOutCode

			--记录订单历史    
		   EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int    
			@OrderId = @OrderId, -- varchar(14)    
			@Remark =@pRemark  -- varchar(5000)    
		         
		  --修改订单项状态    
			 UPDATE b SET IsGoOverseasWarehouse = 1,    
			 ReadyQty = Quantity,    
			 Status = 6,
			 b.WarehouseStockId=@WarehouseId
		   FROM @OrderItems a     
		   JOIN dbo.T_OrderItem b ON a.OrderItemId = b.OrderItemId    
          
		   --修改订单海外仓状态    
           IF ( EXISTS ( SELECT TOP 1
                                1
                         FROM   T_OrderItem
                         WHERE  OrderId = @OrderId
                                AND Status < 12
                                AND IsGoOverseasWarehouse = 0 ) )
            BEGIN    
                UPDATE  T_Order
                SET     OverseasWarehouseStatus = 20,
				IsOverseasWarehouseOrder=1
                WHERE   OrderId = @OrderId;    
		          
			 --记录订单历史    
                EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int    
                    @OrderId = @OrderId, -- varchar(14)    
                    @Remark = N'订单转为部分海外仓订单'; -- varchar(5000)    
            END;     
           ELSE
            BEGIN    
                UPDATE  T_Order
                SET     OverseasWarehouseStatus = 30,
				IsOverseasWarehouseOrder=1
                WHERE   OrderId = @OrderId;    
		          
			 --记录订单历史    
                EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int    
                    @OrderId = @OrderId, -- varchar(14)    
                    @Remark = N'订单转为全海外仓订单'; -- varchar(5000)    
            END;     

		   --保存出库单信息    
		   INSERT INTO dbo.T_OverseasWarehouseStockOutOrder    
			 ( OrderId ,    
			   StockOutCode ,    
			   ExpressService,    
			   Warehouse,    
			   CreateTime ,    
			   Status,
			   LogisticsCarriersId
			 )    
			SELECT @OrderId,Value,@ExpressService,@Warehouse,GETDATE(),20,@LogisticsCarriersId FROM dbo.uf_Split(@StockOutCode,',') 
			 
	  	 --保存出库单项    
		   INSERT into dbo.T_OverseasWarehouseStockOutOrderItem    
			 ( OrderItemId ,    
			   StockOutCode ,    
			   StockOutQty,
			   StorageNo    
			 )    
		   SELECT a.OrderItemId,
			(SELECT TOP 1 Value  FROM dbo.uf_Split(@StockOutCode,',')),--US分出库单，多个只存一个
		   b.ReadyQty,
		   (SELECT TOP 1 c.CK1StorageNo FROM  T_OverseasWarehouseProduct  c WHERE b.CmsProductId=c.CMSProductId AND c.WarehouseId = @WarehouseId AND c.IsDelete=0)
		   FROM @OrderItems a     
		   JOIN dbo.T_OrderItem b ON a.OrderItemId = b.OrderItemId  

		  ----修改转运商品的库存编码
		  --IF EXISTS(SELECT TOP 1 1 FROM dbo.T_Order WHERE OrderId=@OrderId AND TransshipmentStatus>0)
		  --BEGIN
		  --UPDATE T_OverseasWarehouseStockOutOrderItem SET StorageNo=(SELECT TOP  1 StorageNo FROM dbo.T_OrderTransshipmentVirtualProduct WHERE OrderId=@OrderId) 
		  --WHERE StockOutCode=@StockOutCode
		  --AND StorageNo IS NULL
		  --END
                  
			--自动更新订单状态    
			DECLARE @UpdatedStatus INT     
			EXEC dbo.CRM_Order_OrderStatusCheck @OrderId = @OrderId, @UpdatedStatus = @UpdatedStatus OUT -- int   
      END     
      ELSE     
      BEGIN    
			--如果订单都不能走海外仓，则设置为非海外仓订单    
			UPDATE dbo.T_Order SET OverseasWarehouseStatus = 0,IsOverseasWarehouseOrder = 0    
			WHERE OrderId = @OrderId    
              
            IF (LEN(@Log) > 0 )
            BEGIN
                EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int    
				@OrderId = @OrderId, -- varchar(14)   
				@Remark = @Log
            END 
            ELSE
            begin
                 --记录订单历史    
				EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int    
				@OrderId = @OrderId, -- varchar(14)    
				@Remark = N'提交订单商品到海外仓失败，订单转到CMS' -- varchar(5000)   
            END 
			 
      END     
END


go


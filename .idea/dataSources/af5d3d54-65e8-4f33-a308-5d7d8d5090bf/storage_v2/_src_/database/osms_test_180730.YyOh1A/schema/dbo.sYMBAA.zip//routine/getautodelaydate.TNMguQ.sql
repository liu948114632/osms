
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetAutoDelayDate]
(
	-- Add the parameters for the function here
    @OrderId VARCHAR(20)
)
RETURNS DATETIME
AS
BEGIN
	-- Declare the return variable here
	DECLARE @AutoDelayDate DATETIME

	DECLARE @OrderItemCount INT,
			@Days INT, 
			@DisposeDate DATETIME -- 录单时间
					
		-- 获取订单商品数量
		SET @OrderItemCount = 0
		SELECT @OrderItemCount = COUNT(1) FROM t_OrderItem where OrderId = @OrderId AND status < 12
		
		-- 商品项数＜10，X=7天；
		IF( @OrderItemCount < 10 )
		BEGIN
			SET @Days = 7	
		END
		-- 	10≤商品项数≤100， X=8天；
		IF( @OrderItemCount >= 10 AND @OrderItemCount <= 100 )
		BEGIN
			SET @Days = 8
		END
		-- 	商品项数＞100， X=10天
		IF(  @OrderItemCount > 100  )
		BEGIN
			SET @Days = 10
		END
		SET @DisposeDate = '2011-10-07'
		SET @AutoDelayDate =  DATEADD(dd,@Days,@DisposeDate)
--		UPDATE t_Order SET AutoDelayDate = @AutoDelayDate WHERE OrderId = @OrderId;

	-- Return the result of the function
	RETURN @AutoDelayDate

END

go



--ALTER PROC CRM_Order_UpdateOrderActualFreightCosts
--(
--@OrderId VARCHAR(20),
--@FreightCosts DECIMAL(12,2)
--)
--AS
--BEGIN
--	UPDATE dbo.T_OrderPrice SET ActualFreightCost=@FreightCosts WHERE OrderId=@OrderId;
--END
--GO

  
  
/*----------------------------------------------------            
[备注] 获得运费计算的重量：订单重量与发货重量；到货重量与发货重量        
        
   1.1 PH订单结算规则修改：        
 a.当网重>发货重量*1.1，取发货重量        
 b.当网重<发货重量*1.1，取网站重量        
        
   1.2 PW订单结算规则修改： (注：有PW订单就按PW规则，JL订单也按PW规则）       
 实重大于网重:        
  a.当网重x1.1 <实重 , 按实重结算,         
  b.当网重x1.1 >实重, 按网重结算        
 实重小于网重:        
  a. 当实重x1.1<网重 , 按实重结算         
  b. 当实重x1.1>网重 , 按网重结算        
           
   2.0 当按发货重量计算的运费大于按订单重量计算的运费时:取订单重量        
------------------------------------------------------*/            
CREATE  PROCEDURE [dbo].[CRM_Weight_OrderWeightOrPostWeightGet]      
    (      
      @OrderIds VARCHAR(MAX) , -- 订单编号多个用,号相隔        
      @Weight INT OUT , -- 重量        
      @WeightType INT OUT , -- 1：订单重量 2：发货重量        
      @ReadyWeight INT OUT , -- 到货重量        
      @ReadyWeightType INT OUT  -- 1：订单到货重量 2：发货到货重量        
    )      
AS      
    BEGIN        
        SET NOCOUNT ON;         
        SET @Weight = 0;      
        SET @ReadyWeight = 0;      
        SET @WeightType = 1;        
        SET @ReadyWeightType = 1;        
        -- 用来缓存所有订单              
        DECLARE @Orders TABLE ( OrderId VARCHAR(20) );        
               
        INSERT INTO @Orders ( OrderId )      
        SELECT [Value] FROM dbo.uf_Split(@OrderIds, ',');       
          
        -- 获取订单重量，和到货订单重量        
        EXEC CRM_Price_OrderValidWeightGet @OrderId = @OrderIds, @Weight = @Weight OUT, @ReadyWeight = @ReadyWeight OUT;        
         
        -- 获取第一个订单号        
        DECLARE @FirstOrderId VARCHAR(20);        
        SELECT TOP 1 @FirstOrderId = OrderId FROM @Orders;     
          
        -- 获得发货重量        
        DECLARE @OrderIndustryType INT ,      
            @PostWeight INT;        
        SELECT  @PostWeight = PostWeight      
        FROM    dbo.T_Order      
        WHERE   OrderId = @FirstOrderId;        
         
        IF ISNULL(@PostWeight, 0) = 0      
        BEGIN        
            RETURN;        
        END             
   
        --如果有海外仓订单，则只按网重计算运费      
        IF EXISTS ( SELECT TOP 1      
                            1      
                    FROM    @Orders a      
                            JOIN dbo.T_Order b ON a.OrderId = b.OrderId      
                    WHERE   b.IsOverseasWarehouseOrder = 1 )      
        BEGIN        
                RETURN;        
        END         
          
        -- 计算运费用        
        DECLARE @CountryId INT ,      
            @DeliveryId INT ,      
            @IsRemote BIT ,      
            @OrderFreight DECIMAL(18, 2) ,      
            @OrderReadyFreight DECIMAL(18, 2) ,      
            @PostFreight DECIMAL(18, 2) ,      
            @PostReadyFreight DECIMAL(18, 2)         
         
        -- 获得CountryId, DeliveryId, IsRemote        
        SELECT  @CountryId = Country ,      
                @DeliveryId = DeliveryId ,      
                @IsRemote = IsRemote ,      
                @OrderIndustryType = OrderIndustryType      
        FROM    dbo.T_Order      
                JOIN dbo.T_OrderAddresses ON dbo.T_Order.ShipAddressId = dbo.T_OrderAddresses.AddressId      
        WHERE   OrderId = @FirstOrderId;        
           
            
        -- 如果有PW订单一起结算，就按PW订单方式结算      
        IF EXISTS ( SELECT  1      
                    FROM    @Orders      
                            JOIN dbo.T_Order ON [@Orders].OrderId = dbo.T_Order.OrderId      
                    WHERE   dbo.T_Order.OrderIndustryType = 16 )      
            BEGIN        
                SET @OrderIndustryType = 16;        
            END         
         
          
        -- 订单重量和发货重量对比        
        EXEC dbo.CRM_Weight_WeightContrast @Weight, @PostWeight, @OrderIndustryType, @WeightType OUT;        
        -- 按发货重量计算运费        
        IF ( @WeightType = 2 )      
            BEGIN        
               IF NOT EXISTS(SELECT TOP 1 1 FROM T_OrderDeliveryArea WHERE OrderId=@FirstOrderId)    
                    BEGIN    
                        -- 获取按发货重量计算的运费        
                        EXEC CRM_Freight_FreightGet @CountryId, @DeliveryId, @IsRemote, @PostWeight, @PostFreight OUT;         
                        -- 获得按订单重量计算的运费        
                        EXEC CRM_Freight_FreightGet @CountryId, @DeliveryId, @IsRemote, @Weight, @OrderFreight OUT;        
                    END    
                ELSE    
                    BEGIN    
                        EXEC CRM_Order_GetFreightWithSurchargeBySnapshot @OrderId=@FirstOrderId, @IsRemote=@IsRemote, @Weight=@PostWeight, @Freight=@PostFreight OUT;    
                        EXEC CRM_Order_GetFreightWithSurchargeBySnapshot @OrderId=@FirstOrderId, @IsRemote=@IsRemote, @Weight=@Weight, @Freight=@OrderFreight OUT;    
    
                    END    
                        
                -- 发货运费 > 订单运费        
                IF @PostFreight > @OrderFreight      
                    BEGIN        
                        SET @WeightType = 1;        
                    END         
                ELSE      
          BEGIN        
                        SET @WeightType = 2;        
                        SET @Weight = @PostWeight;        
                    END          
            END         
         
        -- 订单到货重量和发货重量对比        
        EXEC dbo.CRM_Weight_WeightContrast @ReadyWeight, @PostWeight, @OrderIndustryType, @ReadyWeightType OUT;        
        -- 按发货重量计算运费        
        IF ( @ReadyWeightType = 2 )      
            BEGIN        
                    
                IF NOT EXISTS(SELECT TOP 1 1 FROM T_OrderDeliveryArea WHERE OrderId=@FirstOrderId)    
                    BEGIN                    
                        -- 获取按发货重量计算的运费        
                        EXEC CRM_Freight_FreightGet @CountryId, @DeliveryId, @IsRemote, @PostWeight, @PostReadyFreight OUT;        
                        -- 获取按订单到货重量计算的运费        
                        EXEC CRM_Freight_FreightGet @CountryId, @DeliveryId, @IsRemote, @ReadyWeight, @OrderReadyFreight OUT;        
                    END    
                ELSE    
                    BEGIN    
                        EXEC CRM_Order_GetFreightWithSurchargeBySnapshot @OrderId=@FirstOrderId, @IsRemote=@IsRemote, @Weight=@PostWeight, @Freight=@PostReadyFreight OUT;    
                        EXEC CRM_Order_GetFreightWithSurchargeBySnapshot @OrderId=@FirstOrderId, @IsRemote=@IsRemote, @Weight=@ReadyWeight, @Freight=@OrderReadyFreight OUT;                        
                    END    
                        
                -- 发货运费 > 订单到货运费        
                IF @PostReadyFreight > @OrderReadyFreight      
                    BEGIN        
                        SET @ReadyWeightType = 1;        
                    END         
                ELSE      
                    BEGIN        
                        SET @ReadyWeightType = 2;        
                        SET @ReadyWeight = @PostWeight;        
                    END         
         
            END          
    END
go


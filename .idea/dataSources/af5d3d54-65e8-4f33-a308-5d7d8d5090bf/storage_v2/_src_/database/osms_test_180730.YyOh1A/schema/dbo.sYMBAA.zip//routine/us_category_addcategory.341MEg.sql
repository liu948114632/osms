CREATE PROCEDURE [dbo].[US_Category_AddCategory]
(
	@CategoryId INT
)
AS
BEGIN 
	IF NOT EXISTS (SELECT 1 FROM dbo.T_Category_US WHERE CategoryId=@CategoryId)
	BEGIN
		INSERT INTO dbo.T_Category_US (
			CategoryId,
			IsDeleted,
			CreateDate,
			LastUpdateDate
		) VALUES ( 
			@CategoryId,
			0,
			GETDATE(),
			GETDATE() ) 
	END
	ELSE
	BEGIN
		UPDATE dbo.T_Category_US SET IsDeleted=0,LastUpdateDate=GETDATE() WHERE CategoryId=@CategoryId
	END
END
go


  
/*-------------------------------------  
[描述]分解字符串  
[作者]FRH  
[时间]2008-08-08  
----------------------------------*/  
CREATE FUNCTION [dbo].[uf_Split]  
(  
 @Text VARCHAR(MAX),  
 @Split VARCHAR(2) = ','  
)  
RETURNS @Table TABLE([Id] INT IDENTITY(1, 1) NOT NULL, [Value] VARCHAR(4000))  
AS  
BEGIN  
 DECLARE @i INT;-- 分隔符所在位置  
    DECLARE @s INT;-- 搜索起点位置  
    DECLARE @tempStr varchar(100);--临时变量
    SET @i=1;  
    SET @s=1;  
      
    WHILE(@i>0)  
    BEGIN     
  -- 搜索分隔符位置   
        SET @i = CHARINDEX(@Split,@Text,@s);  
        IF(@i > 0)  
        BEGIN  
			set @tempStr = SUBSTRING(@Text,@s,@i - @s);
            --INSERT INTO @Table([Value]) VALUES(SUBSTRING(@Text,@s,@i - @s));  
        END     
        ELSE BEGIN  
	        set @tempStr = SUBSTRING(@Text,@s,LEN(@Text)- @s + 1);
            --INSERT INTO @Table([Value]) VALUES(SUBSTRING(@Text,@s,LEN(@Text)- @s + 1));  
        END  
		set @tempStr = rtrim(ltrim(@tempStr));
		if not exists(select Id from @Table where [Value] = @tempStr)    
		begin
			INSERT INTO @Table([Value]) VALUES(rtrim(ltrim(@tempStr)));  		
		end

        SET @s = @i + 1; -- 搜索开始位置匹配到的分隔符往后推    
    END  
      
    RETURN  -- 返回结果  
END

go


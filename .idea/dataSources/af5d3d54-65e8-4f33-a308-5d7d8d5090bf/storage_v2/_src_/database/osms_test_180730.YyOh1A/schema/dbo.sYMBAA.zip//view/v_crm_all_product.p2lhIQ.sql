 CREATE VIEW V_CRM_All_Product          
AS              
SELECT           
a.id AS CmsProductId,          
b.id AS PhProductId,          
c.id AS PwProductId,          
d.id AS ProductSetId,          
d.code AS ProductSetCode,          
e.id AS JlProductId,  
f.id AS UkProdutId,
g.id AS USProductId,
a.code,               
a.name,                  
a.unit_quantity AS UnitQuantity,               
a.unit,           
a.weight,               
a.volume,         
a.cost_price AS BasePrice,         
(case when isnull(a.category_id_3,0) = 0 then (case when isnull(a.category_id_2,0) = 0 then a.category_id_1 else a.category_id_2 end) else a.category_id_3 end) AS  CategoryId,      
a.category_id_1 AS CategoryId1,               
a.category_id_2 AS CategoryId2,               
a.category_id_3 AS CategoryId3,            
CAST(a.is_display_ph AS BIT) AS IsDisplayPh,          
CAST(a.is_display_pw AS BIT) AS IsDisplayPw,          
CAST(a.is_display_jl AS BIT) AS IsDisplayJl,  
a.color_card_picture_code AS ColorCardPictureCode,          
a.primary_picture_code AS PrimaryPictureCode,          
CAST(ISNULL(b.is_promotional,0) AS BIT) AS IsPHPromote,            
CAST(ISNULL(c.is_promotional,0) AS BIT) AS IsPWPromote,            
CAST(0 AS BIT) AS IsJLPromote,
CAST(ISNULL(b.is_pool,0) AS BIT) AS IsPHProductPool,            
CAST(ISNULL(c.is_pool,0) AS BIT) AS IsPWProductPool,           
CAST(0 AS BIT) AS IsJLProductPool,
a.publish_status AS PublishStatus,          
CAST(a.is_gift AS BIT) AS IsGift,              
CAST(a.is_mix AS BIT) AS IsMix,
a.operating_cost_price AS OperatingCostPrice
FROM dbo.product a WITH(NOLOCK)          
LEFT JOIN dbo.ph_product b WITH(NOLOCK) ON a.id=b.product_id          
LEFT JOIN dbo.pw_product c WITH(NOLOCK) ON a.id=c.product_id           
LEFT JOIN product_set d WITH(NOLOCK) ON a.product_set_id=d.id          
LEFT JOIN dbo.jl_product e WITH(NOLOCK) ON a.id=e.product_id
LEFT JOIN dbo.uk_product f WITH(NOLOCK) ON a.id=f.product_id
LEFT JOIN dbo.us_product g WITH(NOLOCK) ON a.id=g.product_id
WHERE (b.is_on_shelf=1 OR c.is_on_shelf=1 OR e.is_on_shelf=1 OR f.is_on_shelf=1 ) AND a.is_delete=0

 go


/*------------------------------------------          
备注:完成现金券订单 ,录单后直接完成，将商品备货量=需求量
------------------------------------------------------*/          
CREATE PROC [dbo].[CRM_Order_CompleteCashOrder]          
(          
  @OrderId VARCHAR(20)   
)          
AS           
BEGIN       

    UPDATE dbo.T_Order SET OrderStatus = 128,  
                           LastModifyTime = GETDATE()  
    WHERE dbo.T_Order.OrderId = @OrderId

     -- 完成订单项      
  UPDATE dbo.T_OrderItem      
  SET [Status] = 10,
  ReadyQty=Quantity
  WHERE OrderId = @OrderId
END
go


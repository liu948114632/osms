
/**
获得订单原始价格总金额
*/
CREATE PROC CRM_Order_GetOrderOriginalProductPrice
(
   @OrderId VARCHAR(20),
   @OriginalProductPrice DECIMAL(18,2) OUT 
)
AS
BEGIN
     SELECT @OriginalProductPrice = CONVERT(DECIMAL(18,2),SUM(SalePrice * Quantity / UnitQuantity))
     FROM dbo.T_OrderItem
     WHERE OrderId=@OrderId AND Status<12
     
     IF( @OriginalProductPrice IS NULL )
        SET @OriginalProductPrice = 0
END
go


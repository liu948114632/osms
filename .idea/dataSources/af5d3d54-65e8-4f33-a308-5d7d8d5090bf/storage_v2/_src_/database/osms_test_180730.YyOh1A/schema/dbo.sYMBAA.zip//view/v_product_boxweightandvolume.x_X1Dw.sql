
CREATE VIEW V_Product_BoxWeightAndVolume
AS 
SELECT a.CmsProductId,a.code,
   (CASE WHEN a.ProductWeight >0 AND a.ProductVolume > 0 THEN a.ProductWeight ELSE CEILING(a.UnitQuantity* ISNULL(a.weight,0) * ISNULL(b.weight_rate,0)) END) AS BoxUnitWeight,
   (CASE WHEN a.ProductWeight >0 AND a.ProductVolume > 0 THEN a.ProductVolume ELSE 
     (CASE WHEN a.volume >0 THEN  CONVERT(DECIMAL(18,3),a.UnitQuantity* ISNULL(a.volume,0) * ISNULL(b.package_volume_rate,0))
	   WHEN b.volume_rate >0 THEN  CONVERT(DECIMAL(18,3),a.UnitQuantity* ISNULL(a.weight,0) * ISNULL(b.volume_rate,0) * ISNULL(b.package_volume_rate,0)) 
	   ELSE 0
	   END
	 ) END) AS BoxUnitVolume
FROM V_CRM_Base_Product a
JOIN dbo.V_CMS_ALL_Category b ON a.CategoryId=b.category_id
go


     
CREATE PROC [dbo].[CMS_ProcessingDepartment_GetAssignmentProduct]
    (
      @StockOutId INT = NULL ,
      @DepartmentId INT = NULL  
    )
AS 
    BEGIN                        
        SET NOCOUNT ON ;
         IF OBJECT_ID('#temp_processing_department_assignment_product') IS NOT NULL 
            DROP TABLE #temp_assignment_product ;            
        WITH    cat_order_item_table
                  AS ( SELECT   b.order_item_id,SUM(b.actual_quantity) AS assign_qty
                       FROM     dbo.view_all_storage_task AS b WITH ( NOLOCK )
                                INNER JOIN dbo.stock_out_ref_storage_task AS c
                                WITH ( NOLOCK ) ON c.storage_task_id = b.id
                       WHERE    c.stock_out_id = @StockOutId GROUP BY b.order_item_id
                     ),
                cat_stock_out_item
                  AS ( SELECT   a.product_id ,
                                SUM(a.quantity) AS stock_out_qty
                       FROM     dbo.stock_out_item AS a WITH ( NOLOCK )
                       WHERE    a.stock_out_id = @StockOutId
                       GROUP BY product_id
                     )
            SELECT  temp.id AS orderItemId ,
                    temp.order_id AS orderId ,
                    temp.department_id AS departmentId ,
                    temp.code AS orderCode ,
                    unit AS productUnit,
                    temp.product_id AS productId ,
                   ( temp.quantity - temp.prepareLockQty2) 
                      AS assignQuantity,
                    ( temp.quantity - temp.prepareLockQty2) 
					 AS orderAssignQuantity 
                    ,co.number AS position,us.name AS assignPersion
                    INTO #temp_processing_department_assignment_product
            FROM    ( SELECT    i.id ,
								o.id AS order_id,
                                ( i.plan_quantity ) AS quantity ,
                                i.product_id ,
                                i.unit ,
                                i.processing_id ,
                                o.code ,
                                o.department_id ,
                                o.create_time,
                                a.stock_out_qty ,
                                o.processor_id,
                                o.status,
                                i.task_status,
                                o.task_type,
                                  ISNULL(( SELECT SUM(sp.assign_quantity)
                                         FROM   dbo.assigment_stay_product AS sp
                                         WHERE  sp.order_item_id = i.id
                                                AND sp.status IN (0,1,2) AND sp.department_id =@DepartmentId
                                       ), 0) AS prepareLockQty2 ,
                                CASE WHEN e.order_item_id = i.id THEN 1
                                     ELSE 0
                                END stockOutSort
                      FROM      cat_stock_out_item AS a
                                INNER JOIN dbo.processing_item AS i ON a.product_id = i.product_id
                                INNER JOIN dbo.processing AS o ON o.id = i.processing_id
                                LEFT JOIN cat_order_item_table AS e ON e.order_item_id = i.id
                      WHERE     o.department_id = @DepartmentId
                                AND o.status <= 20  AND i.status IN (1,2,3) 
                                
                    ) temp   LEFT JOIN dbo.processing_processor_code co ON co.processor_id =temp.processor_id
                     LEFT JOIN dbo.[user] us ON us.id =co.processor_id
            WHERE   temp.quantity > prepareLockQty2
            ORDER BY temp.stockOutSort DESC ,temp.status DESC,
            CASE WHEN temp.task_status=1 THEN 20 ELSE temp.task_status END DESC ,
            CASE WHEN temp.task_type IS NULL OR temp.task_type=0 THEN 20 ELSE temp.task_type END  ASC,
                    temp.create_time ASC   
        SELECT * FROM #temp_processing_department_assignment_product;
                
        DROP TABLE #temp_processing_department_assignment_product;                  
        SET NOCOUNT OFF ;         
    END


go



    
/*--------------------------------------------------    
[备注]    
 保存海运港口    
------------------------------------------------------*/    
CREATE PROCEDURE [dbo].[CRM_Order_OrderPortToPortUpdate]     
(    
 @OrderId  VARCHAR(20),    
 @Port   VARCHAR(100) ,  
 @OperatorId INT    
)    
AS    
DECLARE @AddressId INT;    
BEGIN    
 SELECT @AddressId = ShipAddressId FROM dbo.T_Order WHERE OrderId = @OrderId;    
    
 Update    
  T_OrderAddresses    
 Set       
  Port   = @Port    
 Where     
  AddressId  = @AddressId;    
    
  DECLARE @Log VARCHAR(100)  
  SET @Log = N'修改货运港口为：' + isnull(@Port,'')  
    
  EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = @OperatorId, -- int  
      @OrderId = @OrderId, -- varchar(14)  
      @Remark = @Log-- varchar(5000)  
    
END
go


 
-- =============================================    
-- Author:  <Author,,Name>    
-- Create date: <Create Date,,>    
-- Description: <Description,,>    
-- =============================================    
CREATE PROCEDURE CMS_GetWaitAssignOrderPositionOrder    
AS    
BEGIN    
--;WITH orderCount AS (     
--SELECT COUNT(a.id) AS freezeItemqty,a.order_id  FROM dbo.order_item a WITH(nolock) JOIN (    
-- SELECT SUM(plan_quantity) AS qty,order_item_id  FROM  dbo.storage_task WITH(nolock) WHERE status = 0 GROUP BY order_item_id    
--) b ON a.id =b.order_item_id AND a.order_quantity =b.qty AND a.status!=12 GROUP BY a.order_id     
--)    
--SELECT  DISTINCT a.order_id AS orderId    
--FROM    order_group_position_log a WITH(nolock)    
--        JOIN dbo.small_lot_order b WITH(nolock) ON a.order_id = b.order_id    
--        JOIN dbo.[order] d WITH(nolock) ON d.id = a.order_id    
--        LEFT JOIN orderCount f ON f.order_id=a.order_id    
--WHERE   a.status = 1     
--        AND ( b.is_deleted = 0  OR d.type  NOT IN (1,2) OR d.is_need_processing = 1  OR EXISTS   
--        (SELECT TOP 1 ta.* FROM stock_out_ref_storage_task ta JOIN dbo.view_all_storage_task vi ON ta.storage_task_id =vi.id WHERE vi.order_id =d.id )  
--        -- 物流部门的出库单订单关系    
--    OR EXISTS ( SELECT id FROM department_stock_out_ref_order o WHERE o.order_id = a.order_id )    
--   --预分配    
--    OR EXISTS (SELECT id FROM assigment_stay_product p WHERE p.order_id =a.order_id AND p.status <>0   )    
--   --按订单出库订单    
--              OR ( (( SELECT COUNT(id)--杂物箱的订单    
--                     FROM   dbo.order_group_position_log c WITH(nolock)    
--                     WHERE  c.order_id = a.order_id    
--                   ) = 1    
--                   AND d.valid_order_count = 1)    
--                 )    
--                OR (d.valid_order_count-ISNULL(f.freezeItemqty,0)<=(SELECT value  FROM dbo.common_sys_config WHERE _key='TASK_FREEZE_QTY')  ) --未到货商品项数    
--                OR ((d.valid_order_count-ISNULL(f.freezeItemqty,0))*1.0/d.valid_order_count<(SELECT value  FROM dbo.common_sys_config WHERE _key='TASK_FREEZE_RATE') )--未到货率    
--            );    
--  --预分配商品 补齐箱位  
--  UPDATE a SET a.order_position=b.position FROM  dbo.assigment_stay_product  a  
--JOIN dbo.order_item_group b ON a.order_item_group_id =b.id  
--WHERE status = 1 AND order_position IS NULL  
SELECT a.order_Id FROM order_group_position_log a
--JOIN dbo.small_lot_order b WITH(nolock) ON a.order_id = b.order_id
JOIN dbo.[order] c WITH(NOLOCK) ON c.id =a.order_id    
 WHERE a.status = 1  AND c.type NOT IN (SELECT order_type FROM  dbo.business_type WHERE platform_type = 5)
		  GROUP BY a.order_Id 
END


go


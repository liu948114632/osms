

/*--------------------------------------------------
[备注]
	获取订单的未决订单
--------------------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_OrderPendingListGet] 
(
	@OrderId 	VARCHAR(20)
)
AS
BEGIN
	SELECT TOP (1) 
		Id,
		PendingId,
		OrderId 
	FROM dbo.T_PendingList 
	WHERE OrderId = @OrderId 
	ORDER BY id ASC; 
END
go


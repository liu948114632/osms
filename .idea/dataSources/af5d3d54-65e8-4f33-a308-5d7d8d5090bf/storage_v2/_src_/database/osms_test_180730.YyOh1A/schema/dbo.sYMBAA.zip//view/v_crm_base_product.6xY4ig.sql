
    
CREATE VIEW [dbo].[V_CRM_Base_Product]
AS
    SELECT  a.id AS CmsProductId ,
            a.product_set_id AS ProductSetId ,
            a.code ,
            a.name ,
            a.original_name AS ZhName ,         /* 增加中文名称*/
            a.unit_quantity AS UnitQuantity ,
            a.unit ,
            a.weight ,
            a.volume ,
            a.cost_price+CAST((ISNULL(a.alone_processing_cost_price,0)+ISNULL(alone_packaging_cost_price,0))*1.0/a.unit_quantity AS DECIMAL(18,6)) AS BasePrice ,
            ( CASE WHEN ISNULL(a.category_id_3, 0) = 0
                   THEN ( CASE WHEN ISNULL(a.category_id_2, 0) = 0
                               THEN a.category_id_1
                               ELSE a.category_id_2
                          END )
                   ELSE a.category_id_3
              END ) AS CategoryId ,
            a.category_id_1 AS CategoryId1 ,
            a.category_id_2 AS CategoryId2 ,
            a.category_id_3 AS CategoryId3 ,
            CAST(a.is_display_ph AS BIT) AS IsDisplayPh ,
            CAST(a.is_display_pw AS BIT) AS IsDisplayPw ,
            CAST(a.is_display_jl AS BIT) AS IsDisplayJl ,
            a.offline_status AS OfflineStatus ,
            a.color_card_picture_code AS ColorCardPictureCode ,
            a.primary_picture_code AS PrimaryPictureCode ,
            a.publish_status AS PublishStatus ,
            CAST(a.is_gift AS BIT) AS IsGift ,
            CAST(a.is_mix AS BIT) AS IsMix ,
            a.product_set_color_card_id AS ProductSetColorCardId ,
            a.product_set_specification_id AS ProductSetSpecificationId ,
            b.description,
            ISNULL(c.delivery_weight,0)+ ISNULL(c.input_skin_weight,0) AS ProductWeight,
            ISNULL(c.delivery_volume,0)+ISNULL(c.input_skin_weight*5,0) AS ProductVolume,
			a.cost_price+CAST((ISNULL(a.alone_processing_cost_price,0)+ISNULL(alone_packaging_cost_price,0))*1.0/a.unit_quantity AS DECIMAL(18,6)) AS LastCostPrice
    FROM    dbo.product a WITH ( NOLOCK )
            INNER JOIN dbo.product_description b WITH ( NOLOCK ) ON a.id = b.product_id
            LEFT JOIN dbo.product_weight_volume c ON c.id=a.id
    WHERE   a.status = 4
            AND a.is_delete = 0

go


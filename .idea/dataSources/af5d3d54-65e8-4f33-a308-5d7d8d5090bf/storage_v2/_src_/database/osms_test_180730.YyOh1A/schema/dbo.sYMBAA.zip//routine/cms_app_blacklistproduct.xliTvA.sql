/*
*2014-07-04
*APP,黑名单产品列表
*/
CREATE PROCEDURE [dbo].[CMS_APP_BlackListProduct]
    @code VARCHAR(50) = NULL ,
    @PageSize INT = 50 ,  --页大小                        
    @PageIndex INT = 1    --当前页号   
AS 
    BEGIN
	
        SET NOCOUNT ON;

        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用  
            @FromSQL NVARCHAR(MAX) , --查询表                                         
            @Column NVARCHAR(MAX) , --查询字段                       
            @Condition VARCHAR(MAX) , --条件                         
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ,
            @DistinctCode VARCHAR(10) 
            
        SET @DistinctCode = ' DISTINCT '   
        SET @FromSQL = '  FROM ( SELECT  b.code ,
                    ISNULL(c.quantity, 0) - ISNULL(c.lock_quantity, 0) AS quantity ,
                    d.name ,
                    b.id ,
                    CASE WHEN EXISTS ( SELECT TOP 1
                                                a1.id
                                       FROM     dbo.[order] a1
                                                JOIN dbo.order_item b1 ON a1.id = b1.order_id
                                       WHERE    b1.product_id = a.product_id
                                                AND a1.status < 60
                                                AND b1.STATUS = 6 ) THEN 1
                         ELSE 0
                          END AS status
          FROM  dbo.blacklist_product a WITH (NOLOCK) JOIN product b WITH (NOLOCK) ON a.product_id = b.id LEFT JOIN dbo.storage c WITH (NOLOCK) 
          ON c.product_id = b.id  AND c.department_id = 4 LEFT JOIN dbo.storage_position d WITH (NOLOCK) ON d.id = c.position_id) p'
        SET @Condition = ' WHERE   (p.quantity <> 0 OR p.status <> 0)  '              
        IF @code IS NOT NULL 
            BEGIN
                SET @Condition = @Condition + ' AND p.code like ''%' + @code
                    + '%'''   
            END 
    --设置需要取的字段信息                        
        SET @Column = 'p.code as code,
						p.quantity as quantity,
						p.name as positionName,
						p.id as id,
						p.status as status'
						
				
		   			
        --求符合条件的总数                      
        SET @CountSql = ' SELECT @RowCount = count(' + @DistinctCode
            + ' p.id) ' + @FromSQL + @Condition                 
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT            
                            
		
        IF ISNULL(@PageSize, 0) < 1 
            SET @PageSize = 50                              
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                              
        IF ISNULL(@PageIndex, 0) < 1 
            SET @PageIndex = 1                              
        ELSE 
            IF ISNULL(@PageIndex, 0) > @PageCount 
                SET @PageIndex = @PageCount                              
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                              
        SET @end = @PageIndex * @PageSize   
    
        SET @SQL = 'SELECT * from                      
       (                      
       SELECT *,ROW_NUMBER() OVER(ORDER BY temp.status DESC ,temp.quantity DESC ,temp.code ASC) rowIndex                      
       from (SELECT ' + @DistinctCode + @Column + @FromSQL + @Condition
            + ') temp                      
       ) temp2                           
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))    
            
        EXEC(@SQL);             
        SELECT  @RowCount                
    END
go


CREATE PROCEDURE [dbo].[A_temp]
AS
BEGIN
   DECLARE @importTable TABLE (ID int,CategoryId int,PropertyId int)
   INSERT INTO @importTable SELECT ID, CASE WHEN ID3 > 0 THEN ID3 WHEN ID2 > 0 THEN ID2 ELSE ID1 END AS CategoryId, PropertyID
		FROM A_Temp_CategoryRelatedProperty

   DECLARE @existTable TABLE (ID INT,CategoryId int,PropertyId int)
   INSERT INTO @existTable SELECT a.CategoryRelatedPropertyId,a.CategoryId,a.PropertyId 
		FROM dbo.T_CategoryRelatedProperty a,@importTable b 
		WHERE a.CategoryId=b.CategoryId AND a.PropertyId=b.PropertyId

   --已弃用属性关联表
   DECLARE @delectTable TABLE (CategoryRelatedPropertyId int)
   INSERT INTO @delectTable SELECT a.CategoryRelatedPropertyId FROM dbo.T_CategoryRelatedProperty a 
		WHERE a.CategoryRelatedPropertyId NOT IN (SELECT ID FROM @existTable)
	--查询删除的类别关联属性值
SELECT CategoryRelatedPropertyId '被删除的类别关联属性ID' FROM @delectTable
   --删除关联属性值表的相关记录
   DELETE FROM dbo.T_CategoryRelatedPropertyValue WHERE CategoryRelatedPropertyId IN (SELECT CategoryRelatedPropertyId FROM @delectTable)
   --删除关联属性表的相关记录
   DELETE FROM dbo.T_CategoryRelatedProperty WHERE CategoryRelatedPropertyId IN (SELECT CategoryRelatedPropertyId FROM @delectTable)
   
   
END
go



/*--------------------------------------------------
[备注]
	修改订单商品的重量
FRH:2009-07-21
--------------------------------------------------------*/
CREATE PROCEDURE [dbo].[CRM_Order_OrderItemWeightUpdate] 
(
	@Id				Int,
	@Weight			Int
)
AS
Begin
	IF EXISTS(SELECT * FROM dbo.T_OrderItem  WHERE OrderItemId = @Id And (Weight > 0 Or Volume > 0) )
		BEGIN
			-- 把体积重量和网站重量都清空
			UPDATE 
				dbo.T_OrderItem
			SET
				Weight = @Weight,
				Volume = @Weight,
				XFreight = 0
			WHERE
				OrderItemId = @Id;
		END	
	ELSE
		BEGIN
			RAISERROR ('该商品重量已经取消了！' , 16, 1) WITH NOWAIT;
			RETURN;
		END
END


go


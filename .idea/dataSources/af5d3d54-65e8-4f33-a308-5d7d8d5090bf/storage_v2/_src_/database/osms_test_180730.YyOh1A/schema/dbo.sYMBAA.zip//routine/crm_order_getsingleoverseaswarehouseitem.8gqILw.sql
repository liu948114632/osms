
 /**          
获取订单某个可以海外仓的商品项          
*/          
CREATE PROC [dbo].[CRM_Order_GetSingleOverseasWarehouseItem]          
(          
  @OrderId VARCHAR(20),      
  @WarehouseId INT, --准备走的仓库    
  @OrderItemId int      
)          
AS          
begin          
      SELECT a.OrderItemId,          
             a.OrderId,          
             a.CmsProductId,          
             a.ProductId,          
             a.Quantity,          
             a.UnitQuantity,          
             a.Unit,          
             a.ReadyQty,         
             c.[Length],        
             c.[Width],          
             c.[Height],        
             c.[Weight],        
             a.Volume,          
             a.ItemPrice,          
             a.SalePrice,          
             a.CostPrice,          
             d.code AS ProductCode,          
             d.category_id_1 AS categoryId1,          
             d.category_id_2 AS categoryId2,          
             d.category_id_3 AS categoryId3,          
             ISNULL(d.category_id_3,ISNULL(d.category_id_2,d.category_id_1)) AS categoryId,          
             c.CK1StorageNo AS StorageNo    
      FROM dbo.T_OrderItem a WITH(NOLOCK)              
      JOIN T_OverseasWarehouseProduct c WITH(NOLOCK) ON a.CmsProductId=c.CMSProductId AND c.WarehouseId = @WarehouseId    
      JOIN dbo.product d WITH(NOLOCK) ON c.CMSProductId = d.id          
      WHERE a.OrderId=@OrderId AND a.OrderItemId=@OrderItemId  AND c.IsDelete=0
      ORDER BY d.category_id_1,d.category_id_2,d.category_id_3        
END

 go


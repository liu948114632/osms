CREATE PROC [dbo].[CMS_Order_GetOrderWeighingRecordProducts] 
( @OrderId INT = NULL   --订单        
 )    
    AS     
        BEGIN                                  
            SET NOCOUNT ON ;         
     
            SELECT  
					temp.id,
					temp.product_id AS productId ,    
                    temp.code AS productCode ,    
                    temp.name AS productName ,    
                    temp.weight AS weight ,
                    temp.volume AS volume,    
                    temp.unit_quantity AS unitQuantity ,    
                    temp.unit AS unit ,    
                    temp.sale_price AS salePrice ,    
                    temp.collateQuantity AS orderQutity ,    
                    temp.box1 AS box ,  
                    x.name AS categoyName ,    
                    x.invoice_cn_name AS invoiceCnName ,    
                    x.invoice_en_name AS invoiceEnName ,    
                    x.hs_code AS hsCode,
                    ISNULL((SELECT property_value.name
                     FROM dbo.product_property_value JOIN dbo.property_value ON dbo.product_property_value.property_value = dbo.property_value.id
                     WHERE dbo.product_property_value.product_id=temp.product_id AND dbo.property_value.property_id=2),ISNULL((SELECT property_value.name
                     FROM dbo.product_property_value JOIN dbo.property_value ON dbo.product_property_value.property_value = dbo.property_value.id
                     WHERE dbo.product_property_value.product_id=temp.product_id AND dbo.property_value.property_id=104),'')) AS material,
                    ISNULL((SELECT property_value.name
                     FROM dbo.product_property_value JOIN dbo.property_value ON dbo.product_property_value.property_value = dbo.property_value.id
                     WHERE dbo.product_property_value.product_id=temp.product_id AND dbo.property_value.property_id=11),'') AS usage, 
                     ISNULL((SELECT property_value.name
                     FROM dbo.product_property_value JOIN dbo.property_value ON dbo.product_property_value.property_value = dbo.property_value.id
                     WHERE dbo.product_property_value.product_id=temp.product_id AND dbo.property_value.property_id=14),'') AS classification ,
                     productCnName,temp.[description]
                     
            FROM    ( SELECT    b.*,
                                ( CASE WHEN ( ISNULL(c.category_id_3, 0) ) <> 0    
                                       THEN ( c.category_id_3 )    
                                       WHEN ( ISNULL(c.category_id_2, 0) ) <> 0    
                                       THEN ( c.category_id_2 )    
                                       ELSE ( ISNULL(c.category_id_1, 0) )    
                                  END ) AS category_id ,    
                                c.code ,    
                                c.name ,
                                d.box AS box1,
                                d.quantity AS collateQuantity,
                                c.original_name AS productCnName,
                                f.description
                      FROM      dbo.[order] AS a    
                                INNER JOIN dbo.order_item AS b WITH(NOLOCK) ON a.id = b.order_id    
                                INNER JOIN dbo.order_item_relate_box AS d WITH(NOLOCK) ON b.id=d.order_item_id
                                INNER JOIN dbo.product AS c WITH(NOLOCK) ON c.id = b.product_id   
                                 LEFT JOIN dbo.product_description f WITH(NOLOCK) ON f.product_id=c.id 
                      WHERE     a.id = @OrderId    
                                AND b.status <> 12 --鎺掗櫎宸插彇娑堢殑     
                          
                    ) AS temp    
                    INNER JOIN dbo.category AS x ON temp.category_id = x.id    
    
            SET NOCOUNT OFF ;           
        END

go


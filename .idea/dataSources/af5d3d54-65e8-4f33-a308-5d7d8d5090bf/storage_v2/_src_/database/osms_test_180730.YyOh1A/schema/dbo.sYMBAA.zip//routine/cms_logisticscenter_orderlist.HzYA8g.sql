 --exec [CMS_LogisticsCenter_OrderList]  @IsOverSea = 1 @OverSeaType = '1,2'
   
CREATE  PROC [dbo].[CMS_LogisticsCenter_OrderList]
    (
      @QueryType INT = NULL ,--查询类型：1、待校对；2、待称重；3、待出库；为空则查询所有                            
      @OrderCode VARCHAR(20) = NULL , --订单编号       
      @OrderType VARCHAR(100) = NULL ,--订单类型,多个之间用逗号隔开                             
      @Status INT = NULL ,  --订单状态,  
      @Source INT = NULL ,
	  @IsVip INT = NULL,
      @PriorityLevel INT = NULL , --优先级                            
      @CollateUserId INT = NULL , --校对人ID                             
      @IsNeedProcessing BIT = NULL ,  --是否需要加工                             
      @IsHavePosition BIT = NULL ,--是否已有箱位                             
      @IsCanDeliver BIT = NULL ,--是否能发货                             
      @OrderTimeBegin DATETIME = NULL , --查询下单时间的开始时间                              
      @OrderTimeEnd DATETIME = NULL , --查询下单时间的结束时间                              
      @CollateTimeBegin DATETIME = NULL , --查询校对时间的开始时间                              
      @CollateTimeEnd DATETIME = NULL , --查询校对时间的结束时间                              
      @ProductCode VARCHAR(MAX) = NULL ,--商品编号                              
      @CustomerName VARCHAR(MAX) = NULL ,--客户名称                             
      @IsOrderPosition BIT = NULL ,--是否放箱                     
      @ArrivalRateCondition VARCHAR(MAX) = NULL ,--到货条件表达式                    
      @ArrivalRate INT = NULL ,--到货数量                    
      @PercentageCondition VARCHAR(MAX) = NULL ,--到货条率件表达式                    
      @Percentage VARCHAR(MAX) = NULL ,--到货率                    
      @EstimateDeliverTimeBegin DATETIME = NULL ,--预计发货时间起                    
      @EstimateDeliverTimeEnd DATETIME = NULL ,--预计发货时间止                
      @SendGroupId INT = NULL ,
      @DepartmentId INT = NULL , --部门  
      @IsOrderQuick INT = NULL , --是否快捷订单     
      @IsOrderStockOutType BIT = NULL , -- 是否按订单出库订单类型  
      @OrderGroupFailure INT = NULL , -- 分箱失败 
      @HasNotOrderPosition INT = NULL , --有未放箱 
      @OrderPosition VARCHAR(20) = NULL ,--订单箱位
      @IsOverSea INT = NULL ,--是否海外仓订单
	  @OverSeaType NVARCHAR(500) = NULL,
      @IsBeforeCollect INT = NULL ,--是否校对前状态
      @PrepareDateBegin DATETIME = NULL ,
      @PrepareDateEnd DATETIME = NULL ,
	  @IsBigOrder INT = NULL ,
      @PageSize INT = 50 ,  --页大小                              
      @PageIndex INT = 1    --当前页号  
                                    
    )
AS
    BEGIN                                    
        SET NOCOUNT ON;                                    
                                      
        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用                              
            @FromSQL NVARCHAR(MAX) , --查询表                            
            @Condition VARCHAR(MAX) , --条件                               
            @RowCount INT ,
            @PageCount INT ,
            @BarCount INT , --条码总数    
            @BarCountSql NVARCHAR(MAX) ,
            @start INT ,
            @end INT ,
            @DistinctCode VARCHAR(10) ,
            @OrderSQL VARCHAR(MAX)                            
                                      
        SET @FromSQL = ' FROM [order] a WITH (NOLOCK)                            
                    LEFT JOIN T_Customer c WITH (NOLOCK) on a.customer_id = c.UserId 
                    LEFT JOIN T_CustomerSpecial as tx WITH (NOLOCK) on a.customer_id = tx.CustomerId     
         AND (CASE  a.type WHEN 2 THEN 16 when 5 then 17 ELSE 1 END) = tx.BusinessType  '                               
                                  
        SET @Condition = ' WHERE 1=1 '                              
        SET @DistinctCode = ''    
		IF @IsVip  IS NOT NULL
		BEGIN
			 SET @Condition = @Condition + ' AND a.is_vip=' + CONVERT(VARCHAR(10), @IsVip) 
		END  
        IF ( @QueryType = 1 )
            BEGIN      
                SET @OrderSQL = ' temp.OrderIndex, ';            
            END                   
        SET @OrderSQL = ' temp.orderTime DESC ';                     
                                  
        IF @OrderCode IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND a.code like ''%'
                    + @OrderCode + '%'''                            
            END  
        IF @Source IS NOT NULL
            BEGIN  
                SET @Condition = @Condition + ' AND a.[source]='
                    + CONVERT(VARCHAR(10), @Source)    
            END              
        IF @Status IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND a.status='
                    + CONVERT(VARCHAR(10), @Status)                              
            END                                
        IF @PriorityLevel IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND a.priority_level='
                    + CONVERT(VARCHAR(10), @PriorityLevel)                              
            END                                 
        IF @CollateUserId IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND a.collate_user_id='
                    + CONVERT(VARCHAR(10), @CollateUserId)                              
            END               
        IF @SendGroupId IS NOT NULL
            BEGIN              
                SET @OrderSQL = ' temp.sendGroupId ASC ';                             
                SET @Condition = @Condition + ' AND a.send_group_id='
                    + CONVERT(VARCHAR(10), @SendGroupId)                              
            END                  
        IF @DepartmentId IS NOT NULL
            BEGIN               
                SET @Condition = @Condition + ' AND a.department_id='
                    + CONVERT(VARCHAR(10), @DepartmentId)              
            END                            
        IF @OrderType IS NOT NULL
            BEGIN      
                SET @Condition = @Condition + ' AND a.type in (' + @OrderType
                    + ')'           
            END                 
        IF @IsNeedProcessing IS NOT NULL
            BEGIN                               
                IF @IsNeedProcessing = 1
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.is_need_processing =1'                            
                    END                             
                ELSE
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.is_need_processing =0'                            
                    END                           
            END                             
        IF @IsHavePosition IS NOT NULL
            BEGIN                               
                IF @IsHavePosition = 1
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND NOT EXISTS(select top 1 id from order_item_group d WITH (NOLOCK)                             
                            where a.id = d.order_id and (d.position IS NULL OR d.position = ''''))'                            
                    END                             
                ELSE
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND EXISTS(select top 1 id from order_item_group d WITH (NOLOCK)                             
                   where a.id = d.order_id and (d.position IS NULL OR d.position = ''''))'                            
                    END                             
            END
        IF @HasNotOrderPosition IS NOT NULL
            BEGIN
                IF @HasNotOrderPosition = 1
                    BEGIN
					-- 订单所属的订单组中，只要有一组有箱位，且对应的订单组已放箱为否的搜索出来
                        SET @Condition = @Condition
                            + ' AND EXISTS (select top 1 id from  order_item_group  d WITH (NOLOCK)                             
                            where a.id = d.order_id and d.position is not null  and d.is_order_position = 0)'
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND NOT EXISTS (select top 1 id from  order_item_group  d WITH (NOLOCK)                             
                            where a.id = d.order_id and d.position is not null  and d.is_order_position = 0)'
                    END	
			
			
            END
			    
        IF @OrderPosition IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' AND  EXISTS(select top 1 id from order_item_group d WITH (NOLOCK)                             
                            where a.id = d.order_id and d.position like '''
                    + @OrderPosition + '%'' )'  
            END
		
        IF @IsOverSea IS NOT NULL
            BEGIN
                IF @IsOverSea = 1
                    BEGIN 
                        SET @Condition = @Condition
                            + ' AND  a.type in (select value from uf_Split('''+@OverSeaType+''','',''))'   
                    END 
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND  a.type not in (select value from uf_Split('''+@OverSeaType+''','',''))' 
                    END
            
            END
        
        IF @IsBeforeCollect IS NOT NULL
            BEGIN
                IF @IsBeforeCollect = 1
                    BEGIN
                        SET @Condition = @Condition + ' AND  a.status <=38' 
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition + ' AND  a.status >38' 
                    END
            
            END
		                                
        IF @IsOrderPosition IS NOT NULL
            BEGIN                               
                IF @IsOrderPosition = 1
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.is_order_position =1'                            
                    END                             
                ELSE
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.is_order_position =0'                
                    END                             
            END                             
        IF @IsCanDeliver IS NOT NULL
            BEGIN                               
                IF @IsCanDeliver = 1
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.is_can_deliver =1'                            
                    END                             
                ELSE
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.is_can_deliver =0'                            
                    END                             
            END   
              
        IF @IsOrderQuick IS NOT NULL
            BEGIN                               
                IF @IsOrderQuick = 1
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.is_order_quick =1'                            
                    END                             
                ELSE
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.is_order_quick =0'                            
                    END                             
            END                                      
        IF @OrderTimeBegin IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND a.order_time >='''
                    + CONVERT(VARCHAR(20), @OrderTimeBegin) + ''''                              
            END                               
        IF @OrderTimeEnd IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND a.order_time <='''
                    + CONVERT(VARCHAR(20), @OrderTimeEnd) + ''''                               
            END                             
        IF @CollateTimeBegin IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND a.collate_time >='''
                    + CONVERT(VARCHAR(20), @CollateTimeBegin) + ''''                              
            END         
        IF @CollateTimeEnd IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND a.collate_time <='''
                    + CONVERT(VARCHAR(20), @CollateTimeEnd) + ''''                               
            END                 
        IF @ProductCode IS NOT NULL
            BEGIN                               
                SET @FromSQL = @FromSQL
                    + ' INNER JOIN order_item d WITH (NOLOCK) on a.id = d.order_id                            
                                   INNER JOIN product b WITH (NOLOCK) on d.product_id = b.id'                             
                SET @Condition = @Condition + ' AND b.code =''' + @ProductCode
                    + ''''                              
                SET @DistinctCode = 'DISTINCT'                            
            END                             
        IF @CustomerName IS NOT NULL
            BEGIN                               
                SET @Condition = @Condition + ' AND c.FullName like ''%'
                    + @CustomerName + '%'''                              
            END                     
        IF @ArrivalRateCondition IS NOT NULL
            AND @ArrivalRate IS NOT NULL
            BEGIN                     
                SET @Condition = @Condition
                    + ' AND (a.valid_order_count-a.prepared_count)'
                    + @ArrivalRateCondition
                    + CONVERT(VARCHAR(20), @ArrivalRate);                    
            END                     
        IF @PercentageCondition IS NOT NULL
            AND @Percentage IS NOT NULL
            BEGIN                     
                SET @Condition = @Condition
                    + ' AND convert(NUMERIC(18,2), (a.valid_order_count-a.prepared_count))/convert(NUMERIC(18,2),(case when a.valid_order_count>0 then a.valid_order_count else 1 end))'
                    + @PercentageCondition + @Percentage;                    
            END                     
        IF @EstimateDeliverTimeBegin IS NOT NULL
            BEGIN                    
                SET @Condition = @Condition
                    + ' AND a.estimate_deliver_time >='''
                    + CONVERT(VARCHAR(20), @EstimateDeliverTimeBegin) + '''';                    
            END                       
        IF @EstimateDeliverTimeEnd IS NOT NULL
            BEGIN                    
                SET @Condition = @Condition
                    + ' AND a.estimate_deliver_time <='''
                    + CONVERT(VARCHAR(20), @EstimateDeliverTimeEnd) + '''';                    
            END 
 
          
         -----------------------------------------------------------------------------------------          
        IF @OrderGroupFailure IS NOT NULL
            BEGIN
                IF @OrderGroupFailure = 1
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND EXISTS(SELECT TOP 1 id from order_group_position_log ogpl WITH (NOLOCK) 
							where a.id = ogpl.order_id and ogpl.status = 3 ) ' 
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND EXISTS(SELECT TOP 1 id from order_group_position_log ogpl WITH (NOLOCK) 
							where a.id = ogpl.order_id and ogpl.status != 3 ) ' 
                    END
                    
            END                        
                               
        IF @QueryType IS NOT NULL
            BEGIN                                 
                IF @QueryType = 1
                    BEGIN                            
                        SET @Condition = @Condition
                            + ' AND a.status in (40,45)'--40:待校对 45:校对中                                         
                    END                             
                ELSE
                    IF @QueryType = 2
                        BEGIN           
                            SET @Condition = @Condition + ' AND a.status=50'--50：打包中                           
                            SET @Condition = @Condition
                                + ' AND NOT EXISTS(select top 1 o.id from order_ref_order_weighing_record as o   WITH (NOLOCK)                
           JOIN order_weighing_record ow WITH (NOLOCK) ON o.weighing_record_id=ow.id               
           where a.id = o.order_id and ow.status=1)'--没有               
                        END                             
                    ELSE
                        IF @QueryType = 3
                            BEGIN                            
                                SET @Condition = @Condition
                                    + ' AND a.status=48'--55：已校对             
                                --SET @Condition = @Condition    
                                --    + ' AND a.is_can_deliver>=1'--必须可发货             
                            END                             
            END                                
        --IF @IsOrderStockOutType IS NOT NULL
        --    BEGIN  
        --        IF @IsOrderStockOutType = 1
        --            BEGIN  
        --                SET @Condition = @Condition
        --                    + ' AND EXISTS (select top 1 slo.order_id from small_lot_order AS slo WITH(NOLOCK) where slo.order_id = a.id and slo.is_deleted = 0)';   
        --            END  
        --        IF @IsOrderStockOutType = 0
        --            BEGIN                           
        --                SET @Condition = @Condition
        --                    + ' AND NOT EXISTS (select top 1 slo.order_id from small_lot_order AS slo WITH(NOLOCK) where slo.order_id = a.id and slo.is_deleted = 0)';                      
        --            END   
        --    END
		IF @IsBigOrder IS NOT NULL 
		BEGIN
			IF @IsBigOrder =1
			BEGIN
				SET @Condition = @Condition +' and exists (select top 1 id from  order_item oitem  WITH(NOLOCK) where oitem.order_id = a.id and oitem.is_big_order = 1 )'
            END
			ELSE
            BEGIN
				SET @Condition = @Condition +' and  not exists (select top 1 id from  order_item oitem  WITH(NOLOCK) where oitem.order_id = a.id and oitem.is_big_order = 1 )'
            END
        END
        IF @PrepareDateBegin IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.already_time >='''
                    + CONVERT(VARCHAR(20), @PrepareDateBegin) + ''''   
            END 
        IF @PrepareDateEnd IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.already_time <='''
                    + CONVERT(VARCHAR(20), @PrepareDateEnd) + ''''   
            END 
	                        
        SET @CountSql = ' SELECT @RowCount = count(' + @DistinctCode
            + ' a.id) ' + @FromSQL + @Condition                              
        --总数量                        
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT;             
        -- SELECT @CountSql      
                              
        IF ISNULL(@PageSize, 0) < 1
            SET @PageSize = 50                                    
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                    
        IF ISNULL(@PageIndex, 0) < 1
            SET @PageIndex = 1                                    
        ELSE
            IF ISNULL(@PageIndex, 0) > @PageCount
                SET @PageIndex = @PageCount                                    
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                    
        SET @end = @PageIndex * @PageSize                             
                                
        SET @SQL = 'SELECT * from (                              
   SELECT temp.*,ROW_NUMBER() OVER(ORDER BY ' + @OrderSQL
            + ') rowIndex                            
   from (                             
     SELECT ' + @DistinctCode
            + ' a.id,                              
   a.code,                              
   a.status,
   a.already_time as alreadyTime ,     
   a.type,
   a.is_vip as isVip,                              
   (case a.type when 3 then 1 else 2 end ) as OrderIndex,                              
   a.pay_status AS payStatus,                            
   a.is_can_deliver as isCanDeliver,                            
   a.is_prepared_deliver AS isPreparedDeliver,                              
   a.delivery_id AS deliveryId,                            
   a.country_id AS countryId,                                  
   a.customer_id AS customerId,                              
   a.merchandiser_id AS merchandiserId,                              
   a.priority_level AS priorityLevel,                              
   a.is_need_processing AS isNeedProcessing,                              
   a.order_time AS orderTime,                                   
   a.collate_user_id AS collateUserId,                   
   a.collate_time AS collateTime,                             
   a.deliver_weight AS deliverWeight,                             
   a.website_weight AS websiteWeight,                             
   a.valid_order_count AS validOrderCount,                             
   a.prepared_count AS preparedCount,                             
   a.box_count AS boxCount,                             
   a.customer_remark AS customerRemark,                             
   a.customer_service_remark AS customerServiceRemark,             
   a.branch_remark AS branchRemark,            
   a.stock_out_branch_remark AS stockOutBranchRemark,                             
   a.box_apply_index AS boxApplyIndex,                             
   a.is_remote AS isRemote,                             
   a.is_order_position  as isOrderPosition,                                 
   a.collate_mode  as collateMode,                            
   c.FullName AS customerName,                 
   a.send_group_id AS sendGroupId,                 
   a.estimate_deliver_time as estimateDeliverTime,            
   a.wait_collate_time as waitCollateTime,      
   a.weighing_Time as weighingTime,    
   tx.Special as customerSpecial,  
   a.is_order_quick as isOrderQuick,  
   a.department_id as departmentId ,  
   a.[source],  
   CASE WHEN send_group_id<>0 AND a.status=40 
   AND NOT EXISTS(SELECT b2.id FROM dbo.[order] b2   WITH (NOLOCK) WHERE    
	a.send_group_id=b2.send_group_id AND b2.status <40 
	AND a.SOURCE =b2.source) 
	THEN 1 
	ELSE 0 
	END AS isAddSendGropColor ,
	a.is_picked as isPicked ,
	(SELECT d.position+'',''  from order_item_group d  WITH (NOLOCK)   where d.order_id = a.id and d.position is not null  FOR XML PATH('''')  ) as orderPosition '                            
                       
        SET @SQL = @SQL + @FromSQL + @Condition
            + ') temp ) temp2                             
      where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10))                              
                                   
        PRINT @SQL                              
        EXEC(@SQL);                                        
                                  
        SELECT  @RowCount;     
                                     
    END


 go


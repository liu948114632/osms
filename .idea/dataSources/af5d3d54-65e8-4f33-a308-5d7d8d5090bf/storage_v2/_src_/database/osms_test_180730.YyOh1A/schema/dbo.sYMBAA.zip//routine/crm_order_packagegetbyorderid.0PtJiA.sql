-- =============================================        
-- Author:  <HYD>        
-- Create date: <2010-01-07>        
-- Description: <获取订单对应指定的包裹>        
-- =============================================        
CREATE PROCEDURE [dbo].[CRM_Order_PackageGetByOrderId]        
(        
 @OrderId  NVARCHAR(20)        
)        
AS        
BEGIN        
 SET NOCOUNT ON;        
    
 Select        
  TraceNo,        
  OrderId,        
  CustomerName,        
  EmailId,        
  DeliveryId,        
  Status,        
  DueDate,        
  Remark,        
  DealStatus,        
  IsConfirm,        
  [Remark],        
  UpdateDate,        
  IsSendMail,        
  (Select [Name] From t_Delivery Where DeliveryId = T_OrderPackage.DeliveryId) As DeliveryName,         
  (Select [ReceiveDays] From t_Delivery Where DeliveryId = T_OrderPackage.DeliveryId) As DeliveryDays,         
  (Select [Description] From t_Delivery Where DeliveryId = T_OrderPackage.DeliveryId) As TraceUrl,      
  GoodsCode,  
  ServiceLineType,
  ServiceLineName,
  ServiceCompany 
 From        
  T_OrderPackage        
 Where        
  OrderId = @OrderId        
END

go


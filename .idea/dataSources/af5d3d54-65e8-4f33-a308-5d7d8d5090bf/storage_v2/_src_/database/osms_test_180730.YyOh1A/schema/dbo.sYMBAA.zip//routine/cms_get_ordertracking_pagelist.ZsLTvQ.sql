
CREATE PROC dbo.CMS_GET_OrderTracking_PageList
    (
      @OrderTrackingCode NVARCHAR(50) = NULL ,  --订单跟踪号
      @OrderTrackingCodeList NVARCHAR(MAX) = NULL ,  --订单跟踪号集合
      @Status INT = NULL ,	--状态
      @OrderCode NVARCHAR(50) = NULL ,  --订单编号 
      @OrderCodeList NVARCHAR(MAX) = NULL ,	-- 订单编号集合
      @ConsultationTimeBegin NVARCHAR(20) = NULL , -- 咨询开始时间
      @ConsultationTimeEnd NVARCHAR(20) = NULL , -- 咨询结束时间
      @ReplyTimeBegin NVARCHAR(30) = NULL , -- 答复开始时间
      @ReplyTimeEnd NVARCHAR(30) = NULL , --答复结束时间
      @ReplayUserId INT = NULL ,	-- 答复人
      @Type INT = NULL ,	-- 类型
      @ConsultationUserId INT = NULL , -- 咨询人
      @OperatorUserId INT = NULL , -- 跟进人
      @OrderStatus INT = NULL , -- 订单状态
      @productCode VARCHAR(100) = NULL ,
      @productCodes VARCHAR(MAX) = NULL ,
      @productOperatorUserId INT = NULL ,
      @createdType INT = NULL ,
      @departmentId INT = NULL ,
      @isVip INT = NULL ,
      @alarmTimeBegin NVARCHAR(20) = NULL ,
      @alarmTimeEnd NVARCHAR(20) = NULL ,
	  @orderItemStatus INT=NULL,
      @PredictDeliveryTimeBegin NVARCHAR(30) = NULL , --预计发货时间开始
      @PredictDeliveryTimeEnd NVARCHAR(30) = NULL , --预计发货时间结束
      @PageSize INT = 50 ,  --页大小              
      @PageIndex INT = 1    --当前页号  
    )
 AS
    BEGIN                    
        SET NOCOUNT ON;                    
                        
        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用              
            @FromSQL NVARCHAR(MAX) , --查询表            
            @FromSQL2 NVARCHAR(MAX) , --查询外表            
            @Condition VARCHAR(MAX) , --条件           
            @Column VARCHAR(MAX) ,--查询的字段          
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT 
  				
  				    --获得查询条件                  
        SET @Condition = ' WHERE 1=1 AND ot.is_delete = 0 '   
        IF @OrderTrackingCode IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND ot.code LIKE '''
                    + @OrderTrackingCode + '%'''  
            END
        IF @OrderTrackingCodeList IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND ot.code IN ('''
                    + REPLACE(@OrderTrackingCodeList, ',', ''',''') + ''')'    
            END
        IF @Status IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND oti.status = '
                    + CONVERT(VARCHAR(20), @Status)
            END
        IF @OrderCode IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND ot.order_code LIKE '''
                    + @OrderCode + '%'''  
            END
        IF @OrderCodeList IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND ot.order_code IN ('''
                    + REPLACE(@OrderCodeList, ',', ''',''') + ''')'    
            END
        IF @ConsultationTimeBegin IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND ot.consultation_time >='''
                    + CONVERT(VARCHAR(20), @ConsultationTimeBegin) + ''''
            END
        IF @ConsultationTimeEnd IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND ot.consultation_time <='''
                    + CONVERT(VARCHAR(20), @ConsultationTimeEnd) + ''''
            END	
        IF @ReplyTimeBegin IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND oti.reply_time >='''
                    + CONVERT(VARCHAR(20), @ReplyTimeBegin) + ''''
            END	
        IF @ReplyTimeEnd IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND oti.reply_time <='''
                    + CONVERT(VARCHAR(20), @ReplyTimeEnd) + ''''
            END		
        IF @Type IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND ot.type = '
       + CONVERT(VARCHAR(10), @Type)
            END	
        IF @ConsultationUserId IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' AND ot.consultation_user_id =  '
                    + CONVERT(VARCHAR(10), @ConsultationUserId)
            END
        IF @OperatorUserId IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND oti.operator_id =  '
                    + CONVERT(VARCHAR(10), @OperatorUserId)
            END	
        IF @OrderStatus IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND o.status = '
                    + CONVERT(VARCHAR(10), @OrderStatus)
            END
      
        IF @PredictDeliveryTimeBegin IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' AND oti.predict_delivery_time >='''
                    + CONVERT(VARCHAR(20), @PredictDeliveryTimeBegin) + ''''
            END
        IF @PredictDeliveryTimeEnd IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' AND oti.predict_delivery_time <='''
                    + CONVERT(VARCHAR(20), @PredictDeliveryTimeEnd) + ''''
            END	
        IF @ReplayUserId IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND oti.reply_user_id = '
                    + CONVERT(VARCHAR(10), @ReplayUserId)
            END		
      
        IF @alarmTimeBegin IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND oti.alarm_time >='''
                    + CONVERT(VARCHAR(20), @alarmTimeBegin) + ''''
            END	
        IF @alarmTimeEnd IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND oti.alarm_time <='''
                    + CONVERT(VARCHAR(20), @alarmTimeEnd) + ''''
            END	
  	
        IF @createdType IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND ot.create_type = '
                    + CONVERT(VARCHAR(10), @createdType)
            END	
        IF @productOperatorUserId IS NOT NULL
            BEGIN
                IF @productOperatorUserId = 0
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND oti.product_operaotr_id is null ' 
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND oti.product_operaotr_id =  '
                            + CONVERT(VARCHAR(10), @productOperatorUserId)    
                    END
  			
            END	
  
        IF @productCode IS NOT NULL
            BEGIN
                SET @Condition = @Condition + '  AND p.code LIKE '''
                    + @productCode + '%'''  
            END
        IF @productCodes IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND p.code IN ('''
                    + REPLACE(@productCodes, ',', ''',''') + ''')'    
            END
        IF @isVip IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND o.is_vip = '
                    + CONVERT(VARCHAR(10), @isVip)
            END
		IF @orderItemStatus IS NOT NULL
        BEGIN
		  SET @Condition = @Condition + ' AND item.status = '
                    + CONVERT(VARCHAR(10), @orderItemStatus)
		END
      --设置条件查询必须关联的表              
        SET @FromSQL = ' FROM dbo.order_tracking_item oti WITH(NOLOCK)
  						INNER JOIN dbo.order_tracking ot WITH(NOLOCK) 
  						ON ot.is_delete=0 AND oti.order_tracking_id=ot.id
  						LEFT JOIN dbo.[order] o WITH(NOLOCK) 
  						ON o.code=ot.order_code
  						LEFT JOIN dbo.processing ps WITH(NOLOCK) 
  						ON ps.code=ot.order_code
  						LEFT JOIN dbo.product p WITH(NOLOCK)
  						ON p.id=oti.product_id '
	  

        SET @FromSQL2 = '  inner join dbo.order_tracking_item oti WITH(NOLOCK)
  						ON oti.id = temp.id
  						INNER JOIN dbo.order_tracking ot WITH(NOLOCK) 
  						ON ot.is_delete=0 AND oti.order_tracking_id=ot.id
  						LEFT JOIN dbo.[order] o WITH(NOLOCK) 
  						ON o.code=ot.order_code
  						LEFT JOIN dbo.processing ps WITH(NOLOCK) 
  						ON ps.code=ot.order_code
						LEFT JOIN dbo.view_all_department_purchase_task task
					ON ((ot.create_type IN (1,2,3,5,6,7,8,9)  and  task.product_id=oti.product_id AND task.type =1 AND task.order_id =o.id) OR (task.product_id=oti.product_id AND task.type =2 AND task.order_id =ps.id))	
  						LEFT JOIN dbo.product p WITH(NOLOCK)
  						ON p.id=oti.product_id
  						LEFT JOIN view_product_all_storage_quantity_info storage
  						ON storage.product_id = oti.product_id 
						left join order_item  item with(nolock) on item.order_id = o.id and item.product_id = p.id 
  						 '				
  		  IF   @orderItemStatus>0
		BEGIN
			  SET @FromSQL =@FromSQL+'  join order_item  item with(nolock) on item.order_id = o.id and item.product_id = p.id '
			    SET @FromSQL2 = @FromSQL2+' where item.status= '   + CONVERT(VARCHAR(10), @orderItemStatus)+' '
		END			
  	 --求符合条件的总数          
        SET @CountSql = ' SELECT @RowCount = count(oti.id) ' + @FromSQL
            + @Condition            
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                    
                                             
        IF ISNULL(@PageSize, 0) < 1
            SET @PageSize = 50                    
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                    
        IF ISNULL(@PageIndex, 0) < 1
            SET @PageIndex = 1                    
        ELSE
            IF ISNULL(@PageIndex, 0) > @PageCount
                SET @PageIndex = @PageCount                    
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                 
        SET @end = @PageIndex * @PageSize
      
          --设置需要取的字段信息            
        SET @Column = '
  		 oti.id ,
         oti.order_tracking_id AS orderTrackingId,
  	   ot.consultation_time AS consultationTime,
         oti.product_id AS productId,
  	   p.code AS productCode,
  	   ot.code,
  	   ot.order_code AS objectCode,
  	   CASE WHEN ot.create_type=4 THEN ps.status
  		ELSE o.status  END AS objectStatus,
  	   ot.consultation_user_id AS consultationUserId,
         oti.status ,
         oti.content ,
  	   ot.type,
        oti.reply_content AS replyContent,
         oti.reply_time AS replyTime,
         oti.reply_user_id AS replyUserId,
         oti.operator_id operatorId,
  	     oti.product_operaotr_id AS productOperatorId,
         oti.remark ,
         oti.predict_delivery_time predictDeliveryTime,
         oti.alarm_time alarmTime,
         oti.branch_remark branchRemark,
         oti.branch_remark_operater_id branchRemarkOperaterId,
  	   oti.branch_remark_operater_time AS branchRemarkOperaterTime,
         oti.audit_user_id AS auditUserId,
         oti.audit_time AS auditTime,
         oti.assign_time AS assignTime,
         oti.assign_user_id assignUserId,
         oti.audit_cause AS auditCause,
  	   oti.cs_content as csContent,
  	   storage.available_qty AS storageQty,
	   item.status as orderItemStatus,
	   item.id as orderItemId,
	   item.order_quantity as orderQuantity,
	   item.prepared_quantity as preparedQuantity,
	   o.is_vip as isVip,
	   task.completion_quantity AS completionQuantity
  	 '
      --组装基本查询的SQL          
        SET @SQL = 'SELECT * FROM ( SELECT  oti.id, ROW_NUMBER() OVER(ORDER BY oti.status ASC , 
  						ot.consultation_time DESC, p.code asc ) rowIndex'              
        SET @SQL = @SQL + @FromSQL + @Condition + ') temp2               
        WHERE rowIndex BETWEEN ' + CAST(@start AS NVARCHAR(10)) + ' AND '
            + CAST(@end AS NVARCHAR(10))  
       --组装最终取数的SQL          
        SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp '
            + @FromSQL2 + ' ORDER BY rowIndex' 
        PRINT ( @SQL )                       
        EXEC(@SQL)                                  
        SELECT  @RowCount
       
    END
go


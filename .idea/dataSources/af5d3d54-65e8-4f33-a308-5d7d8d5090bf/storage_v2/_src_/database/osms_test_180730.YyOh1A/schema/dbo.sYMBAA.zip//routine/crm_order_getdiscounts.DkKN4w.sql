
/*获取订单的折扣金额*/
CREATE PROC dbo.CRM_Order_GetDiscounts
(
	@OrderIds NVARCHAR(MAX),
	@CashCoupon DECIMAL(18,2) OUT,	
	@SpecialOffer DECIMAL(18,2) OUT,
	@ReplaceDiscount DECIMAL(18,2) OUT,
	@FrightOffer DECIMAL(9,2)=0 OUT
)
AS
BEGIN
		 -- 用来缓存所有订单        
		 DECLARE @TempOrders TABLE(SN NVARCHAR(15));  		         
		 INSERT INTO @TempOrders(SN)        
		 SELECT [Value]         
		 FROM dbo.uf_Split(@OrderIds,',');  

		SET @CashCoupon=0; 
		SET @SpecialOffer=0;
		SET @ReplaceDiscount=0;
		SET @FrightOffer=0;

		--获取现金券金额
        SELECT  @CashCoupon = ISNULL(SUM(ISNULL(Value, 0)), 0)
        FROM    T_CashCoupon
        WHERE   OrderId IN (SELECT SN FROM @TempOrders)
        
		--获取特别优惠
        SELECT  @SpecialOffer =  ISNULL(SUM(ISNULL(Amount, 0)),0)
        FROM    T_OrderSpecialOffer
        WHERE   OrderId IN (SELECT SN FROM @TempOrders)
       
		--获取替代品优惠
        SELECT @ReplaceDiscount=SUM(ISNULL(DiscountForReplace, 0)) 
        FROM dbo.T_OrderPrice
        WHERE OrderId IN (SELECT SN FROM @TempOrders)

		--货运运费优惠
		SELECT @FrightOffer=SUM(ISNULL(Amount,0))
		FROM T_OrderFrightOffer a WITH(NOLOCK)
		INNER JOIN dbo.T_Order WITH(NOLOCK) ON  a.OrderId=dbo.T_Order.OrderId
		WHERE a.OrderId IN (SELECT SN FROM @TempOrders)
		 AND OrderStatus<>132
		 AND a.IsDelete=0
       
END
go


CREATE PROC dbo.CRM_AddBankTransferRecord
 (
 @CreatorUserId INT,
 @Type INT,
 @CustomerName VARCHAR(50),
@OrderId VARCHAR(200),
@CountryId INT,
@AccountType INT,
@PayCurrencyId INT,
@PayMoney DECIMAL(9,2),
@ReceiptCurrencyId INT,
@ReceiptMoeny DECIMAL(9,2),
@ReceiptTime VARCHAR(20),
@PayUserInfo NVARCHAR(200),
@TranNo VARCHAR(100),
@Remark NVARCHAR(500),
@Status INT
 )
 AS
 BEGIN
 DECLARE @Message VARCHAR(100)='';
 IF   LEN(RTRIM(@TranNo))>0 AND  EXISTS (SELECT TOP 1 1FROM dbo.T_BankTransferRecord WHERE TransactionNo=@TranNo AND Type=1)
 BEGIN
 	       SET @Message = '<info>交易号'+@TranNo+'重复!</info>'            
       RAISERROR(@Message, 16, 1) WITH NOWAIT ;        
 END

 	INSERT INTO dbo.T_BankTransferRecord
 	        ( CreateTime ,
 	          CustomerName ,
 	          CountryId ,
 	          OrderId ,
 	          PayCurrencyId ,
 	          PayMoney ,
 	          AccountType ,
 	          ReceiptCurrencyId ,
 	          ReceiptMoeny ,
 	          ReceiptTime ,
 	          CreatorUserId ,
 	          Remark ,
 	          PayUserInfo ,
 	          TransactionNo ,
 	          [Type],
			  [status]
 	        )
 	VALUES  ( GETDATE() , -- CreateTime - datetime
 	          @CustomerName , -- CustomerName - varchar(50)
 	         @CountryId , -- CountryId - int
 	          @OrderId , -- OrderId - varchar(200)
 	          @PayCurrencyId, -- PayCurrencyId - tinyint
 	          @PayMoney , -- PayMoney - decimal
 	          @AccountType, -- AccountType - tinyint
 	          @ReceiptCurrencyId, -- ReceiptCurrencyId - tinyint
 	          @ReceiptMoeny , -- ReceiptMoeny - decimal
 	     	          CASE WHEN ISDATE(@ReceiptTime)=1 and DATEPART(YEAR,@ReceiptTime)>1000 THEN convert(VARCHAR,@ReceiptTime, 121) ELSE NULL END , -- ReceiptTime - datetime
 	          @CreatorUserId , -- CreatorUserId - int
 	          @Remark , -- Remark - nvarchar(500)
 	          @PayUserInfo, -- PayUserInfo - nvarchar(200)
 	          @TranNo, -- TransactionNo - varchar(100)
 	          @Type,  -- Type - tinyint
			  @Status
 	        )
 END


go


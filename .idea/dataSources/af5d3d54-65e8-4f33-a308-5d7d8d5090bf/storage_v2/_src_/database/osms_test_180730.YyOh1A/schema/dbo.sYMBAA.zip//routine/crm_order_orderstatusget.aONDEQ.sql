

/*----------------------------------------
备注:返回订单状态
创建人: FRH
创建日期:2009-01-11

修改人：HYD 
修改时间：2010-04-01
修改内容：增加返回订单类型
-----------------------------------------------------*/
CREATE PROC [dbo].[CRM_Order_OrderStatusGet] 
(
	@OrderId 		VARCHAR(20),
	@Status			INT	OUT	,
	@OrderType		INT OUT
)
AS
BEGIN
	SELECT @Status = [OrderStatus],@OrderType = OrderType FROM dbo.T_Order WHERE OrderId = @OrderId;
	IF @Status IS NULL SET @Status = 0; -- Pending状态
	IF @OrderType IS NULL SET @OrderType = 1; -- 网站订单
END
go


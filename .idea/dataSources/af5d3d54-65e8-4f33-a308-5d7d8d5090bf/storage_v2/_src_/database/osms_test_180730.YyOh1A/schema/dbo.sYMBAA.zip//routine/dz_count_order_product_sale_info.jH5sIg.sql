  
/**  
 @desc 统计订单历史销量  
 @date 2016-05-18  
 @author whw   
*/  
CREATE FUNCTION dz_count_order_product_sale_info(  
 @EndDate DATETIME,  
 @maxDays INT  
)  
RETURNS @table TABLE (  
      product_id INT NULL,  
      saleQuantity INT NULL,  
      orderNum INT NULL  
      )   
AS   
 BEGIN  
  DECLARE @startDate DATETIME=DATEADD(Day,-@maxDays,GETDATE())  
    
  INSERT @table  
          ( product_id, saleQuantity,orderNum )  
  SELECT i.product_id,SUM(i.order_quantity) AS saleQuantity,  
  COUNT(DISTINCT o.id)  
   FROM dbo.[order] o WITH(NOLOCK)   
  JOIN dbo.order_item i WITH(NOLOCK)  
  ON i.order_id = o.id   
  AND (o.status<132 AND i.status<12)   
  where o.order_time >=  CONVERT(VARCHAR(100),@startDate,20)  -- 录单时间      
  AND o.order_time <  CONVERT(VARCHAR(100),@EndDate,20)  
  AND o.type NOT IN(SELECT order_type FROM dbo.business_type WHERE platform_type = 5)           --排除点单来源为6.CN、21.TA-DZ-DH、27.WH-FBA的订单  
  GROUP BY i.product_id   
    
  RETURN ;  
 end

go


CREATE PROC dbo.CMS_CheckProduct_CheckProductList
    (
      @ProductCode VARCHAR(22) = NULL , --产品编号    
      @ProductCodes VARCHAR(MAX)= NULL , --产品编号列表  
      @CategoryId1 INT = NULL ,--一级类别ID    
      @CategoryId2 INT = NULL ,--二级类别ID    
      @CategoryId3 INT = NULL ,--三级类别ID  
      @DepartmentId INT = NULL,--部门（物流1、物流2）
      @OrderCode VARCHAR(22) = NULL,--订单编号 
      @OrderCodes VARCHAR(MAX) = NULL, --订单编号批量
      @Status INT = NULL,--质检状态
      @IsCancel INT = NULL,--是否取消质检
      @CheckTimeBegin VARCHAR(20) = NULL,
      @OrderItemStatus INT =NULL,  -- 3.9.31 备货状态
      @MerchandiserId INT = NULL, -- 3.9.31 跟单员
      @OrderPosition VARCHAR(MAX) = NULL, --3.9.31 订单箱号
      @CheckTimeOver VARCHAR(20) = NULL,
      @PrepareEnough INT = NULL, -- 3.9.32 备货充足
      @WaitProcess INT =NULL , -- 3.9.32 等待加工
	  @restockStatus INT=NULL,
	  @preparedLevel INT=NULL,
	  @isVip INT = NULL,
      @PageSize INT = 50 ,  --页大小                            
      @PageIndex INT = 1    --当前页号  
    )
AS 
   
 BEGIN  
        DECLARE @SQL NVARCHAR(MAX) ,
            @FromSQL NVARCHAR(MAX) ,
            @FromSQL2 NVARCHAR(MAX) ,  
            @Column NVARCHAR(MAX) ,
            @Condition NVARCHAR(MAX) ,
            @CountSQL NVARCHAR(MAX) , 
            @RowCount INT ,
            @PageCount INT ,   
            @start INT ,
            @end INT ;           
     
		--组装查询条件          
        SET @Condition = ' WHERE 1=1 ' ;    
    IF @isVip IS NOT NULL
	BEGIN
	SET @Condition = @Condition + 
	' AND c.is_vip='
						+ CONVERT(VARCHAR(10), @isVip) 
	END    
	IF @ProductCode IS NOT NULL 
				BEGIN  
					SET @Condition = @Condition + ' and product.code like '''
						+ 
	@ProductCode + '%''' ;  
				END  
			IF @ProductCodes IS NOT NULL 
				BEGIN  
					SET @Condition = @Condition + ' and 
	product.code in ('''
						+ REPLACE(@ProductCodes, ',', ''',''') + ''')' ;        
				END 
			IF @CategoryId1 IS NOT NULL 
				BEGIN        
					SET @Condition = @Condition + ' AND product.category_id_1='
						+ CONVERT(VARCHAR(10), 
	@CategoryId1)      
				END       
			IF @CategoryId2 IS NOT NULL 
				BEGIN        
					SET @Condition = @Condition + 
	' AND product.category_id_2='
						+ CONVERT(VARCHAR(10), @CategoryId2)      
				END       
			IF @CategoryId3 IS NOT NULL 
				BEGIN         
					SET @Condition = @Condition + ' AND product.category_id_3='
						+ CONVERT(VARCHAR(10), 
	@CategoryId3)      
				END 
			IF @DepartmentId IS NOT NULL 
				BEGIN  
					SET @Condition = @Condition + ' and 
	c.department_id=' + CONVERT(VARCHAR(10), @DepartmentId) ;  
				END  
			IF @OrderCode IS NOT NULL 
				BEGIN  
					SET 
	@Condition = @Condition + ' and c.code like  ''%' + @OrderCode + '%''' ;  
				END 
			IF @OrderCodes IS NOT NULL
				
	BEGIN
					SET @Condition = @Condition + ' and c.code in ('''+ REPLACE(@OrderCodes, ',', ''',''') + ''') '
				END
	  
		  IF @Status IS NOT NULL 
				BEGIN  
					SET @Condition = @Condition + ' and a.status=' + CONVERT(VARCHAR(10), @Status) ;    
				END 
			IF @IsCancel IS NOT NULL 
				BEGIN  
					IF @IsCancel = 1
					 BEGIN
					
		SET @Condition = @Condition + ' and a.cancel_quantity > 0 ';    
					 END 
				END
			IF @CheckTimeBegin IS NOT NULL 
		
			BEGIN
					 SET @Condition = @Condition + ' and a.check_time>=''' + @CheckTimeBegin + ''''
				END
		
		IF @CheckTimeOver IS NOT NULL 
				BEGIN
					SET @Condition = @Condition + ' and a.check_time<=''' + 
	@CheckTimeOver + ''''
				END
	-----------------------------3.9.31------------------------------------------------			
	 IF @OrderItemStatus IS NOT NULL
			BEGIN
				SET @Condition = @Condition + ' and b.status=' + CONVERT(VARCHAR(10), @OrderItemStatus) ;    
			END	
	
	IF @MerchandiserId IS NOT NULL
			BEGIN
				SET @Condition = @Condition + ' and c.merchandiser_id=' + CONVERT(VARCHAR(10), @MerchandiserId) ;    
			END	
	IF @OrderPosition IS NOT NULL
			BEGIN
				SET @Condition = @Condition + ' and t.position like  ''%' + @OrderPosition + '%''' ;  
			END	
						
	----------------------------------3.9.32-------------------------------------
	IF @PrepareEnough IS NOT NULL
		BEGIN
			IF @PrepareEnough = 1
				BEGIN
					SET @Condition = @Condition + ' and isnull(b.zcq_department_received_qty,0) >= b.order_quantity ';
				END
			ELSE
				BEGIN
					SET @Condition = @Condition + ' and isnull(b.zcq_department_received_qty,0) < b.order_quantity ';
				END	
		END
	
	IF @WaitProcess IS NOT NULL
		BEGIN
			IF @WaitProcess = 1
				BEGIN
					SET @Condition = @Condition + ' AND b.processing_status = 20';
				END
			ELSE
				BEGIN
					SET @Condition = @Condition + ' AND b.processing_status != 20';
				END	
			
		END
	
	IF @restockStatus IS NOT NULL
	BEGIN
	    SET @Condition = @Condition + ' and a.restock_status = ' + CONVERT(VARCHAR(10), @restockStatus) ;;
	END
	IF @preparedLevel IS NOT NULL
	BEGIN
	    IF @preparedLevel=0
		BEGIN
		    SET @Condition = @Condition + ' and (b.status<6)' 
		END
		ELSE IF @preparedLevel=1
		BEGIN
		     SET @Condition = @Condition + ' and b.status>=6 and DATEDIFF(HOUR,b.ready_time,GETDATE() )<=24 ' 
		END
		ELSE IF @preparedLevel=2
		BEGIN
		     SET @Condition = @Condition + ' and b.status>=6 and DATEDIFF(HOUR,b.ready_time,GETDATE() )<=48 
													and DATEDIFF(HOUR,b.ready_time,GETDATE() )>24 ' 
		END
		ELSE IF @preparedLevel=3
		BEGIN
		     SET @Condition = @Condition + '  and b.status>=6 and DATEDIFF(HOUR,b.ready_time,GETDATE() )>48	 ' 
		END
	END

	-----------------------------------------------------------------------------
	             
	                
	SET @FromSQL = ' FROM dbo.check_product AS a WITH(NOLOCK)
					 inner join [order_item] as b  WITH(NOLOCK) on a.order_item_id = b.id and a.order_id= b.order_id
					 inner join [order] as c WITH(NOLOCK) on c.id = b.order_id
					 INNER JOIN product AS product WITH(NOLOCK) ON b.product_id =product.id
					 LEFT JOIN  [user] u WITH(NOLOCK) ON u.id = c.merchandiser_id  
					 left join order_item_group as t WITH(NOLOCK) on t.id = b.order_item_group_id
					 left join blacklist_product as t2 WITH(NOLOCK) on t2.product_id = product.id
					 left join view_product_all_storage_quantity_info v on v.product_id=product.id
					 ';
        
	  --获取符合条件的总记录数          
			SET @CountSQL = ' SELECT @RowCount = count(a.id) ' + 
	@FromSQL
				+ @Condition                    
			EXEC sp_executesql @CountSQL, N'@RowCount INT OUT', @RowCount OUT           
	  
	  --设置分页参数(一定要放在取记录数的后面)          
			IF ISNULL(@PageSize, 0) < 1 
				SET @PageSize = 50                          
			SET 
	@PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                          
			IF ISNULL(@PageIndex, 0) < 1 
				SET @PageIndex = 1  
	                        
			ELSE 
				IF ISNULL(@PageIndex, 0) > @PageCount 
					SET @PageIndex = @PageCount                   
	    
			SET @start = ( @PageIndex - 1 ) * @PageSize + 1                          
			SET @end = @PageIndex * @PageSize     
	  
			SET 
	@Column = 'a.id,
			a.restock_status as restockStatus,
			a.restock_quantity as restockQuantity,
			a.problem_quantity as problemQuanntity ,
			isnull( CASE WHEN b.complete_recive_date is null  THEN 0 --未备货 
		WHEN DATEDIFF(HOUR,b.complete_recive_date,GETDATE() )<=24 THEN 1 --24小时内
		WHEN DATEDIFF(HOUR,b.complete_recive_date,GETDATE() )<=48 THEN 2 --超过24小时
		WHEN DATEDIFF(HOUR,b.complete_recive_date,GETDATE() )>48 THEN 3 --超过48小时
		END,0) as preparedLevel,
		a.checked_quantity as checkedQuantity,
		 isnull(v.available_qty,0) as availableQuantity,
		 a.order_id as orderId,  
		 a.order_item_id as orderItemId,  
		 a.status as status,
		 a.cancel_quantity as cancelQuantity,
		 a.remark as remark,
		 a.create_time as createTime,
		 a.create_user_id as createUserId,
		 a.check_time as checkTime,
	     a.check_user_id as checkUserId,
		 a.order_modify_record_id as orderModifyRecordId,
		 product.id as  productId, 
		 product.primary_picture_code as primaryPictureCode,  
		 product.color_card_picture_code as colorCardPictureCode,       
		 product.code as productCode, 
	     CONVERT(VARCHAR(500),product.unit_quantity)+'' ''+ product.unit as productUnit,    
		 product.name as productName,   
		 b.order_item_group_id as order_item_group_id,
		 b.order_quantity as orderQuantity,
		 b.prepared_quantity as preparedQuantity,
		 b.zcq_department_received_qty as receivedQty,
		 b.customer_service_remark as customerRemark,
		 c.customer_service_remark orderRemark,
		 b.customer_remark AS customerServiceRemark,
		 b.branch_remark  as branchRemark,
		 c.code as orderCode,  
		 c.department_id as departmentId,
	     u.id as merchandiserId,
		 u.name as merchandiserName, 
		 b.status as preparedStatus,
		 a.app_flag as appFlag,
		 t.position as orderPosition,
		 t.name as orderGroupCode,
		 c.is_vip as isVip,
		 CASE WHEN ISNULL(t2.id,0) = 0 THEN 0 ELSE 1 END  as isBlackProduct, 
		 b.processing_status as processingStatus ,
		 a.afresh_ckeck as afreshCkeck ,
		 b.is_add_quantity as hasModified
		 ' ;         
	  --b.customer_Remark as orderRemark,   
	  --b.customer_Service_Remark as customerServiceRemark,
	    
	  --组装查询语句              
	        
	SET @SQL = 'SELECT ' + @Column + ', ROW_NUMBER() OVER (ORDER BY a.id desc) RowIndex '
				+ @FromSQL + @Condition ;    
	         
	   	             
--	SET @FromSQL2 = ' inner join order_item_group as t WITH(NOLOCK) on t.id = temp.order_item_group_id 
--	left join blacklist_product as t2 WITH(NOLOCK) on t2.product_id = temp.productId';
							
	  
			SET @SQL = 'SELECT temp.* FROM (' + @SQL + ') temp  WHERE RowIndex between '
				+ CONVERT(VARCHAR(10), @Start) + ' AND '
				+ CONVERT(VARCHAR(10), @End) + ' order by RowIndex' ;    
	                    
			--SELECT @SQL
			PRINT @SQL  
			EXEC(@SQL) ;                                      
	     
	   SELECT  @RowCount    
	   SET NOCOUNT OFF ;  
    END


go


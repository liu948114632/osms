
-- =============================================      
-- Author:  HYD      
-- Create date: 2010-04-01      
-- Description: 生成未决订单前的判断      
      
-- 修改人:  HYD      
-- 修改版本: CMS 5.1.0.0      
-- 修改时间: 2010-04-29      
-- 修改内容: 由原先的判断T_Order表改为判断C_Order表，为了兼容PW的生成未决订单操作      
-- =============================================      
CREATE PROCEDURE [dbo].[CRM_Order_PendingOrderCreateCheck]      
(      
 @OrderId VARCHAR(20)      
)      
AS      
BEGIN      
 -- 不记录行的变化       
 SET NOCOUNT ON;      
     
 DECLARE @Status INT--订单状态      
      
 -- 获取订单信息      
 Select  @Status  = OrderStatus       
 From  dbo.T_Order      
 Where OrderId = @OrderId;      
       
 If (@Status != 1)      
 BEGIN      
  Raiserror('只允许准备货物状态下生成未决订单！' , 16, 1) WITH NOWAIT;      
  RETURN;      
 END      
       
 IF NOT EXISTS(SELECT * FROM dbo.T_OrderItem Where OrderId = @OrderId And ReadyQty < Quantity AND [Status] < 12)      
 BEGIN      
  Raiserror('全部备货的订单不能生成！' , 16, 1) WITH NOWAIT;      
  RETURN;      
 END      
       
 IF NOT EXISTS(SELECT * FROM dbo.T_OrderItem Where OrderId = @OrderId And ReadyQty > 0 AND [Status] < 12)      
 BEGIN      
  Raiserror('没有到货商品的订单不能生成未决订单！' , 16, 1) WITH NOWAIT;      
  RETURN;      
 END      
END
go


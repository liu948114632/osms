

/*----------------------------------------------------
[推广]
	注册客户当天下单情况
当天注册客户有多少个下单；
有多少个下单且付款；
up_Report_Market_RegOrderCustomerGet '2008-01-01','2008-10-01'
-----------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Market_RegOrderCustomerGet]  
(
	@Start			Datetime, 
	@End			Datetime	
)
AS
Begin
	SET NOCOUNT ON;
	
	/*
	WITH cte AS
	(
		Select CONVERT(VARCHAR(8),regtime,112) as RegTime,
		count(1) as Users
		From t_customer
		Where regfrom is null
			And regtime > @Start And regtime < @End
		Group By CONVERT(VARCHAR(8),regtime,112)
	)

	SELECT Regtime,Users,
	[dbo].[uf_report_mark_GetRegOrderCustomers](Regtime,@Start,@End) AS  OrderUsers,
	[dbo].[uf_report_mark_GetRegOrderPayCustomers](Regtime,@Start,@End)AS  PayUsers
	FROM cte
	ORDER BY regtime
	
	*/
	
	WITH cte AS
	(
		SELECT 
			CONVERT(VARCHAR(8),regtime,112) as RegTime,-- 当天
			COUNT(1) Users -- 每天注册客户数
		FROM dbo.T_Customer
		WHERE regtime > @Start And regtime < @End AND RegFrom = '' -- PH客户
		Group By CONVERT(VARCHAR(8),regtime,112)
	)

	SELECT 
		Regtime,
		Users,
		[dbo].[uf_report_mark_GetRegOrderCustomers](Regtime,@Start,@End) AS  OrderUsers,
		[dbo].[uf_report_mark_GetRegOrderPayCustomers](Regtime,@Start,@End)AS  PayUsers
	FROM cte
	ORDER BY regtime;
End


go




CREATE PROC dbo.CRM_Order_OrderDeliver                    
(                    
  @OrderId VARCHAR(20),      
  @SendWeight DECIMAL(18,2) ,
  @DMSOrderShippingRemark NVARCHAR(500)='',
  @ActualFreightCosts DECIMAL(9,2)
)                    
AS                     
BEGIN                 
    DECLARE @OrderStatus INT             
        
    SELECT @OrderStatus = dbo.T_Order.OrderStatus            
    FROM dbo.T_Order            
    WHERE dbo.T_Order.OrderId = @OrderId            
        
    IF( @OrderStatus<>62 AND @OrderStatus<>60)            
    BEGIN            
        RAISERROR ('订单状态不是已出库或发货中状态，不允许发货!' , 16, 1) WITH NOWAIT;            
        RETURN;            
    END             
        
    UPDATE dbo.T_Order SET OrderStatus = 64,            
                           PostWeight = @SendWeight,     
                           IsModifyFreight_deliverWeight = 1,     
                           LastModifyTime = GETDATE(),    
                          DeliveryDate=GETDATE()             
    WHERE dbo.T_Order.OrderId = @OrderId  AND dbo.T_Order.OrderStatus >= 60        
        
     -- 完成订单项                
  UPDATE dbo.T_OrderItem                
  SET [Status] = 8                
  WHERE OrderId = @OrderId And [Status] =6;              

  UPDATE dbo.T_OrderRemark SET DMSOrderShippingRemark=@DMSOrderShippingRemark WHERE OrderId=@OrderId;

  UPDATE dbo.T_OrderPrice SET ActualFreightCosts=@ActualFreightCosts WHERE OrderId=@OrderId

UPDATE T_OrderExtend SET DeliveryTimes=ISNULL(DeliveryTimes,0)+1 WHERE OrderId=@OrderId

END

go


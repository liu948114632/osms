CREATE PROC [dbo].[CMS_Service_OrderStorageTask]  
AS   
    BEGIN                        
        SET NOCOUNT ON ;           
        IF OBJECT_ID('#temp_order_item_demand') IS NOT NULL   
            DROP TABLE #temp_order_item_demand ;      
       
        SELECT 
        IDENTITY(int,1,1) AS rowindex,
         temp.id AS orderItemId ,  
                temp.order_id AS orderId ,  
                temp.code AS orderCode ,  
                temp.product_id AS productId ,  
                temp.quantity AS assignQuantity ,  
                CONVERT(VARCHAR(20), temp.unit_quantity) + ' ' + temp.unit AS productUnit ,  
                temp.orderType AS orderType ,  
                temp.department_id AS departmentId ,  
                temp.is_pool  
        INTO    #temp_order_item_demand  
        FROM    ( SELECT    i.id ,  
                            ( i.order_quantity - i.prepared_quantity ) AS quantity,
                            i.product_id ,  
                            o.code ,  
                            o.valid_Order_Count ,  
                            o.prepared_Count ,  
                            o.priority_Level ,  
                            o.order_Time ,  
                            i.unit_quantity ,  
                            i.unit ,  
                            i.order_id ,  
                            o.department_id ,  
                            o.type AS orderType ,  
                            i.is_pool  
                  FROM      order_item AS i WITH(NOLOCK)  
                            INNER JOIN [Order] AS o  WITH(NOLOCK) ON o.id = i.order_Id  
                           -- JOIN small_lot_order slo WITH(NOLOCK) ON slo.order_id=o.id   
                  WHERE  i.status < 6 AND o.status = 1  AND i.processing_status<>30   AND i.is_customize = 0 AND
                   DATEDIFF(hh,i.order_time,GETDATE())>=1
                  --AND o.type NOT IN (SELECT order_type FROM business_type WITH(NOLOCK) WHERE is_dz=1)  
                 -- AND  slo.is_deleted=1   
                  AND NOT EXISTS   
                  (SELECT id FROM purchasing_management_task c WITH(NOLOCK) WHERE c.status IN (1,8) AND c.order_id=o.id AND c.order_item_id=i.id)   
                  AND (i.status<>4 OR ( i.status=4 AND   
                   NOT EXISTS ( SELECT  id FROM  dbo.p_storage_task d  WITH(NOLOCK) where d.order_item_id=i.id AND d.order_id=o.id   AND d.type=4 )))  
                            --AND o.type < 3  
                ) temp  
       
        ORDER BY ( temp.valid_Order_Count - temp.prepared_Count ) ,  
                temp.priority_Level DESC ,  
                temp.order_Time ASC            
    
--        DELETE  a  
 --       FROM    #temp_order_item_demand AS a  
  --             INNER JOIN product_pool AS b ON a.productid = b.product_Id  
   --     WHERE   a.orderType = 2     
    
        SELECT  a.*  
        FROM    #temp_order_item_demand AS a  
                INNER JOIN [view_product_all_storage_quantity_info] AS s WITH(NOLOCK) ON a.productId = s.product_id  
                --LEFT JOIN (SELECT product_id,SUM(freeze_quantity) AS real_freeze_quantity FROM  dbo.business_department_reservation_storage  GROUP BY product_id) d  ON d.product_id =a.productId                                 
        WHERE   ( s.quantity - s.lock_quantity ) >= a.assignQuantity    AND a.assignQuantity>0   ORDER BY a.rowindex asc
     
      
        SET NOCOUNT OFF ;         
        DROP TABLE #temp_order_item_demand      
    END


go


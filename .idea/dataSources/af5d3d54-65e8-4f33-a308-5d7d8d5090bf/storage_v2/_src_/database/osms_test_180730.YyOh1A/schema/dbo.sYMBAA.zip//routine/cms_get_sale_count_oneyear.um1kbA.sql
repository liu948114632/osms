


CREATE FUNCTION CMS_Get_Sale_Count_OneYear(@productId INT )
RETURNS INT
AS
	BEGIN
		 DECLARE @Result INT
		 SELECT @Result = Count(A.id)  FROM order_item A WITH(NOLOCK)
		 WHERE A.product_id = @productId 
							AND A.order_time >  DATEADD(YEAR,-1,GetDate())
							AND A.status <>12
		 RETURN @Result
	END

go


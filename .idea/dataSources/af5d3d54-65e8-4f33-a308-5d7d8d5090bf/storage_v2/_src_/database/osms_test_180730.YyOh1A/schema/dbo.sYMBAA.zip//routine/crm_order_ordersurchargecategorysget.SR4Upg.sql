  
-- =============================================      
-- Author:  HYD      
-- Create date: 2010-06-10      
-- Description: 获取附加费所有类别      
-- Version：CRM 5.1.0      
-- =============================================      
CREATE PROCEDURE [dbo].[CRM_Order_OrderSurchargeCategorysGet]      
AS      
BEGIN    
 SET NOCOUNT ON;    
 SELECT CategoryId,CategoryName,[Type] FROM dbo.T_OrderSurchargeCategory    
END
go


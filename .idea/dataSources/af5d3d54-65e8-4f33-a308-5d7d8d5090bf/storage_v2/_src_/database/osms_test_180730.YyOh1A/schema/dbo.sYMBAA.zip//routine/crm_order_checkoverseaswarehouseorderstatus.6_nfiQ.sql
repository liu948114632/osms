

/**
检查海外仓订单状态
*/
CREATE PROC CRM_Order_CheckOverseasWarehouseOrderStatus
(  
  @OrderId VARCHAR(20) --订单号
)
AS
BEGIN
      Declare @IsOverseasWarehouseOrder bit ,@OverseasWarehouseStatus int 
      
      select @IsOverseasWarehouseOrder = IsOverseasWarehouseOrder ,
             @OverseasWarehouseStatus = OverseasWarehouseStatus
      from T_order
      where OrderID = @OrderId
      
      --如果不是海外仓订单或未确定的海外仓订单，则不用检查
      if( @IsOverseasWarehouseOrder = 0 OR @OverseasWarehouseStatus = 10 )
      begin
         return ;
      end 
      
      if( not exists(select top 1 1 from T_OrderItem where OrderId =@OrderId and Status < 12 AND IsGoOverseasWarehouse=1) )
      BEGIN
			  update T_order set IsOverseasWarehouseOrder=0, OverseasWarehouseStatus = 0
			  where OrderID = @OrderId
	          
			  --记录订单历史
			  EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int
						 @OrderId = @OrderId, -- varchar(14)
						 @Remark = N'订单转为非海外仓订单' -- varchar(5000)
		 
      end 
      else 
      begin
           if( exists(select top 1 1 from T_OrderItem where OrderId =@OrderId and Status < 12 AND IsGoOverseasWarehouse=0) )
		   BEGIN
		      IF( @OverseasWarehouseStatus != 20 )
		      BEGIN
				  update T_order set OverseasWarehouseStatus = 20
				  where OrderID = @OrderId
				  
				   --记录订单历史
				  EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int
						 @OrderId = @OrderId, -- varchar(14)
						 @Remark = N'订单转为部分海外仓订单' -- varchar(5000)
			 END 
		   end 
		   else 
		   BEGIN
		      IF( @OverseasWarehouseStatus != 30 )
		      BEGIN
				  update T_order set OverseasWarehouseStatus = 30
				  where OrderID = @OrderId
				  
				   --记录订单历史
				   EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int
						 @OrderId = @OrderId, -- varchar(14)
						 @Remark = N'订单转为全海外仓订单' -- varchar(5000)
			 END 
		   end 
      end 
END
go


CREATE PROC dbo.CRM_Order_GetOrderModifyRecordItemsByOrderId
(        
  @OrderId VARCHAR(20)                                                                                                 
)                                                    
AS      
BEGIN                                                    
SET NOCOUNT ON ;  

WITH temp AS
(
	SELECT       
	  A.Id,      
	  A.OrderModifyRecordId,      
	  A.CmsProductId,      
	  a.OrderQty,      
	  A.OperateType,      
	  A.Remark,      
	  B.code AS ProductCode,      
	  D.OrderItemId,    
	  (CASE WHEN I.Description IS NOT NULL AND LEN(RTRIM(LTRIM(I.Description))) > 0 then I.Description ELSE B.DESCRIPTION end ) AS Description ,
	  d.Quantity AS OldQuantity,
	  I.ImageName AS ImageUrl,  
	  CONVERT(INT ,D.Status) AS Status    ,
		  (SELECT ISNULL(SUM(a1.UnProcessQty),0) FROM dbo.T_OrderModifyRecordItem a1 WITH(NOLOCK)
		  INNER JOIN dbo.T_OrderModifyRecord b1 WITH(NOLOCK) ON a1.OrderModifyRecordId=b1.Id
		   WHERE b1.OrderId=e.orderid  AND a1.CmsProductId=a.CmsProductId AND a1.OperateType=2) AS UnProcessQty ,--多次变更修改订购量 数量要累加
	  ROW_NUMBER() OVER(PARTITION BY A.CmsProductId ORDER BY D.OrderItemId,A.OrderModifyRecordId DESC,A.OperateType ASC) AS rowIndex--OperateType=1 取消，2=修改订购量，以取消为最终结果
	  FROM dbo.T_OrderModifyRecordItem AS A WITH(NOLOCK) 
	  INNER JOIN dbo.T_OrderModifyRecord e ON a.OrderModifyRecordId=e.Id
	  INNER JOIN dbo.V_CRM_Base_Product AS B ON A.CmsProductId = B.CmsProductId      
	  INNER JOIN dbo.T_OrderModifyRecord AS C WITH(NOLOCK) ON C.Id = A.OrderModifyRecordId      
	  INNER JOIN dbo.T_OrderItem AS D WITH(NOLOCK) ON D.OrderId = C.OrderId AND D.CmsProductId = A.CmsProductId      
	  LEFT JOIN dbo.T_OrderItemProduct AS I WITH(NOLOCK) ON D.OrderItemId = I.OrderItemId     
	  WHERE e.OrderId=@OrderId
)    
SELECT id,OrderModifyRecordId,CmsProductId,OrderQty,OperateType,Remark,ProductCode,OrderItemId,Description,OrderQty+UnProcessQty AS OldQuantity,ImageUrl,Status,UnProcessQty,rowIndex
FROM  temp
  WHERE rowIndex=1
END
go


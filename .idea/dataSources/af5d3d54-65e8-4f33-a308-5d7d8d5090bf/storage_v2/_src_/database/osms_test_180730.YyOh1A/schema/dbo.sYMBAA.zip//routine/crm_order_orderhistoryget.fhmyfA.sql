
/*------------------------------------------
[备注] 
	查看订单历史记录
	
	
-- 修改人:		HYD
-- 修改日期:	2010-06-3
-- 版本：		CRM 5.1.0
-- 修改内容:	增加CASE判断如果UserId为0的话，则显示用户为“系统”
--------------------------------------------*/
CREATE PROC [dbo].[CRM_Order_OrderHistoryGet] 
(
	@OrderId 		VARCHAR(20) = ''
)
AS

Begin
	Set Nocount On
	
	Select
		Id,
		order_code AS OrderId,
		operator_id AS UserId,
		CASE WHEN operator_id =0 THEN '系统' ELSE  (Select [name] From [user] Where [Id] = dbo.order_history.operator_id) END As UserName,

		operator_time AS UpdateTime,
		process AS Remark
	From 
		dbo.order_history
	Where
		order_code = @OrderId
	Order By
		id DESC;
END

go


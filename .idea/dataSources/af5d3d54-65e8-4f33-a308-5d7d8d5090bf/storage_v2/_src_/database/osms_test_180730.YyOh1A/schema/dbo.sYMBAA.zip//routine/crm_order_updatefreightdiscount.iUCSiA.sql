
CREATE PROC CRM_Order_UpdateFreightDiscount  
(  
  @OrderId VARCHAR(20),  
  @NewFreightDiscount DECIMAL(18,2)  
)  
AS   
Begin  
   --如果运费折扣变了，则去掉原先运费活动ID
   UPDATE dbo.T_Order 
   SET  DeliveryPromoteActivityId = (CASE WHEN FreightDiscount != @NewFreightDiscount THEN NULL ELSE DeliveryPromoteActivityId END),
        FreightDiscount = isnull(@NewFreightDiscount,1)
   WHERE orderid= @OrderId  
END
go


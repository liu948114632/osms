
-- =============================================    
-- Author:  HYD    
-- Create date: 2011-10-18    
-- Description: 根据CMS产品Id获取产品可用库存    
-- =============================================    
CREATE PROC dbo.CRM_Product_ProductStorageQtyGet    
 @CMSProductId INT,    
 @BuessType INT=1,
 @StorageQty INT OUT    
AS    
BEGIN    
 -- SET NOCOUNT ON added to prevent extra result sets from    
 -- interfering with SELECT statements.    
 SET NOCOUNT ON;    
 DECLARE @ProductDataId INT    
 SET @StorageQty = 0;     
IF  (@BuessType=1 OR @BuessType=5 OR @BuessType=6 OR EXISTS (SELECT TOP 1 1 FROM dbo.T_BusinessType WHERE BusinessTypeValue=@BuessType AND  IsPHClone=1))
		 SELECT @StorageQty =phStorageQuantity
		 FROM CRM_View_ProductStorageQuantity WHERE product_id = @CMSProductId  
 ELSE
	  SELECT @StorageQty = PublicStorageQuantity
	 FROM CRM_View_ProductStorageQuantity WHERE product_id = @CMSProductId  

END
go


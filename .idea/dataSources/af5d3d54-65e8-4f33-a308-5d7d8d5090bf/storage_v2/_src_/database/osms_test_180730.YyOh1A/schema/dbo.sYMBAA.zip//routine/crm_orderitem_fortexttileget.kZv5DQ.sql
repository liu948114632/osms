
/*----------------------------------      
[描述]: 查找已出库的订单的商品项的商品名称及纺织品关键词      
      
创建人：HYD      
创建时间：2009-08-29      
版本：V 3.2      
----------------------------------------------------------*/      
CREATE PROC [dbo].[CRM_OrderItem_ForTextTileGet]      
 @OrderId VARCHAR(20)      
AS      
BEGIN      
      
       
 SELECT a.OrderItemId,a.CmsProductId,a.ProductId,p.Name,a.Box 
 FROM t_OrderItem a      
  JOIN dbo.T_Order b ON a.OrderId = b.OrderId      
   JOIN dbo.V_CRM_Base_Product p ON a.CmsProductId = p.CmsProductId      
 WHERE a.Status < 12 AND b.OrderId = @OrderId      
      
      
      
END
go


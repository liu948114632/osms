
/*-----------------------------------------------    
备注：获取订单发货后15天之内之前取消的订单商品    
创建人: FRH    
创建日期:2010-01-14    
    
修改人:HYD    
修改时间：2010-07-21    
修改内容：由原先的获取可用库存，更改为获取库存，及商品总需求    
----------------------------------------------------------*/    
CREATE PROCEDURE [dbo].[CRM_Order_OrderItemListGetByCancel]    
AS    
BEGIN    
 WITH cte AS (    
  SELECT b.HandlerId,b.OrderId ,c.CmsProductId,c.Unit,c.Quantity,c.UnitQuantity    
  FROM dbo.T_OrderPackage a    
   JOIN dbo.T_Order b     
    ON a.OrderId = b.OrderId AND (b.OrderStatus > 128 OR b.OrderStatus < 128)    
   JOIN dbo.T_OrderItem c     
    ON b.OrderId = c.OrderId AND c.[Status] = 12    
  WHERE DATEDIFF(DAY,a.DueDate,GETDATE()) < 15    
 )    
    
 SELECT    
   a.HandlerId,    
   a.OrderId,    
   a.ProductId,    
   a.Quantity,    
   a.UnitQuantity,    
   0 AS StorageQty,    
   0 AS RequireQty,    
   (SELECT [Code] FROM dbo.V_CRM_Base_Product WHERE CmsProductId = a.CmsProductId) AS Code,-- 商品编号    
   (SELECT [Email] FROM [user] WHERE [Id] = a.HandlerId) AS Email -- 跟单员邮箱    
 FROM cte a     
  JOIN dbo.D_ProductRelation b     
   ON a.ProductId = b.ProductId AND b.[Type] = 1 -- PH商品    
--  LEFT JOIN dbo.C_Storage c -- 中心库存    
--   ON c.StockId = 4 AND b.ProductDataId = c.ProductDataId    
--  LEFT JOIN V_CMS_RequireQty d    
--   ON b.ProductDataId = d.ProductDataId    
 ORDER BY a.OrderId;    
END
go


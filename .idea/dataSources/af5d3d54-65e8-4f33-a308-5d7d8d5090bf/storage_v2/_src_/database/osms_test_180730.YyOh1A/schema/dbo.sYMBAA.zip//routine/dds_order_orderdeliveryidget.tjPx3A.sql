
--dk
--获得PW订单货运方式ID
CREATE PROC [dbo].[DDS_Order_OrderDeliveryIdGet]
(
	@OrderId			VARCHAR(20),
	@DeliveryId			Int  Out
)
AS
BEGIN
	SET @DeliveryId = 0;
	SELECT @DeliveryId = delivery_id FROM dbo.[order] WHERE code = @OrderId;
END
go




--添加订单评价
CREATE PROC CRM_Order_AddOrderComment
(
@OrderId VARCHAR(15),
@CommentTime VARCHAR(25),
@ShipmentComment NVARCHAR(500),
@ShipmentScore INT,
@QualityComment NVARCHAR(500),
@QualityScore INT,
@ServiceComment NVARCHAR(500),
@ServiceScore INT,
@OtherComment NVARCHAR(500)
)
AS 
BEGIN
    INSERT  INTO dbo.T_OrderComment
            ( OrderId ,
              CommentTime ,
              ShipmentComment ,
              ShipmentScore ,
              QualityComment ,
              QualityScore ,
              ServiceComment ,
              ServiceScore ,
              OtherComment,
			  UnRead
	        )
    VALUES  ( @OrderId ,
              @CommentTime ,
              @ShipmentComment ,
              @ShipmentScore ,
              @QualityComment ,
              @QualityScore ,
              @ServiceComment ,
              @ServiceScore ,
              @OtherComment,
			  1
            );
END

go


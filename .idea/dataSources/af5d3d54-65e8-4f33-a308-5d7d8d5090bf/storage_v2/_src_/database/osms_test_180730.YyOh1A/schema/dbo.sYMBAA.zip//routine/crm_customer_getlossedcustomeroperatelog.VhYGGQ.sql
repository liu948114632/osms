

---获取操作日志
CREATE PROC CRM_Customer_GetLossedCustomerOperateLog
(
@CustomerId INT
)
AS 
BEGIN
SELECT a.*,u.name AS 'Operator' FROM dbo.T_LossedCustomerOperateLog a INNER JOIN 
dbo.[user] u ON a.CreatorId=u.id   WHERE a.CustomerId=@CustomerId    ORDER BY a.Id DESC 
END
go


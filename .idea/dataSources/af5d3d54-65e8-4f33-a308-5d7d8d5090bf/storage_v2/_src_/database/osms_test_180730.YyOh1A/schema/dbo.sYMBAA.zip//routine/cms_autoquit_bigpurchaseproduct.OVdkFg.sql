--自动退出大采购产品
CREATE PROC CMS_AutoQuit_BigPurchaseProduct
AS                          
BEGIN                          
    SET NOCOUNT ON ;

--获取符合退出大采购产品条件的商品池产品
WITH temp1 AS( SELECT pp.* FROM dbo.product_pool AS pp WITH (NOLOCK)
INNER JOIN dbo.product_aldi_record AS ar WITH (NOLOCK) ON ar.product_id = pp.product_id AND ar.[type] = 2
INNER JOIN dbo.product AS p WITH (NOLOCK) ON p.id=pp.product_id
WHERE p.is_display =0 
OR (DATEADD(mm,3,ar.create_time)<= GETDATE() 
AND pp.min_quantity > (SELECT SUM(temp.order_quantity) FROM 
(SELECT product_id,order_quantity FROM order_item AS oi WITH (NOLOCK)
					              INNER JOIN dbo.[order] AS o WITH (NOLOCK) ON o.id= oi.order_id
                                  WHERE o.order_time>= DATEADD(mm,-3,GETDATE()) AND oi.status <> 12 )AS temp 
WHERE temp.product_id = pp.product_id )))

--插入到待退出阿尔迪产品列表
INSERT INTO stay_quit_aldi_product(product_id,product_pool_id,create_time,[type]) 
SELECT temp1.product_id,temp1.id,GETDATE(),2 FROM temp1 
WHERE NOT EXISTS(SELECT * FROM dbo.stay_quit_aldi_product WHERE product_pool_id=temp1.id)

END
go


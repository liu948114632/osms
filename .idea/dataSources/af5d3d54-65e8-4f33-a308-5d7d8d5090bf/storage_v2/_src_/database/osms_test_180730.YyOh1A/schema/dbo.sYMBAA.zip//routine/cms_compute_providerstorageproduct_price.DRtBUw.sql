CREATE PROC dbo.CMS_Compute_ProviderStorageProduct_Price      
(      
 @providerId INT = NULL, -- 供应商id 
 @productCode VARCHAR(Max) = NULL, --一产品编号 
 @productCodes VARCHAR(Max) = NULL,--多产品编号  
 @providerCode VARCHAR(Max) = NULL,--供应商编号
 @factoryCode VARCHAR(max) = NULL, --厂家编号
 @factoryCodes  VARCHAR(max) = NULL, --厂家编号
 @isNeedReplenishment INT =NULL,
 @replenishmentStatus INT = NULL,
 @AvailableStockCompareMode VARCHAR(2) = NULL, --比较有效库存时的模式：1、=,2、>3、<，4、>=,5、<=,6、!=    
 @AvailableStock INT = NULL, --有效库存量
 @ProductProviderFeedback VARCHAR(MAX) =NULL, --V3.9.30 给我们留言
 @IsDullSale INT=NULL,--是否滞销品
 @ISHot INT=NULL,--是否畅销品
 @isFullBuy INT =NULL,
   @isDisplayPH INT=NULL,
	  @isDisplayPW INT =NULL,
 @NoProviderCode VARCHAR(Max)=NULL,
  @buyingStockCompareMode VARCHAR(2) = NULL ,  
 @buyingStock INT = NULL 
)      
AS          
BEGIN          
 SET NOCOUNT ON   
 IF @providerId IS NULL 
 begin       
 DECLARE      
  @SQL NVARCHAR(MAX),        
  @tempSQL NVARCHAR(MAX),        
  @FromSQL NVARCHAR(MAX),         
  @FromSQL2 NVARCHAR(MAX),        
  @Column NVARCHAR(MAX),          
  @Condition NVARCHAR(MAX),     
  @CountSQL NVARCHAR(MAX),
  @OrderCondition NVARCHAR(MAX),          
  @IsQueryProvider BIT,     
  @RowCount INT , @PageCount INT , @start INT ,@end INT;       
 --组装查询条件     
 SET @Condition = ' WHERE P.is_provider_stock=1 and P.status = 4 and is_delete = 0 ';      
 
 IF @providerId IS NOT NULL       
 BEGIN      
  SET @Condition = @Condition + ' AND PR.id ='+CONVERT(VARCHAR(10),@providerId);   
 END 
      IF @IsDullSale IS NOT NULL
            BEGIN
				IF @IsDullSale>2
				BEGIN
				    SET @Condition = @Condition + ' and PSP.is_dull_sale <>0 '
				END
				ELSE 
				BEGIN
				    SET @Condition = @Condition + ' and PSP.is_dull_sale='
                    + CONVERT(VARCHAR(10), @IsDullSale);
				END
                
            END;

 IF @productCode IS NOT NULL       
 BEGIN      
  SET @Condition = @Condition + ' AND P.code like ''%' + @productCode+'%''';      
 END
 IF @AvailableStock IS NOT NULL AND @AvailableStockCompareMode IS NOT NULL     
	BEGIN       
	 IF( @AvailableStockCompareMode = '!=' )    
	 BEGIN    
		SET @Condition = @Condition + ' AND isnull(v1.quantity,0) > isnull(v1.lock_quantity,0) + ' + CONVERT(VARCHAR(10),@AvailableStock);      
		SET @Condition = @Condition + ' AND isnull(v1.quantity,0) < isnull(v1.lock_quantity,0) + ' + CONVERT(VARCHAR(10),@AvailableStock);      
	 END     
	 ELSE     
	 BEGIN    
		SET @Condition = @Condition + ' AND isnull(v1.quantity,0) ' + @AvailableStockCompareMode + ' isnull(v1.lock_quantity,0) + ' + CONVERT(VARCHAR(10),@AvailableStock);
	 END     
	END   
 IF @buyingStock IS NOT NULL
            AND @buyingStockCompareMode IS NOT NULL
            BEGIN       
                IF ( @buyingStockCompareMode = '!=' )
                    BEGIN    
                        SET @Condition = @Condition
                            + ' AND isnull(PSP.buying_quantity,0) <> '
                            + CONVERT(VARCHAR(10), @buyingStock);    
                    END;     
                ELSE
                    BEGIN    
                        SET @Condition = @Condition
                            + ' AND isnull(PSP.buying_quantity,0) '
                            + @buyingStockCompareMode
                            + CONVERT(VARCHAR(10), @buyingStock);
                    END;     
            END;           
 IF @productCodes IS NOT NULL       
 BEGIN      
  SET @Condition = @Condition + ' AND P.code in (''' + REPLACE(@productCodes,',',''',''') + ''') and P.code is  not  null';      
 END  
 
 IF @providerCode IS NOT NULL
 BEGIN
	SET @Condition = @Condition + ' AND PR.code like ''%' + @providerCode + '%''';      
 END  
 IF @NoProviderCode IS NOT NULL
 BEGIN
	SET @Condition = @Condition + ' AND PR.code not like ''%' + @providerCode + '%''';    
 END
 	IF @isDisplayPH IS NOT NULL
	BEGIN
	     SET @Condition = @Condition + ' and P.is_display_ph='
                    + CONVERT(VARCHAR(10), @isDisplayPH);
	END
	IF @isDisplayPW IS NOT NULL
	BEGIN
	     SET @Condition = @Condition + ' and P.is_display_pw='
                    + CONVERT(VARCHAR(10), @isDisplayPW);
	END
 -------------------V3.9.30
 IF @ProductProviderFeedback IS NOT NULL
		BEGIN
			SET  @Condition = @Condition + ' AND PSP.product_provider_feedback like ''%'
                    + @ProductProviderFeedback + '%''';  
		END  	 
 -----------------------   
 IF @factoryCode IS NOT NULL       
 BEGIN      
  SET @Condition = @Condition + ' AND P.provider_code like ''%' + @factoryCode + '%''';      
 END    
   
 IF @factoryCodes IS NOT NULL       
 BEGIN      
  SET @Condition = @Condition + ' AND P.provider_code in (''' + REPLACE(@factoryCodes,',',''',''') + ''') and P.provider_code  is not null';   
 END       
 IF @isNeedReplenishment IS NOT NULL
 BEGIN
	SET @Condition = @Condition +' AND PSP.is_need_replenishment='+CONVERT(VARCHAR(10),@isNeedReplenishment)
 END
 IF @replenishmentStatus IS NOT NULL
 BEGIN
	SET @Condition = @Condition +' AND PSP.replenishment_status='+CONVERT(VARCHAR(10),@replenishmentStatus)
 END
  IF @ISHot IS NOT NULL 
BEGIN
	SET @Condition = @Condition +' AND PSP.is_hot='+CONVERT(VARCHAR(10),@ISHot)
END
  IF @isFullBuy IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' and CASE WHEN FLOOR((ISNULL(prepare_qty,0)-ISNULL(PSP.buying_quantity,0))*1.00/P.unit_quantity)*P.unit_quantity<=FLOOR((ISNULL(v.quantity,0)-ISNULL(PSP.buying_quantity,0))/P.unit_quantity) THEN FLOOR((ISNULL(prepare_qty,0)-ISNULL(PSP.buying_quantity,0))*1.00/P.unit_quantity)*P.unit_quantity ELSE FLOOR((ISNULL(v.quantity,0)-ISNULL(PSP.buying_quantity,0))/P.unit_quantity) END >0 and (ISNULL(v.quantity,0)-ISNULL(PSP.buying_quantity,0))>0	AND PR.code not like ''sz-%''';
            END;
 --设置查询主表      
 SET @FromSQL = ' FROM product P WITH (NOLOCK)  
 INNER JOIN product_strategy PS WITH (NOLOCK) ON P.id = PS.product_id AND P.status=4 AND P.is_delete=0
 JOIN provider_storage_product PSP WITH(NOLOCK) ON PSP.product_id = P.id
 ';      
   
 SET @FromSQL = @FromSQL + ' LEFT JOIN product_provider PP WITH (NOLOCK) ON P.id = PP.product_id AND PP.department_id = PS.department_id'      
        + ' LEFT JOIN provider PR WITH (NOLOCK) ON PP.provider_id = PR.id
            LEFT JOIN dbo.view_product_all_storage_quantity_info v ON v.product_id = p.id 
            LEFT JOIN dbo.view_product_provider_storage_quantity_info v1 ON v1.product_id = p.id';      
   
       
 --设置取字段表      
 SET @FromSQL2 = ' INNER JOIN product P WITH(NOLOCK) ON temp.id=P.id 
      LEFT JOIN dbo.view_product_all_storage_quantity_info v ON v.product_id = p.id
      LEFT JOIN dbo.view_product_provider_storage_quantity_info v1 ON v1.product_id = p.id
      LEFT JOIN dbo.product_set_specification  ps WITH(NOLOCK) ON ps.id = P.product_set_specification_id
      LEFT JOIN dbo.product_description pd  WITH(NOLOCK) ON pd.product_id =P.id
      JOIN provider_storage_product PSP WITH(NOLOCK) ON PSP.product_id = P.id
      '
      
     IF @providerId IS NOT null
     BEGIN
      SET @FromSQL2 = @FromSQL2 +
      ' JOIN product_strategy PS1 WITH (NOLOCK) ON P.id = PS1.product_id
        JOIN product_provider PP1 WITH (NOLOCK) ON P.id = PP1.product_id AND PP1.department_id = PS1.department_id
        JOIN provider PR1 WITH (NOLOCK) ON PP1.provider_id = PR1.id     
        LEFT JOIN product_picture_collection ppcm WITH(NOLOCK) on ppcm.picture_code = P.primary_picture_code
        LEFT JOIN product_set_color_card ccpc WITH(NOLOCK) on ccpc.id = P.product_set_color_card_id
        
        LEFT JOIN view_product_color pv2 WITH(NOLOCK) ON  PSP.product_id=pv2.id 
        LEFT JOIN product_property_value ppv3 WITH(NOLOCK) ON PSP.product_id = ppv3.product_id and ppv3.property_id = 10                        
        LEFT JOIN property_value pv3 WITH(NOLOCK) ON ppv3.property_value = pv3.id'; --v3.9.0 add
      END
      ELSE
      BEGIN
       SET @FromSQL2 = @FromSQL2 +
      ' LEFT JOIN product_strategy PS1 WITH (NOLOCK) ON P.id = PS1.product_id
        LEFT JOIN product_provider PP1 WITH (NOLOCK) ON P.id = PP1.product_id AND PP1.department_id = PS1.department_id
        LEFT JOIN provider PR1 WITH (NOLOCK) ON PP1.provider_id = PR1.id 
        
        LEFT JOIN view_product_color pv2 WITH(NOLOCK) ON  PSP.product_id=pv2.id 
        LEFT JOIN product_property_value ppv3 WITH(NOLOCK) ON PSP.product_id = ppv3.product_id and ppv3.property_id = 10                        
		LEFT JOIN property_value pv3 WITH(NOLOCK) ON ppv3.property_value = pv3.id';
      END
         
 --获取符合条件的总记录数      
 SET @CountSQL = ' SELECT @RowCount = count(P.id) ' + @FromSQL + @Condition            
    EXEC sp_executesql @CountSQL, N'@RowCount INT OUT', @RowCount OUT       
          
   
    --设置取字段信息    
    SET @Column = 'SUM(isnull(v1.available_qty,0)*P.cost_price ) as totalPrice,
					SUM(isnull(v1.lock_quantity,0)*P.cost_price ) as freezePrice,
					SUM(ISNULL(PSP.buying_quantity,0)* P.cost_price ) AS totalBuyingPrice ';     
             
    
  SET @SQL = 'select P.id, ROW_NUMBER() OVER(ORDER BY P.id desc) rowIndex' + @FromSQL + @Condition;      

 SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp ' + @FromSQL2    
 PRINT(@SQL) 
 EXEC(@SQL)        
    select @RowCount
    
END
ELSE
BEGIN
  SELECT  SUM(isnull(v1.available_qty,0)*P.cost_price ) AS totalPrice,
		  SUM(isnull(v1.lock_quantity,0)*P.cost_price ) AS freezePrice ,
		  SUM(ISNULL(PSP.buying_quantity,0)* P.cost_price ) AS totalBuyingPrice
   FROM product P WITH (NOLOCK)  
   INNER JOIN product_strategy PS WITH (NOLOCK) ON P.id = PS.product_id AND P.status=4 AND P.is_delete=0
   JOIN provider_storage_product PSP WITH(NOLOCK) ON PSP.product_id = P.id
   LEFT JOIN product_provider PP WITH (NOLOCK) ON P.id = PP.product_id AND PP.department_id = PS.department_id
   --LEFT JOIN dbo.view_product_all_storage_quantity_info v ON v.product_id = p.id 
   LEFT JOIN dbo.view_product_provider_storage_quantity_info v1 ON v1.product_id = p.id 
   WHERE P.is_provider_stock=1 and P.status = 4 and is_delete = 0  AND pp.provider_id =@providerId
END
           
END


go





/*------------------------------------------------------
报表统计-考核-当月成本节省金额
frh 创建
成本价由原先的T_Item 的basePrice 
改成从 T_ItemBasePriceLog的basePrice
up_Report_Assess_CostSaveAmount '2008-01-01','2010-01-01','GZ'
------------------------------------------------------*/
CREATE PROCEDURE [dbo].[up_Report_Assess_CostSaveAmount]
(
	@StartTime		DateTime,
	@EndTime		DateTime,
	@Stock			NVARCHAR(10)
)
As
Begin
	Declare @StockId INT;
	
	SET @StockId  = (SELECT ISNULL(Id,0) FROM dbo.C_Stock WHERE Short = @Stock);
	
	
	If (@StockId > 0)
	BEGIN
		/*
		Select b.FirstName As UserName,a.采购价格 As CostSaveAmount
		From (
				Select a.userId ,cast(sum((b.BasePrice - a.TotalPrice) * a.DueQty)*100/Sum(a.TotalPrice*a.DueQty) as decimal(18,2)) as 采购价格 
				From(
						select b.UserId,a.ProductId,a.TotalPrice,b.Status,a.DueQty
						from b_PurchaseItem a join b_purchase b on a.purchaseId = b.Id
						where b.CreateDate >= @StartTime AND b.CreateDate <= @EndTime AND b.StockId = @StockId AND b.status = 8
						AND a.PurchaseStatus = 1 AND a.DueQty > 0 AND a.TotalPrice > 0
				) a
				Left Join T_ItemBasePriceLog b on a.ProductId = b.ProductId
				Group by a.UserId
		) a
		Left Join b_user b on a.UserId = b.Id
		Order by b.FirstName
		
		*/

		WITH ctePurchase AS -- 采购商品情况,每百元成本节省额
		(
			SELECT b.CreatorId,a.ProductDataId,a.TotalPrice,a.DueQty
			FROM dbo.C_PurchaseItem a 
			JOIN dbo.C_Purchase b ON a.purchaseId = b.PurchaseId
			WHERE b.CreateTime > @StartTime AND b.CreateTime < @EndTime AND b.StockId = @StockId AND b.[Status] = 8 -- 已报销
			AND a.[Status] = 2 AND a.DueQty > 0 AND a.TotalPrice > 0
		), cteSaveAmount AS -- 采购节省情况
		(
			SELECT a.CreatorId ,
				CAST(SUM((b.BasePrice - a.TotalPrice) * a.DueQty)*100/SUM(a.TotalPrice*a.DueQty) AS DECIMAL(18,2)) AS SaveAmount 
			FROM ctePurchase a JOIN dbo.D_ProductBasePriceLog b  -- 商品基准成本标杆价格
					ON a.ProductDataId = b.ProductDataId
			GROUP BY a.CreatorId
		)
		
		-- 显示结果
		SELECT b.FirstName AS UserName,a.SaveAmount AS CostSaveAmount 
		FROM cteSaveAmount a 
		LEFT JOIN dbo.B_User b ON a.CreatorId = b.Id
		ORDER BY b.FirstName;
	End
End


go


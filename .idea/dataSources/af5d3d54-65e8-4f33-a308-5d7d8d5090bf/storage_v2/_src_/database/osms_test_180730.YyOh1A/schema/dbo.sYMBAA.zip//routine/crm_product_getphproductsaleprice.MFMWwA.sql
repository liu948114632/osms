
			
/**  
根据客户及货运国家获取PH商品当前售价,  
如果没有传客户信息(客户ID、客户等级、客户类型)或货运国家ID，则只能查询商品普通售价，不能代表真正购买售价  
*/  
CREATE PROC CRM_Product_GetPhProductSalePrice    
(    
  @CmsProductId INT ,  --CMS商品ID  
  @CrmCustomerId INT = -1 ,--CRM客户ID  
  @ShipCountryId INT = -1, --货运地址国家ID  
  @CustomerRatingId INT = -1, --客户等级ID  
  @CustomerType  INT = -1 --客户类型  
)    
AS     
BEGIN    
  DECLARE @WebCustomerId int --网站的客户ID  
  SET  @WebCustomerId = -1  
  IF (@CrmCustomerId >0 )  
  BEGIN  
      --获取网站的客户ID    
   SELECT @WebCustomerId = BussinessCustomerId  
   FROM dbo.T_Customer  
   WHERE UserID=@CrmCustomerId  
  END   
    
  IF (@WebCustomerId = -1 OR @CustomerRatingId = -1 OR @CustomerType = -1 OR @ShipCountryId = -1)    
  BEGIN    
    SELECT  *    
    FROM    V_CRM_PH_ProductSalePrice    
    WHERE   CmsProductId = @CmsProductId    
    RETURN;    
  END    
    
    --获取商品当前最大折扣促销数据  
    ;WITH promoteInfo AS    
    (    
        SELECT  TOP 1 a.*    
        FROM    product_promote a WITH(NOLOCK)  
                LEFT JOIN ph_promote_activity b WITH(NOLOCK) ON a.promote_activity_id = b.id    
                LEFT JOIN ph_promote_activity_range c1 WITH(NOLOCK) ON b.id = c1.promote_activity_id AND c1.range_type = 1  --国家限制  
                LEFT JOIN ph_promote_activity_range c2 WITH(NOLOCK) ON b.id = c2.promote_activity_id AND c2.range_type = 2  --客户限制  
                LEFT JOIN ph_promote_activity_range c3 WITH(NOLOCK) ON b.id = c3.promote_activity_id AND c3.range_type = 3  --客户等级限制  
                LEFT JOIN ph_promote_activity_range c4 WITH(NOLOCK) ON b.id = c4.promote_activity_id AND c4.range_type = 4  --客户类型限制  
        WHERE   a.product_id = @CmsProductId    
                AND a.is_promote = 1    
                AND DATEADD(hh,-15,GETDATE())>=a.start_time AND DATEADD(hh,-15,GETDATE())<=a.end_time --转成美国时间再比较  
                AND ( a.promote_activity_id IS NULL --非活动促销   
                      OR  
                      ( --判断是否满足活动促销条件  
                        c2.ids LIKE ('%,' + CONVERT(VARCHAR(10), @WebCustomerId) + ',%')  --1、如果促销针对特定的客户则其他条件不限    
                        OR (  
                             ( c1.ids = '-1'    
                               OR c1.ids = '-11'    
                               OR c1.ids LIKE ('%,' + CONVERT(VARCHAR(10), @ShipCountryId) + ',%')    
                             )  --2.1、判断货运国家是否满足限制要求  
                             AND ( c3.ids = '-1'    
                                   OR c3.ids = '-11'    
                                   OR c3.ids LIKE ('%,'  + CONVERT(VARCHAR(10), @CustomerRatingId) + ',%')    
                                 ) --2.2、判断客户等级是否满足限制要求   
                             AND ( c4.ids = '-1'    
                                   OR c4.ids = '-11'    
                                   OR c4.ids LIKE ('%,' + CONVERT(VARCHAR(10), @customerType) + ',%')    
                                 ) --2.3、判断客户类型是否满足限制要求   
                           )                             
                      )    
                    )    
             ORDER BY a.discount DESC   
      )    
          
        --获取商品的最终售价信息  
  SELECT             
  b.CmsProductId,            
  a.id AS WebProductId,            
  CAST(ISNULL(c.is_promote,0) AS BIT) AS IsPromote,     
  (100 - ISNULL(c.Discount,0)) AS Discount, --注意：product_promote表中的Discount是降的折扣      
  ISNULL(c.[type],0) AS PromoteType,  --促销类型     
  CAST(ISNULL(c.is_bind_storage,0) AS BIT) AS IsBindStorage,  --是否绑定库存促销      
  b.LastCostPrice AS CostPrice,            
  b.UnitQuantity,            
  8.2 AS ExchangeRate,            
  a.first_profit_coefficient AS Profit1,        
  a.first_quantity_from AS QuantityFrom1,        
  a.first_quantity_to AS QuantityTo1,        
  a.second_profit_coefficient AS Profit2,        
  a.second_quantity_from AS QuantityFrom2,        
  a.second_quantity_to AS QuantityTo2,        
  a.third_profit_coefficient AS Profit3,        
  a.third_quantity_from AS QuantityFrom3,        
  a.third_quantity_to AS QuantityTo3,
  ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * first_profit_coefficient AS Decimal(18,2)),0) AS OriginalSalePrice,   --商品如有促销，各段价格都按第一段利润算            
  ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * (CASE WHEN Discount > 0 THEN first_profit_coefficient ELSE second_profit_coefficient END ) AS Decimal(18,2)),0) AS OriginalSalePrice2,           
  ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * (CASE WHEN Discount > 0 THEN first_profit_coefficient ELSE third_profit_coefficient END ) AS Decimal(18,2)),0) AS OriginalSalePrice3,     
  CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 * first_profit_coefficient AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice,  
  CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 *   
  (CASE WHEN Discount > 0 THEN first_profit_coefficient ELSE  second_profit_coefficient END ) AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice2,       
  CONVERT(DECIMAL(18,2),ISNULL(CAST((LastCostPrice * UnitQuantity) / 8.2 *   
  (CASE WHEN Discount > 0 THEN first_profit_coefficient ELSE  third_profit_coefficient END ) AS Decimal(18,4)),0) * (100 - ISNULL(c.Discount,0)) / 100) AS FinalSalePrice3,  
  promote_activity_id,
  c.id AS PromoteId                 
  FROM dbo.ph_product a WITH(NOLOCK)            
  JOIN dbo.V_CRM_Base_Product b WITH(NOLOCK) ON a.product_id = b.CmsProductId            
  LEFT JOIN promoteInfo c  ON b.CmsProductId = c.product_id       
  WHERE a.product_id= @CmsProductId     
END

go



/*
作废，没用到
*/
/* 增加免运费字段到DMS */
CREATE PROC dbo.CRM_Service_ConsignmentRemarkListGet2 @OrderId VARCHAR(20)
AS 
    BEGIN    
 -- SET NOCOUNT ON added to prevent extra result sets from    
 -- interfering with SELECT statements.    
        SET NOCOUNT ON;    
          
        --获取订单的网站重量  
        DECLARE @Weight INT ,
            @ReadyWeight INT,
            @Price DECIMAL(18, 2) ,                                          
@ReadyPrice DECIMAL(18, 2),
            @ExcludeOverseaPrice DECIMAL(18, 2) ,                                          
@ExcludeOverseaReadyPrice DECIMAL(18, 2) 

        SET @Weight = 0   
        EXEC CRM_Price_OrderValidWeightGet @OrderId, @Weight OUT, @ReadyWeight OUT;    
          
          --排除海外仓商品的货物价值
       EXEC CRM_Price_OrderPriceExcludeOverseaProductGet  @OrderId,@ExcludeOverseaPrice OUT,@ExcludeOverseaReadyPrice OUT;
            
    	-- 获取该订单商品和到货商品的价值                                          
    EXEC CRM_Price_OrderPriceGet @OrderId, @Price OUT, @ReadyPrice OUT ;         

        WITH    cte
                  AS ( SELECT   *
                       FROM     dbo.T_Addresses t1
                                INNER JOIN dbo.T_SmllLanguageOrder t2 ON t2.EnglishAddressId = t1.AddressID
                     )
            SELECT  a.OrderId ,  -- 订单编号                   
                    a.CreateTime , -- 送货时间    
                    a.BoxCount , -- 箱子数 （Quantity）    
                    a.Weight ,
                    @Weight AS OrderWeight , --订单重量  
                    ISNULL(f.PrintRemark, '') AS PrintRemark , -- 发货提醒    
                    ISNULL(a.BranchRemark, '') AS BranchRemark ,-- 分布备注    
                    a.IsTextile , -- 是否纺织品    
                    b.DeliveryId , -- 货运方式      
                    b.IsActualInvoice ,-- 是否实价发票    
                    b.IsRemote ,
                    b.CPFCode , --税号 
                    b.TaxCodeType ,
                    b.CustomerId ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.FirstName
                         ELSE cte.Firstname
                    END AS [FirstName] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.LastName
                         ELSE cte.Lastname
                    END AS [LastName] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.Address1
                         ELSE cte.Street1
                    END AS [Address1] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.Address2
                         ELSE cte.Street2
                    END AS [Address2] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.City
                         ELSE cte.City
                    END AS [City] ,
                    CASE WHEN cte.EnglishAddressId IS NULL THEN c.[State]
                         ELSE cte.[State]
                    END AS [State] ,
                    c.Country AS CountryId ,
                    c.Fax ,
                    c.Zip ,
                    c.Phone ,
                    ISNULL(d.name, '') AS [HandlerName] , -- 跟单员姓名
                    ISNULL(d.email, '') AS [HandlerEmail] , -- 跟单员邮箱   
                    1 AS [Type] ,
                    c.CompanyName ,--公司名称    
                    b.IsIncludeShippingFee ,--是否包含运费 
                    b.IsFreeShipping ,
                    b.SubTotalPercent ,--发票金额百分比    
                    b.Freight ,--订单运费    
                    e.EmailId AS CustomerEmailId ,
                    ISNULL(( SELECT dbo.[order].department_id
                             FROM   dbo.[order]
                             WHERE  dbo.[order].code = b.OrderId
                           ), 0) AS DepartmentId,
                                @Price AS Price , -- 订单商品价值                                           
            @ReadyPrice AS ActualPrice,  -- 到货商品价值 
            b.SendGroupID,
          @ExcludeOverseaPrice AS  ExcludeOverseaPrice
            FROM    T_ConsignmentRemark a
                    INNER JOIN t_Order b ON a.OrderId = b.OrderId
                    INNER JOIN t_OrderAddresses c ON b.ShipAddressId = c.AddressId
                    INNER JOIN dbo.T_Customer e ON b.CustomerId = e.UserID
                    LEFT JOIN t_OrderRemark f ON b.OrderId = f.OrderId
                    LEFT JOIN dbo.[user] d ON b.HandlerId = d.Id
                    LEFT JOIN cte ON cte.OrderId = b.OrderId
            WHERE   b.OrderId = @OrderId    
    END


go


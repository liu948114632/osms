


/* 创建网店邮件订单  */
CREATE PROC [CRM_Order_AddShopCustomerInfo]
    @OrderId VARCHAR(20) ,
    @Name VARCHAR(50) ,
    @Email VARCHAR(50) ,
    @TradeNo VARCHAR(50) ,
    @TradeAmount DECIMAL(18, 2)
AS 
    BEGIN
		DECLARE @BusinessType INT		
		SELECT @BusinessType=id FROM dbo.user_type WHERE UPPER(name)='EBAY';
    
		IF EXISTS (SELECT TOP 1 1 FROM dbo.T_ShopCustomer a INNER JOIN T_Order o ON o.OrderId=a.OrderId  WHERE ShopTradeNo=@TradeNo AND OrderIndustryType=@BusinessType AND o.OrderStatus<>132)
		BEGIN
			RAISERROR('网店交易号已存在。',16,1);
			RETURN;
		END
			
        INSERT  INTO dbo.T_ShopCustomer
                ( OrderId ,
                  ShopCustomerName ,
                  ShopCustomerEmail ,
                  ShopTradeNo ,
                  ShopTradeAmount
	            )
        VALUES  ( @orderId ,
                  @Name ,
                  @Email ,
                  @TradeNo ,
                  @TradeAmount
	            )
    END

go


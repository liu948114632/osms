
/**
获取其他货架的可用库存信息，优先同区库存
*/
 CREATE PROC CMS_Storage_GetOtherPositionStorage
 (
   @ProductId INT ,
   @CurrentPositionIds VARCHAR(max),
   @WarehouseId INT ,
   @DepartmentId INT 
 ) AS 
 BEGIN
     DECLARE @SQL VARCHAR(MAX)
	SET @SQL ='
	SELECT temp.department_id AS departmentId,
	       temp.warehouse_area_id AS warehouseAreaId,
		   temp.position_id AS positionId,
		   temp.positionCode,
		   temp.quantity ,
		   temp.lock_quantity AS lockQuantity,
		   (temp.quantity - temp.lock_quantity) AS availableQty,
		   temp.product_id AS productId ,
		   temp.productCode
	FROM (     
	SELECT a.*,(CASE WHEN a.warehouse_area_id = ' + CONVERT(VARCHAR(10),@WarehouseId) + ' THEN 1 ELSE 0 END) AS IsSameArea,b.department_id,c.name AS positionCode,b.product_id,d.code as productCode
	FROM view_storage_detail a WITH(NOLOCK) 
    JOIN dbo.storage b WITH(NOLOCK) ON a.storage_id = b.id 
	JOIN dbo.storage_position c ON a.position_id=c.id
	join product d WITH(NOLOCK) on b.product_id =d.id
	where a.quantity >a.lock_quantity AND b.product_id=' + CONVERT(VARCHAR(10),@ProductId) + ' AND b.department_id=' + CONVERT(VARCHAR(10),@DepartmentId)    
	IF( @CurrentPositionIds IS NOT NULL  AND LEN(@CurrentPositionIds) >0)
	BEGIN
        SET @SQL = @SQL + ' AND a.position_id NOT IN (' + @CurrentPositionIds + ')  '
	END 
	
	SET @SQL = @SQL + ')temp
	ORDER BY IsSameArea DESC,temp.purchase_time ASC'

	 EXEC(@SQL) ;  
 END

go


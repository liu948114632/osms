/**
	@author whw
	@date 2016-8-5
	ph展示类别提取商品:按类别提取
*/
CREATE PROC dbo.proc_extraction_product_1
(
	@phShowCategoryId INT=51 
)
as
DECLARE @extraction_mode TINYINT =NULL
DECLARE @releted_num INT=NULL
DECLARE @command VARCHAR(100)='PH_UPDATE_PRODUCT_RELEASE_PHSHOWCATEGORY'
DECLARE @modelType VARCHAR(100)='PHPRODUCT'
DECLARE @needNum INT=NULL

--1/基础数据
SELECT @extraction_mode=extraction_mode FROM dbo.ph_show_category
WHERE id=@phShowCategoryId

SELECT show_category_id,category_id,property_related_mode,ROW_NUMBER() OVER(ORDER BY id)  AS no
INTO #category_releted FROM dbo.ph_show_category_related_category
WHERE show_category_id=@phShowCategoryId
SELECT @releted_num=COUNT(*) FROM #category_releted

DECLARE @tb_result TABLE
(
product_id INT ,
ph_product_id INT ,
show_category_id INT	
)
----2/比较数据
IF @extraction_mode=1 --标准模式
BEGIN
	INSERT INTO @tb_result
	        ( product_id, ph_product_id, show_category_id )
	SELECT DISTINCT p.id,ph.id, t.show_category_id  FROM dbo.ph_product ph WITH(NOLOCK)
	INNER JOIN product p WITH(NOLOCK)
	ON p.id = ph.product_id 
	INNER JOIN  #category_releted t 
	ON t.category_id=CASE WHEN p.category_id_3<>0 THEN p.category_id_3 
WHEN p.category_id_2<>0 THEN p.category_id_2 ELSE p.category_id_1 end
END

IF @extraction_mode=2 --标准模式+属性
BEGIN
	   

    DECLARE @start INT =1
	DECLARE @category_id INT=0
	DECLARE @property_related_mode TINYINT=NULL
	DECLARE @tb_category_product TABLE   --类别商品
		(
		product_id INT ,
		property_id INT	,
		property_value INT,
		ph_product_id INT 
		)

	DECLARE @tb_category_property_ph TABLE  --类别属性 
		(
		property_value_id INT ,
		show_category_id INT	,
		category_id INT,
		property_id INT 
		)

	WHILE(@start<=@releted_num)
	BEGIN
		SELECT @property_related_mode=property_related_mode,@category_id=category_id FROM #category_releted WHERE no=@start
		--PRINT '@property_related_mode='+CONVERT(VARCHAR(10), @property_related_mode)
		--展示类别所有属性
		INSERT @tb_category_property_ph
		        ( property_value_id ,
		          show_category_id ,
		          category_id ,
		          property_id
		        )
		SELECT v.property_value_id ,
               p.show_category_id ,
               p.category_id ,
               p.property_id 
			   FROM ph_show_category_related_property_value v WITH(NOLOCK)
		INNER JOIN ph_show_category_related_property p WITH(NOLOCK)
		ON v.show_category_related_property_id=p.id
		INNER JOIN category_related_property cp  WITH(NOLOCK)
		ON cp.category_id=p.category_id AND cp.property_id=p.property_id
		INNER JOIN dbo.category_related_property_value cv WITH(NOLOCK)
		ON cv.category_related_property_id=cp.id AND cv.property_value_id=v.property_value_id
		WHERE p.show_category_id=@phShowCategoryId
		and p.category_id=@category_id
		--标准类别商品属性
		INSERT @tb_category_product
			    ( product_id ,
			        property_id ,
			        property_value ,
			        ph_product_id
			    )
		SELECT pv.product_id,pv.property_id,pv.property_value,ph.id AS ph_product_id 
			FROM dbo.product p WITH(NOLOCK)
				INNER JOIN dbo.ph_product ph WITH(NOLOCK)
		ON p.id=ph.product_id
		INNER JOIN dbo.product_property_value pv WITH(NOLOCK)
		ON pv.product_id=p.id
		WHERE CASE WHEN p.category_id_3<>0 THEN p.category_id_3 WHEN p.category_id_2<>0 THEN p.category_id_2 ELSE p.category_id_1 end=@category_id
		
		--AND模式
		IF @property_related_mode=1
		BEGIN
			SELECT @needNum=COUNT(*) FROM (SELECT property_id FROM @tb_category_property_ph GROUP BY property_id) AS t

			INSERT @tb_result
			        ( product_id ,
			          ph_product_id ,
			          show_category_id
			        )
			SELECT * FROM (
			SELECT DISTINCT product_id,ph_product_id,@phShowCategoryId AS ph_cateogry_id FROM @tb_category_product t
			WHERE product_id IN  
				(
					--属性全匹配-=属性值有其一
				SELECT t1.product_id
				FROM @tb_category_property_ph c
				INNER JOIN @tb_category_product t1  
				ON t1.property_id=c.property_id AND t1.property_value = c.property_value_id
				GROUP BY t1.product_id HAVING COUNT(t1.product_id)=@needNum
				)
			  ) AS tmp
					
		END

		--OR 模式
		IF @property_related_mode=2
		BEGIN
			INSERT INTO @tb_result
			        ( product_id ,
			          ph_product_id ,
			          show_category_id
			        )
		    SELECT DISTINCT product_id,ph_product_id,@phShowCategoryId FROM @tb_category_product t
			INNER JOIN @tb_category_property_ph c
			ON c.property_value_id=t.property_value AND c.property_id=t.property_id
			--属性有其一，属性值有其一
		END
		
		DELETE FROM @tb_category_product
		DELETE FROM @tb_category_property_ph
		--SELECT COUNT(*) AS _part FROM @tb_result
	    SET @start=@start+1;
	END
END



--3/更新数据
	--3.1已经存在的数据(旧数据和新数据的交集)
	SELECT p.* INTO #exist_data FROM dbo.ph_show_category_relate_product p
	INNER JOIN @tb_result t ON t.ph_product_id=p.ph_product_id AND t.show_category_id=p.ph_show_category_id
	--3.2删除旧数据
	SELECT * INTO #delet_data FROM ph_show_category_relate_product WHERE ph_show_category_id=@phShowCategoryId
	AND id NOT IN (SELECT id FROM #exist_data)

	DELETE FROM ph_show_category_relate_product WHERE id IN
	(SELECT id FROM #delet_data)
	--3.3增加新数据
	SELECT t.show_category_id,t.ph_product_id,t.product_id INTO #add_data FROM @tb_result t LEFT JOIN #exist_data e
	 ON e.ph_product_id = t.ph_product_id
	AND e.ph_show_category_id = t.show_category_id
	WHERE e.id IS NULL

	INSERT INTO dbo.ph_show_category_relate_product
	        ( ph_show_category_id ,
	          ph_product_id ,
	          product_id
	        )
	SELECT show_category_id ,
           ph_product_id ,
           product_id FROM #add_data

--4/完成，记录通讯日志
	INSERT INTO dbo.communication_log
	        ( command ,
	          object_id ,
	          status ,
	          create_time ,
	          operator ,
	          model_type ,
	          execute_time ,
	          promote_type
	        )
	SELECT @command,product_id,1,GETDATE(),NULL,@modelType,NULL,NULL FROM #delet_data
	

	INSERT INTO dbo.communication_log
	        ( command ,
	          object_id ,
	          status ,
	          create_time ,
	          operator ,
	          model_type ,
	          execute_time ,
	          promote_type
	        )
	SELECT @command,product_id,1,GETDATE(),NULL,@modelType,NULL,NULL FROM #add_data

	--SELECT COUNT(*)AS add_ FROM #add_data
	--SELECT COUNT(*) AS re_ FROM @tb_result
	--SELECT COUNT(*)AS del_ FROM #delet_data
	--SELECT COUNT(*) AS exist_ FROM #exist_data
	DROP TABLE #category_releted
	DROP TABLE #add_data
	DROP TABLE #delet_data
	DROP TABLE #exist_data


go


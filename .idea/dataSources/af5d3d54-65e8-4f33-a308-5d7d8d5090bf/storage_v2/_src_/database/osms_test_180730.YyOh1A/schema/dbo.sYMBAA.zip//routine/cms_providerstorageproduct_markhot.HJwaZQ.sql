
    
CREATE PROC [dbo].[CMS_ProviderStorageProduct_MarkHot] AS  
BEGIN   
with one_month_sale AS 
(
	--新产品上架一个月
	SELECT temp1.product_id, 
		   (temp1.total_limited_unit_quantity / 3) AS month_sale_quantity, --月平均销量
		   temp1.order_number,   
		   1 AS sale_type    --新品热销
    FROM 
    (
  	    SELECT * 
	    FROM dbo.uf_product_remaind_new_product_sale_info(1) --获取新品上架一个月内的销售信息和加工信息
	    WHERE order_number >=3 AND total_limited_unit_quantity >=3 --找出上架后一个月内满足条件的商品：下单次数≥3　且　销售总批数≥3
     ) temp1 
),
two_month_sale AS 
(
      --新产品上架2个月
      SELECT temp1.product_id, 
		     (temp1.total_limited_unit_quantity / 3) AS month_sale_quantity, --月平均销量
		     temp1.order_number,   
		     2 AS sale_type    --新品热销
      FROM 
      (
  	      SELECT * 
	      FROM dbo.uf_product_remaind_new_product_sale_info(2) --获取新品上架两个月内的销售信息和加工信息
	      WHERE order_number >=4 AND total_limited_unit_quantity >=4 --找出上架后两个月内满足条件的商品：下单次数≥4　且　销售总批数≥4
	        AND publish_time < DATEADD(MONTH,-1,GETDATE())  --排除仅上架一个月的  
       ) temp1 
)
,other_sale AS 
(
      --普通产品
      SELECT temp1.product_id, 
		     (temp1.total_limited_unit_quantity / 3) AS month_sale_quantity, --月平均销量
		     temp1.order_number,
		     3 AS sale_type    --PH热销
      FROM 
      (
  	      SELECT * 
	      FROM dbo.uf_product_remaind_sale_info(DATEADD(MONTH,-3,GETDATE()),GETDATE(),1,1)  --获取所有商品的3个月内销量
	       --找出三个月内满足条件的商品：总下单数≥3，总销售批数≥9 OR 过去三个月总下单数≥6，总销售批数≥6 
	      WHERE ((order_number >=3 AND total_limited_unit_quantity >=9) OR (order_number >=6 AND total_limited_unit_quantity >=6))
	        AND publish_time < DATEADD(MONTH,-2,GETDATE())  --排除仅上架两个月的  
       ) temp1 
)


       
  UPDATE ps SET ps.is_hot = 1
   FROM 
   (
	   SELECT * FROM one_month_sale	    
	   UNION    
	   SELECT * FROM two_month_sale
	   UNION 
	   SELECT * FROM other_sale
   ) temp  JOIN dbo.provider_storage_product ps ON ps.product_id=temp.product_id  
INNER JOIN product p WITH(NOLOCK)  ON  p.id = temp.product_id
INNER JOIN dbo.product_strategy AS e WITH(NOLOCK)  ON e.product_id = temp.product_id
INNER JOIN dbo.product_provider AS f WITH(NOLOCK) ON f.product_id = temp.product_id AND f.department_id = e.department_id
WHERE  f.provider_id NOT IN (SELECT id FROM dbo.provider WHERE p.code LIKE 'sz-%' )
AND ps.is_dull_sale =0
--排除待下架或永久下架的商品(v3.9.10)
AND p.offline_status != 2
AND NOT EXISTS (
			SELECT TOP 1 product_id FROM stay_shield_product ssp
			WHERE operate_type = 1 AND ssp.product_id = temp.product_id
) 

end

go


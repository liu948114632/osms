CREATE PROCEDURE [dbo].[US_Category_ExistsCategory]
(
	@CategoryId INT
)
AS
BEGIN 
	IF EXISTS (SELECT 1 FROM dbo.T_Category_US WHERE CategoryId=@CategoryId AND IsDeleted=0)
		SELECT 1
    ELSE 
		SELECT 0 
END
go


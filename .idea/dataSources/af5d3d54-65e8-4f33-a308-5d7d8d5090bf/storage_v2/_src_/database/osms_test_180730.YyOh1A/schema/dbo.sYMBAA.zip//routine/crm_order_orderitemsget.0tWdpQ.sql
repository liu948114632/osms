 
-- =============================================                            
-- Author:  <HYD>                            
-- Create date: <2010-01-14>                            
-- Description: <获取订单商品的基本信息>                                                 
-- =============================================                            
CREATE PROC dbo.CRM_Order_OrderItemsGet
    (
      @OrderId VARCHAR(20) ,
      @IsGoOverseasWarehouse INT = -1 --是否走海外仓： -1 不限、0 不走海外仓 1走海外仓                            
    )
AS
    BEGIN                            

DECLARE @CountryId INT;
DECLARE @OrderStatus INT ;
DECLARE @OrderIndustryType INT;
DECLARE @IsPhClone BIT=0;

SELECT @CountryId=b.Country,@OrderStatus=o.OrderStatus,@OrderIndustryType=o.OrderIndustryType FROM dbo.T_Order o INNER JOIN dbo.T_OrderAddresses b
ON o.ShipAddressId=b.AddressId WHERE o.OrderId=@OrderId

SELECT @IsPhClone=IsPHClone FROM dbo.T_BusinessType WHERE BusinessTypeValue=@OrderIndustryType
                       
        SET NOCOUNT ON;                          
                
        SELECT  a.[OrderItemId] ,
                a.[OrderId] ,
                a.[ProductId] ,
                a.CmsProductId ,
                a.ProductSetId ,
                c.Name AS ProductName ,
                c.ItemCode AS ProductCode ,
                c.Description AS ProductDescription ,
                c.Discount ,
                c.ImageName AS ProductImageName ,
                c.ColorCode ,
                c.ColorImageName ,
                a.[Type] ,
                a.[Quantity] ,
                a.[ReadyQty] ,
                a.[Unit] ,
                a.[UnitQuantity] ,
                ( LTRIM(a.UnitQuantity) + ' ' + LTRIM(a.Unit) ) AS UnitStr ,
                a.[ItemPrice] ,
                a.[SalePrice] ,
                a.[Weight] ,
                a.[Volume] ,
                a.[IsPromote] ,
                a.[IsProductPool] ,
                a.[Box] ,
                a.[Status] ,
                a.[XFreight] ,
                a.[JoinDate] ,
                a.[UpdateTime] ,
              CASE WHEN a.MoldFee>0 THEN   a.[CustomerRemark] +';开模费:$'+CAST(a.MoldFee AS VARCHAR(10)) ELSE a.CustomerRemark END AS CustomerRemark,
                a.[BranchRemark] ,
                a.[CSRemark] ,
                a.CollateStatus ,
                a.CollateUser ,
                a.IsPHReplaceProduct ,
                a.ColorCardName ,
                a.SpecficationName ,
                a.MinBatchQty ,
                a.PackageProductId ,
                b.[Code] ,
                b.IsGift ,
                '' AS ReceiveDate ,
                '' AS ReceiveDateEnd ,
                '' AS SubstitutePicName ,
                '' AS SubstitutePicUrl ,
                0 AS UserId ,
                '' AS StrategyName ,
                CASE WHEN b.IsGift = '1' THEN 2
                     ELSE 1
                END AS ProductType ,
                CONVERT(VARCHAR(2), ProcessingStatus) AS ProcessingStatus ,
                b.PrimaryPictureCode ,
                b.ColorCardPictureCode ,
                a.Box ,
                a.IsGoOverseasWarehouse ,
                a.PromoteId ,
				a.PackFee,
				a.MoldFee,
				a.BarCode+',' AS BarCode,
               CASE WHEN (@OrderIndustryType=5 AND IsGoOverseasWarehouse=1  OR @OrderIndustryType=6  )
                THEN
						CASE WHEN @CountryId=35
								   THEN   
								   (SELECT TOP 1 w.AvailableAmount-ISNULL(w.LockStockQty,0) FROM dbo.T_OverseasWarehouseProduct w WHERE a.CmsProductId=w.CMSProductId AND w.WarehouseId=3)*a.UnitQuantity
					   ELSE
								  (SELECT TOP 1 SUM(w.AvailableAmount-ISNULL(w.LockStockQty,0)) FROM dbo.T_OverseasWarehouseProduct w WHERE a.CmsProductId=w.CMSProductId AND (w.WarehouseId=1 OR w.WarehouseId=2 OR w.WarehouseId=5))*a.UnitQuantity
					   END
               WHEN (@OrderIndustryType=5 AND IsGoOverseasWarehouse=0 OR @OrderIndustryType=1 OR   @IsPhClone=1)
			   THEN d.phStorageQuantity
							 ELSE 
               d.PublicStorageQuantity  END   AS StorageQty ,     /*可用库存*/
                a.SellBy ,
               a.ReadyDate,
               a.PromoteType,
			 CAST(ISNULL(a.IsQualityInspection,0) AS BIT) AS IsQualityInspection,
			    a.IsBattery,
			  a.IsBuiltInBattery,
			  a.IsExternalBattery,
			  a.IsMagnetism,
			  a.IsLargeVolume,
			  a.WarehouseStockId,
			  a.FBAProductInventoryStatus,
			  b.OfflineStatus,
			  a.PurchaseHandlerRemark,
            CAST(CASE WHEN @OrderStatus=0 AND @OrderIndustryType<>17 AND @OrderIndustryType<>16 AND @OrderIndustryType<>4 AND 
            (@CountryId=103 
            AND EXISTS(SELECT TOP 1 1 FROM dbo.T_OverseasWarehouseProduct op WHERE op.CMSProductId=a.CmsProductId AND  (op.WarehouseId=1 OR op.WarehouseId=2 OR op.WarehouseId=5)  AND op.IsDelete=0)) OR
              (@CountryId IN (24,34,35,44,50)  AND EXISTS(SELECT TOP 1 1 FROM dbo.T_OverseasWarehouseProduct op WHERE op.CMSProductId=a.CmsProductId AND op.WarehouseId=3 AND op.IsDelete=0))
				  THEN 1
				 ELSE  0
              END AS bit ) AS IsOverseasProduct
        FROM    [dbo].[T_OrderItem] a
                INNER JOIN dbo.V_CRM_Base_Product b ON a.CmsProductId = b.CmsProductId
                LEFT JOIN T_OrderItemProduct c ON a.OrderItemId = c.OrderItemId
                LEFT JOIN CRM_View_ProductStorageQuantity d WITH ( NOLOCK ) ON b.CMSProductId = d.Product_id
        WHERE   a.OrderId = @OrderId
                AND (
                      @IsGoOverseasWarehouse = -1
                      OR IsGoOverseasWarehouse = @IsGoOverseasWarehouse
                    )
        ORDER BY a.PackageProductId DESC ,
                a.Status ASC ,b.code ASC 
    END
go


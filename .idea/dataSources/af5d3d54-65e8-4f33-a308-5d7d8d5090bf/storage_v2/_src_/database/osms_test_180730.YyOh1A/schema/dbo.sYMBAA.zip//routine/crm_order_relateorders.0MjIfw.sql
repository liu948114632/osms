


/*------------------------------------------              
备注:同票订单              
创建人: LXH              
创建日期:2012-06-14              
------------------------------------------------------*/              
CREATE PROC dbo.CRM_Order_RelateOrders              
(              
  @OrderIds VARCHAR(MAX), --需要同票的订单，用逗号隔开            
  @OperatorId INT, --操作人ID         
  @SendGroupId INT OUT --返回同票ID           
)              
AS               
BEGIN          
    --1、获得订单信息          
    SELECT  b.OrderId ,
            b.DeliveryId ,
            ISNULL(c.Firstname, '') AS Firstname ,
            ISNULL(c.Lastname, '') AS Lastname ,
            ISNULL(c.Address1, '') AS Address1 ,
            ISNULL(c.Address2, '') AS Address2 ,
            c.Country ,
            ISNULL(c.City, '') AS City ,
            ISNULL(c.Fax, '') AS Fax ,
            ISNULL(c.Phone, '') AS Phone ,
            ISNULL(c.Zip, '') AS Zip ,
            ISNULL(c.State, '') AS State ,
            ISNULL(c.Port, '') AS Port ,
            ISNULL(c.CompanyName, '') AS CompanyName,
            ISNULL(b.IsRemote, 0) AS IsRemote,
            ISNULL(b.FreightDiscount, 0) AS FreightDiscount,
			ISNULL(b.IsIncludeShippingFee,0) AS IsIncludeShippingFee,
		CASE WHEN d.CustomsCurrencyId IS NULL OR d.CustomsCurrencyId<=0 THEN 1 ELSE d.CustomsCurrencyId END AS CustomsCurrencyId
    INTO #Temp_OrderInfo          
    FROM dbo.uf_Split(@OrderIds,',') a          
    INNER JOIN dbo.T_Order b WITH(NOLOCK) ON a.Value = b.OrderId    
    INNER JOIN dbo.T_OrderAddresses c WITH(NOLOCK) ON b.ShipAddressId = c.AddressId          
    LEFT JOIN dbo.T_OrderExtend d    WITH(NOLOCK) ON d.OrderId=b.OrderId
    IF ( @@ROWCOUNT < 2)          
    BEGIN           
        RAISERROR ('同票订单至少需要2个订单才能进行!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;
    END
                     
	SELECT DISTINCT
			IsRemote
	FROM #Temp_OrderInfo	
    IF ( @@ROWCOUNT > 1)          
    BEGIN           
        RAISERROR ('偏远标识不同的订单不能进行同票操作!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END

		SELECT DISTINCT
			CustomsCurrencyId
	FROM #Temp_OrderInfo	
    IF ( @@ROWCOUNT > 1)          
    BEGIN           
        RAISERROR ('报关币种不同的订单不能进行同票操作!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END

			SELECT DISTINCT
			IsIncludeShippingFee
	FROM #Temp_OrderInfo	
    IF ( @@ROWCOUNT > 1)          
    BEGIN           
        RAISERROR ('报运费不同的订单不能进行同票操作!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END
	
	SELECT DISTINCT
			FreightDiscount
	FROM #Temp_OrderInfo	
    IF ( @@ROWCOUNT > 1)          
    BEGIN           
        RAISERROR ('运费折扣不同的订单不能进行同票操作!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END
	   
     --2、检查需要同票的订单的货运地址和货运方式是否相同          
	SELECT DISTINCT
			DeliveryId ,
			LTRIM(RTRIM(Firstname)),
			LTRIM(RTRIM(Lastname)),
			LTRIM(RTRIM(Address1)),
			LTRIM(RTRIM(Address2)),
			LTRIM(RTRIM(Country)),
			LTRIM(RTRIM(City)),
			LTRIM(RTRIM(Fax)),
			LTRIM(RTRIM(Phone)),
			LTRIM(RTRIM(Zip)),
			LTRIM(RTRIM([State])),
			LTRIM(RTRIM(Port)),
			LTRIM(RTRIM(CompanyName))
	FROM #Temp_OrderInfo
	   
    IF ( @@ROWCOUNT >= 2)          
    BEGIN           
        RAISERROR ('只有货运方式和货运地址完全相同的订单才能进行同票订单!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END           
          
    --2.2 检查待同票的订单状态：Pending和取消状态订单不允许同票      
    IF EXISTS (SELECT TOP 1 1 FROM #Temp_OrderInfo a        
      INNER JOIN T_Order b WITH(NOLOCK) ON a.OrderId = b.OrderId          
      WHERE b.OrderStatus IN (132) )        
    BEGIN        
        RAISERROR ('Pending状态订单和取消状态订单不允许参与同票操作!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END    
    
    --2.3 检查待同票的订单是否存在全海外仓订单      
    IF EXISTS (SELECT TOP 1 1 FROM #Temp_OrderInfo a        
      INNER JOIN T_Order b WITH(NOLOCK) ON a.OrderId = b.OrderId          
      WHERE b.OverseasWarehouseStatus = 30 or b.OverseasWarehouseStatus=10 )        
    BEGIN        
        RAISERROR ('全海外仓订单或者未决海外仓订单不允许参与同票操作!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END       
            
    --3、判断同票订单中是否存在校对中或已校对的订单，有则不允许操作        
    IF EXISTS (SELECT TOP 1 1 FROM #Temp_OrderInfo a        
      INNER JOIN T_Order b WITH(NOLOCK) ON a.OrderId = b.OrderId          
      WHERE b.OrderStatus >= 45 )        
    BEGIN        
        RAISERROR ('选择的订单中存在校对中及其后的订单，不允许进行同票操作!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END         
            
    IF EXISTS ( SELECT TOP 1 1 FROM T_Order WITH(NOLOCK)        
                WHERE dbo.T_Order.SendGroupID IN         
      ( SELECT b.SendGroupID        
        FROM #Temp_OrderInfo a        
        INNER JOIN T_Order b WITH(NOLOCK) ON a.OrderId = b.OrderId         
        WHERE b.SendGroupID > 0         
      )        
         AND OrderStatus >= 45  )        
    BEGIN        
        RAISERROR ('选择的订单存在同票订单中有校对中及其后的订单，不允许进行同票操作!' , 16, 1) WITH NOWAIT ;            
        DROP TABLE #Temp_OrderInfo          
        RETURN;          
    END         
              
    --4、进行同票处理          
    --4.1、取出需要同票订单中的一个同票ID为新同票ID          
    SELECT @SendGroupId = SendGroupID          
    FROM T_Order a          
    INNER JOIN #Temp_OrderInfo b ON a.OrderId = b.OrderId          
    WHERE SendGroupID IS NOT NULL AND a.OrderStatus < 132
              
    IF( @SendGroupId IS NULL)          
    BEGIN          
        --4.2如果都没有被同票过，则获得新的同票ID          
        SELECT @SendGroupId = ISNULL(MAX(SendGroupID),0) + 1          
        FROM T_Order WITH(UPDLOCK)  
    END           
    ELSE          
    BEGIN    
            
    --更新其它同票ID为新同票ID          
    UPDATE T_Order SET SendGroupId = @SendGroupId          
    FROM T_Order           
    WHERE SendGroupId IN           
    (SELECT SendGroupId           
     FROM T_Order a           
     INNER JOIN #Temp_OrderInfo b ON a.OrderId = b.OrderId           
     WHERE a.SendGroupId IS NOT NULL AND a.SendGroupId != @SendGroupId)          
    END               
              
    --4.3更新所有相关订单的同票ID          
  UPDATE a SET SendGroupId = @SendGroupId          
  FROM T_Order a          
  INNER JOIN #Temp_OrderInfo b ON a.OrderId = b.OrderId      
    
     --增加同票历史  
     INSERT INTO dbo.order_history  
             ( order_code ,  
               operator_id ,  
               operator_time ,  
               process  
             )  
     SELECT #Temp_OrderInfo.OrderId,  
            @OperatorId,  
            GETDATE(),  
            '同票订单:' + @OrderIds  
     FROM #Temp_OrderInfo  
END

go


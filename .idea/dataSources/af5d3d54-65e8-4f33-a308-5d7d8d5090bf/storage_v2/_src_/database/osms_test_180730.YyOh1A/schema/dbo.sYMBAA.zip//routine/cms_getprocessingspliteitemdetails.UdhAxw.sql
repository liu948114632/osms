-- =============================================  
-- Author:  <Author,,Name>  
-- Create date: <Create Date,,>  
-- Description: <Description,,>  
-- =============================================  
CREATE PROCEDURE CMS_GetProcessingSpliteItemDetails  
 @ProcessingId INT,  
 @spliteQty INT  
AS  
BEGIN  
 SELECT b.id,g.code AS productCode,g.primary_picture_code AS pictureCode,g.unit,g.unit_quantity AS unitQty,
  ISNULL(f.unit,g.unit) AS newUnit ,ISNULL(p.quantity,b.plan_quantity*1.00/a.plan_processing_quantity) AS bindQty,p.unit AS bindUnit,  
  ROUND(ISNULL(f.convert_rate,1)*(i.quantity-ISNULL(i.lock_quantity,0)) ,6)  
     AS storageQuantity, @spliteQty* CASE WHEN p.quantity IS NULL THEN  b.plan_quantity*1.00/a.plan_processing_quantity ELSE p.quantity END AS planQuantity,g.id AS productId,  
     CASE WHEN ISNULL(p.is_mix_colour,0) =1 THEN 2
	      WHEN g.is_valuables=1 OR a.department_id<>7 THEN 1  
		WHEN m.material_type=1 THEN 1.07  
     ELSE 1.12 END AS rate      
 FROM dbo.processing a WITH(NOLOCK)  
 JOIN dbo.processing_item b WITH(NOLOCK) ON a.id =b.processing_id AND b.status<>4  
 LEFT JOIN dbo.department_storage i ON i.product_id=b.product_id AND i.department_id = 41  
 LEFT JOIN dbo.product_unit_convert f WITH(NOLOCK) ON f.product_id=b.product_id AND f.unit=b.unit  AND f.department_id =a.department_id
 JOIN dbo.product g WITH(NOLOCK) ON g.id =b.product_id  
 LEFT JOIN dbo.product_processing_item p WITH(NOLOCK) ON p.product_id =a.product_id AND p.processing_product_id =b.product_id  AND p.department_id =a.department_id
 LEFT JOIN dbo.set_material_type m WITH(NOLOCK) ON m.department_id=a.department_id AND m.product_id =b.product_id  
 WHERE a.id =@ProcessingId  
END
go



/*
* 2012-08-10
* 根据产品集ID获取产品集下产品的绑定规格信息
*/
CREATE PROC [dbo].[CMS_Product_GetProductSpecByProductSetID]       
(        
	@ProductSetId INT = NULL   --产品集ID  
)      
AS       
BEGIN                        
	SET NOCOUNT ON ;     
	SELECT *
	FROM dbo.product p WITH(NOLOCK) LEFT JOIN product_set_specification_value ps WITH(NOLOCK)
	ON p.product_set_specification_id = ps.product_set_specification_id 
	WHERE p.product_set_id=@ProductSetId and P.is_delete=0
	ORDER BY p.id 
    SET NOCOUNT OFF ;           
END
go


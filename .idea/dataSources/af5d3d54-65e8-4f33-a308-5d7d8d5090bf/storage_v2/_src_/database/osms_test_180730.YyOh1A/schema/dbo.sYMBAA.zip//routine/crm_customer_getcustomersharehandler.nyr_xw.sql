
CREATE PROC dbo.CRM_Customer_GetCustomerShareHandler
AS 
BEGIN
WITH cte AS 
(
SELECT a.HandlerId FROM dbo.T_Handler a WITH(NOLOCK) 
WHERE a.BusinessType=1 OR a.BusinessType=16
GROUP BY a.HandlerId
)
SELECT c.*, c.name+(SELECT CASE WHEN b.BusinessType=1 THEN '(PH)' ELSE '(PW)' END  FROM dbo.T_Handler  b  WHERE  a.HandlerId=b.HandlerId AND b.BusinessType IN (1,16) FOR XML PATH(''))  AS HandlerName FROM cte a
INNER JOIN dbo.[t_user] c ON a.HandlerId=c.id
ORDER BY c.name
END
go


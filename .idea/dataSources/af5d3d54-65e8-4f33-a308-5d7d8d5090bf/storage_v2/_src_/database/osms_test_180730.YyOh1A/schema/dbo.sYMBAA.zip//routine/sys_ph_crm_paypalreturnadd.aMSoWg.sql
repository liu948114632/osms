
-- =============================================          
-- Author:  <HYD>          
-- Create date: <2010-01-16>          
-- Description: <添加Paypal付款记录,付款信息正确时，自动录入订单支付记录>          
-- =============================================          
CREATE PROCEDURE [dbo].[SYS_PH_CRM_PaypalReturnAdd]          
(           
    @gross nvarchar(50),    --支付金额      
    @currencyName nvarchar(50),    --支付币种      
    @country nvarchar(50),    --账单地址国家      
    @name nvarchar(50),          
    @number nvarchar(50),    --订单号      
    @txnId nvarchar(50),    --交易号      
    @BusinessType INT,  --业务行业：1:PH订单;2:UK订单;3:CN订单;8:DM 10:成品订单 16:PW订单        
    @payPalType INT, --付款方式 1、PayPal 2、GC 3、Cash 4、Coupon 5、WestUnion 6、BankTransfer 7、Check 8、WebMoney 9、Sofort 10 PayPayGC 100、Other     
    @PayerEmail NVARCHAR(50),
    @PaymentFee NVARCHAR(50),
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @PayAmountUS DECIMAL(18,2),
	@payment_status VARCHAR(50),
	@payment_type VARCHAR(50),
	@PaymentSource VARCHAR(50)
)          
AS          
BEGIN          
      
 SET NOCOUNT ON;          
  --LXH 2012-05-30 PayPal付款信息正确时，自动录入订单支付记录        
      
  DECLARE @Status INT ,@OrderId VARCHAR(50),@CurrencyId INT ,@Rate DECIMAL(18,6),@Message VARCHAR(100) , 
          @OrderCurrencyId INT ,@OrderRate DECIMAL(18,6) ,@pIseCheckNoClear BIT=0
  SET @Status = 6 --默认是信息正确的        
  SET @OrderId = @number        

  IF(LOWER(@payment_type)='echeck' AND LOWER(@payment_status)='pending')
  BEGIN
  	SET @pIseCheckNoClear=1
  END
      
   --1、检查币种        
    SELECT @Rate = Rate,@currencyName =Currency,@CurrencyId=Id  FROM dbo.T_Currency WHERE currency = @currencyName         
    IF( @Rate IS NULL )        
    begin        
     SET @Status = 4 -- 付款币种无效        
    END  
    
   --获取订单币种和下单时汇率
   SELECT @OrderCurrencyId = Currency,@OrderRate=Rate
   FROM dbo.T_Order
   WHERE OrderId = @OrderId
   
   --以下单时的汇率进行转换，如果不是下单的币种，则实时汇率转换
   IF( @OrderCurrencyId = @CurrencyId AND @OrderRate > 0)
   BEGIN
       SET @Rate = @OrderRate
   END 
      
   --将支付金额转换为美元()
   --SET @PayAmountUS = CONVERT(MONEY,@gross) / @Rate         
   IF( @PayAmountUS <= 0 )            
   BEGIN            
       SET @Message = '提示：订单' + @OrderId + '支付金额无效(' + LTRIM(@gross) + ')!'            
       RAISERROR(@Message, 16, 1) WITH NOWAIT ;             
       RETURN;            
   END                
      
   --2、检查地址        
   IF @Status = 6         
   BEGIN        
        DECLARE @result INT         
        EXEC CRM_Service_OrderAddressCheck @country,@OrderId,@result OUT;          
     IF @result > 0          
     BEGIN          
        SET @Status = @result        
     END         
   END          
      
 --添加PayPal付款信息        
 INSERT INTO [T_PaypalReturn]          
           ([mc_gross]          
           ,[mc_currency]          
           ,[address_country]          
           ,[address_name]          
           ,[item_number]          
           ,[status]          
           ,[txn_Id]          
           ,BusinessType
           ,PayerEmail
           ,PaymentFee
           ,FirstName
           ,LastName
		   ,payment_status
		   ,payment_type
		   ,PaymentSource
           )      
     VALUES          
           (@gross          
           ,@currencyName          
           ,@country          
           ,@name          
           ,@number          
           ,@Status          
           ,@txnId      
           ,@BusinessType
           ,@PayerEmail
           ,@PaymentFee
           ,@FirstName
           ,@LastName
		   ,@payment_status
		   ,@payment_type
		   ,@PaymentSource
           )         
      
   IF @Status = 4     
   BEGIN    
     RETURN ;--如果币种不对，则不录入支付记录    
   END      
     
   IF @Status = 2  
   BEGIN--如果付款地址与货运地址不对，则设置为不允许自动录单  
      UPDATE dbo.T_Order SET IsCanAutoImportOrder=0 WHERE OrderId=@OrderId  
   END   
     
   --信息合格，则录入订单支付记录      
 DECLARE @PayTypeString NVARchar(100)   
 SET @PayTypeString = dbo.uf_Order_PayTypeNameGet(@payPalType)  
   
    DECLARE @Remark NVARCHAR(2000),@Action NVARCHAR(500)             
    Select @CurrencyId = [Id] From t_Currency Where Currency = 'USD';        
    SET @Remark = ''        
    IF @currencyName !=  'USD'        
    BEGIN --如果支付币种不是美元，则在备注里加上原金额        
        SET @Remark = @PayTypeString + ':' + @gross + @currencyName        
    END         
      
    SET @Action = '自动录入' + @PayTypeString + '支付金额:' + LTRIM(@PayAmountUS) + 'USD';  

      
    EXEC CRM_Order_OrderPayAdd @OrderId=@OrderId,@PaySum=@PayAmountUS,@CurrencyId = @CurrencyId,@Remark=@Remark,@PayDate=NULL,@ActionUserId=0,@Action=@Action,@PayType=@payPalType,@PayId = @txnId,@IseCheckNoClear=@pIseCheckNoClear
END

go


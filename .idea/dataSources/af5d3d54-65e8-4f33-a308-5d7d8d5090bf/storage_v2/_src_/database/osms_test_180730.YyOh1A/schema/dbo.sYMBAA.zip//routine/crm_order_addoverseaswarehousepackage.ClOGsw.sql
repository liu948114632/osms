/**    
保存出口易包裹信息    
*/    
CREATE PROC CRM_Order_AddOverseasWarehousePackage    
(    
  @OrderId VARCHAR(20), --订单号    
  @StockOutCode VARCHAR(30),--出库单号    
  @PackageCode VARCHAR(30), --包裹号    
  @TrackingNumber VARCHAR(30), --包裹跟踪号    
  @LogisticsCarriersName VARCHAR(1000) --物流商名称   
)    
AS    
begin    
      DECLARE @LogisticsCarriersId INT   
      IF( LEN(@LogisticsCarriersName) > 0)  
      BEGIN  
           SELECT @LogisticsCarriersId= a.ID  
           FROM T_OverseasWarehouseLogisticsCarriers a  
           JOIN dbo.T_OverseasWarehouse b ON a.WarehouseId = b.ID  
           JOIN T_OverseasWarehouseStockOutOrder c ON b.WarehouseCode = c.Warehouse  
           WHERE LogisticsCarriersName = @LogisticsCarriersName AND c.OrderId = @OrderId  
      END   
        
        
      INSERT INTO dbo.T_OverseasWarehousePackage    
              (     
                OrderId,    
                StockOutCode ,    
                PackageCode ,    
                TrackingNumber,  
                LogisticsCarriersId    
              )    
      VALUES  ( @OrderId,    
                @StockOutCode , -- StockOutCode - varchar(30)    
                @PackageCode , -- PackageCode - varchar(30)    
                @TrackingNumber,  -- TrackingNumber - varchar(30)    
                @LogisticsCarriersId  
              )    
END
go


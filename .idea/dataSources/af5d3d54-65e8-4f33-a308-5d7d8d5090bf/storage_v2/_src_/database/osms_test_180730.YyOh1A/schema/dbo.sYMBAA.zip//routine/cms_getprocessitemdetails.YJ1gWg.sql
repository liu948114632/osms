
CREATE PROC dbo.CMS_GetProcessItemDetails
	@ProcessingId INT
AS
BEGIN
 DECLARE @departmentId INT
 SELECT @departmentId=department_id  FROM dbo.processing WHERE id =@ProcessingId
 IF @departmentId =7 OR @departmentId=9
 BEGIN
	;WITH waitProcessingQty AS (
		select sum(b.ready_Quantity) AS readyQty,
		b.product_id from dbo.processing_item as b 
			JOIN dbo.processing c ON c.id =b.processing_id
			JOIN (SELECT product_id  FROM processing_item WHERE processing_id=@ProcessingId) a 
				ON a.product_id=b.product_id
				where c.status=10 and c.department_Id =@departmentId GROUP BY b.product_id
			)
	SELECT 
	a.id,
	a.processing_id AS processingId,
	a.product_id AS productId,
	a.plan_quantity AS planQuantity,
	a.ready_quantity AS readyQuantity,
	a.used_quantity AS usedQuantity,
	ISNULL(h.readyQty,0)-ISNULL(a.ready_quantity,0)
			 AS waitProcessQuantity,
			 a.status,a.remark,
			 a.is_task AS isTask,
			 a.process_convert_rate AS processConvertRate,
			 a.convert_qty AS convertQty,
			 ROUND(ISNULL(f.convert_rate,1)*(i.quantity-ISNULL(i.lock_quantity,0)) ,6)AS storageQuantity,
			 ROUND(ISNULL(f.convert_rate,1)*(ISNULL(i.lock_quantity,0)) ,6)AS storageFreezeQuantity,
			  b.code AS productCode,b.name AS productName,
			  b.original_name AS productOriginalName,
			 ISNULL(f.convert_rate,1) AS depotStockQty ,--记录convert_rate
			 b.primary_picture_code AS primaryPictureCode  ,
			 b.color_card_picture_code AS colorCardPictureCode,
			 b.cost_price AS productCostPrice,
			 b.unit AS productUnit,
			 CAST(b.unit_quantity AS VARCHAR(50)) +' '+b.unit AS productUnitQuantity,
			 a.unit,
			 ISNULL(f.convert_rate,1) AS convertRate, 
			 f.unit AS newProductUnit,
			 k.name AS position,
			 g.material_type AS materialType,
			 b.is_display_ph AS isDisplayPh,
			 b.is_display_pw AS pwIsDisplay,
			 ISNULL(f.new_unit_weight,b.weight) AS convertWeight,
			 a.replenish_qty AS replenishQty,
			 a.excess_weight AS excessWeight,
			 a.excess_qty AS excessQty,
			 a.wait_task_qty AS waitTaskQty,
			 a.task_status AS taskStatus,
			 a.surplus_quantity AS surplusQuantity,
			 a.is_tracking AS tracked,
			 a.is_enable_stock AS isEnableStock,
			 b.offline_status AS offlineStatus,
			 a.has_surplus AS hasSurplus,
			 pd.department_ids AS departmentIds

	FROM dbo.processing_item  a WITH(NOLOCK)
	JOIN product b WITH(NOLOCK) ON a.product_id=b.id AND b.is_delete=0
	JOIN dbo.processing d WITH(NOLOCK) ON d.id =a.processing_id
	--LEFT JOIN dbo.department_storage c WITH(NOLOCK) ON c.product_id = a.product_id AND c.department_id =d.department_id
	--LEFT JOIN dbo.view_product_all_storage_quantity_info e ON e.product_id=a.product_id
	LEFT JOIN dbo.department_storage i ON i.product_id=a.product_id AND i.department_id = 41
	LEFT JOIN dbo.department_storage_detail j WITH(NOLOCK) ON j.storage_id=i.id
	LEFT JOIN dbo.storage_position k WITH(NOLOCK) ON k.id =j.position_id
	LEFT JOIN dbo.product_unit_convert f WITH(NOLOCK) ON f.product_id=a.product_id AND f.unit=a.unit AND f.department_id =d.department_id
	LEFT JOIN set_material_type g ON g.product_id=a.product_id AND g.department_id=d.department_id
	LEFT JOIN waitProcessingQty h ON h.product_id=a.product_id
	LEFT JOIN processing_item_picking_department pd ON pd.product_id=a.product_id
	WHERE processing_id =@ProcessingId 
 END
 ELSE
 begin
	SELECT 
	a.id,
	a.processing_id AS processingId,
	a.product_id AS productId,
	a.plan_quantity AS planQuantity,
	a.ready_quantity AS readyQuantity,
	a.used_quantity AS usedQuantity,
	a.status,
	a.remark,
	a.is_task AS isTask,
	a.process_convert_rate AS processConvertRate,
	a.convert_qty AS convertQty,
	ROUND(i.quantity-ISNULL(i.lock_quantity,0) ,2)AS storageQuantity,
	b.code AS productCode,b.name AS productName,b.original_name AS productOriginalName,
	1 AS depotStockQty ,
	 b.primary_picture_code 
	 AS primaryPictureCode  ,
	 b.color_card_picture_code AS colorCardPictureCode,
	 b.cost_price AS productCostPrice,
	 b.unit AS productUnit,
	 CAST(b.unit_quantity AS VARCHAR(50)) +' '+b.unit AS productUnitQuantity,
	 a.unit,
	 b.is_display_ph AS isDisplayPh,
	 b.is_display_pw AS pwIsDisplay,
	 a.wait_task_qty AS waitTaskQty,
	 a.task_status AS taskStatus,
	 a.surplus_quantity AS surplusQuantity  ,
	 a.is_tracking AS tracked,
	 k.name AS position,
	 a.is_enable_stock AS isEnableStock,
	 b.offline_status AS offlineStatus,
	 a.has_surplus AS hasSurplus
	FROM dbo.processing_item  a WITH(NOLOCK)
	JOIN product b WITH(NOLOCK) ON a.product_id=b.id AND b.is_delete=0
	JOIN dbo.processing d WITH(NOLOCK) ON d.id =a.processing_id
	--LEFT JOIN dbo.view_product_all_storage_quantity_info e ON e.product_id=a.product_id
    LEFT JOIN dbo.department_storage i ON i.product_id=a.product_id AND i.department_id = d.department_id
    LEFT JOIN dbo.department_storage_detail j WITH(NOLOCK) ON j.storage_id=i.id
    LEFT JOIN dbo.storage_position k WITH(NOLOCK) ON k.id =j.position_id

	WHERE processing_id =@ProcessingId ORDER BY a.status ASC
 END
END
go


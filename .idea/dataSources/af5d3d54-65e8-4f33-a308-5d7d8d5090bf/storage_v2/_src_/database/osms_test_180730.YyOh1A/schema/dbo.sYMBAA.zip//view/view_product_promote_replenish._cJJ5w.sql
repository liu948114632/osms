CREATE VIEW view_product_promote_replenish       
AS       
SELECT id,product_id,prepare_quantity     
FROM (        
 SELECT p.id,p.product_id,    
 (ISNULL((SELECT SUM(b.quantity-b.lock_quantity) FROM dbo.storage AS b WHERE b.product_id = p.product_id AND b.department_id =4  ),0)) AS storage_count ,     
 (ISNULL((SELECT TOP 1 a.plan_quantity FROM dbo.product_inquiry_price AS a WHERE a.status = 30 AND a.product_id = p.product_id ORDER BY a.create_time DESC),0)) AS prepare_quantity    
 FROM dbo.product_promote AS p      
 WHERE  p.is_promote = 1 AND p.id = -1 --暂时屏蔽所有数据
 AND NOT EXISTS     
 (    
  SELECT pmt.id     
	  FROM dbo.purchasing_management_task AS pmt     
	  WHERE pmt.[type]=3 AND pmt.[status]<5 AND pmt.product_id = p.product_id  
	  AND (   (pmt.sub_type = 1 AND Convert(VARCHAR(7),transmit_time,120) = Convert(VARCHAR(7),GETDATE(),120))--主动备库存，本月的当月促销  
		   OR (pmt.sub_type = 2 AND Convert(VARCHAR(7),transmit_time,120) = Convert(VARCHAR(7),DATEADD(m,-1,GETDATE()),120))--主动备库存，上月的下月促销  
		  )   
 )      
) AS temp         
WHERE  temp.storage_count < (temp.prepare_quantity *0.3) AND prepare_quantity>0
go


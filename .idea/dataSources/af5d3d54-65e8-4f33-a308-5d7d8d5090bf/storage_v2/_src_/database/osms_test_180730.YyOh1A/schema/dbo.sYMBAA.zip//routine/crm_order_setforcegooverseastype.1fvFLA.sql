--设置订单海外仓类型，0-不限,1-强制海外仓订单,2-强制国内仓
CREATE PROC CRM_Order_SetForceGoOverseasType
(
@ForceGoOverseasType INT,
@OrderIds VARCHAR(MAX)
)
AS 
BEGIN                  
 SET NOCOUNT ON;   
UPDATE  dbo.T_Order
SET     ForceGoOverseas = @ForceGoOverseasType
WHERE   OrderId IN ( SELECT Value
                     FROM   dbo.uf_Split(@OrderIds, ',') ) 
END

go


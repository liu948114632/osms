
---查询流失客户信息
CREATE PROC dbo.CRM_Customer_GetLossedCustomerList
(
@pageSize INT=50 ,
@PageIndex INT=1 ,
@emailId INT=-1 ,
@customerName VARCHAR(50)='',
@countryId INT=-1 ,
@startDate VARCHAR(20)='',
@endDate VARCHAR(20)='',
@handlerId INT=-1 ,
@hasNewEmail INT=-1 ,
@redeemStatus INT=-1 ,
@redeemGapDays INT=-1 ,
@contactSituation INT=-1 ,
@hasNewOrder INT =-1 ,
@redeemLevel INT=-1,
@dbName VARCHAR(20)='bmsTicket'
)
AS 
BEGIN
SET NOCOUNT ON;        
 DECLARE @sql NVARCHAR(max)        
 DECLARE @countSql NVARCHAR(max)        
 DECLARE @rowCount int,@pageCount int, @startPageIndex int, @endPageIndex int        
         
 SET  @sql = N'
 SELECT *,
ROW_NUMBER() OVER(ORDER BY Id DESC ) AS RowNo FROM (
SELECT * FROM (
 SELECT a.Id,g.EmailId,HasNewEmail,
CASE WHEN  a.RedeemStatus<>10 AND EXISTS(SELECT TOP 1 1 FROM dbo.T_Order WHERE CustomerId=a.CustomerId AND (OrderIndustryType=1 OR OrderIndustryType=5 OR OrderIndustryType=6) AND OrderStatus>0 AND OrderStatus<132 AND OrderDate>=a.ImportTime)
THEN 10 ELSE  a.RedeemStatus
 END AS RedeemStatus,
a.RedeemLevel,
CASE WHEN  ISNULL(a.FirstRespondWay,0)<1
THEN 0
ELSE 
a.ContactSituation
END 
AS ContactSituation,a.FirstRespondWay,
a.HasValidInfo,a.HasValidInfo as IsHasInalidInfo,a.ContactNum,a.SendFirstEmailTime,a.LastContactTime,a.RedeemGapDays,a.ImportTime,
b.*,g.FullName as CustomerName ,h.Name AS CustomerRating,g.Regtime,g.PurchaseAmountPh,  g.PurchaseAmountPw,h.Discount,
a.PendingOrderQty,a.PaidOrderQty,ISNULL(a.PendingOrderQty,0)+ISNULL(a.PaidOrderQty,0) AS NewOrderQty,
a.TotalProductPrice,a.LastComplaintDate,
e.CountryId,e.Name AS countryName,
(SELECT TOP 1 f.HandlerId FROM dbo.T_CustomerHandler f with(nolock)  INNER JOIN
dbo.T_Handler k with(nolock)  ON k.HandlerId=f.HandlerId AND k.BusinessType=1 WHERE   f.CustomerId=a.CustomerId) AS HandlerId,
(SELECT COUNT(*) FROM dbo.T_LossedCustomerPhoneRecord WHERE CustomerId=a.CustomerId) AS PhoneContactNum
 FROM dbo.T_LossedCustomer a INNER JOIN
dbo.T_LossedCustomerRedeemDtl b with(nolock)  ON a.CustomerId=b.CustomerId INNER JOIN
dbo.T_CustomerAddresses c with(nolock)  ON a.CustomerId=c.UserID INNER JOIN 
dbo.T_Addresses d with(nolock)  ON c.AddressID=d.AddressID AND c.Type IN (1,3) INNER JOIN 
dbo.T_Country e with(nolock)  ON d.Country=e.CountryId INNER JOIN 
dbo.T_Customer g with(nolock)  ON g.UserID=a.CustomerId INNER JOIN 
dbo.T_CustomerRating h with(nolock)  ON h.RatingId=g.RatingId) a 
 WHERE 1 = 1 '        
         
   IF(@StartDate<>'')        
 BEGIN         
    SET @sql = @sql + ' AND a.ImportTime>='''+ @StartDate+''''        
 END         
         
 IF(@EndDate<>'')        
 BEGIN         
    SET @sql = @sql + ' AND a.ImportTime<='''+ @EndDate+''''        
 END         
  
 IF(@HandlerId>-1)        
 BEGIN        
     SET @sql = @sql + ' AND a.HandlerId='+ ltrim(str(@HandlerId))        
 END        
  
  IF(@emailId>0)  
     BEGIN         
    SET @sql = @sql + ' AND a.emailid='+ltrim(str(@emailId))        
    END   
    
   IF(@customerName<>'')        
 BEGIN        
  SET @sql = @sql + ' AND a.CustomerName  like ''%'+ltrim(@customerName)+'%'''        
 END       
         
  IF(@countryId>-1)  
     BEGIN         
    SET @sql = @sql + ' AND a.CountryId='+ltrim(str(@countryId))        
    END   
    
      IF(@hasNewEmail>-1)  
     BEGIN         
    SET @sql = @sql + ' AND a.HasNewEmail='+ltrim(str(@hasNewEmail))        
    END   
    
         IF(@redeemStatus>-1)  
     BEGIN         
    SET @sql = @sql + ' AND a.RedeemStatus='+ltrim(str(@redeemStatus))        
    END   
    
         IF(@redeemGapDays>-1 AND @redeemGapDays<11)  
     BEGIN         
    SET @sql = @sql + ' AND a.RedeemGapDays='+ltrim(str(@redeemGapDays))        
    END   
    
           IF(@redeemGapDays=11)  
     BEGIN         
    SET @sql = @sql + ' AND a.RedeemGapDays>='+ltrim(str(@redeemGapDays))        
    END   
     
         IF(@contactSituation>-1)  
     BEGIN         
    SET @sql = @sql + ' AND a.ContactSituation='+ltrim(str(@contactSituation))        
    END   
    
         IF(@hasNewOrder>-1)  
     BEGIN         
     IF(@hasNewOrder>0)
    SET @sql = @sql + ' AND a.NewOrderQty>0'       
   ELSE  
    SET @sql = @sql + ' AND a.NewOrderQty=0'       
    END       
    
  IF(@redeemLevel>-1)  
     BEGIN         
    SET @sql = @sql + ' AND a.RedeemLevel='+ltrim(str(@redeemLevel))        
    END       
   SET @sql=@sql+') AS tt' 
    
 --得到记录条数          
    SET @countSql = 'SELECT @rowCount = COUNT(1) FROM (' + @sql + ') AS Items'          
    EXEC sp_executesql  @countSql, N'@rowCount INT OUT', @rowCount OUT           
         
 IF(@PageIndex<1) SET @PageIndex=1        
    SET @pageCount = (@RowCount + @PageSize - 1) / @PageSize          
    IF ISNULL(@PageIndex, 0) < 1 SET @PageIndex = 1          
    ELSE IF @PageIndex > @pageCount  SET @PageIndex = @pageCount          
    SET @startPageIndex = (@PageIndex - 1) * @PageSize + 1          
    SET @endPageIndex = @PageIndex * @PageSize         
              
 SET @sql = 'SELECT * FROM ('+@sql+') AS Items WHERE RowNo BETWEEN ' + ltrim(STR(@startPageIndex)) + ' AND ' + ltrim(STR(@endPageIndex))+' ORDER BY id desc'        
         
    PRINT @sql        
    EXEC(@sql)         
         
    SELECT @rowCount   AS 'RowCount',@pageCount AS 'PageCount'  
END


go


CREATE PROC dbo.CRM_Cash_CashWithdrawRecordGetById
(
@CashId int,
@BuessTypeId INT
)
AS 
BEGIN
SELECT TOP 1 * FROM dbo.T_CashWithdrawRecord WHERE cashId=@cashId AND  BusinessTypeId=@BuessTypeId ORDER BY CreateDate DESC 
END


go


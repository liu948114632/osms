/**        
出口易出库单出库失败        
*/        
CREATE PROC CRM_Order_SetCK1SendOutFail        
(          
  @OrderId VARCHAR(20), --订单号        
  @StockOutCode VARCHAR(30) --出库单号        
)        
AS        
BEGIN        
   --记录订单历史        
   DECLARE @remark VARCHAR(max)        
   SET @remark = N'海外仓出库单(' + @StockOutCode + ')出库失败'         
   EXEC dbo.CRM_Order_OrderHistoryAdd @UserId = 0, -- int        
       @OrderId = @OrderId, -- varchar(14)        
       @Remark = @remark -- varchar(5000)        
                   
    ----判断订单是否是发往美国，如是，则还原海外仓的库存    
    --DECLARE @ShipCountryId INT ,@WarehouseId INT    
    --SELECT @ShipCountryId = b.Country    
    --FROM dbo.T_Order a    
    --JOIN dbo.T_OrderAddresses b ON a.ShipAddressId=b.AddressId    
    --WHERE a.OrderId =  @OrderId    
        
    --IF( @ShipCountryId = 103 )    
    --BEGIN    
    --    SELECT @WarehouseId = ID     
    --    FROM T_OverseasWarehouseStockOutOrder a    
    --    JOIN dbo.T_OverseasWarehouse b ON a.Warehouse=b.WarehouseCode    
    --    WHERE a.OrderId = @OrderId    
            
    --    INSERT INTO dbo.T_OverseasWarehouseStorageLog    
    --            ( CK1StorageNo ,    
    --              OriginalQty ,    
    --              UpdateQty ,    
    --              OrderId ,    
    --              OpearteTime ,    
    --              Remark    
    --            )    
    --   SELECT c.CK1StorageNo,AvailableAmount,(b.Quantity / b.UnitQuantity),@OrderId,GETDATE(),'出口易出库失败'    
    --    FROM dbo.T_OrderItem b     
    --    JOIN dbo.T_OverseasWarehouseProduct c ON b.CmsProductId=c.CMSProductId    
    --    WHERE c.WarehouseId=@WarehouseId AND b.OrderId = @OrderId AND Status<12 AND IsGoOverseasWarehouse=1       
            
    --    UPDATE c SET AvailableAmount = AvailableAmount + (b.Quantity / b.UnitQuantity)    
    --    FROM dbo.T_OrderItem b     
    --    JOIN dbo.T_OverseasWarehouseProduct c ON b.CmsProductId=c.CMSProductId    
    --    WHERE c.WarehouseId=@WarehouseId AND b.OrderId = @OrderId AND Status<12 AND IsGoOverseasWarehouse=1                       
            
    --END         
        
      UPDATE a set [Status] = 1,        
                   ReadyQty = 0,        
                   IsGoOverseasWarehouse = 0         
      from dbo.T_OrderItem a        
      JOIN dbo.T_OverseasWarehouseStockOutOrderItem b ON a.OrderItemId = b.OrderItemId        
      WHERE b.StockOutCode= @StockOutCode AND OrderId=@OrderId        
        
        
      --检查海外仓状态        
      EXEC dbo.CRM_Order_CheckOverseasWarehouseOrderStatus @OrderId = @OrderId -- varchar(20)        
            
      --更新订单状态      
      EXEC dbo.CRM_Order_OrderStatusCheck @OrderId = @OrderId, -- varchar(14)      
          @UpdatedStatus = 0 -- int      
            
END
go





 
CREATE PROCEDURE [dbo].CMS_Service_CheckProductCategoryBindSpec
AS
    BEGIN	
-- 缓存需删除商品属性
        IF OBJECT_ID('#temp_product_spec') IS NOT NULL
            DROP TABLE #temp_product_spec;
	
        WITH    cta_category_bind_spec
                  --类别绑定的属性值
                  AS ( SELECT   category_id ,
                                spec_id
                       FROM     category_related_spec
                     ),
                cta_product_bind_spec
                  --产品绑定的属性值
                  AS ( SELECT   temp.category_id ,
                                temp.id AS product_id ,
                                temp.product_set_specification_id ,
                                p.spec_id
                       FROM     ( SELECT    CASE WHEN category_id_3 = 0
                                                  THEN  CASE WHEN category_id_2 = 0 THEN category_id_1  ELSE
                                                 category_id_2 end
                                                 ELSE category_id_3
                                            END AS category_id ,
                                            id ,
                                            product_set_specification_id
                                  FROM      dbo.product
                                  WHERE     is_delete = 0
                                            
                                            AND status = 4
                                ) AS temp
                                INNER JOIN dbo.product_set_specification_value
                                AS p ON temp.product_set_specification_id = p.product_set_specification_id
                     )
            SELECT  a.*
            INTO    #temp_product_spec
            FROM    cta_product_bind_spec AS a
                    LEFT JOIN cta_category_bind_spec AS b ON a.category_id = b.category_id
                                                             AND a.spec_id = b.spec_id
            WHERE   b.spec_id IS NULL;
            --删除多余属性
        DELETE  a
        FROM    dbo.product_set_specification_value a
                JOIN #temp_product_spec b ON a.product_set_specification_id = b.product_set_specification_id
                                             AND a.spec_id = b.spec_id;
        
        INSERT  INTO dbo.communication_log
                ( command ,
                  object_id ,
                  status ,
                  create_time ,
                  operator ,
                  model_type ,
                  execute_time
                )
                SELECT  'UPDATE_PRODUCT_SPEC' ,
                        t.product_id ,
                        1 ,
                        GETDATE() ,
                        0 ,
                        'PRODUCT' ,
                        NULL
                FROM    ( SELECT DISTINCT
                                    product_id
                          FROM      #temp_product_spec
                        ) AS t;
                        
        INSERT  INTO dbo.communication_log
                ( command ,
                  object_id ,
                  status ,
                  create_time ,
                  operator ,
                  model_type ,
                  execute_time
                )
                SELECT  'UPDATE_PRODUCT_SET_SPECIFICATION' ,
                        t.product_set_specification_id ,
                        1 ,
                        GETDATE() ,
                        0 ,
                        'PRODUCT' ,
                        NULL
                FROM    ( SELECT DISTINCT
                                    product_set_specification_id
                          FROM      #temp_product_spec
                        ) AS t;
        INSERT  INTO dbo.product_description_info_log
                ( product_id ,
                  status ,
                  operate_time
                )
                SELECT  a.id ,
                        1 ,
                        GETDATE()
                FROM    ( SELECT DISTINCT
                                    product_id AS id
                          FROM      #temp_product_spec
                        ) a; 
        DROP TABLE #temp_product_spec;
 
    END;


go


CREATE VIEW V_CMS_Product_Category
AS
SELECT a.id AS product_id,a.code,b.*
FROM dbo.product a WITH(NOLOCK)
JOIN dbo.V_CMS_Category b ON b.category_id= (CASE WHEN a.category_id_3>0 THEN a.category_id_3 WHEN a.category_id_2>0 THEN a.category_id_2 ELSE a.category_id_1 END) 
WHERE is_delete=0
go


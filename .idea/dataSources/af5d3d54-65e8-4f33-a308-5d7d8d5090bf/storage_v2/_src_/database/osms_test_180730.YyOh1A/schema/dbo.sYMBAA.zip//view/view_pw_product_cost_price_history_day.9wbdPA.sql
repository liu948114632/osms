
CREATE VIEW view_pw_product_cost_price_history_day 
AS 
SELECT d.id, d.product_id, d.original_cost_price, d.adjusted_cost_price, d.cause, d.operator_id, d.operate_time,p.is_ts
FROM dbo.product_cost_price_history AS d 
JOIN dbo.pw_product AS b ON d.product_id = b.product_id AND b.is_on_shelf=1
JOIN product AS p ON p.id = b.product_id
WHERE d.id IN (
	SELECT MAX(id) FROM dbo.product_cost_price_history AS a
	WHERE  a.operate_time >=  CONVERT(CHAR(10),GETDATE(),25) AND a.operate_time < CONVERT(CHAR(10),GETDATE()+1,25)and a.cause  not in('调整产品批量') 
	GROUP BY product_id
)

go


CREATE FUNCTION [dbo].[uf_get_sum_purchase_price]
(
	@department_id	INT = 0,			-- 仓库
	@buyer_id	INT = 0,			-- 采购员
	@check_time_start	VARCHAR(10) = '',	-- 报销时间,开始
	@check_time_end	VARCHAR(10) = ''	-- 报销时间,结束
)
RETURNS DECIMAL(18, 6)
AS 
BEGIN
DECLARE @sum_purchase_price_total DECIMAL(18, 6)	
SELECT @sum_purchase_price_total =  SUM(a.purchase_price*a.completion_quantity) FROM dbo.view_purchase_analyst_items AS a

WHERE a.purchase_expense_time >=@check_time_start AND a.purchase_expense_time <= @check_time_end
AND a.department_id = @department_id AND a.buyer_id=@buyer_id

RETURN @sum_purchase_price_total;
END

go


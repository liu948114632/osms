

CREATE PROC CRM_Order_UpdateOverseasWarehousLogisticsCarriersId
(
@StockOutCode VARCHAR(20),
@LogisticsCarriersCode  VARCHAR(200) 
)
AS 
BEGIN
    UPDATE  dbo.T_OverseasWarehousePackage
    SET     LogisticsCarriersId = ( SELECT c.ID
                                    FROM   dbo.T_OverseasWarehouseLogisticsCarriers c  
                                    WHERE c.LogisticsCarriersCode = @LogisticsCarriersCode
                                  )
    WHERE   StockOutCode = @StockOutCode


	UPDATE  dbo.T_OverseasWarehouseStockOutOrder
    SET     LogisticsCarriersId = ( SELECT c.ID
                                    FROM   dbo.T_OverseasWarehouseLogisticsCarriers c  
                                    WHERE c.LogisticsCarriersCode = @LogisticsCarriersCode
                                  )
    WHERE   StockOutCode = @StockOutCode
END

go


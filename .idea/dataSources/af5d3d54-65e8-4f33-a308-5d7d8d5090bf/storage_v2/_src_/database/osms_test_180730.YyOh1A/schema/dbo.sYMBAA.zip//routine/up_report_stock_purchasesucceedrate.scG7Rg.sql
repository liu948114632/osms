



/**************************************************************
		备注：采购员月采购完成率
某个采购员每个月采购任务的完成情况
指标：采购员月采购完成率＝该采购员月已采购成功的商品项 / 该采购员月需采购的商品项
**************************************************************/
CREATE PROCEDURE [dbo].[up_Report_Stock_PurchaseSucceedRate] 
	@StartTime		DateTime, 
	@EndTime		DateTime,
	@Stock			NVARCHAR(10)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @StockId	INT;
	DECLARE @UserPurchseCount Table (UserId INT,ItemCount INT);
	DECLARE @ShortCount Table (UserId INT,ShortCount INT);

	SET @StockId  = (SELECT ISNULL(Id,0) FROM dbo.C_Stock WHERE Short = @Stock);

	IF @StockId > 0
	BEGIN
		/*
		INSERT INTO @UserPurchseCount 
		SELECT b.UserId,COUNT(1) AS ItemCount FROM b_PurchaseItem a
		LEFT JOIN b_Purchase b ON a.PurchaseId = b.Id
		WHERE b.Status >= 4 AND b.Status < 12 AND b.CompleteDate >= @StartTime AND b.CompleteDate <= @EndTime AND StockId = @StockId
		GROUP BY b.UserId

		INSERT INTO @ShortCount
		SELECT  UserId,count(1) 
		FROM B_OrderItemStatusChangeLog
		WHERE newstatus =4 AND  LogTime >= @StartTime AND LogTime <= @EndTime 
		GROUP BY UserId

		SELECT c.FirstName AS UserName,a.ItemCount,ISNULL(b.ShortCount,0) as ShortCount, 
		LTRIM(CAST((CAST(a.ItemCount AS DECIMAL(18,2)) 
			/ CASE WHEN a.ItemCount + ISNULL(b.ShortCount,0) = 0 THEN 1 ELSE  a.ItemCount + ISNULL(b.ShortCount,0) END) * 100 AS DECIMAL(18,2) )) + '%' AS Rate
		FROM @UserPurchseCount a LEFT JOIN @ShortCount b ON a.UserId = b.UserId
		LEFT JOIN b_User c ON a.UserId = c.Id
		ORDER by c.FirstName
		*/
		
		-- 每个采购员采购商品个数
		INSERT INTO @UserPurchseCount(UserId,ItemCount)
		SELECT b.CreatorId,COUNT(1) AS ItemCount 
		FROM dbo.C_PurchaseItem a
			JOIN dbo.C_Purchase b ON a.PurchaseId = b.PurchaseId
				AND StockId = @StockId AND b.[Type] = 1 -- 需求采购
					AND b.Status >= 4  AND b.Status < 16 -- 已完成状态以后的且排除已删除的
						AND b.FinishTime >= @StartTime AND b.FinishTime <= @EndTime
		GROUP BY b.CreatorId;
		
		SELECT '' AS UserName,0 AS ItemCount,0 AS ShortCount,'' AS Rate;

		
	END
	ELSE
	BEGIN
		SELECT '' AS UserName,0 AS ItemCount,0 AS ShortCount,'' AS Rate;
	END	
		
	
END


go


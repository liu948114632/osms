   
   ---添加流失客户操作日志信息
CREATE PROC CRM_Customer_AddLossedCustomerLog
(
@CustomerId INT ,
@OperatorId INT=0 ,
@log NVARCHAR(2000),
@EmailContent NVARCHAR(MAX)=''
)
AS 
BEGIN
INSERT  INTO dbo.T_LossedCustomerOperateLog
        ( CustomerId ,
          CreateTime ,
          Content ,
          CreatorId,
         EmailContent 
        )
VALUES  ( @CustomerId ,
          GETDATE() ,
          @log ,
          @OperatorId,
         @EmailContent 
        )
END

   go


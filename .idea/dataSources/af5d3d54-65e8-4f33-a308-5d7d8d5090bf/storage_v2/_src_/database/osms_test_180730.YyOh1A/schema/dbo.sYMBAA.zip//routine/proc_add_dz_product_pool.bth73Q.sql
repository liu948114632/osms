/**
	@desc 原膜加入电子业务备货
	@date 2016-05-18
			-->2016-09-18	增加平均销量统计
	@author whw	
*/ 
CREATE PROC dbo.proc_add_dz_product_pool(
	@EndDate DATETIME --统计的结束日期
)
AS 
BEGIN
	DECLARE @create_time DATETIME=GETDATE(),
	@pool_type INT=2 , --原膜
	@plan_day INT=15,
	@sale_quantity INT=0 ,
	@refresh_param DECIMAL(18,2)=0.5 ,
	@is_update_prepare_quantity CHAR(1)=0,
	@is_forever_exit CHAR(1)=0,
	@limit_rate DECIMAL(18,2)=0.5,
	@join_user_id INT =0
	;


	WITH order_info AS (
		SELECT * FROM dbo.dz_count_order_product_sale_info(@EndDate,30)
	),
	ninety_days AS (
		SELECT * FROM dbo.dz_count_order_product_sale_info(@EndDate, 90) 
    ),
	temp AS(
		  SELECT  p.id AS product_id,
			ISNULL(t1.saleQuantity,0)*@refresh_param AS original_product_preprae_qty,
			ISNULL(t2.saleQuantity,0)*@refresh_param*(p.unit_quantity*@refresh_param/s.convert_rate) 
					AS processing_product_preprae_qty,
			p.unit_quantity,
			s.convert_rate,
			ISNULL(t3.saleQuantity,0) AS  avg_sale_qty,
                            --原膜（+子膜销量）
            ISNULL(t4.saleQuantity, 0)
				* ( p.unit_quantity*1.0 / s.convert_rate )
					AS child_avg_sale_qty 
    FROM    dbo.product p WITH ( NOLOCK )
            INNER JOIN dbo.storage_product_processing_accessories s WITH ( NOLOCK ) 
            ON s.original_product_id = p.id
            LEFT JOIN order_info t1 ON t1.product_id = s.original_product_id    --原膜
            LEFT JOIN order_info t2 ON t2.product_id = s.processing_product_id --子膜
			 LEFT JOIN ninety_days
                            t3 ON t3.product_id = s.original_product_id --月均销量
							LEFT JOIN ninety_days
                            t4 ON t4.product_id = s.processing_product_id --子膜月均销量
            LEFT JOIN dbo.dz_product_pool d WITH ( NOLOCK ) ON d.product_id = p.id
    WHERE   d.product_id IS NULL AND p.offline_status<>2
            AND ( t1.product_id IS NOT NULL
                  OR t2.product_id IS NOT NULL
                )
	)

	INSERT dbo.dz_product_pool
	        ( product_id ,
	          pool_type ,
	          is_forever_exit ,
	          plan_day ,
	          prepare_quantity ,
	          create_time ,
	          last_update_time ,
	          last_update_user_id ,
	          sale_quantity ,
	          refresh_param ,
	          is_update_prepare_quantity ,
	          limit_rate ,
	          join_user_id
	        )
    SELECT product_id AS productId ,@pool_type,@is_forever_exit,@plan_day,
    dbo.dz_product_pool_calc_original_product_preprae_qty(MIN(original_product_preprae_qty),
						SUM(processing_product_preprae_qty) ,
						 MIN(unit_quantity))          
             AS prepareQuantity 
             ,@create_time,NULL,NULL,
			 FLOOR(MIN(avg_sale_qty*1.0/3)+SUM(a.child_avg_sale_qty*1.0/3)) AS saleQuantity
			 ,@refresh_param,@is_update_prepare_quantity
             ,@limit_rate,@join_user_id
             FROM 
				temp AS a
    GROUP BY a.product_id 
END


go


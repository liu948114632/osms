
CREATE FUNCTION [dbo].[tempuf_Split_char]
(
	@Text	VARCHAR(MAX),
	@Split	VARCHAR(2) = ','
)
RETURNS @Table TABLE([Id] INT IDENTITY(1, 1) NOT NULL, [Value] VARCHAR(4000))
AS
BEGIN
	DECLARE @i INT;-- 分隔符所在位置
    DECLARE @s INT;-- 搜索起点位置
    
    SET @i=1;
    SET @s=1;
    
    WHILE(@i>0)
    BEGIN   
		-- 搜索分隔符位置 
        SET @i = CHARINDEX(@Split,@Text,@s);
        IF(@i > 0)
        BEGIN
            INSERT INTO @Table([Value]) VALUES(SUBSTRING(@Text,@s,@i - @s));
        END   
        ELSE BEGIN
            INSERT INTO @Table([Value]) VALUES(SUBSTRING(@Text,@s,LEN(@Text)- @s + 1));
        END
        
        SET @s = @i + 1; -- 搜索开始位置匹配到的分隔符往后推  
    END
    
    RETURN;  -- 返回结果
END
go


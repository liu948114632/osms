
CREATE VIEW view_ph_product_hot_category 
AS 
SELECT category_id,SUM(temp.batch_quantity) AS batch_quantity
FROM view_ph_product_hot AS temp 
GROUP BY category_id

go


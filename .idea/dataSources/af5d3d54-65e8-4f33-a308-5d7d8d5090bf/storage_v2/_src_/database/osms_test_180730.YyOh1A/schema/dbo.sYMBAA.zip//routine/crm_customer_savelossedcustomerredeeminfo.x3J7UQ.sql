

---保存挽回信息
CREATE PROC CRM_Customer_SaveLossedCustomerRedeemInfo
(
@CustomerId INT ,
@ContactSituation INT ,
@Lang INT ,
@Phone VARCHAR(50),
@JoinVipTime VARCHAR(20),
@RedeemLevel INT ,
@RedeemStatus INT ,
@IsSatisfaction INT ,
@IsHasOtherSupplier INT ,
@IsFreightHigh INT ,
@IsManageVeer INT ,
@IsFreightCycleLong INT ,
@IsNowNoOrderPlan INT ,
@IsCoupon INT ,
@IsStockUpCycleLong INT ,
@IsNowHasOrderPlan INT ,
@IsLevelChange INT ,
@IsRecommendPW INT ,
@IsHasComplainHistory INT ,
@SupplierInfo NVARCHAR(200),
@RedeemWayDesc NVARCHAR(500),
@CustomerOtherFacebook NVARCHAR(200),
@OperatorId INT=0 ,
@log NVARCHAR(2000)
)
AS
BEGIN

IF(ISDATE(@JoinVipTime)<>1)
SET @JoinVipTime=NULL;

UPDATE dbo.T_LossedCustomerRedeemDtl SET CustomerId=@CustomerId,Phone=@Phone,Lang=@Lang,JoinVipTime=@JoinVipTime,
IsSatisfaction=@IsSatisfaction,IsHasOtherSupplier=@IsHasOtherSupplier,IsFreightHigh=@IsFreightHigh,IsManageVeer=@IsManageVeer,
IsFreightCycleLong=@IsFreightCycleLong,IsNowNoOrderPlan=@IsNowNoOrderPlan,IsCoupon=@IsCoupon,IsStockUpCycleLong=@IsStockUpCycleLong,
IsNowHasOrderPlan=@IsNowHasOrderPlan,IsLevelChange=@IsLevelChange,IsRecommendPW=@IsRecommendPW,IsHasComplainHistory=@IsHasComplainHistory,
SupplierInfo=@SupplierInfo,CustomerOtherFacebook=@CustomerOtherFacebook,RedeemWayDesc=@RedeemWayDesc
WHERE CustomerId=@CustomerId;

UPDATE dbo.T_LossedCustomer SET ContactSituation=@ContactSituation,RedeemLevel=@RedeemLevel,RedeemStatus=@RedeemStatus WHERE CustomerId=@CustomerId;

IF(LEN(@log)>0)
BEGIN
INSERT INTO dbo.T_LossedCustomerOperateLog
        ( CustomerId ,
          CreateTime ,
          Content ,
          CreatorId
        )
VALUES  (@CustomerId,
          GETDATE() ,
          @log , 
          @OperatorId 
        )
END

IF @IsSatisfaction>0 OR @IsHasOtherSupplier>0 OR @IsFreightHigh>0 OR @IsManageVeer>0 OR @IsFreightCycleLong>0 OR @IsNowNoOrderPlan>0 OR @IsStockUpCycleLong>0 OR @IsNowHasOrderPlan>0 OR @IsRecommendPW>0 OR @IsHasComplainHistory>0 OR Len(@SupplierInfo)>0 OR LEN(@CustomerOtherFacebook)>0
BEGIN
 UPDATE dbo.T_LossedCustomer SET HasValidInfo=1 WHERE CustomerId=@CustomerId;
END
ELSE
BEGIN
 UPDATE dbo.T_LossedCustomer SET HasValidInfo=0 WHERE CustomerId=@CustomerId;
END
END


go


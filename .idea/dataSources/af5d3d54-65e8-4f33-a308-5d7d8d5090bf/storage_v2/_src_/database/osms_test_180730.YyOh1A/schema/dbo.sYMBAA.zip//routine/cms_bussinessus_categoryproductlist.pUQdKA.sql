
CREATE
 PROCEDURE [dbo].[CMS_BussinessUS_CategoryProductList](
	@CategoryId1 INT = NULL,--一级类别
	@CategoryId2 INT = NULL,--二级类别
	@CategoryId3 INT = NULL,--三级类别
	@SeriesId INT = NULL,--系列
	@PropertyValueId1 INT = NULL,--第一个属性值 
	@PropertyValueId2 INT = NULL,--第二个属性值
	@PropertyValueId3 INT = NULL,--第三个属性值
	@IsOnShelf INT = NULL,--是否上架
	@IsMix INT = NULL,--是否混装
	@IsPromotional INT = NULL,--是否促销
	@IsPool INT = NULL,--是否商品池产品
	@IsDisplay INT = NULL,--是否显示
	@IsGift INT = NULL,--是否成品
	@ProductCode VARCHAR(22) = NULL,--产品编号
	@ProductCodes VARCHAR(max) = NULL,--产品编号
	@ProductName VARCHAR(MAX) = NULL,--产品名称
	@HasTags INT = NULL, --是否有Tags
	@IsSmallQuantities INT=null,--是否小批量
	@IsCompetition int=null,--是否竞争对手
	@IsCategorySeries int=null,--是否加入系列
	@IsAdvancedPack BIT = NULL ,--是否高级包装   
	@PageSize INT = 50 ,  --页大小              
	@PageIndex INT = 1    --当前页号    
)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE
		@SQL VARCHAR(max),              
        @CountSql NVARCHAR(MAX), --查询数量用              
        @FromSQL NVARCHAR(max), --查询内表            
        @Column NVARCHAR(max), --取的字段            
        @Condition varchar(MAX), --条件               
        @RowCount INT , 
        @PageCount INT , 
        @start INT ,
        @end INT,
        @IsQueryPropertyValue BIT;
	--设置查询主表
	SET @FromSQL = ' FROM us_product PH WITH(NOLOCK) INNER JOIN product P WITH(NOLOCK) ON PH.product_id = P.id 
					LEFT JOIN dbo.product_small_quantities S WITH(NOLOCK) ON S.product_id = P.id
					LEFT JOIN dbo.us_product ph2 WITH(NOLOCK) ON ph2.product_id = S.original_product_id';			 
	--设置查询条件
	SET @Condition = ' WHERE 1=1 ';
	IF @CategoryId1 IS NOT NULL
	BEGIN
		SET @Condition = @Condition + ' AND P.category_id_1=' + CONVERT(VARCHAR(10), @CategoryId1)
	END
	IF @CategoryId2 IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND P.category_id_2=' + CONVERT(VARCHAR(10), @CategoryId2)
	END
	IF @CategoryId3 IS NOT NULL
	BEGIN
		SET @Condition = @Condition + ' AND P.category_id_3=' + CONVERT(VARCHAR(10), @CategoryId3)
	END
	
	IF @ProductCode IS NOT NULL
	BEGIN
		SET @Condition = @Condition + ' AND P.code like ''' + @ProductCode + '%''';
	END
	IF @ProductCodes IS NOT NULL
	BEGIN
		SET @Condition = @Condition + ' AND P.code in (''' + REPLACE(@ProductCodes,',',''',''') + ''')'   
	END
	
	IF @SeriesId IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND PH.category_series_id=' + CONVERT(VARCHAR(10), @SeriesId);
	END 
	
	DECLARE @TempSQL NVARCHAR(MAX);
	SET @TempSQL = '';
	SET @IsQueryPropertyValue = 0;
	
	IF @PropertyValueId1 IS NOT NULL
	BEGIN
		IF @IsQueryPropertyValue = 1
		BEGIN 
			SET @TempSQL = @TempSQL + ',';
		END 
		SET @IsQueryPropertyValue = 1;
		SET @TempSQL = @TempSQL + CONVERT(VARCHAR(10), @PropertyValueId1);	
	END
	IF @PropertyValueId2 IS NOT NULL
	BEGIN
		IF @IsQueryPropertyValue = 1
		BEGIN 
			SET @TempSQL = @TempSQL + ',';
		END 
		SET @IsQueryPropertyValue = 1;
		SET @TempSQL = @TempSQL + CONVERT(VARCHAR(10), @PropertyValueId2);	
	END
	IF @PropertyValueId3 IS NOT NULL
	BEGIN
		IF @IsQueryPropertyValue = 1
		BEGIN 
			SET @TempSQL = @TempSQL + ',';
		END 
		SET @IsQueryPropertyValue = 1;
		SET @TempSQL = @TempSQL + CONVERT(VARCHAR(10), @PropertyValueId3);		
	END
	
	IF @IsQueryPropertyValue =1
	BEGIN
		SET @Condition = @Condition + ' AND EXISTS(SELECT PP.id FROM dbo.product_property_value PP WITH(NOLOCK)'
					   + ' WHERE PP.product_id=PH.product_id AND PP.property_value IN (' + @TempSQL + '))';	 
	END 
	
	IF @IsOnShelf is not null
	BEGIN
		SET @Condition = @Condition + ' AND PH.is_on_shelf=' + CONVERT(VARCHAR(10), @IsOnShelf);
	END
	
	IF @IsMix IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND P.is_mix=' + CONVERT(VARCHAR(10), @IsMix);
	END 
	
	IF @IsPromotional IS NOT NULL 
	BEGIN 
		SET @Condition = @Condition + ' AND PH.is_promotional=' + CONVERT(VARCHAR(10), @IsPromotional); 
	END 
	
	if @IsPool is not null
	begin
		SET @Condition = @Condition + ' AND PH.is_pool=' + CONVERT(VARCHAR(10), @IsPool);
	end
	
	if @IsGift is not null
	begin
		SET @Condition = @Condition + ' AND P.is_gift=' + CONVERT(VARCHAR(10), @IsGift);
	end
	
	IF @IsDisplay IS NOT NULL
	BEGIN
		SET @Condition = @Condition + ' AND P.is_display_us =' + CONVERT(VARCHAR(10), @IsDisplay);
	END
	
	IF @ProductName IS NOT NULL 
	BEGIN
		SET @Condition = @Condition + ' AND P.name like ''%' + @ProductName + '%''';
	END	
	IF @HasTags IS NOT NULL
	BEGIN
		IF @HasTags=1
		BEGIN
			SET @Condition = @Condition + ' AND  EXISTS(SELECT id FROM product_tag WHERE product_tag.product_id=P.id)'	
		END
		IF @HasTags=0
		BEGIN
			SET @Condition = @Condition + ' AND  NOT EXISTS(SELECT id FROM product_tag WHERE product_tag.product_id=P.id)'
		END
	END
	
	if @IsSmallQuantities is not null
	begin
		set @Condition = @Condition + ' and p.is_small_quantities ='+CONVERT(varchar(10),@IsSmallQuantities);
	end
	
	if @IsCompetition is not null
	begin
		set @Condition=@Condition+' and PH.is_competition='+CONVERT(varchar(10),@IsCompetition);
	end
	
	if @IsCategorySeries is not null
	begin
		if @IsCategorySeries=1
		begin
			set @Condition =@Condition +' and PH.category_series_id is not null'
		end
		if @IsCategorySeries=0
		begin
			set @Condition =@Condition +' and PH.category_series_id is null'
		end
	end
	IF @IsAdvancedPack IS NOT NULL
        BEGIN
			IF @IsAdvancedPack = 1 
                BEGIN              
                    SET @Condition = @Condition + ' AND P.is_advanced_pack=1'            
                END               
            ELSE 
                BEGIN               
                    SET @Condition = @Condition + ' AND P.is_advanced_pack=0'              
                END 
        END  
	--设置查询列
	SET @Column = 'PD.id,
				   PD.browse_count browseCount,
				   PD.category_series_id categorySeriesId,
				   PD.current_cost_price currentCostPrice,
				   PD.first_profit_coefficient firstProfitCoefficient,
				   PD.first_quantity_from firstQuantityFrom,
				   PD.first_quantity_to firstQuantityTo,
				   PD.is_best_sellers isBestSellers,
				   PD.is_competitor_best_sellers isCompetitorBestSellers,
				   PD.is_on_shelf isOnShelf,
				   PD.is_pool isPool,
				   PD.is_promotional isPromotional,
				   PD.order_count orderCount,
				   PD.product_id productId,
				   PD.publish_time publishTime,
				   PD.publish_user_id publishUserId,
				   PD.reference_cost_price referenceCostPrice,
				   PD.second_profit_coefficient secondProfitCoefficient,
				   PD.second_quantity_from secondQuantityFrom,
				   PD.second_quantity_to secondQuantityTo,
				   PD.third_profit_coefficient thirdProfitCoefficient,
				   PD.third_quantity_from thirdQuantityFrom,
				   PD.is_competition as isCompetition,
				   p.is_small_quantities as isSmallQuantities,
				   PD.third_quantity_to thirdQuantityTo,
				   p.is_display_us as isDisplayUs ';
				   
	--查询记录数
	SET @CountSQL = '';
	SET @CountSQL = 'SELECT @RowCountOUT=count(PH.id) ' + @FromSQL + @Condition;
	--print @CountSQL;
	EXEC sp_executesql @CountSQL, N'@RowCountOUT INT OUT', @RowCountOUT=@RowCount OUT;	

   	--查询的分页条件
	IF ISNULL(@PageSize, 0) < 1                       
		SET @PageSize = 50                      
    SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                      
    IF ISNULL(@PageIndex, 0) < 1                       
        SET @PageIndex = 1                      
    ELSE                       
    IF ISNULL(@PageIndex, 0) > @PageCount                       
        SET @PageIndex = @PageCount                      
    SET @Start = ( @PageIndex - 1 ) * @PageSize + 1                      
    SET @End = @PageIndex * @PageSize  
    			   
	--组装查询语句
		SET @SQL = 'SELECT id, ROW_NUMBER() OVER (ORDER BY sortPublishTime DESC, sort DESC, id ASC) RowIndex FROM  ( SELECT PH.id,CASE WHEN p.is_small_quantities=0 THEN p.code ELSE s.original_product_code END AS sort,CASE WHEN p.is_small_quantities=0 THEN PH.publish_time ELSE ph2.publish_time END AS sortPublishTime ' + @FromSQL + @Condition+') z';
	
		SET @SQL = 'SELECT ' + @Column + ' FROM (' + @SQL + ') temp INNER JOIN us_product PD WITH(NOLOCK) on PD.id=temp.id 
		            JOIN dbo.product p WITH(NOLOCK) ON PD.product_id = p.id
		            
		            WHERE RowIndex between '
				 + CONVERT(VARCHAR(10), @Start) + ' AND ' + CONVERT(VARCHAR(10), @End) + ' order by RowIndex';
	PRINT @SQL
	EXEC(@SQL);                        
    select @RowCount  					   
END


go


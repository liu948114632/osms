


CREATE PROC CRM_Order_PackageProblemDetailGet
(
@ProblemId INT
--@OrderCodes NVARCHAR(200)
)
AS
BEGIN
    SELECT  a.* ,
            ( SELECT   CAST(id AS VARCHAR(10))+ ',' + OriginalFileName+'|'
              FROM      dbo.T_PackageProblemAttachment
              WHERE     objectId = a.Id
            FOR
              XML PATH('')
            ) AS Attachment
    FROM    dbo.T_PackageProblemDetail a 
    WHERE  a.ProblemId=@ProblemId
   ORDER BY id DESC  
END

go


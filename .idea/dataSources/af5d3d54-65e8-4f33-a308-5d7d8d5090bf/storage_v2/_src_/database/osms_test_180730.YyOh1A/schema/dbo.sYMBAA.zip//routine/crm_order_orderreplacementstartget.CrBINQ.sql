

CREATE PROC dbo.CRM_Order_OrderReplacementStartGet        
AS        
BEGIN        
 -- SET NOCOUNT ON added to prevent extra result sets from        
 -- interfering with SELECT statements.        
 SET NOCOUNT ON;        

 SELECT  a.OrderId ,        
            a.HandlerId ,        
            c.english_name AS HandlerName ,        
            a.CustomerId ,        
			   --b.Email AS CustomerMail,
            b.FullName AS CustomerName 	
    FROM t_Order a        
            JOIN dbo.T_Customer b ON a.CustomerId = b.UserID        
            LEFT JOIN dbo.[user] c ON a.HandlerId = c.Id      
			LEFT JOIN dbo.T_BusinessType d WITH(NOLOCK) ON d.BusinessTypeValue=a.OrderIndustryType  
 WHERE a.OrderStatus = 1        
                        AND (a.OrderIndustryType = 1 OR d.IsPHClone=1) -- 只处理PH的订单        
                        AND a.OrderType IN ( 1, 2 )        
                        AND a.IsAutoDelay = 1        
      AND DATEDIFF(DAY,a.AutoDelayDate,GETDATE()) IN (0,1)      --预计发货日期已经在录单和添加商品的是已经初始化好了，预计发货日期不会在假期内，不用再判断假期
      AND a.DelayStatus NOT IN (3,5,6)  AND a.ReplaceSwitch != 1      
END
go


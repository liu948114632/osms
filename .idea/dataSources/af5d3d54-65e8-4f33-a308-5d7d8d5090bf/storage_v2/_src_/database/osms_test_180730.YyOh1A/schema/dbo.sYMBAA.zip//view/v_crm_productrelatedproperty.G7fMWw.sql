
CREATE VIEW V_CRM_ProductRelatedProperty  
AS   
SELECT a.product_id AS CmsProductId,  
    a.property_id AS PropertyId,  
    a.property_value AS PropertyValueId   
FROM   product_property_value a WITH(NOLOCK)
go


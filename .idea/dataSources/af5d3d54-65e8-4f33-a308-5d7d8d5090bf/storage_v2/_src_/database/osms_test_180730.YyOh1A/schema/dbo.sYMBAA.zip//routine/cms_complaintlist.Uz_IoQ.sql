CREATE PROC CMS_ComplaintList
(
	@code VARCHAR(100)=NULL,
	@codes VARCHAR(max)=NULL,
	@name VARCHAR(200)=NULL,
    @orderCode VARCHAR(100)=NULL,
	@orderCodes VARCHAR(max)=NULL,
	@status INT=NULL,
	@trackerUserId INT=NULL,
	@creatorId INT=NULL,
	@creatorTimeBegin VARCHAR(200)=NULL,
	@creatorTimeOver VARCHAR(200)=NULL, 
	@productCode VARCHAR(200)=NULL,
	@productCodes VARCHAR(max)=NULL,
	@productStatus INT=NULL,
	@productTrackerId INT =NULL,
	@type INT=NULL,
	@isVip INT = NULL ,
	@productType INT=NULL,
	@complaintDepartmentId INT=NULL,
	@dutyUserId INT=NULL,
	@customerName VARCHAR(500)=NULL,
	@purchaseDepartmentId INT = NULL,
	 @PageSize INT = 50 ,  --页大小                              
    @PageIndex INT = 1    --当前页号  
)
AS  
BEGIN  
 DECLARE @SQL NVARCHAR(MAX) ,  
            @FromSQL NVARCHAR(MAX) ,  
            @FromSQL2 NVARCHAR(MAX) ,    
            @Column NVARCHAR(MAX) ,  
            @Condition NVARCHAR(MAX) ,  
            @CountSQL NVARCHAR(MAX) ,   
            @RowCount INT ,  
            @PageCount INT ,     
            @Start INT ,  
            @End INT ,  
            @IsQueryProduct BIT;  
              
    SET @IsQueryProduct = 0 ;  
                  
 SET @Condition = ' WHERE 1 = 1  ';  

   
 IF @code IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and a.code like ''' + @code + '''' ;    
  END 
IF @isVip IS NOT NULL
BEGIN
	SET @Condition = @Condition + ' and a.is_vip = ' + CONVERT(VARCHAR(10),  @isVip) ;  
END
IF @codes IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.code in (''' + REPLACE(@codes, ',', ''',''') + ''')';  
  END  

IF @name IS NOT NULL
BEGIN
    SET @Condition = @Condition + ' and a.name like ''' + @name + '''' ;
END
  
   IF @orderCode IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and a.order_code like ''' + @orderCode + '''' ;    
  END 

IF @orderCodes IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and EXISTS 
		( SELECT 1 FROM dbo.uf_Split_Str(a.order_code,'','') WHERE Id  in (''' + REPLACE(@orderCodes, ',', ''',''') + '''))';  
  END 

 IF @status IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and a.status = ' + CONVERT(VARCHAR(10),  @status) ;  
  END  


 IF @trackerUserId IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and a.tracker_user_id = ' + CONVERT(VARCHAR(10),  @trackerUserId) ;  
  END  

 IF @creatorId IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and a.creator_id = ' + CONVERT(VARCHAR(10),  @creatorId) ;  
  END  
IF @creatorTimeBegin IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.crate_time >=''' + @creatorTimeBegin + ''''  
  END  
   IF @creatorTimeOver IS NOT NULL  
  BEGIN  
   SET @Condition = @Condition + ' and a.crate_time <=''' + @creatorTimeOver + ''''  
  END  
 IF @type IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and a.type = ' + CONVERT(VARCHAR(10),  @type) ;  
  END  

   IF @productCode IS NOT NULL  
  BEGIN  
   SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and cp.product_code like ''' +  @productCode + '''' ;  
  END 
 IF @purchaseDepartmentId IS NOT NULL
 BEGIN
	SET @IsQueryProduct = 1;  
    SET @Condition = @Condition + ' and cp.strategy_department_id = '+CAST(@purchaseDepartmentId AS VARCHAR(10))
 END 
 IF @productCodes IS NOT NULL  
  BEGIN  
   SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and cp.product_code in (''' + REPLACE(@productCodes, ',', ''',''') + ''')';  
  END 
IF @productType IS NOT NULL   
  BEGIN    
	 SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and cp.type = ' + CONVERT(VARCHAR(10),  @productType) ;  
  END  
IF @productStatus IS NOT NULL   
  BEGIN    
   SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and cp.status = ' + CONVERT(VARCHAR(10),  @productStatus) ;  
  END 
  IF @productTrackerId IS NOT NULL   
  BEGIN    
   SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and cp.product_tracker_user_id = ' + CONVERT(VARCHAR(10),  @productTrackerId) ;  
  END 
IF @dutyUserId IS NOT NULL   
  BEGIN    
   SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and cp.duty_user_id = ' + CONVERT(VARCHAR(10),  @dutyUserId) ;  
  END 

  IF @complaintDepartmentId IS NOT NULL   
  BEGIN    
   SET @IsQueryProduct = 1;  
   SET @Condition = @Condition + ' and cp.complaint_department_id = ' + CONVERT(VARCHAR(10),  @complaintDepartmentId) ;  
  END 

IF @customerName IS NOT NULL   
  BEGIN    
   SET @Condition = @Condition + ' and a.customer_name like ''' + @customerName + '''' ;    
  END 

 SET @FromSQL = ' FROM   dbo.complaint AS a WITH ( NOLOCK )  
        ';  
 IF @IsQueryProduct = 1  
 BEGIN  
  SET @FromSQL = @FromSQL + 'inner JOIN dbo.complaint_product AS cp WITH(NOLOCK) 
				ON a.code = cp.complaint_code     
				 ';  
 END        

--获取符合条件的总记录数            
   SET @CountSQL = ' SELECT @RowCount = count(DISTINCT a.id) ' + @FromSQL + @Condition                      
   EXEC sp_executesql @CountSQL, N'@RowCount INT OUT', @RowCount OUT             
     
   --设置分页参数(一定要放在取记录数的后面)            
   IF ISNULL(@PageSize, 0) < 1   
    SET @PageSize = 50                            
   SET   
 @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                            
   IF ISNULL(@PageIndex, 0) < 1   
    SET @PageIndex = 1    
                           
   ELSE   
    IF ISNULL(@PageIndex, 0) > @PageCount   
     SET @PageIndex = @PageCount                     
       
   SET @Start = ( @PageIndex - 1 ) * @PageSize + 1                            
   SET @End = @PageIndex * @PageSize       
        
  SET @Column = '   
	a.id ,a.is_vip as isVip,
           a.code ,
           a.name ,
           a.content ,
           a.priority ,
           a.order_code orderCode,
           a.expense ,
           a.status ,
           a.cause ,
           a.creator_id creatorId,
           a.crate_time crateTime,
           a.tracker_user_id trackerUserId,
           a.remark ,
           a.type ,
           a.appeal_reason appealReason,
           a.system_source systemSource,
		   a.customer_name as customerName
  ' ;   
       
   --组装查询语句   
   
IF @IsQueryProduct = 1  
 BEGIN  
	
  SET @FromSQL = '	FROM   dbo.complaint AS a WITH ( NOLOCK ) inner join   (select DISTINCT a.id ' +@FromSQL + @Condition+' ) b 
				on a.id=b.id ';  
 END   
 ELSE
 BEGIN
      SET @FromSQL= @FromSQL + @Condition 
 END             
           
 SET @SQL = 'SELECT ' + @Column + ', ROW_NUMBER() OVER (ORDER BY a.status asc ,a.code desc) RowIndex '  
    + @FromSQL  ;      
                         
 SET @SQL = 'SELECT temp.*   
  FROM (' + @SQL + ') temp WHERE RowIndex between '  
  + CONVERT(VARCHAR(10), @Start) + ' AND '  
  + CONVERT(VARCHAR(10), @End) + ' order by RowIndex' ;      
                       
 --SELECT @SQL  
 PRINT @SQL    
 EXEC(@SQL) ;                                        
 SELECT  @RowCount  
END

go


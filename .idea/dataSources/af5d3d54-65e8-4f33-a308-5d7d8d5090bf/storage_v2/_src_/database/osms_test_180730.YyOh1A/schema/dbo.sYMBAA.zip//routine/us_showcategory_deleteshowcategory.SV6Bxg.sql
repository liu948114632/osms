CREATE PROCEDURE [dbo].[US_ShowCategory_DeleteShowCategory]
(
	@ShowCategoryId INT
)
AS
BEGIN 
	UPDATE dbo.T_ShowCategory_US SET IsDeleted=1 WHERE ShowCategoryId=@ShowCategoryId
END
go


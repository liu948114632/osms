CREATE PROC dbo.CMS_DepartmentPurchase_GetPurchaseItemDetais  
 @purchaseId INT =NULL  
AS  
BEGIN  
 SELECT   
 b.id as id,  
 b.purchase_id as purchaseId,  
 b.product_id as productId,  
 b.product_unit as productUnit,  
 b.product_cost_price as productCostPrice,   
 b.provider_id as providerId,  
 b.plan_quantity as planQuantity,  
 b.completion_quantity as completionQuantity,  
 b.un_discount_purchase_price as unDiscountPurchasePrice,  
 b. discount,  
 b.purchase_price AS  purchasePrice,  
  b.kg_price AS kgPrice,  
 CASE WHEN (b.expense_no IS NULL OR b.expense_no=0) THEN 1 ELSE  expense_no END as expenseNO,  
 task_id AS taskId,  
 task_remark AS taskRemark,  
 b.remark,  
 b.order_quantity AS orderQuantity,  
 purchase_order_product_id AS  purchaseOrderProductId,  
 is_deleted AS  isDeleted,  
 package_user_id as packageUserId,  
 base_discount as baseDiscount,  
 c.code AS productCode,  
 c.name AS productName,  
 c.original_name AS productOriginalName,  
 c.primary_picture_code AS primaryPictureCode,  
 c.color_card_picture_code AS colorCardPictureCode,  
 c.provider_code AS productProviderCode,  
 d.provider_code AS productColorCardProviderCode,  
 f.source_department_id AS sourceDepartmentId,  
 c.is_small_quantities AS isSmallQuantities,  
 a.code AS purchaseCode,  
 pd.chinese_description AS productInfo,  
 b.coefficient_of_difficulty AS coefficientOfDifficulty ,
 b.is_remove AS isRemove,
 b.status,
 b.audit_remark AS auditRemark,
 b.check_remark AS checkRemark,
 b.check_user AS checkUser,
 b.box,
 b.audit_user AS auditUser,
 CASE WHEN b.is_exemption IS NULL THEN 
 CASE WHEN pr.id IS NOT NULL   THEN dbo.uf_is_exemption(pr.exemption_level) 
 WHEN  c.status=4 THEN dbo.uf_is_exemption('C级') 
 ELSE 0
 END 
 ELSE b.is_exemption END 
 AS isExemption,
 b.stock_out_code AS stockOutCode,b.last_check_user AS lastCheckUserId,
 b.is_vip AS isVip,
 cplr.level AS complaintLevel,
 b.has_complaint AS hasComplaint,
 f.completion_quantity AS taskCompletionQuantity,
 f.plan_quantity AS taskPlanQuantity,
 f.original_source_department_id AS originalSourceDepartmentId
  FROM  dbo.purchase a WITH(NOLOCK) 
  JOIN dbo.purchase_item b WITH(NOLOCK) ON a.id =b.purchase_id AND ((a.status =160 AND b.is_deleted=1) OR (a.status<>160 AND b.is_deleted =0 ))  
  JOIN dbo.product c WITH(NOLOCK) ON c.id =b.product_id  
  LEFT JOIN dbo.product_set_color_card d WITH(NOLOCK) ON d.id =c.product_set_color_card_id  
  LEFT JOIN dbo.view_all_department_purchase_task f ON f.id =b.task_id  
  LEFT JOIN dbo.product_description pd WITH(NOLOCK) ON pd.product_id = b.product_id  
  LEFT JOIN dbo.exemption_product pr WITH(NOLOCK) ON pr.product_id =b.product_id
  LEFT JOIN dbo.complaint_product_level_ratio cplr WITH(NOLOCK) ON b.product_id=cplr.product_id
  WHERE a.id =@purchaseId  
END
go


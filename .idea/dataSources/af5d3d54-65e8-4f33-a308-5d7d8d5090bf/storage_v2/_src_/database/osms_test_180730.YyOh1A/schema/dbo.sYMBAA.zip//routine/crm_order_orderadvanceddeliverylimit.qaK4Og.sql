



CREATE PROC CRM_Order_OrderAdvancedDeliveryLimit
(
@OrderId VARCHAR(20),
@DeliveryId INT=0 ,
@CountryId int =0,
@City VARCHAR(50)='',
@Zip VARCHAR(50)='',
@ReturnInfo VARCHAR(100)='' OUTPUT
)
AS
BEGIN
	
	SET @ReturnInfo='';
	DECLARE @DeliveryName VARCHAR(50),
	@PolicyType INT; --1-表示不到，2-表示只到;	
	
	IF(@DeliveryId=0)
	BEGIN
		SELECT @DeliveryId=DeliveryId FROM dbo.T_Order WITH (NOLOCK) WHERE OrderId=@OrderId;
	END
	
	IF(@CountryId=0)
	BEGIN
		SELECT @CountryId=b.Country FROM dbo.T_Order o WITH (NOLOCK) 
		INNER JOIN dbo.T_OrderAddresses b WITH (NOLOCK) ON o.ShipAddressId=b.AddressId WHERE OrderId=@OrderId;
	END
	
IF EXISTS(	SELECT  TOP 1 1  FROM dbo.T_DeliveryCountryPolicy WHERE DeliveryId=@DeliveryId AND CountryId=@CountryId)
	BEGIN
			SELECT  @PolicyType=PolicyType FROM dbo.T_DeliveryCountryPolicy WHERE DeliveryId=@DeliveryId AND CountryId=@CountryId
	END
ELSE
	BEGIN
		SET @ReturnInfo='';
		RETURN
	END
		
	IF(@City='')
	BEGIN
		SELECT @City=b.City FROM dbo.T_Order o WITH (NOLOCK) 
		INNER JOIN dbo.T_OrderAddresses b WITH (NOLOCK) ON o.ShipAddressId=b.AddressId WHERE OrderId=@OrderId;
	END
	
	 IF(@Zip='')
	BEGIN
		SELECT @Zip=b.Zip FROM dbo.T_Order o WITH (NOLOCK) 
		INNER JOIN dbo.T_OrderAddresses b WITH (NOLOCK) ON o.ShipAddressId=b.AddressId WHERE OrderId=@OrderId;
	END
	
	SELECT @DeliveryName=Name FROM dbo.T_Delivery WHERE DeliveryId=@DeliveryId
	
PRINT @PolicyType;
	
IF(@PolicyType=1)--不到
BEGIN	
		IF @City>'' AND  EXISTS(SELECT TOP 1 1 FROM dbo.T_DeliveryIgnoreCity WITH (NOLOCK) WHERE DeliveryId=@DeliveryId AND CountryId=@CountryId AND City=@City) 
			BEGIN			
				SET @ReturnInfo='<info>该货运方式'+@DeliveryName+'不到城市'+@City+'</info>';
				RETURN;
			END
			
		IF @Zip>'' AND  EXISTS(SELECT TOP 1 1  FROM T_DeliveryIgnoreZip WITH (NOLOCK)  WHERE  CountryId=@CountryId AND DeliveryId=@DeliveryId
	AND FromZip>'' 
	AND  LEFT (@Zip,LEN(REPLACE(REPLACE(FromZip, ' ',''),'-',''))) BETWEEN REPLACE(REPLACE(FromZip, ' ',''),'-','') AND   REPLACE(REPLACE(ToZip,' ',''),'-',''))
		BEGIN
				SET @ReturnInfo='<info>该货运方式'+@DeliveryName+'不到邮编'+@Zip+'</info>';
				RETURN;
		END 
	END
		
	IF(@PolicyType=2)--只到
	BEGIN
--只到表，只要一个有数据就是只到
		IF (@City>'' AND EXISTS(SELECT TOP 1 1 FROM dbo.T_DeliveryOnlyCity  WITH (NOLOCK) WHERE DeliveryId=@DeliveryId AND CountryId=@CountryId AND City=@City) 
		OR 
		@Zip>'' AND  EXISTS(SELECT TOP 1 1 FROM dbo.T_DeliveryOnlyZip WITH (NOLOCK)  WHERE  CountryId=@CountryId AND DeliveryId=@DeliveryId 
		AND  FromZip>'' 
		AND  LEFT (@Zip,LEN(REPLACE(REPLACE(FromZip, ' ',''),'-',''))) BETWEEN REPLACE(REPLACE(FromZip, ' ',''),'-','') AND   REPLACE(REPLACE(ToZip,' ',''),'-','')))
		BEGIN
		SET @ReturnInfo='';
			RETURN;
		END
	
	IF @City>'' AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.T_DeliveryOnlyCity  WITH (NOLOCK) WHERE DeliveryId=@DeliveryId AND CountryId=@CountryId AND City=@City)
	BEGIN
			SET @ReturnInfo='<info>该货运方式'+@DeliveryName+'不到城市'+@City+'</info>';
			RETURN;
	END
	
	IF @Zip>'' AND NOT EXISTS(
		SELECT TOP 1 1 FROM dbo.T_DeliveryOnlyZip WITH (NOLOCK)  WHERE  CountryId=@CountryId AND DeliveryId=@DeliveryId 
		AND  FromZip>'' 
		AND  LEFT (@Zip,LEN(REPLACE(REPLACE(FromZip, ' ',''),'-',''))) BETWEEN REPLACE(REPLACE(FromZip, ' ',''),'-','') AND   REPLACE(REPLACE(ToZip,' ',''),'-',''))
		BEGIN
			 SET @ReturnInfo='<info>该货运方式'+@DeliveryName+'不到邮编'+@Zip+'</info>';
					RETURN;
		END 
	END

END


go


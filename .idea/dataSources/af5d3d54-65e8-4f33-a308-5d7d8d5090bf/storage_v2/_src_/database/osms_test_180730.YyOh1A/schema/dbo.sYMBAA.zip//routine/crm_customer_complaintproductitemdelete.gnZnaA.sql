/*
	删除投诉产品
*/
CREATE PROC CRM_Customer_ComplaintProductItemDelete
(
	@Id INT
)
AS
BEGIN
	DELETE dbo.T_ComplaintProductItem WHERE Id= @Id
END
go


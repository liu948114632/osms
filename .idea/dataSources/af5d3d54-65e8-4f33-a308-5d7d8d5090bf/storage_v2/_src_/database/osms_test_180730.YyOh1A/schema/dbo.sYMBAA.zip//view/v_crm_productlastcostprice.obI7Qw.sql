
CREATE VIEW V_CRM_ProductLastCostPrice
AS 
SELECT a.id AS CmsProductId,
a.operating_cost_price AS LastCostPrice
FROM   dbo.product a WITH ( NOLOCK )

go


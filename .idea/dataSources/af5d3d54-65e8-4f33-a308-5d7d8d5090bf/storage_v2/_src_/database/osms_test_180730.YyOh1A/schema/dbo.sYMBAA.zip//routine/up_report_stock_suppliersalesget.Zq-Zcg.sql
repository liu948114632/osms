




/**************************************************************
[备注]
	统计某个供应商的商品销售情况
up_Report_Stock_SupplierSalesGet '2009-08-01','2009-09-01','jxgz'
**************************************************************/
CREATE PROCEDURE [dbo].[up_Report_Stock_SupplierSalesGet] 
(
	@StartTime		Datetime, 
	@EndTime		Datetime,
	@Name			VARCHAR(100) -- 供应商名称
)
AS
Declare
	@Id			INT; -- 供应商编号
BEGIN
	SET NOCOUNT ON;

	Select @Id = ProviderId FROM dbo.D_Provider WHERE [Name] = @Name;
	
	If @Id > 0 And @Name > ''
	Begin
--		Select 
--			(Select ItemCode From T_Item Where ItemKeyId =  T_ItemProvider.ItemKeyId) As ItemCode,
--			(Select unit From t_item Where itemkeyid = T_ItemProvider.ItemKeyId) As Unit,
--			Sum(b_orderItem.Quantity) As Qty
--		From 
--			T_ItemProvider Inner Join b_orderItem 
--				On T_ItemProvider.ItemKeyId = b_orderItem.ProductId
--					Inner Join b_order 
--						On b_orderItem.OrderId = b_order.OrderId
--		Where 
--				T_ItemProvider.ProviderId = @Id And b_order.OrderDate > @StartTime 
--				And b_Order.OrderDate < @EndTime
--				And b_orderItem.Status < 12 And b_order.Status < 132
--		Group by T_ItemProvider.ItemKeyId
--		Order By Qty DESC
		
		
		SELECT
			(SELECT Code FROM dbo.D_Product WHERE ProductDataId = b.ProductDataId) As ItemCode,
			(SELECT LTRIM(UnitQuantity) + ' ' + Unit FROM dbo.D_Product WHERE ProductDataId = b.ProductDataId) As Unit,
			CAST(Sum(b.Quantity*1.0/b.UnitQuantity) AS DECIMAL(9,2)) As Qty 
		FROM dbo.D_ProductRelatedProvider a 
		JOIN dbo.C_OrderItem b
			ON a.ProductDataId = b.ProductDataId 
				AND a.ProviderId = @Id
					AND b.[Status] < 12 -- 排除取消过的商品
		JOIN dbo.C_Order c 
			ON b.OrderId = c.OrderId 
				AND c.OrderStatus < 132 
					AND c.OrderDate > @StartTime AND c.OrderDate < @EndTime
		GROUP BY b.ProductDataId
		ORDER BY Qty DESC;
				
	End
	
END


go



CREATE FUNCTION   [dbo].[Fu_IFreightMng_CalculateDeliveryFreight]
(
	@DeliveryId int,
	@AreaId int,--定义国家在这种运输方式下所在的区域
	@weight decimal(18,2)
)
RETURNS decimal(18,2)
AS
BEGIN
	if @DeliveryId = 17
		return 0
 	declare @freight decimal(18,2) --定义最终运费

	/*计算首重和首重运费相关*/
	declare @FirstWeight decimal(18,2) --定义首重
	declare @FirstFreight Money  --定义首重运费
	 
	/*计算最大运输重量相关*/
	declare @MaxFromWeight  decimal(18,2)--定义最大重量
	declare @MaxToWeight  decimal(18,2)--定义最大重量，最大用-1标识
	declare @RangeId int --定义所在的重量区间
	declare @Packages int --定义包裹的数量，当输入的重量超过运费的最大重量时，分几个包裹处理


	/*定义运费表中的梯度重量，梯度费用和费用方式*/
	declare @LadderWeight decimal(18,2)
	declare @LadderPrice  Money
	declare @PriceType int  
	declare @LadderNumbers int --定义梯度的数量，在计算续费时用到

	declare @Currency decimal(18,4) --定义汇率
	select @Currency = rate from t_currency where id = (select Currency from t_delivery where deliveryId = @DeliveryId)
	if @Currency <=0 
		set @Currency = 1
	/*取出这种运输方式的最大运输区间编号和区间重量*/	 
	/*20071007LDQ对下列做了修改，以适应小的运输方式比如surface,air的重量区间问题*/
	select  @RangeId = max(rangeid)  from t_deliveryfreight  where areaid=@AreaId --获得对应的运输方式在该区域的最大运输区间
	select  @MaxFromWeight = fromweight,@MaxToWeight=Toweight  from t_deliveryweight where rangeid = @rangeid
	 


	/*取出这种运输方式的首重和首重运费*/
	select @FirstWeight  = FirstWeight ,@FirstFreight = firstfreight from t_DeliveryArea where AreaId = @AreaId

	/* 根据重量和区域计算运费*/
	if @weight = 0
		set @freight = 0
	else if @weight <=@FirstWeight 
		set @freight = @FirstFreight  /@Currency
	else if @weight>@MaxFromWeight
			begin
				if @weight<=@maxtoweight
					/*根据区间来进行计算*/
					begin
						select @LadderWeight=LadderWeight , @LadderPrice=LadderPrice,  @PriceType=PriceType
							   from t_deliveryfreight where rangeid=@rangeid and AreaId = @AreaId
						if		@PriceType=1   --平价
							set @Freight = @LadderPrice /@Currency
						else if @PriceType = 2 --续费
							begin					
								set @LadderNumbers = (@weight-@FirstWeight+@LadderWeight-1)/@LadderWeight					
								set @Freight = cast( ((@LadderPrice* @LadderNumbers+ @FirstFreight) /@Currency) as decimal(18,2))
							end 				 
						else if @PriceType = 3 --梯度
							begin
								set @LadderNumbers = (@weight+@LadderWeight-1)/@LadderWeight	
								set @Freight = cast((@LadderNumbers *@LadderPrice /@Currency) as decimal(18,2)) 									
							end	
					end
				else --超过最大重量
					begin
						if @maxtoweight=-1 --没有上限制
							begin
								select @LadderWeight=LadderWeight , @LadderPrice=LadderPrice,  @PriceType=PriceType
									   from t_deliveryfreight where rangeid=@rangeid and AreaId = @AreaId
								if		@PriceType=1   --平价
									set @Freight = @LadderPrice /@Currency
								else if @PriceType = 2 --续费
									begin					
										set @LadderNumbers = (@weight-@FirstWeight+@LadderWeight-1)/@LadderWeight					
										set @Freight = cast(((@LadderPrice* @LadderNumbers +@FirstFreight) /@Currency) as decimal(18,2))
									end 				 
								else if @PriceType = 3 --梯度
									begin
										set @LadderNumbers = (@weight+@LadderWeight-1)/@LadderWeight	
										set @Freight =cast( (@LadderNumbers *@LadderPrice /@Currency)	as decimal(18,2))
									end								
							end	
						else --有上限制，分包处理
							begin
								set @Packages= @weight/@maxtoweight
								set @weight = @weight-@Packages*@maxtoweight
								set @Freight = cast(@Packages*dbo.Fu_IFreightMng_CalculateDeliveryFreight(@DeliveryId,@AreaId,@maxtoweight)  as decimal(18,2))+cast(dbo.Fu_IFreightMng_CalculateDeliveryFreight(@DeliveryId,@AreaId,@weight) as decimal(18,2))
							end
					 end
			end
	else  --存在区间包含输入的重量
			
				
				begin
					select @rangeid =  rangeid  from t_deliveryweight 
							where rangeid in (select rangeid from t_deliveryfreight where areaid=@areaid)
								  and @weight>fromweight and @weight<=toweight						

					select @LadderWeight=LadderWeight , @LadderPrice=LadderPrice,  @PriceType=PriceType
							   from t_deliveryfreight where rangeid=@rangeid and AreaId = @AreaId
						if		@PriceType=1   --平价
							set @Freight = @LadderPrice /@Currency
						else if @PriceType = 2 --续费
							begin					
								set @LadderNumbers = (@weight-@FirstWeight+@LadderWeight-1)/@LadderWeight					
								set @Freight = cast(((@LadderPrice * @LadderNumbers+@FirstFreight) /@Currency) as decimal(18,2))
							end 				 
						else if @PriceType = 3 --梯度
							begin
								set @LadderNumbers = (@weight+@LadderWeight-1)/@LadderWeight	
								set @Freight = cast((@LadderNumbers *@LadderPrice /@Currency) as decimal(18,2))									
							end	
					end
		
					
			  
return @Freight	
END


go


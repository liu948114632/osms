-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE CMS_GetProcessingExpenseItem
	@ProcessingExpenseId INT =NULL
AS
BEGIN
SELECT a.id,a.processing_expense_id AS processingExpenseId,a.processing_code AS processingCode,
a.product_id AS productId,a.actual_processing_quantity AS actualProcessingQuantity,a.actual_amount AS actualAmount,
a.due_amount AS dueAmount,a.remark,c.processing_outward_cost AS processingCost,c.processing_web_cost AS processingWebCost,
d.name AS processingUserName,b.code AS productCode,b.primary_picture_code AS primaryPictureCode,b.cost_price AS costPrice,
b.unit ,CAST(b.unit_quantity AS VARCHAR(50))+' '+b.unit AS productUnit,c.outsource_time AS outsourceTime,
c.processing_cost_price
 as processingCostPrice
  FROM dbo.processing_expense_item  a WITH(NOLOCK)
JOIN product b WITH(NOLOCK) ON a.product_id =b.id
JOIN dbo.processing c  WITH(NOLOCK) ON c.code=a.processing_code
LEFT JOIN dbo.processing_outward_user d  WITH(NOLOCK) ON d.id =c.processing_user_id
WHERE processing_expense_id=@ProcessingExpenseId

END
go


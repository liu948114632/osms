
-- exec[CMS_DepartmentPurchase_ProcessList]  @DepartmentId=9,@Status=10
/**                             
* 2012-02-27 获得办事处-加工单列表                            
* 2012-09-22 增加返回外发加工人的姓名                  
*                 
*                          
*/                            
CREATE PROC [dbo].[CMS_DepartmentPurchase_ProcessList]
    (
      @DepartmentId INT = NULL , --部门ID                            
      @ProcessorId INT = NULL , --加工人ID                            
      @ProcessCode VARCHAR(20) = NULL ,--加工单单号
      @ProcessingCodeList VARCHAR(MAX) = NULL , --多个加工单单号                           
      @Status INT = NULL ,  --加工状态                            
      @ProcessMode INT = NULL , --加工模式                            
      @CreateTimeBegin VARCHAR(20) = NULL , --查询生成时间的开始时间                            
      @CreateTimeEnd VARCHAR(20) = NULL , --查询生成时间的结束时间                  
      @CompleteTimeBegin VARCHAR(20) = NULL , --查询完成时间的开始时间                   
      @CompleteTimeEnd VARCHAR(20) = NULL ,    --查询完成时间的结束时间                     
      @ProductCode VARCHAR(MAX) = NULL ,--商品编号    
      @ProductCodeList VARCHAR(MAX) = NULL ,--多个商品编号  
      @ProductItemCode VARCHAR(MAX) = NULL ,--配件编号                         
      @IsEnough INT = NULL ,   --配件库存是否充足               
      @ConfirmTimeBegin VARCHAR(20) = NULL , --入库时间，开始              
      @ConfirmTimeEnd VARCHAR(20) = NULL , --入库时间，结束              
      @ProcessingUserId INT = NULL , -- 外发加工工人              
      @ProductitemCnName VARCHAR(MAX) = NULL , --加工产品中文名称           
      @IsCreateTask BIT = NULL , --配件是否生成任务           
      @IsUnableProcess BIT = NULL , --无法处理        
      @OutSourceOperatorId INT = NULL , --外发负责人      
      @IsPreparedItemCountEnough INT = NULL ,--是否配件充足  
      @IsApplayStockIn INT = NULL ,--是否申请入库   
      @ReplenishProductCode VARCHAR(100) = NULL ,--补料code  
      @ReplenishStatus INT = NULL ,--申请补料状态  
      @SpliteCode VARCHAR(50) = NULL ,--拆分号  
      @ProcessingCompleteTimeBegin VARCHAR(20) = NULL ,--加工完成时间
      @ProcessingCompleteTimeEnd VARCHAR(20) = NULL , --加工完成时间
      @StockOutOperatorId INT = NULL ,		-- 配件出库人 
      @StockOutTimeBegin VARCHAR(20) = NULL , --出库开始时间
      @StockOutTimeEnd VARCHAR(20) = NULL ,	-- 出库结束时间
      @SubmitTimeBegin VARCHAR(20) = NULL ,	--提交时间
      @SubmitTimeEnd VARCHAR(20) = NULL ,		-- 提交时间
      @ProcessingItemTaskStatus INT = NULL , --配件任务待审核
      @HasSetDifficultyCoefficient INT = NULL , -- 3.9.32 难易系数
      @HasSetpackagingCoefficient INT = NULL ,-- 3.9.32	打包系数
      @HasSetPackageUser INT = NULL ,-- 3.9.32	 是否设置兼职人	
      @HasProcessPiecework INT = NULL , -- 3.9.37 是否添加到加工计件产品列表
      @IsDepartmentTaskCancel INT = NULL , -- 3.9.37 --办事处任务是否取消
      @PackageUserId INT = NULL , -- 兼职
      @hasUnEnableStockTask BIT = NULL , --仓库是否有配件冻结
      @isVip INT = NULL ,
      @submitUserId INT = NULL ,
	  @hasOutwardWeight INT = NULL,
      @pickingUser INT = NULL ,--捡料人
      @packageUserProblem INT = NULL ,--兼职人问题
      @hasSupplus INT = NULL ,--是否有余料
      @PageSize INT = 50 ,  --页大小                            
      @PageIndex INT = 1    --当前页号                            
    )
AS
    BEGIN                                  
        SET NOCOUNT ON;                                  
                                    
        DECLARE @SQL VARCHAR(MAX) ,
            @CountSql NVARCHAR(MAX) , --查询数量用                            
            @FROMSQL NVARCHAR(MAX) , --查询表                          
            @FROMSQL2 NVARCHAR(MAX) , --查询外表                          
            @Column NVARCHAR(MAX) , --查询字段                           
            @Condition VARCHAR(MAX) , --条件                             
            @RowCount INT ,
            @PageCount INT ,
            @start INT ,
            @end INT ,
            @IsQueryProduct BIT ,
            @IsQueryProductItem BIT ,
            @DistinctCode VARCHAR(10) ,
            @storageDepartment INT                      
                                      
    --获得查询条件                  
        SET @DistinctCode = ' DISTINCT '                         
        SET @Condition = ' WHERE 1=1 '                  
        SET @IsQueryProduct = 1   
        SET @IsQueryProductItem = 1--查询配件                        
                                
        IF @DepartmentId IS NOT NULL
            BEGIN    
    --v3.9.5 add 区分佛山和义乌成品部与其他部门的加工单。成品加工单管理界面部门选择请选择时(@DepartmentId = 0)，查2个成品部，其他不变                   
                IF @DepartmentId = 0
                    BEGIN    
                        SET @Condition = @Condition
                            + ' AND a.department_id in (7,9) '   
                        SET @storageDepartment = 41 
                    END 
                ELSE
                    BEGIN    
                        SET @Condition = @Condition + ' AND a.department_id='
                            + CONVERT(VARCHAR(10), @DepartmentId)   
                        IF @DepartmentId = 7
                            OR @DepartmentId = 9
                            BEGIN
                                SET @storageDepartment = 41 
                            END
                        ELSE
                            BEGIN
                                SET @storageDepartment = @DepartmentId
                            END  
                    END 
            END  
        IF @isVip IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.is_vip= '
                    + CONVERT(VARCHAR(10), @isVip)   
            END   
        IF @hasSupplus IS NOT NULL
            BEGIN
                IF @hasSupplus = 1
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND EXISTS ( SELECT  TOP 1 1   
                                    FROM dbo.processing_item AS e2 WITH ( NOLOCK ) where e2.has_surplus = 1 and e2.status<>4  and e2.processing_id =a.id) '
                    END 
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND not  EXISTS ( SELECT  TOP 1 1   
                                    FROM dbo.processing_item AS e2 WITH ( NOLOCK ) where e2.has_surplus = 1 and e2.status<>4  and e2.processing_id =a.id) '
                    END
									 
            END                               
                                       
        IF @ProcessorId IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.processor_id='
                    + CONVERT(VARCHAR(10), @ProcessorId)                            
            END 
        IF @submitUserId IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.submit_user_id='
                    + CONVERT(VARCHAR(10), @submitUserId)     
            END                
        IF @ProcessCode IS NOT NULL
            BEGIN 
                SET @Condition = @Condition + ' AND a.code like ''%'
                    + @ProcessCode + '%'''                          
            END  
        ---------------------------- 3.9.32 ---------------------------------
        IF @ProcessingCodeList IS NOT NULL
            BEGIN 
                SET @Condition = @Condition + ' AND a.code IN ('''
                    + REPLACE(@ProcessingCodeList, ',', ''',''') + ''')'        
            END
         ---------------------------- 3.9.32 ---------------------------------                              
        IF @Status IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.status='
                    + CONVERT(VARCHAR(10), @Status)                            
            END    
        IF @IsPreparedItemCountEnough IS NOT NULL
            BEGIN    
                IF @IsPreparedItemCountEnough = 1
                    BEGIN    
                        SET @Condition = @Condition
                            + '  AND ( NOT EXISTS( SELECT  TOP 1 1   
                                    FROM dbo.processing_item AS e WITH ( NOLOCK )    
                                         LEFT JOIN dbo.department_storage f WITH ( NOLOCK ) ON e.product_id = f.product_id AND f.department_id ='
                            + CONVERT(VARCHAR(20), @storageDepartment)
                            + '    
                                   WHERE e.processing_id = a.id    
                                         AND e.status < 4    
                                         AND e.plan_quantity > e.ready_quantity + ISNULL((f.quantity - f.lock_quantity),0)  
                                    )  
                            )'  
                    END    
                ELSE
                    BEGIN    
                        SET @Condition = @Condition
                            + '  AND ( EXISTS( SELECT TOP 1 1  
                                    FROM dbo.processing_item AS e WITH ( NOLOCK )  
                                         LEFT JOIN dbo.department_storage f WITH ( NOLOCK ) ON e.product_id = f.product_id AND f.department_id = '
                            + CONVERT(VARCHAR(20), @storageDepartment)
                            + '   
                                   WHERE e.processing_id = a.id    
                                         AND e.status < 4    
                                         AND e.plan_quantity > e.ready_quantity + ISNULL((f.quantity - f.lock_quantity),0)  
                                    )  
                            )'  
                    END         
            END                                   
        IF @ProcessMode IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.process_mode='
                    + CONVERT(VARCHAR(10), @ProcessMode)                            
            END                           
        IF @CreateTimeBegin IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.create_time >='''
                    + CONVERT(VARCHAR(20), @CreateTimeBegin) + ''''                            
            END                             
        IF @CreateTimeEnd IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.create_time <='''
                    + CONVERT(VARCHAR(20), @CreateTimeEnd) + ''''                             
            END  
        IF @ProcessingCompleteTimeBegin IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' AND a.processing_complete_time >='''
                    + CONVERT(VARCHAR(20), @ProcessingCompleteTimeBegin)
                    + ''''   
            END 
        IF @ProcessingCompleteTimeEnd IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' AND a.processing_complete_time <='''
                    + CONVERT(VARCHAR(20), @ProcessingCompleteTimeEnd) + ''''   
            END 
        IF @StockOutTimeBegin IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.stock_out_time >='''
                    + CONVERT(VARCHAR(20), @StockOutTimeBegin) + ''''   
            END 
        IF @StockOutTimeEnd IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.stock_out_time <='''
                    + CONVERT(VARCHAR(20), @StockOutTimeEnd) + ''''   
            END 
        IF @SubmitTimeBegin IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.submit_time >='''
                    + CONVERT(VARCHAR(20), @SubmitTimeBegin) + ''''   
            END 
        IF @SubmitTimeEnd IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' AND a.submit_time <='''
                    + CONVERT(VARCHAR(20), @SubmitTimeEnd) + ''''   
            END   
        IF @StockOutOperatorId IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' AND a.stock_out_operator_id ='''
                    + CONVERT(VARCHAR(20), @StockOutOperatorId) + ''''  
            END            
        IF @CompleteTimeBegin IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.completion_time >='''
                    + CONVERT(VARCHAR(20), @CompleteTimeBegin) + ''''                            
            END                             
        IF @CompleteTimeEnd IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.completion_time <='''
                    + CONVERT(VARCHAR(20), @CompleteTimeEnd) + ''''                             
            END              
                  
        IF @ConfirmTimeBegin IS NOT NULL
            BEGIN        
                SET @Condition = @Condition + ' AND a.confirm_time >='''
                    + CONVERT(VARCHAR(20), @ConfirmTimeBegin) + ''''                            
            END                             
        IF @ConfirmTimeEnd IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.confirm_time <='''
                    + CONVERT(VARCHAR(20), @ConfirmTimeEnd) + ''''                             
            END              
        IF @ProcessingUserId IS NOT NULL
            BEGIN                             
                SET @Condition = @Condition + ' AND a.processing_user_id ='''
                    + CONVERT(VARCHAR(20), @ProcessingUserId) + ''''                             
            END        
        IF @OutSourceOperatorId IS NOT NULL
            BEGIN      
                SET @Condition = @Condition
                    + ' AND a.outsource_operator_id ='''
                    + CONVERT(VARCHAR(20), @OutSourceOperatorId) + ''''      
            END                              
        IF @ProductCode IS NOT NULL
            BEGIN                             
                SET @IsQueryProduct = 1                          
                SET @Condition = @Condition + ' AND b.code like '''
                    + @ProductCode + '%'''                            
            END  
        IF @ProductCodeList IS NOT NULL
            BEGIN  
                SET @IsQueryProduct = 1                          
                SET @Condition = @Condition + ' AND b.code in ('''
                    + REPLACE(@ProductCodeList, ',', ''',''') + ''')'     
            END  
        IF @IsApplayStockIn IS NOT NULL
            BEGIN  
                IF @IsApplayStockIn = 1
                    BEGIN  
                        SET @Condition = @Condition
                            + ' and apply_stock_in_status=1'  
                    END  
                ELSE
                    BEGIN  
                        SET @Condition = @Condition
                            + ' and apply_stock_in_status<>1'  
                    END  
            END   
        IF @ReplenishProductCode IS NOT NULL
            BEGIN  
                SET @Condition = @Condition
                    + '  AND ( EXISTS( SELECT TOP 1 1  
                                    FROM dbo.processing_item AS e WITH ( NOLOCK )  
                                    JOIN product pr WITH ( NOLOCK ) on e.product_id =pr.id  
                                   WHERE e.processing_id = a.id    
                                         AND e.replenish_qty > 0 and pr.code like ''%'
                    + @ReplenishProductCode + '%''  
                                    )  
                            )'  
            END        
        IF @ReplenishStatus IS NOT NULL
            BEGIN
            
                IF @ReplenishStatus = 1
                    BEGIN
                        SET @Condition = @Condition + ' and a.status<30'
                        SET @Condition = @Condition
                            + ' AND apply_replenish_status='
                            + CONVERT(VARCHAR(20), @ReplenishStatus)
                    END 
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND apply_replenish_status<=1'
                    END
               -- IF @ReplenishStatus = 1
                  --  BEGIN
                SET @Condition = @Condition
                    + ' and (CASE WHEN ISNULL(( SELECT   MAX(e.id)                      
          FROM  processing_apply_replenish r WITH ( NOLOCK ) join   dbo.processing_apply_replenish_item AS e WITH ( NOLOCK )  on r.id =e.processing_apply_replenish_id                    
          LEFT JOIN dbo.department_storage f WITH(NOLOCK) ON e.product_id = f.product_id  AND f.department_id = '
                    + CONVERT(VARCHAR(20), @storageDepartment)
                    + '  
          LEFT JOIN dbo.product_unit_convert AS u  WITH(NOLOCK) ON e.product_id = u.product_id AND e.unit = u.unit and u.department_id ='
                    + CONVERT(VARCHAR(20), @DepartmentId)
                    + '    
          WHERE    r.processing_id = a.id AND r.status=1  AND    
        (f.id IS NULL OR (a.department_id not in (7,9) and f.quantity < ( e.qty )+ f.lock_quantity) or (a.department_id  in (7,9) and f.quantity < (e.qty/ISNULL(u.convert_rate,1) )
	 + f.lock_quantity) )                       
         ),0) = 0   
    THEN 1 ELSE 0 END  
     )=' + CONVERT(VARCHAR(20), @ReplenishStatus) 
                   -- END	  
            END  
        IF @SpliteCode IS  NOT NULL
            BEGIN  
                SET @Condition = @Condition + ' AND splite_code LIKE ''%'
                    + @SpliteCode + '%'''  
            END                   
        IF @ProductItemCode IS NOT NULL
            BEGIN                          
                SET @IsQueryProductItem = 1                                  
                SET @Condition = @Condition + ' AND d.code = '''
                    + @ProductItemCode + ''''                            
                SET @DistinctCode = ' DISTINCT '         
            END         
                 
        IF @ProductitemCnName IS NOT NULL
            BEGIN                          
                SET @IsQueryProduct = 1                                  
                SET @Condition = @Condition + ' AND b.original_name like ''%'
                    + @ProductitemCnName + '%'''                            
                SET @DistinctCode = ' DISTINCT '                          
            END           
        IF @IsCreateTask IS NOT NULL
            BEGIN        
                IF @IsCreateTask = 1
                    BEGIN        
                        SET @Condition = @Condition + ' AND c.is_task = 1'        
                    END        
                ELSE
                    BEGIN        
                        SET @Condition = @Condition + ' AND c.is_task = 0'        
                    END        
            END        
        IF @IsUnableProcess IS NOT NULL
            BEGIN        
                IF @IsUnableProcess = 1
                    BEGIN        
                        SET @IsQueryProductItem = 1                                                    
                        SET @DistinctCode = ' DISTINCT '         
                        SET @Condition = @Condition + ' AND c.status = 3'        
                    END        
                ELSE
                    BEGIN        
                        SET @Condition = @Condition
                            + ' AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.processing_item AS m WITH(NOLOCK)   
                                       WHERE m.processing_id=a.id AND m.status =3)'         
                    END        
            END        
        IF @ProcessingItemTaskStatus IS NOT NULL
            BEGIN
                IF @ProcessingItemTaskStatus = 0
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.processing_item  WITH(NOLOCK)   
                                       WHERE processing_id=a.id AND task_status =2)'   
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND EXISTS(SELECT TOP 1 1 FROM dbo.processing_item WITH(NOLOCK)   
                                       WHERE processing_id=a.id AND  task_status =2)'   
                    END
            END  
      
     ---------------------------------------3.9.32------------------------------------------   
        IF @HasSetDifficultyCoefficient IS NOT NULL
            BEGIN
                IF @HasSetDifficultyCoefficient = 1
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND a.process_difficulty_coefficient > 0 ';
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND (a.process_difficulty_coefficient IS NULL OR a.process_difficulty_coefficient <=0)';
                    END	
				
            END
        IF @HasSetpackagingCoefficient IS NOT NULL
            BEGIN
                IF @HasSetpackagingCoefficient = 1
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND a.process_packaging_coefficient > 0 ';
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND (a.process_packaging_coefficient IS NULL OR  a.process_packaging_coefficient <=0) ';
                    END				
            END
        IF @HasSetPackageUser IS NOT NULL
            BEGIN
                IF @HasSetPackageUser = 1
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND EXISTS(SELECT TOP 1 id FROM processing_relate_package_user WITH(NOLOCK) 
										WHERE processing_id = a.id) ';
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND NOT EXISTS(SELECT TOP 1 id FROM processing_relate_package_user WITH(NOLOCK) 
										WHERE processing_id = a.id) ';
                    END						
            END
        IF @PackageUserId IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' AND EXISTS ( SELECT TOP 1 id FROM processing_relate_package_user WITH(NOLOCK) 
										WHERE processing_id = a.id and  package_user_id = '''
                    + CAST(@PackageUserId AS VARCHAR(20)) + ''') ';
            END	
        IF @HasProcessPiecework IS NOT NULL
            BEGIN
                IF @HasProcessPiecework = 1
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND EXISTS(SELECT TOP 1 id FROM processing_piecework  WITH(NOLOCK) 
										WHERE source_code = a.code) '
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND NOT EXISTS(SELECT TOP 1 id FROM processing_piecework  WITH(NOLOCK) 
										WHERE source_code = a.code )  '
                    END	
            END
        IF @IsDepartmentTaskCancel IS NOT NULL
            BEGIN
                IF @IsDepartmentTaskCancel = 1
                    BEGIN
								
                        SET @Condition = @Condition
                            + ' AND taskCounts = isCancleds'
                    END
                ELSE
                    BEGIN
                        SET @Condition = @Condition
                            + ' AND (taskCounts != isCancleds  OR taskCounts IS NULL OR isCancleds IS NULL )'
                    END	
		
            END	
     
        IF @IsEnough IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' and a.status<30'
                SET @Condition = @Condition
                    + ' And (CASE WHEN ISNULL(( SELECT   MAX(e.id)  
          FROM     dbo.processing_item AS e WITH ( NOLOCK )                      
          LEFT JOIN dbo.department_storage f WITH(NOLOCK) ON e.product_id = f.product_id  AND f.department_id = '
                    + CONVERT(VARCHAR(20), @storageDepartment)
                    + '  
          LEFT JOIN dbo.product_unit_convert AS u  WITH(NOLOCK) ON e.product_id = u.product_id AND e.unit = u.unit and u.department_id = a.department_id'
                    + '    
          WHERE    e.processing_id = a.id AND e.status < 4  AND                       
        (f.id IS NULL OR (a.department_id not in (7,9) and f.quantity < ( e.plan_quantity - e.ready_quantity )+ f.lock_quantity) or (a.department_id  in (7,9) and f.quantity < (e.ready_quantity/ISNULL(u.convert_rate,1) )
	 + f.lock_quantity) )                       
         ),0) = 0   
    THEN 1 ELSE 0 END  
     )=' + CONVERT(VARCHAR(20), @IsEnough) 
            END

        IF @pickingUser IS NOT NULL
            BEGIN
                SET @Condition = @Condition
                    + ' and  a.print_picking_operator_id='
                    + CONVERT(VARCHAR(20), @pickingUser)
            END

        IF @packageUserProblem IS NOT NULL
            BEGIN
                SET @Condition = @Condition + ' and a.is_problem ='
                    + CONVERT(VARCHAR(20), @packageUserProblem)
            END
      IF @hasOutwardWeight IS NOT NULL 
	  BEGIN
	  IF @hasOutwardWeight = 1
		 BEGIN 
			SET @Condition = @Condition + ' and a.outward_weight >0'
		END
		ELSE
        BEGIN
			SET @Condition = @Condition + ' and isnull(a.outward_weight,0)=0'
        END
	  end
    ---------------------------------------3.9.32------------------------------------------                 
    --设置条件查询必须关联的表                  
        SET @FROMSQL = ' FROM processing a WITH (NOLOCK) 
			LEFT JOIN
			(
				SELECT COUNT(pr1.id) as taskCounts ,pr1.id FROM processing pr1
				JOIN (
						SELECT dpt.is_cancled ,b.processing_id FROM processing_task b 
						LEFT JOIN view_all_department_purchase_task dpt on dpt.id = b.department_task_id
					)  taskTemp on taskTemp.processing_id = pr1.id
			GROUP BY pr1.id 
			) taskCountTemp on taskCountTemp.id = a.id 
			
		LEFT JOIN (
					SELECT SUM(case when is_cancled = 2 then 0 ELSE is_cancled END) isCancleds ,pr2.id as id  FROM processing pr2
					JOIN (
					SELECT dpt.is_cancled ,b.processing_id FROM processing_task b 
					left JOIN view_all_department_purchase_task dpt on dpt.id = b.department_task_id
				)  cancledTemp on cancledTemp.processing_id = pr2.id
	  GROUP by pr2.id ) cancledSum on cancledSum.id = taskCountTemp.id '  
        
                                
        IF @IsQueryProduct = 1
            BEGIN                          
                SET @FROMSQL = @FROMSQL
                    + ' INNER JOIN product b WITH(NOLOCK) ON a.product_id = b.id'                          
            END                          
        IF @IsQueryProductItem = 1
            BEGIN        
                SET @FROMSQL = @FROMSQL
                    + ' INNER JOIN processing_item c WITH(NOLOCK) ON a.id = c.processing_id                            
                                        INNER JOIN product d WITH(NOLOCK) ON c.product_id = d.id '                       
            END 
        IF @DepartmentId = 7
            OR @DepartmentId = 9
            BEGIN
                SET @FROMSQL = @FROMSQL
                    + ' left join processing_apply_stock_in si with(nolock) on si.processing_id = a.id and si.status<=2  left join view_product_all_storage_quantity_info info on info.product_id=a.product_id '
            END
--        SET @FROMSQL = @FROMSQL +' LEFT JOIN processing_relate_package_user prpu WITH(NOLOCK) ON prpu.id = (SELECT top 1 id FROM  processing_relate_package_user where processing_id = a.id) ' 
--		  SET @FROMSQL = @FROMSQL +' LEFT JOIN package_user pu WITH(NOLOCK) ON pu.id = prpu.package_user_id '                         
                           
    --求符合条件的总数                          
        SET @CountSql = ' SELECT @RowCount = count(' + @DistinctCode
            + ' a.id) ' + @FROMSQL + @Condition                     
        EXEC sp_executesql @CountSql, N'@RowCount INT OUT', @RowCount OUT                
                                
--     SELECT @CountSql                                   
        IF ISNULL(@PageSize, 0) < 1
            SET @PageSize = 50                                  
        SET @PageCount = ( @RowCount + @PageSize - 1 ) / @PageSize                                  
        IF ISNULL(@PageIndex, 0) < 1
            SET @PageIndex = 1                                  
        ELSE
            IF ISNULL(@PageIndex, 0) > @PageCount
                SET @PageIndex = @PageCount                                  
        SET @start = ( @PageIndex - 1 ) * @PageSize + 1                                  
        SET @end = @PageIndex * @PageSize                           
                           
    --设置需要取的字段信息                            
        SET @Column = 'a.id,                            
       a.department_id as departmentId,                          
       a.code, 
	   a.picking_department_id as pickingDepartmentId,
	   a.is_vip as isVip,                        
       a.process_mode AS processMode, 
       a.complete_processing_user as completeProcessingUser,                           
       a.status, 
	   a.default_plan_processing_quantity  as defaultPlanProcessingQuantity,                          
       a.plan_processing_quantity AS planProcessingQuantity,                            
       a.actual_processing_quantity AS actualProcessingQuantity,                          
       a.processing_cost AS processingCost,                            
       a.create_time AS createTime,                            
       a.processor_id AS processorId,                 
       a.storage_keeper_id AS storageKeeperId,                            
       a.confirm_time AS confirmTime,                            
       a.completion_time AS completionTime,     
       a.processing_complete_time as processingCompleteTime,                           
       a.is_system_create AS isSystemCreate,                            
       a.remark,
	   a.outward_weight as outwardWeight,
	   a.last_apply_stock_in_time as lastApplyStockInTime,
	   a.last_apply_stock_in_audit_time as lastApplyStockInAuditTime,
	   a.print_picking_operator_id as printPickingOperatorId,             
       a.product_id AS productId,                       
       a.task_type AS taskType,                  
       a.task_sub_type AS taskSubType,                  
       a.outsource_operator_id as outsourceOperatorId,                 
       a.valuation_way as valuationWay,                
       a.outsource_time AS outsourceTime,                  
       a.plan_completion_time AS planCompletionTime,         
       a.processing_outward_cost AS processingOutwardCost,  
       a.processing_user_id,  
       a.is_original_processing as isOriginalProcessing,  
       a.apply_stock_in_status as applyStockInStatus,  
       a.apply_replenish_status as applyReplenishStatus,  
       a.splite_code as spliteCode,  
       a.stock_out_time  as createStockOutTime,  
       a.parent_processing_id as parentProcessingId,
       a.stock_out_operator_id as stockOutOperatorId,
       a.submit_time as submitTime,
	   a.submit_user_id as submitUserId,
       0 as hasUnEnableStockTask,
	   a.is_problem as isProblem,
	   a.start_processing_date as startProcessingDate,
	   a.start_processing_operater as startProcessingOperater,

       	  CASE WHEN EXISTS (SELECT TOP 1 id FROM processing_relate_package_user WITH(NOLOCK) WHERE processing_id = a.id)
	  THEN
		( SELECT ''''+ pu2.package_user_code +'';'' FROM package_user pu2 WITH(NOLOCK)
			 left JOIN processing_relate_package_user  prpu2 WITH(NOLOCK) ON prpu2.package_user_id= pu2.id
			 WHERE prpu2.processing_id =a.id
			 for xml path('''') ) 
	  ELSE
	  ''''
       end as packageUserCode,
       
--	   pu.package_user_code AS packageUserCode,
	   a.coefficient_of_difficulty AS coefficientOfDifficulty,
	   a.coefficient_of_difficulty_remark AS coefficientOfDifficultyRemark,
	 a.process_difficulty_coefficient AS processDifficultyCoefficient,
	   a.process_packaging_coefficient AS processPackagingCoefficient,
	   case when taskCounts is not null and taskCounts = isCancleds then 1 else 0  END AS isDepartmentTaskCancel,
	   CASE WHEN  EXISTS(SELECT TOP 1 pice.id FROM processing_piecework pice WITH(NOLOCK) WHERE pice.source_code = a.code AND pice.status <>4 ) THEN 1 
			ELSE 0 END AS hasProcessPiecework
      '                            
        IF @DepartmentId = 7
            OR @DepartmentId = 9
            BEGIN
                SET @Column = @Column
                    + ',si.qty as applayStockinQty,isnull(info.quantity,0)-isnull(info.lock_quantity,0) as zxckStorageQty '
            END                               
 --组装基本查询的SQL                          
 --IF LEN(@DistinctCode) > 0                          
 --BEGIN                           
        SET @SQL = '  
        SELECT *,  
         b.code AS productCode ,    
         b.primary_picture_code AS primaryPictureCode,     
         b.cost_price AS processingProductCostPrice ,    
         b.color_card_picture_code AS colorCardPictureCode, 
         (CASE WHEN ISNULL((SELECT TOP 1 i.id FROM dbo.processing_item AS i WITH(NOLOCK) WHERE i.status=3 AND i.processing_id=temp2.id ),0)>0 THEN 1 ELSE 0 END ) as isUnableProcess,  
        (SELECT count(item.id) FROM processing_item item  WITH(NOLOCK) where item.processing_id=temp2.id and item.status < 4) AS itemCount,  
        (SELECT count(item.id) FROM processing_item item  WITH(NOLOCK) where item.processing_id=temp2.id and item.status IN (2,3) AND item.plan_quantity= item.ready_quantity )AS preparationItemCount,     
        (SELECT u.[name] FROM processing_outward_user u  WITH ( NOLOCK ) where u.id=temp2.processing_user_id) as processingUserName,                
        (SELECT u.[phone] FROM processing_outward_user u WITH ( NOLOCK ) where u.id=temp2.processing_user_id) as processingUserPhone,  
        ( SELECT    MIN(b.purchase_delivery_time)    
   FROM dbo.view_all_department_purchase_task AS b WITH(NOLOCK)    
   JOIN processing_task AS o WITH(NOLOCK) ON o.department_task_id = b.id  
   WHERE  (o.processing_id = temp2.id or o.processing_id = temp2.parentProcessingId)  
    AND b.purchase_delivery_time IS NOT NULL   
     ) AS purchaseDeliveryTime ,   
     (CASE WHEN ISNULL(( SELECT   MAX(e.id)                      
          FROM     dbo.processing_item AS e WITH ( NOLOCK )                      
          LEFT JOIN dbo.department_storage f WITH(NOLOCK) ON e.product_id = f.product_id  AND f.department_id = '
            + CONVERT(VARCHAR(20), @storageDepartment)
            + '  
          LEFT JOIN dbo.product_unit_convert AS u  WITH(NOLOCK) ON e.product_id = u.product_id AND e.unit = u.unit and u.department_id ='
            + CONVERT(VARCHAR(20), @DepartmentId)
            + '    
          WHERE    e.processing_id = temp2.id AND e.status < 4  AND                       
        (f.id IS NULL OR (temp2.departmentId not in (7,9) and f.quantity < ( e.plan_quantity - e.ready_quantity )+ f.lock_quantity) or (temp2.departmentId  in (7,9) and f.quantity < (e.ready_quantity/ISNULL(u.convert_rate,1) )
 + f.lock_quantity) )                       
         ),0) = 0   
    THEN 1 ELSE 0 END  
     ) AS isEnough ,   
      CASE WHEN   temp2.departmentId <> 7 and temp2.departmentId<>9 and temp2.status=10 then  
     ( SELECT ISNULL(SUM(CASE WHEN ISNULL(v.available_qty,0) >= item.plan_quantity   
                     THEN 1   
                     ELSE 0  
                 END)   
        , 0)    
   FROM  dbo.processing_item item WITH(NOLOCK) '
            + '   
   LEFT JOIN view_product_all_storage_quantity_info AS v  WITH(NOLOCK) ON v.product_id = item.product_id    
   WHERE item.processing_id = temp2.id    
        AND item.status < 4     
   ) else 0 end AS storageItemCount,     
   CASE WHEN   temp2.departmentId = 9   
          AND ( SELECT    SUM(ISNULL(p.cost_price, 0)*ISNULL(item.used_quantity, 0))    
       FROM      processing_item item WITH ( NOLOCK )    
        JOIN dbo.product AS p WITH ( NOLOCK ) ON item.product_id = p.id    
       WHERE     item.processing_id = temp2.id  
        AND item.status < 4    
     ) >  b.cost_price * actualProcessingQuantity  
    THEN 1    
       ELSE 0    
       END isSetYellow    
       FROM                          
       (            
     SELECT *,  
     ROW_NUMBER() OVER(ORDER BY temp.status,temp.createTime DESC) rowIndex                          
     FROM   
     (  
    SELECT ' + @DistinctCode + @Column + @FROMSQL + @Condition
            + ') temp                          
       ) temp2         
       INNER JOIN product b WITH(NOLOCK) ON temp2.productId = b.id                      
       where rowIndex between ' + CAST(@start AS NVARCHAR(10)) + ' and '
            + CAST(@end AS NVARCHAR(10)) + ' ORDER BY rowIndex'  
		--SELECT  @SQL                                                          
        EXEC(@SQL);                 
        SELECT  @RowCount                                
    END

go


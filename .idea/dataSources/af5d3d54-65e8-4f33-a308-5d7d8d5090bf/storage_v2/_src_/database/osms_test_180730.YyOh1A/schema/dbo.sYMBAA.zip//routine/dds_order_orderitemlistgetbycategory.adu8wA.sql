
/*---------------------------------------------------------      
备注:按类别获取订单的商品      
创建人: FRH      
创建日期:2009-12-30      
-----------------------------------------------------------*/      
CREATE PROC [dbo].[DDS_Order_OrderItemListGetByCategory]      
(      
 @OrderId   VARCHAR(MAX),      
 @Box    VARCHAR(255) = ''        
)      
AS      
BEGIN      
 SET NOCOUNT ON;      
 -- 创建表变量,用来缓存各个结算的订单      
 DECLARE @Orders TABLE (OrderId VARCHAR(20));      
 DECLARE @Boxs TABLE (Box INT);      
      
 -- 记录要打印发票的订单号      
 INSERT INTO @Orders(OrderId)      
 SELECT [Value]       
 FROM dbo.uf_Split(@OrderId,',');      
       
 INSERT INTO @Boxs(Box)      
 SELECT [Value]       
 FROM dbo.uf_Split(@Box,',');      
       
 -- 总订单商品价值      
 DECLARE @AllPrice DECIMAL(18,2);      
 SET @AllPrice = 1;      
 SELECT @AllPrice = SUM(b.ReadyQty*1.0*b.ItemPrice/b.UnitQuantity)      
 FROM dbo.T_OrderItem b       
 WHERE (@Box = '' OR b.Box IN(SELECT Box FROM @Boxs)) AND b.OrderId IN(SELECT OrderId FROM @Orders) AND [Status] < 12;      
       
 -- 订单商品按所在类别重新归类      
 WITH cte AS      
 (       
  SELECT      
   CAST(SUM(b.ReadyQty*1.0*b.ItemPrice/b.UnitQuantity) AS DECIMAL(18,2)) AS Price, -- 备货的商品价值      
   CEILING(SUM(b.ReadyQty*1.0/b.UnitQuantity)) AS Quantity, -- 取批量数      
   d.invoice_en_name, d.invoice_cn_name, d.hs_code, b.Box      
  FROM @Orders a       
  INNER JOIN dbo.T_OrderItem b ON a.OrderId = b.OrderId AND b.[Status] < 12      
  INNER JOIN dbo.V_CRM_Base_Product c ON b.CmsProductId = c.CmsProductId      
  INNER JOIN dbo.category d ON d.id = (CASE WHEN ISNULL(c.CategoryId3,0) = 0 THEN (CASE WHEN ISNULL(c.CategoryId2,0) = 0 THEN c.CategoryId1 ELSE c.CategoryId2 END) ELSE c.CategoryId3 END)      
  WHERE @Box = '' OR b.Box IN(SELECT Box FROM @Boxs)      
  GROUP BY d.invoice_en_name, d.invoice_cn_name, d.hs_code, b.Box      
 )      
 ,cteOrderItems AS      
 (      
  SELECT       
   a.invoice_en_name, a.invoice_cn_name, a.hs_code,       
   CEILING(SUM(a.Quantity)) AS Quantity,       
   CAST(SUM(a.Price) AS DECIMAL(18,2)) AS Price,       
   (SELECT DISTINCT(LTRIM(box)) + ',' FROM cte WHERE invoice_en_name = a.invoice_en_name FOR XML PATH('')) AS Box      
  FROM cte a WHERE a.invoice_en_name IS NOT NULL       
  GROUP BY a.invoice_en_name, a.invoice_cn_name, a.hs_code      
  UNION ALL       
  SELECT       
   a.invoice_en_name, a.invoice_cn_name, a.hs_code,       
   CEILING(SUM(a.Quantity)) AS Quantity,       
   CAST(SUM(a.Price) AS DECIMAL(18,2)) AS Price,       
   (SELECT DISTINCT(LTRIM(box)) + ',' FROM cte WHERE invoice_en_name IS NULL FOR XML PATH('')) AS Box      
  FROM cte a WHERE a.invoice_en_name IS NULL       
  GROUP BY a.invoice_en_name, a.invoice_cn_name, a.hs_code      
 )      
       
 SELECT       
  invoice_en_name AS InvoiceEn,      
  invoice_en_name AS ShowInvoiceEn,      
  invoice_cn_name AS CNName,      
  hs_code AS CustomsCode,      
  Quantity,      
  Box,      
  CASE @AllPrice WHEN 0 THEN 0 ELSE  Price * 1.0 /@AllPrice END AS Rate,      
        Price AS ReadyPrice,      
   0 AS Price      
 FROM cteOrderItems      
END

go


----初始化---

/*--------------------------------------
	获取每个客户的Cash有效金额
---------------------------------------*/
CREATE VIEW [dbo].[V_CustomerCashPw]  
AS
SELECT 
	UserId,
	SUM(Income - Payout) AS CashPrice,
	COUNT_BIG(*) AS Counts
FROM dbo.T_CashPw WITH(NOLOCK)
GROUP BY UserId
go


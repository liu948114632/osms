/**
	@desc 计算商品备货量
	@author whw
	@date 2016-05-18
*/
CREATE FUNCTION dz_product_pool_calc_original_product_preprae_qty
    (
      @original_prepare_qty NUMERIC(18,2) ,
      @processing_prepare_qty NUMERIC(18,2) ,
      @unit_quantity INT
    )
RETURNS INT
AS
    BEGIN
	--原膜过去30天销售数（排除取消订单）× 备货倍数 + 
	--[子膜过去30天销售数（排除取消订单） × 备货倍数 × 原模产品批量数量/转换数量）]，
	--再按批量进行往上取整批量数量
        RETURN CONVERT(INT, CEILING(( ISNULL(@original_prepare_qty, 0)
                                   + ISNULL(@processing_prepare_qty, 0))
                                 / @unit_quantity) * @unit_quantity);
    
    END;

go


create  PROC [dbo].[CleanTranLog]    
AS    
    BEGIN    
        DECLARE @num TINYINT --执行次数    
        DECLARE @backLogName VARCHAR(100) ;--备份日志文件名称    
        DECLARE @backLogPath VARCHAR(100) ; --备份日志文件的路径    
        SET @num = 0 ;    
        SET @backLogPath = N'G:\Log' ;--设定备份日志的路径    
        --备份3次镜像日志文件，同时删除    
        WHILE( @num < 3 )    
            BEGIN    
                DECLARE @LogPath VARCHAR(100)    
                SET @backLogName = CAST(@num as VARCHAR(2)) + '.trn' ;    
                SET @LogPath = @backLogPath + '\' + @backLogName    
                BACKUP LOG OSMS  TO DISK = @LogPath WITH NOFORMAT, NOINIT,    
                    NAME= @backLogName, SKIP, REWIND, NOUNLOAD,STATS = 10    
                SET @num = @num + 1    
                --删除刚备份的trn日志文件结束的备份日志文件    
                EXECUTE master.dbo.xp_delete_file 0, @LogPath ;    
            end    
         --收缩日志文件到300M    
        DBCC SHRINKFILE (OSMS_log, 10) ;         
    END
go


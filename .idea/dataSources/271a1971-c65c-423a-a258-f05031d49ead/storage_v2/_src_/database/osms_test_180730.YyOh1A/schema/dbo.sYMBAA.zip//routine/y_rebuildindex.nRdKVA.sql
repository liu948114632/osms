  
  
  
/*================================================================      
--author:  frh      
--Date:   2008-08-08      
--Description: 定期对表的索引进行重建操作  
--注意：要观察索引的情况，对于不经常用的索引可以删除。  
--注意：小表字段可以不用创建索引。    
================================================================*/      
create PROCEDURE [dbo].[Y_RebuildIndex]  
AS        
BEGIN   
 SET NOCOUNT ON;  
     
 DECLARE @t TABLE(id INT PRIMARY KEY IDENTITY(1,1),table_name VARCHAR(200),index_name VARCHAR(500),fragmentation_rate INT);  
 DECLARE @i INT,@n INT,@fragmentation_rate INT;  
 DECLARE @table_name VARCHAR(200),@index_name VARCHAR(500);  
 DECLARE @sql VARCHAR(MAX);  
  
 /*将表的索引碎片情况缓存*/  
 INSERT INTO @t(table_name,index_name,fragmentation_rate)  
 SELECT    
  object_name(a.object_id) AS [table_name]  
  ,[NAME] AS [index_name]  
  ,avg_fragmentation_in_percent AS [fragmentation_rate]  
 FROM sys.dm_db_index_physical_stats   
  (  
   DB_ID()  
   , NULL  
   , NULL, NULL, NULL  
  ) AS a  
 JOIN sys.indexes AS b   
 ON a.object_id = b.object_id AND a.index_id = b.index_id  
-- AND a.OBJECT_ID IN /*指定哪些表的索引重建*/  
-- (  
--  object_id('dbo.Y_SysAccept')  
-- )   
 AND [NAME] > ''   
 AND avg_fragmentation_in_percent > 5 /*排除非常低的碎片级别*/  
 ORDER BY [Type]; /*先创建聚集索引再创建非聚集索引*/  
  
 SET @i = 1;  
 SELECT @n = COUNT(1) FROM @t;  
 WHILE (@i <= @n)  
 BEGIN  
  SET @table_name = '';  
  SET @index_name = '';  
  SET @sql = '';  
  SET @fragmentation_rate = 0;  
  SELECT @table_name = table_name,@index_name = index_name,@fragmentation_rate = fragmentation_rate FROM @t WHERE id = @i;  
    
  IF @table_name > '' AND @index_name > ''  
  BEGIN  
   IF @fragmentation_rate > 30 /* > 30%重新生成索引 除非采用ALTER INDEX REBUILD WITH (ONLINE = ON) 联机方式才不锁表*/   
    SET @sql = 'ALTER INDEX ' +  @index_name + ' ON [' + @table_name + ']  REBUILD;';  
      
   ELSE /* <= 30%重新组织索引，这种情况下不会锁表*/   
    SET @sql = 'ALTER INDEX ' +  @index_name + ' ON [' + @table_name + ']  REORGANIZE;';  
   EXEC (@sql);  
  END   
    
  SET @i = @i + 1;  
 END  
END


go


CREATE VIEW v_current_currency_us
AS 
SELECT *,a.rate / (SELECT rate FROM v_current_currency WHERE currency=1) AS rate_us
 FROM dbo.v_current_currency a
go


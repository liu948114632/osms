CREATE VIEW v_modify_record_order
as
SELECT m.id ,
       m.code ,
       m.create_date ,
       m.creator ,
       m.order_code ,
       m.type ,
       m.bussiness_id ,
       m.status ,
       m.remark,
	   u.name AS merchandiser,
	   u.id AS user_id FROM dbo.modify_record_order m
LEFT JOIN dbo.v_order_all_detail o ON m.order_code=o.code
LEFT JOIN dbo.merchandiser me WITH(NOLOCK) ON me.id=o.merchandiser_id
LEFT JOIN dbo.[user] u WITH(NOLOCK) ON u.code=me.code
go


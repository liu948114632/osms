
CREATE VIEW v_current_change_usd_currency
AS 
(
    SELECT a.currency,c.code,c.name,CONVERT(DECIMAL(18,6),a.rate / b.rate) AS usd_rate
	FROM v_current_currency a
	JOIN v_current_currency b ON b.currency=1
	JOIN dbo.currency c ON a.currency=c.id
)
go


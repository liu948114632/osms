package com.itecheasy.core.system;
/** 
 * @author whw
 * @date 2018-4-18 
 * @description TODO
 * @version 
 */
public class ShopType {
	private int id;
	private int name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getName() {
		return name;
	}
	public void setName(int name) {
		this.name = name;
	}
}

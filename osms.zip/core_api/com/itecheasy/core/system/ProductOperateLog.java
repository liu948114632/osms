package com.itecheasy.core.system;

import java.util.Date;

/**
 * @author wanghw
 * @date 2015-3-26
 * @description 商品操作日志
 * @version
 */
public class ProductOperateLog {
	private int id;
	private int type;
	private String remark;
	private Date time;
	private int operator;
	private Integer objId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public int getOperator() {
		return operator;
	}

	public void setOperator(int operator) {
		this.operator = operator;
	}

	public Integer getObjId() {
		return objId;
	}

	public void setObjId(Integer objId) {
		this.objId = objId;
	}

}

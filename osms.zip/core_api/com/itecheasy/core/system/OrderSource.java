package com.itecheasy.core.system;
/** 
 * @author whw
 * @date 2018-4-18 
 * @description TODO
 * @version 
 */
public class OrderSource {
	private int shopType;
	private int id;
	private String name;
	public int getShopType() {
		return shopType;
	}
	public void setShopType(int shopType) {
		this.shopType = shopType;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}

package com.itecheasy.core.system;

import java.util.List;

/**
 * @author wanghw
 * @date 2015-3-28
 * @description TODO
 * @version
 */
public class Property {
	private String cnName;
	private String description;
	private int id;
	private String name;
	private List<PropertyValue> propertyValues;

	public String getCnName() {
		return cnName;
	}

	public void setCnName(String cnName) {
		this.cnName = cnName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<PropertyValue> getPropertyValues() {
		return propertyValues;
	}

	public void setPropertyValues(List<PropertyValue> propertyValues) {
		this.propertyValues = propertyValues;
	}

}

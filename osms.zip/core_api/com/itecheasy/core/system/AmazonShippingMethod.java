package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2015-7-16
 * @description TODO
 * @version
 */
public class AmazonShippingMethod {
	private String shippingMethod;
	private String carrierCode;
	private String carrierName;

	public String getShippingMethod() {
		return shippingMethod;
	}

	public void setShippingMethod(String shippingMethod) {
		this.shippingMethod = shippingMethod;
	}

	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public String getCarrierName() {
		return carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

}

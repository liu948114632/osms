package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2015-3-28
 * @description TODO
 * @version
 */
public class ShopInfo {
	private int id;
	private String currency;
	private int language;
	private String productType;
	private String browseNode;
	private int shopId;
	private String webserviceUrl;
	private Integer country;
	private Integer customerId;
	private Integer shopSource;
	private String merchandiserId;
	private Integer timeDiff;
	private String ebaySellerId;
	private String fbaBarcodeKey;
	
	/**
	 * 是否填充省
	 * 省为空时自动将城市填充到省中
	 */
	private boolean fillState;

	public String getFbaBarcodeKey() {
		return fbaBarcodeKey;
	}

	public void setFbaBarcodeKey(String fbaBarcodeKey) {
		this.fbaBarcodeKey = fbaBarcodeKey;
	}

	public String getEbaySellerId() {
		return ebaySellerId;
	}

	public void setEbaySellerId(String ebaySellerId) {
		this.ebaySellerId = ebaySellerId;
	}

	public Integer getTimeDiff() {
		return timeDiff;
	}

	public void setTimeDiff(Integer timeDiff) {
		this.timeDiff = timeDiff;
	}

	/**
	 * 是否走采购流程
	 */
	private boolean isPurchase;

	public boolean getIsPurchase() {
		return isPurchase;
	}

	public void setPurchase(boolean isPurchase) {
		this.isPurchase = isPurchase;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getShopSource() {
		return shopSource;
	}

	public void setShopSource(Integer shopSource) {
		this.shopSource = shopSource;
	}

	public Integer getCountry() {
		return country;
	}

	public void setCountry(Integer country) {
		this.country = country;
	}

	public String getWebserviceUrl() {
		return webserviceUrl;
	}

	public void setWebserviceUrl(String webserviceUrl) {
		this.webserviceUrl = webserviceUrl;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public int getLanguage() {
		return language;
	}

	public void setLanguage(int language) {
		this.language = language;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getBrowseNode() {
		return browseNode;
	}

	public void setBrowseNode(String browseNode) {
		this.browseNode = browseNode;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getMerchandiserId() {
		return merchandiserId;
	}

	public void setMerchandiserId(String merchandiserId) {
		this.merchandiserId = merchandiserId;
	}

	public boolean isFillState() {
		return fillState;
	}

	public void setFillState(boolean fillState) {
		this.fillState = fillState;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	
}

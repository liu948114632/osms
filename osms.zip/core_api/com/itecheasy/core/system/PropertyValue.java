package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2015-3-28
 * @description TODO
 * @version
 */
public class PropertyValue {
	private String cnName;
	private int id;
	private String name;
	private int propertyID;

	public String getCnName() {
		return cnName;
	}

	public void setCnName(String cnName) {
		this.cnName = cnName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPropertyID() {
		return propertyID;
	}

	public void setPropertyID(int propertyID) {
		this.propertyID = propertyID;
	}

}

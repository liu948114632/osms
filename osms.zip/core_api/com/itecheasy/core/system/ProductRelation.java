package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2015-3-27
 * @description TODO
 * @version
 */
public class ProductRelation {
	private int id;
	private Integer mainProductId;
	private int productId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getMainProductId() {
		return mainProductId;
	}

	public void setMainProductId(Integer mainProductId) {
		this.mainProductId = mainProductId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

}

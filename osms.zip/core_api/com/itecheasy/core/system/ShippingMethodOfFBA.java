package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2016-1-13
 * @description TODO
 * @version
 */
public class ShippingMethodOfFBA {
	private int id;
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2015-6-16
 * @description TODO
 * @version
 */
public class ShopRelation {
	private int id;
	private int shop1;
	private int shop2;
	private int type;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getShop1() {
		return shop1;
	}

	public void setShop1(int shop1) {
		this.shop1 = shop1;
	}

	public int getShop2() {
		return shop2;
	}

	public void setShop2(int shop2) {
		this.shop2 = shop2;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}

package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2016-1-25
 * @description 特殊字符转换
 * @version
 */
public class SpecialPhonetic {
	private String key;
	private String value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}

package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2015-6-4
 * @description 跟单员
 * @version
 */
public class Merchandiser {
	private int id;
	private String merchandiserName;
	private String merchandiserEmail;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMerchandiserName() {
		return merchandiserName;
	}

	public void setMerchandiserName(String merchandiserName) {
		this.merchandiserName = merchandiserName;
	}

	public String getMerchandiserEmail() {
		return merchandiserEmail;
	}

	public void setMerchandiserEmail(String merchandiserEmail) {
		this.merchandiserEmail = merchandiserEmail;
	}

}

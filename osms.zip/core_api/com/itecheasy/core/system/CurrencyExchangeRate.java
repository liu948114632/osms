package com.itecheasy.core.system;

import java.math.BigDecimal;

/**
 * @author wanghw
 * @date 2016-1-11
 * @description TODO
 * @version
 */
public class CurrencyExchangeRate {
	private int id;
	private String version;
	private int currency;
	private BigDecimal rate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public int getCurrency() {
		return currency;
	}

	public void setCurrency(int currency) {
		this.currency = currency;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

}

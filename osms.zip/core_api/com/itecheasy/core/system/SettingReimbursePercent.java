package com.itecheasy.core.system;

import java.math.BigDecimal;

/**
 * @author wanghw
 * @date 2016-5-26
 * @description TODO
 * @version 3.9.27
 */
public class SettingReimbursePercent {
	private BigDecimal threshold;
	private BigDecimal outOfThresholdToCalcForPercent;
	private int shippingMethod;

	public BigDecimal getThreshold() {
		return threshold;
	}

	public void setThreshold(BigDecimal threshold) {
		this.threshold = threshold;
	}

	public BigDecimal getOutOfThresholdToCalcForPercent() {
		return outOfThresholdToCalcForPercent;
	}

	public void setOutOfThresholdToCalcForPercent(BigDecimal outOfThresholdToCalcForPercent) {
		this.outOfThresholdToCalcForPercent = outOfThresholdToCalcForPercent;
	}

	public int getShippingMethod() {
		return shippingMethod;
	}

	public void setShippingMethod(int shippingMethod) {
		this.shippingMethod = shippingMethod;
	}

}

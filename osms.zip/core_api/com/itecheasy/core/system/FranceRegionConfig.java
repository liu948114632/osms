package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2016-1-18
 * @description 法国邮编转省
 * @version
 */
public class FranceRegionConfig {
	private String postal_code_key;
	private String region_value;

	public String getPostal_code_key() {
		return postal_code_key;
	}

	public void setPostal_code_key(String postal_code_key) {
		this.postal_code_key = postal_code_key;
	}

	public String getRegion_value() {
		return region_value;
	}

	public void setRegion_value(String region_value) {
		this.region_value = region_value;
	}

}

package com.itecheasy.core.system;

/**
 * @author wanghw
 * @date 2015-6-16
 * @description TODO
 * @version
 */
public class UserShop {
	private int id;
	private int shopId;
	private int userId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}

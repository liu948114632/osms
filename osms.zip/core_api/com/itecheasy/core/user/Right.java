package com.itecheasy.core.user;

import java.io.Serializable;

public class Right implements Serializable{
	private static final long serialVersionUID = -4234608482170150051L;
	private int id;
	private int rightGroupID;
	private String name;
	private String description;
	private String code;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRightGroupID() {
		return rightGroupID;
	}
	public void setRightGroupID(int rightGroupID) {
		this.rightGroupID = rightGroupID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}

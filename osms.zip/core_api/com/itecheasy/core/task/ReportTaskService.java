package com.itecheasy.core.task;
/** 
 * @author wanghw
 * @date 2016-3-15 
 * @description 报表自动统计
 * @version 1.1.7
 */
public interface ReportTaskService {
	void autoCountFBASales();
	
	void autoStatisticOrder();

	void autoSetSumInventorySercurityLine();
	
}

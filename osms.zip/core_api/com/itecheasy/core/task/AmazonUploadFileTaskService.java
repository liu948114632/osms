package com.itecheasy.core.task;
/** 
 * @author wanghw
 * @date 2015-6-25 
 * @description TODO
 * @version
 */
public interface AmazonUploadFileTaskService {
	public void autoUploadProductFileTask();
	
	/**
	 * 订单发货自动对接 网站
	 */
	public void autoOrderDeliveryTask();
}

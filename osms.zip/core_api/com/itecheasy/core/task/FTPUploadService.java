package com.itecheasy.core.task;
/** 
 * @author wanghw
 * @date 2015-5-25 
 * @description TODO
 * @version
 */
public interface FTPUploadService {
	public void doWork();
}

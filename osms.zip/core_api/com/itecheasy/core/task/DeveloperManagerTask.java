package com.itecheasy.core.task;
/** 
 * @author whw
 * @date 2017-5-19 
 * @description TODO
 * @version 
 */
public interface DeveloperManagerTask {
	/**
	 * smt 重新授权
	 */
	void postponeToken();
}

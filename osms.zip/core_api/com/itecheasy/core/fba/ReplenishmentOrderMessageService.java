package com.itecheasy.core.fba;

import com.itecheasy.core.order.IBaseOrderMessage;

/** 
 * @author wanghw
 * @date 2017-1-11 
 * @description TODO
 * @version 1.2.2
 */
public interface ReplenishmentOrderMessageService extends IBaseOrderMessage{

}

package com.itecheasy.core.fba;

import com.itecheasy.core.task.BaseOrderView;
import com.itecheasy.webservice.sw.Notification;


/** 
 * @author whw
 * @date 2017-8-3 
 * @description TODO
 * @version 
 */
public interface ROrderSwMessageService extends ReplenishmentOrderService{
	void processSW(Notification notification, BaseOrderView order);
}

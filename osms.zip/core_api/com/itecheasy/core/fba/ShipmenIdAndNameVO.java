package com.itecheasy.core.fba;

/**
 * @author taozihao
 * @date 2018年6月8日 下午1:24:12
 * @description
 */
public class ShipmenIdAndNameVO {
	
	private String shipmentId;
	private String shipmentName;

	public String getShipmentId() {
		return shipmentId;
	}

	public void setShipmentId(String shipmentId) {
		this.shipmentId = shipmentId;
	}

	public String getShipmentName() {
		return shipmentName;
	}

	public void setShipmentName(String shipmentName) {
		this.shipmentName = shipmentName;
	}

}

package com.itecheasy.core.fba;

/**
 * @author whw
 * @date 2017-3-25
 * @description TODO
 * @version 
 */
public class UpdateOrdertProductInfo {
	private int orderPrepareProductId;
	private String customerRemark;
	private String csRemark;

	public int getOrderPrepareProductId() {
		return orderPrepareProductId;
	}

	public void setOrderPrepareProductId(int orderPrepareProductId) {
		this.orderPrepareProductId = orderPrepareProductId;
	}

	public String getCustomerRemark() {
		return customerRemark;
	}

	public void setCustomerRemark(String customerRemark) {
		this.customerRemark = customerRemark;
	}

	public String getCsRemark() {
		return csRemark;
	}

	public void setCsRemark(String csRemark) {
		this.csRemark = csRemark;
	}

}

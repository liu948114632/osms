package com.itecheasy.core.fba;

import java.util.Date;

/**
 * @author taozihao
 * @date 2018年6月13日 下午6:25:15
 * @description fba补货计划操作日志
 */
public class FbaInboundPlanOperateLog {
	private Date date;
	private String operator;
	private String comment;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

}

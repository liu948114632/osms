package com.itecheasy.core.fba;

import java.util.List;

/**
 * @author whw
 * @date 2018-2-22
 * @description TODO
 * @version
 */
public class ReplenishmentTaskProductSearch {
	private int currentPage;
	private int pageSize;
	private String orderCode;
	private List<String> productCodes;
	private String productCode;
	private String code;
	private int type;
	private int waitMoreBatchAudit;
	private int partProductWaitMoreBatchAudit;

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public List<String> getProductCodes() {
		return productCodes;
	}

	public void setProductCodes(List<String> productCodes) {
		this.productCodes = productCodes;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public int getWaitMoreBatchAudit() {
		return waitMoreBatchAudit;
	}

	public void setWaitMoreBatchAudit(int waitMoreBatchAudit) {
		this.waitMoreBatchAudit = waitMoreBatchAudit;
	}

	public int getPartProductWaitMoreBatchAudit() {
		return partProductWaitMoreBatchAudit;
	}

	public void setPartProductWaitMoreBatchAudit(int partProductWaitMoreBatchAudit) {
		this.partProductWaitMoreBatchAudit = partProductWaitMoreBatchAudit;
	}
}

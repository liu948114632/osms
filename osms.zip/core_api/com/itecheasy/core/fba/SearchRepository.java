package com.itecheasy.core.fba;

/**
 * @author wanghw
 * @date 2016-11-29
 * @description TODO
 * @version 1.2.2
 */
public class SearchRepository {
	private int pageSize;
	private int currentPage;

	private int deparementId;
	private int shopId;

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getDeparementId() {
		return deparementId;
	}

	public void setDeparementId(int deparementId) {
		this.deparementId = deparementId;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

}

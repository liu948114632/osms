package com.itecheasy.core.fba;

import java.util.Date;

import com.itecheasy.common.attachment.Attachment;

/**
 * @author wanghw
 * @date 2016-11-30
 * @description fba补货单发货清单
 * @version 1.2.2
 */
public class ReplenishmentOrderShippingList extends Attachment {
	private int id;
	private int replenishmentOrderId;
	private String fileName;
	private String fileCode;
	private Date joinDate;
	private byte[] file;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getReplenishmentOrderId() {
		return replenishmentOrderId;
	}

	public void setReplenishmentOrderId(int replenishmentOrderId) {
		this.replenishmentOrderId = replenishmentOrderId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileCode() {
		return fileCode;
	}

	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public byte[] getFile() {
		return file;
	}

	public void setFile(byte[] file) {
		this.file = file;
	}

}

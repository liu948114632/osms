package com.itecheasy.core.order;
/** 
 * @author whw
 * @date 2017-8-25 
 * @description TODO
 * @version 
 */
public interface OrderTrackingMessageService {
	void processingOrderTracking();

}

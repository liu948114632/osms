package com.itecheasy.core.order;

import java.util.Date;

/**
 * @author wanghw
 * @date 2017-08-22
 * @description TODO
 * @version
 */
public class OrderTrackingItem {
	private int id;
	private int orderTrackingId;
	private String content;
	private Date replyDate;
	private int replyUserId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getOrderTrackingId() {
		return orderTrackingId;
	}
	public void setOrderTrackingId(int orderTrackingId) {
		this.orderTrackingId = orderTrackingId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getReplyDate() {
		return replyDate;
	}
	public void setReplyDate(Date replyDate) {
		this.replyDate = replyDate;
	}
	public int getReplyUserId() {
		return replyUserId;
	}
	public void setReplyUserId(int replyUserId) {
		this.replyUserId = replyUserId;
	}
	
	
}

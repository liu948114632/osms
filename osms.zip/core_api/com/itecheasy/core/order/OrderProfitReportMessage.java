package com.itecheasy.core.order;

/**
 * @author wanghw
 * @date 2016-1-14
 * @description 非FBA商品月度毛利统计消息
 * @version
 */
public class OrderProfitReportMessage {
	private String shopName;
	private int shopId;
	private String shopOrderCode;

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getShopOrderCode() {
		return shopOrderCode;
	}

	public void setShopOrderCode(String shopOrderCode) {
		this.shopOrderCode = shopOrderCode;
	}

}

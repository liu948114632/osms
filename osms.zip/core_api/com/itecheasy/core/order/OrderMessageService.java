package com.itecheasy.core.order;
/** 
 * @author wanghw
 * @date 2017-1-11 
 * @description TODO
 * @version 1.2.2
 */
public interface OrderMessageService extends IBaseOrderMessage{

}

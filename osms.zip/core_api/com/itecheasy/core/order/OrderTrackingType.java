package com.itecheasy.core.order;
/** 
 * @author wanghw
 * @date 2015-12-16 
 * @description 订单跟踪类别
 * @version
 */
public enum OrderTrackingType {
	订单发货确认(1), 订单产品替代(2), 单前备货确认(3), 色差(4), 规格偏差(5), 数量差异(6), 瑕疵(7), 其他(8);
	private int val;

	public int getVal() {
		return val;
	}

	private OrderTrackingType(int val) {
		this.val = val;
	}
}

package com.itecheasy.core.order;

/**
 * @author wanghw
 * @date 2015-5-6
 * @description TODO
 * @version
 */
public class OrderAddress {
	private int id;
	/**
	 * 收件人
	 * 
	 */
	private String name;
	/**
	 * 地址1
	 * 
	 */
	private String addressLine1;
	/**
	 * 县
	 * 
	 */
	private String county;
	/**
	 * 国家简码
	 * 
	 */
	private String countryCode;
	/**
	 * 省、州或者区域
	 * 
	 */
	private String stateOrRegion;
	/**
	 * 城市
	 * 
	 */
	private String city;
	/**
	 * 街道
	 * 
	 */
	private String district;
	/**
	 * 邮编
	 * 
	 */
	private String postalCode;
	/**
	 * 电话
	 * 
	 */
	private String phone;
	/**
	 * 发货说明
	 * 
	 */
	private String remark;
	/**
	 * 地址2
	 * 
	 */
	private String addressLine2;

	private int orderId;

	private int countryId;

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getStateOrRegion() {
		return stateOrRegion;
	}

	public void setStateOrRegion(String stateOrRegion) {
		this.stateOrRegion = stateOrRegion;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	

	
}

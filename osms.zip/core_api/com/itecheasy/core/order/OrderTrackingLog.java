package com.itecheasy.core.order;

import java.util.Date;

/** 
 * @author whw
 * @date 2017-8-22 
 * @description TODO
 * @version 
 */
public class OrderTrackingLog {
	private int id;
	private int orderTrackingId;
	private String remark;
	private int operator;
	private Date operateDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getOrderTrackingId() {
		return orderTrackingId;
	}
	public void setOrderTrackingId(int orderTrackingId) {
		this.orderTrackingId = orderTrackingId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public int getOperator() {
		return operator;
	}
	public void setOperator(int operator) {
		this.operator = operator;
	}
	public Date getOperateDate() {
		return operateDate;
	}
	public void setOperateDate(Date operateDate) {
		this.operateDate = operateDate;
	}
	
	
}

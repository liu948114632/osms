package com.itecheasy.core.order;

import java.math.BigDecimal;

/**
 * @author wanghw
 * @date 2016-3-4
 * @description 头程运费
 * @version 1.1.7
 */
public class FirstWayFreightSetting {
	private String version;
	private int country;
	private BigDecimal freightOfUnit;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public int getCountry() {
		return country;
	}

	public void setCountry(int country) {
		this.country = country;
	}

	public BigDecimal getFreightOfUnit() {
		return freightOfUnit;
	}

	public void setFreightOfUnit(BigDecimal freightOfUnit) {
		this.freightOfUnit = freightOfUnit;
	}

}

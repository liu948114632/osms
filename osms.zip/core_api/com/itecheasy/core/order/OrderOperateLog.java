package com.itecheasy.core.order;

import java.util.Date;

/**
 * @author wanghw
 * @date 2015-5-6
 * @description 操作日志
 * @version
 */
public class OrderOperateLog {
	private String comment;

	private int objectId;

	private Date operateDate;

	private String operator;

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getObjectId() {
		return objectId;
	}

	public void setObjectId(int objectId) {
		this.objectId = objectId;
	}

	public Date getOperateDate() {
		return operateDate;
	}

	public void setOperateDate(Date operateDate) {
		this.operateDate = operateDate;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

}

package com.itecheasy.core.order;
/** 
 * @author wanghw
 * @date 2015-12-16 
 * @description 订单跟踪状态
 * @version
 */
public enum OrderTrackingStatus {
	未答复(10), 已答复(20), 完成(30);
	private int val;

	public int getVal() {
		return val;
	}

	private OrderTrackingStatus(int val) {
		this.val = val;
	}
}

package com.itecheasy.core.order;
/** 
 * @author wanghw
 * @date 2016-2-25 
 * @description 报表类型 <ul>proc_order_count_report</ul>
 * @version 1.1.7
 */
public enum ReportType {
	月度业绩统计(1),
	月度退款统计(2),
	FBA商品实际收款统计(3),
	非FBA订单总金额统计(4),
	FBA订单总金额统计(5),
	所有订单总金额统计(6),
	非FBA实际收款统计(7),
	FBA头程运费统计(8),
	FBA库存商品销量统计(9);
	
	private int val;
	public int getVal() {
		return val;
	}

	private ReportType(int val){
		this.val=val;
	}
}

package com.itecheasy.core.order;

import java.util.Date;
import java.util.List;

/**
 * @author wanghw
 * @date 2016-2-18
 * @description 问题件答复历史
 * @version 1.1.7
 */
public class PackageProblemHistory {
	private int id;
	private String content;
	private String replyUser;
	private Date replyDate;
	private int packageProblemId;
	

	private List<PackageProblemAttachment> attachments;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getReplyUser() {
		return replyUser;
	}

	public void setReplyUser(String replyUser) {
		this.replyUser = replyUser;
	}

	public Date getReplyDate() {
		return replyDate;
	}

	public void setReplyDate(Date replyDate) {
		this.replyDate = replyDate;
	}

	public int getPackageProblemId() {
		return packageProblemId;
	}

	public void setPackageProblemId(int packageProblemId) {
		this.packageProblemId = packageProblemId;
	}

	public List<PackageProblemAttachment> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<PackageProblemAttachment> attachments) {
		this.attachments = attachments;
	}

}

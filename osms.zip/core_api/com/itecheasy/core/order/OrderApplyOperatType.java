package com.itecheasy.core.order;
/** 
 * @author wanghw
 * @date 2016-2-19 
 * @description 订单申请操作类型
 * @version 1.1.7
 */
public enum OrderApplyOperatType {
	CANCEL(1),
	RESEND(2),
	CONFIRM_PROCESS(3),
	ORDER_MISS(5),
	COULD_NOT_RETRIEVE(6),
	UNDO_APPLY(7),
	BACK(8)
	;
	private int val;
	
	public int getVal() {
		return val;
	}

	private OrderApplyOperatType(int val){
		this.val=val;
	}
	
}

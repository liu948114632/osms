package com.itecheasy.core.order;
/** 
 * @author wanghw
 * @date 2016-12-1 
 * @description TODO
 * @version 1.2.2
 */
public interface IOrderProxy {
	IBaseOrder getProxy(String orderCode);
	
	IBaseOrderMessage getMessageProxy(String orderCode);
}

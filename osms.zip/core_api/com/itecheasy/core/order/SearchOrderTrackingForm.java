package com.itecheasy.core.order;

import java.util.Date;
import java.util.List;

import com.itecheasy.core.BaseSearchForm;

/**
 * @author wanghw
 * @date 2015-12-10
 * @description TODO
 * @version
 */
public class SearchOrderTrackingForm extends BaseSearchForm{
	private String orderCode;
	private List<String> orderCodes;
	private Date consultationDateBegin;
	private Date consultationDateEnd;
	private int type;
	private int status;
	private String code;
	private Date replyDateBegin;
	private Date replyDateEnd;
	private int consultationUserId;

	//cmsProductId
	private String cmsProductCode;



	public String getCmsProductCode() {
		return cmsProductCode;
	}

	public void setCmsProductCode(String cmsProductCode) {
		this.cmsProductCode = cmsProductCode;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public List<String> getOrderCodes() {
		return orderCodes;
	}

	public void setOrderCodes(List<String> orderCodes) {
		this.orderCodes = orderCodes;
	}

	public Date getConsultationDateBegin() {
		return consultationDateBegin;
	}

	public void setConsultationDateBegin(Date consultationDateBegin) {
		this.consultationDateBegin = consultationDateBegin;
	}

	public Date getConsultationDateEnd() {
		return consultationDateEnd;
	}

	public void setConsultationDateEnd(Date consultationDateEnd) {
		this.consultationDateEnd = consultationDateEnd;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Date getReplyDateBegin() {
		return replyDateBegin;
	}

	public void setReplyDateBegin(Date replyDateBegin) {
		this.replyDateBegin = replyDateBegin;
	}

	public Date getReplyDateEnd() {
		return replyDateEnd;
	}

	public void setReplyDateEnd(Date replyDateEnd) {
		this.replyDateEnd = replyDateEnd;
	}

	public int getConsultationUserId() {
		return consultationUserId;
	}

	public void setConsultationUserId(int consultationUserId) {
		this.consultationUserId = consultationUserId;
	}

}

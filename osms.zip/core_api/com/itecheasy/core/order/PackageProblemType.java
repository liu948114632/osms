package com.itecheasy.core.order;
/** 
 * @author wanghw
 * @date 2016-6-24 
 * @description TODO
 * @version 3.9.27
 */
public enum PackageProblemType {
	问题件(0),未妥投件(1),退件(2)
	;
	private int val;

	public int getVal() {
		return val;
	}
	
	private PackageProblemType(int val) {
		this.val=val;
	}
}



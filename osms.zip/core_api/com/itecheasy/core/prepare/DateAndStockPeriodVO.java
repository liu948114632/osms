package com.itecheasy.core.prepare;

import java.util.Date;

/**
 * @author taozihao
 * @date 2018年6月30日 下午2:24:36
 * @description 日期以及对应的库存周期
 */
public class DateAndStockPeriodVO {
	private Date date;
	private double stockPeriod;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public double getStockPeriod() {
		return stockPeriod;
	}

	public void setStockPeriod(double stockPeriod) {
		this.stockPeriod = stockPeriod;
	}

}

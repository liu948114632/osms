package com.itecheasy.core.prepare;

import java.util.Date;

/**
 * @author taozihao
 * @date 2018年7月13日 下午3:28:58
 * @description 将日期和对应的海运在途<br>
 *             Map<String, List<DateAndOnPassageVO>>
 */
public class DateAndOnPassageVO {

	private Date date;
	private Integer quantity;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}

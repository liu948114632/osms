package com.itecheasy.core;
/** 
 * @author wanghw
 * @date 2016-1-13 
 * @description 数据库币种
 * @version
 */
public class CurrencyUtils {
	public final static int USD=1;
	public final static int EUR=2;
	public final static int CAD=3;
	public final static int JPY=4;
	public final static int MXN=5;
	public final static int GBP=6;
	public final static int RMB=7;
}

package com.itecheasy.core.product;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author wanghw
 * @date 2015-3-25
 * @description TODO
 * @version
 */
public class AMShopProduct {

	private int id;
	private Integer productId;
	private String cmsProductCode;
	private int shopId;
	private String Sku;
	private String upc;
	private String productType;
	private String browseNode;
	private BigDecimal price;
	private Boolean contentStatus;
	private int uploadStatus;
	private Boolean shelveStatus;
	private String productName;
	private String productContent;
	private Date time;
	private int operator;
	private String brandName;
	private int groupId;

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getCmsProductCode() {
		return cmsProductCode;
	}

	public void setCmsProductCode(String cmsProductCode) {
		this.cmsProductCode = cmsProductCode;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getSku() {
		return Sku;
	}

	public void setSku(String sku) {
		Sku = sku;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getBrowseNode() {
		return browseNode;
	}

	public void setBrowseNode(String browseNode) {
		this.browseNode = browseNode;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Boolean getContentStatus() {
		return contentStatus;
	}

	public void setContentStatus(Boolean contentStatus) {
		this.contentStatus = contentStatus;
	}

	public int getUploadStatus() {
		return uploadStatus;
	}

	public void setUploadStatus(int uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public Boolean getShelveStatus() {
		return shelveStatus;
	}

	public void setShelveStatus(Boolean shelveStatus) {
		this.shelveStatus = shelveStatus;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductContent() {
		return productContent;
	}

	public void setProductContent(String productContent) {
		this.productContent = productContent;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public int getOperator() {
		return operator;
	}

	public void setOperator(int operator) {
		this.operator = operator;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

}

package com.itecheasy.core.product;
/** 
 * @author wanghw
 * @date 2015-3-25 
 * @description 网店销售商品日志
 * @version
 */
public interface ProductLogService {
	
}

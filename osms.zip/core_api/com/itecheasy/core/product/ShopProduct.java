package com.itecheasy.core.product;
/** 
 * @author wanghw
 * @date 2015-3-25 
 * @description TODO
 * @version
 */
public class ShopProduct {

}

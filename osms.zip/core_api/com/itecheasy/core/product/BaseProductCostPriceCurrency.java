package com.itecheasy.core.product;

/**
 * @author wanghw
 * @date 2016-1-11
 * @description TODO
 * @version
 */
public class BaseProductCostPriceCurrency {
	private int id;
	private int currency;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCurrency() {
		return currency;
	}

	public void setCurrency(int currency) {
		this.currency = currency;
	}

}

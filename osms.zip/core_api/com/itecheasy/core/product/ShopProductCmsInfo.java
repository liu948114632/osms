package com.itecheasy.core.product;

import java.math.BigDecimal;

/**
 * @author wanghw
 * @date 2016-12-2
 * @description TODO
 * @version 1.2.2
 */
public class ShopProductCmsInfo {
	private int cmsProductId;
	private String cmsProductCode;
	private String productName;
	private int unitQuantity;

	private String primaryPictureCode;
	private String unit;

	private double availableStock;
	private BigDecimal costPrice;
	private String colorCardPictureCode;
	private Double unitWeight;
	private Double unitVolume;

	private int cmsAwaitReplenishment;
	private int cmsTheReplenishment;
	private boolean ts;
	
	private int sales;
	
	public int getCmsProductId() {
		return cmsProductId;
	}

	public void setCmsProductId(int cmsProductId) {
		this.cmsProductId = cmsProductId;
	}

	public String getCmsProductCode() {
		return cmsProductCode;
	}

	public void setCmsProductCode(String cmsProductCode) {
		this.cmsProductCode = cmsProductCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getUnitQuantity() {
		return unitQuantity;
	}

	public void setUnitQuantity(int unitQuantity) {
		this.unitQuantity = unitQuantity;
	}

	public String getPrimaryPictureCode() {
		return primaryPictureCode;
	}

	public void setPrimaryPictureCode(String primaryPictureCode) {
		this.primaryPictureCode = primaryPictureCode;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public double getAvailableStock() {
		return availableStock;
	}

	public void setAvailableStock(double availableStock) {
		this.availableStock = availableStock;
	}

	public BigDecimal getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(BigDecimal costPrice) {
		this.costPrice = costPrice;
	}

	public String getColorCardPictureCode() {
		return colorCardPictureCode;
	}

	public void setColorCardPictureCode(String colorCardPictureCode) {
		this.colorCardPictureCode = colorCardPictureCode;
	}

	public Double getUnitWeight() {
		return unitWeight;
	}

	public void setUnitWeight(Double unitWeight) {
		this.unitWeight = unitWeight;
	}

	public Double getUnitVolume() {
		return unitVolume;
	}

	public void setUnitVolume(Double unitVolume) {
		this.unitVolume = unitVolume;
	}

	public int getCmsAwaitReplenishment() {
		return cmsAwaitReplenishment;
	}

	public void setCmsAwaitReplenishment(int cmsAwaitReplenishment) {
		this.cmsAwaitReplenishment = cmsAwaitReplenishment;
	}

	public int getCmsTheReplenishment() {
		return cmsTheReplenishment;
	}

	public void setCmsTheReplenishment(int cmsTheReplenishment) {
		this.cmsTheReplenishment = cmsTheReplenishment;
	}

	public boolean isTs() {
		return ts;
	}

	public void setTs(boolean ts) {
		this.ts = ts;
	}

	public int getSales() {
		return sales;
	}

	public void setSales(int sales) {
		this.sales = sales;
	}

	
}

package com.itecheasy.core.product;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author wanghw
 * @date 2015-3-27
 * @description TODO
 * @version
 */
public class ShopProductVo {
	private int id;
	private Integer productId;
	private String cmsProductCode;
	private int shopId;
	private String Sku;
	private String upc;
	private String productType;
	private String browseNode;
	private BigDecimal price;
	private BigDecimal amPrice;
	private BigDecimal phPrice;

	private Boolean contentStatus;
	private int uploadStatus;
	private Boolean shelveStatus;
	private String productName;
	private String productContent;
	private Date time;
	private int operator;
	private String brandName;
	private String primaryPictureCode;
	private String unit;
	private int unitQuantity;
	private double weight;
	private boolean pictureStatus;

	public boolean isPictureStatus() {
		return pictureStatus;
	}

	public void setPictureStatus(boolean pictureStatus) {
		this.pictureStatus = pictureStatus;
	}

	private int shouldQty;
	private int freezeQty;
	private String skuEnd;

	public String getSkuEnd() {
		return skuEnd;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getCmsProductCode() {
		return cmsProductCode;
	}

	public void setCmsProductCode(String cmsProductCode) {
		this.cmsProductCode = cmsProductCode;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getSku() {
		return Sku;
	}

	public void setSku(String sku) {
		Sku = sku;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getBrowseNode() {
		return browseNode;
	}

	public void setBrowseNode(String browseNode) {
		this.browseNode = browseNode;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getAmPrice() {
		return amPrice;
	}

	public void setAmPrice(BigDecimal amPrice) {
		this.amPrice = amPrice;
	}

	public BigDecimal getPhPrice() {
		return phPrice;
	}

	public void setPhPrice(BigDecimal phPrice) {
		this.phPrice = phPrice;
	}

	public Boolean getContentStatus() {
		return contentStatus;
	}

	public void setContentStatus(Boolean contentStatus) {
		this.contentStatus = contentStatus;
	}

	public int getUploadStatus() {
		return uploadStatus;
	}

	public void setUploadStatus(int uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public void setSkuEnd(String skuEnd) {
		this.skuEnd = skuEnd;
	}

	public Boolean getShelveStatus() {
		return shelveStatus;
	}

	public void setShelveStatus(Boolean shelveStatus) {
		this.shelveStatus = shelveStatus;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductContent() {
		return productContent;
	}

	public void setProductContent(String productContent) {
		this.productContent = productContent;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public int getOperator() {
		return operator;
	}

	public void setOperator(int operator) {
		this.operator = operator;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getPrimaryPictureCode() {
		return primaryPictureCode;
	}

	public void setPrimaryPictureCode(String primaryPictureCode) {
		this.primaryPictureCode = primaryPictureCode;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public int getUnitQuantity() {
		return unitQuantity;
	}

	public void setUnitQuantity(int unitQuantity) {
		this.unitQuantity = unitQuantity;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public int getShouldQty() {
		return shouldQty;
	}

	public void setShouldQty(int shouldQty) {
		this.shouldQty = shouldQty;
	}

	public int getFreezeQty() {
		return freezeQty;
	}

	public void setFreezeQty(int freezeQty) {
		this.freezeQty = freezeQty;
	}

}

package com.itecheasy.core.product;

import java.math.BigDecimal;

/**
 * @author wanghw
 * @date 2015-3-30
 * @description TODO
 * @version
 */
public class CMSProductVo {

	private int phProductId;

	private int categoryId1;
	private int categoryId2;
	private int categoryId3;
	private String code;
	private BigDecimal costPrice;
	private Boolean isGift;
	private int id;
	private int isMix;
	private String name;
	private BigDecimal phSalePrice;
	private String primaryPictureCode;
	private Boolean isProductPool;
	private Boolean isSmallQuantities;
	private int storageQty;
	private String unit;
	private int unitQuantity;
	private BigDecimal weight;

	private int phSaleTotleP;
	private int phSaleTotleN;
	private double availableStock;
	private double realFreezeQuantity;
	
	private BigDecimal fbaeStock;
	private BigDecimal sellOrderStock;

	public double getRealFreezeQuantity() {
		return realFreezeQuantity;
	}

	public void setRealFreezeQuantity(double realFreezeQuantity) {
		this.realFreezeQuantity = realFreezeQuantity;
	}

	public int getPhProductId() {
		return phProductId;
	}

	public Boolean getIsGift() {
		return isGift;
	}

	public void setIsGift(Boolean isGift) {
		this.isGift = isGift;
	}

	public Boolean getIsProductPool() {
		return isProductPool;
	}

	public void setIsProductPool(Boolean isProductPool) {
		this.isProductPool = isProductPool;
	}

	public Boolean getIsSmallQuantities() {
		return isSmallQuantities;
	}

	public void setIsSmallQuantities(Boolean isSmallQuantities) {
		this.isSmallQuantities = isSmallQuantities;
	}

	public void setPhProductId(int phProductId) {
		this.phProductId = phProductId;
	}

	public int getCategoryId1() {
		return categoryId1;
	}

	public void setCategoryId1(int categoryId1) {
		this.categoryId1 = categoryId1;
	}

	public int getCategoryId2() {
		return categoryId2;
	}

	public void setCategoryId2(int categoryId2) {
		this.categoryId2 = categoryId2;
	}

	public int getCategoryId3() {
		return categoryId3;
	}

	public void setCategoryId3(int categoryId3) {
		this.categoryId3 = categoryId3;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public BigDecimal getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(BigDecimal costPrice) {
		this.costPrice = costPrice;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIsMix() {
		return isMix;
	}

	public void setIsMix(int isMix) {
		this.isMix = isMix;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getPhSalePrice() {
		return phSalePrice;
	}

	public void setPhSalePrice(BigDecimal phSalePrice) {
		this.phSalePrice = phSalePrice;
	}

	public String getPrimaryPictureCode() {
		return primaryPictureCode;
	}

	public void setPrimaryPictureCode(String primaryPictureCode) {
		this.primaryPictureCode = primaryPictureCode;
	}

	public int getStorageQty() {
		return storageQty;
	}

	public void setStorageQty(int storageQty) {
		this.storageQty = storageQty;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public int getUnitQuantity() {
		return unitQuantity;
	}

	public void setUnitQuantity(int unitQuantity) {
		this.unitQuantity = unitQuantity;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public int getPhSaleTotleP() {
		return phSaleTotleP;
	}

	public void setPhSaleTotleP(int phSaleTotleP) {
		this.phSaleTotleP = phSaleTotleP;
	}

	public int getPhSaleTotleN() {
		return phSaleTotleN;
	}

	public void setPhSaleTotleN(int phSaleTotleN) {
		this.phSaleTotleN = phSaleTotleN;
	}

	public double getAvailableStock() {
		return availableStock;
	}

	public void setAvailableStock(double availableStock) {
		this.availableStock = availableStock;
	}

	public BigDecimal getFbaeStock() {
		return fbaeStock;
	}

	public void setFbaeStock(BigDecimal fbaeStock) {
		this.fbaeStock = fbaeStock;
	}

	public BigDecimal getSellOrderStock() {
		return sellOrderStock;
	}

	public void setSellOrderStock(BigDecimal sellOrderStock) {
		this.sellOrderStock = sellOrderStock;
	}

	
}

package com.itecheasy.core.product;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author wanghw
 * @date 2016-1-11
 * @description TODO
 * @version
 */
public class PHProductCostPrice {
	private String productCode;
	private BigDecimal weight;
	private BigDecimal costPrice;
	private BigDecimal phSale;
	private String title;
	private String content;

	List<ProductFreight> productFreight;

	public BigDecimal getPhSale() {
		return phSale;
	}

	public void setPhSale(BigDecimal phSale) {
		this.phSale = phSale;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(BigDecimal costPrice) {
		this.costPrice = costPrice;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public List<ProductFreight> getProductFreight() {
		return productFreight;
	}

	public void setProductFreight(List<ProductFreight> productFreight) {
		this.productFreight = productFreight;
	}

}

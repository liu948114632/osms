package com.itecheasy.common.asynemail;

public abstract interface AsynEmailService
{
  /**
   * 把邮件写入到数据库
   * @param paramEmail
   */
  public abstract void addEmail(Email paramEmail);

  public abstract void sendEmail();

  public abstract void start();

  public abstract void stop();
}
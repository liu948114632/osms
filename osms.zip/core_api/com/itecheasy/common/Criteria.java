package com.itecheasy.common;

public class Criteria {

}

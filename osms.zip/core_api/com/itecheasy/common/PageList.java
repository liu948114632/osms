package com.itecheasy.common;

import java.util.List;

public class PageList<T> {
	protected List<T> data;
	protected Page page;

	public PageList() {
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}
}

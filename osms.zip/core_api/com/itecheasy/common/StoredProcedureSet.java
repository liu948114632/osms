package com.itecheasy.common;

import java.sql.ResultSet;

public class StoredProcedureSet {
	private ResultSet resultSet;
	private Page page;
	public ResultSet getResultSet() {
		return resultSet;
	}
	public void setResultSet(ResultSet resultSet) {
		this.resultSet = resultSet;
	}
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}	
}

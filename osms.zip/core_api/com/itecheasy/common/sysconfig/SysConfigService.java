package com.itecheasy.common.sysconfig;

public abstract interface SysConfigService {
	public abstract String getValue(String key);

	public abstract void setValue(String key, String value);
}
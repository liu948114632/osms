/*
 * Copyright (c) 2018. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.AmazonInventoryAgedReportPO;

import java.util.List;

/**
 * @Auther: liteng
 * @Date: 2018/8/9 17:13
 * @Description:
 */
public interface AmazonInventoryAgedReportDao extends BaseDAO<AmazonInventoryAgedReportPO,Integer> {

    /**
     * 取到sku和shopId来查找对象List
     * @param agedReportPOS
     * @param shopId
     * @return
     */
    public List<AmazonInventoryAgedReportPO> findByShopIdAndSkuIn(List<AmazonInventoryAgedReportPO> agedReportPOS, Integer shopId);

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.RepositoryPO;

/** 
 * @author wanghw
 * @date 2016-12-2 
 * @description TODO
 * @version 1.2.2
 */
public class RepositoryDaoImpl extends BaseDAOImpl<RepositoryPO, Integer>
implements RepositoryDao{

}

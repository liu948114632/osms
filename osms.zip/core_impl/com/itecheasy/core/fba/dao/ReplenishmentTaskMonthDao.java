package com.itecheasy.core.fba.dao;

import com.itecheasy.core.po.ReplenishmentTaskMonthPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author whw
 * @date 2017-8-17 
 * @description TODO
 * @version 
 */
public interface ReplenishmentTaskMonthDao extends BaseDAO<ReplenishmentTaskMonthPO,Integer>{

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentTaskRulePO;

/** 
 * @author whw
 * @date 2017-8-17 
 * @description TODO
 * @version 
 */
public class ReplenishmentTaskRuleDaoImpl extends BaseDAOImpl<ReplenishmentTaskRulePO, Integer>
implements ReplenishmentTaskRuleDao{

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.AmazonStockReportHistoryPO;
import com.itecheasy.core.po.AmazonStockReportPO;

/**
 * @Auther: liteng
 * @Date: 2018/7/2 15:53
 * @Description:
 */
public interface AmazonStockReportHistoryDao extends BaseDAO<AmazonStockReportHistoryPO,Integer>{



}

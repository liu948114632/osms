package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.FbaReplenishmentPlanItemPO;

/**
 * 
 * @author taozihao
 * @date 2018-6-6
 * @description 
 */
public interface FbaReplenishmentPlanItemDao extends BaseDAO<FbaReplenishmentPlanItemPO, Integer> {

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.ReplenishmentOrderShippingListPO;

/** 
 * @author wanghw
 * @date 2016-12-3 
 * @description TODO
 * @version 1.2.2
 */
public interface ReplenishmentOrderShippingListDao extends BaseDAO<ReplenishmentOrderShippingListPO, Integer>{

}

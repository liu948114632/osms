package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentTaskMonthPO;

/** 
 * @author whw
 * @date 2017-8-17 
 * @description TODO
 * @version 
 */
public class ReplenishmentTaskMonthDaoImpl extends BaseDAOImpl<ReplenishmentTaskMonthPO, Integer>
implements ReplenishmentTaskMonthDao{

}

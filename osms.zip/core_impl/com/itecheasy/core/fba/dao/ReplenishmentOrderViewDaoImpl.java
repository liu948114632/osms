package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentOrderViewPO;

/** 
 * @author wanghw
 * @date 2016-12-7 
 * @description TODO
 * @version 1.2.2
 */
public class ReplenishmentOrderViewDaoImpl extends BaseDAOImpl<ReplenishmentOrderViewPO, Integer>
implements ReplenishmentOrderViewDao{

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentOrderRepositoryPO;

/** 
 * @author whw
 * @date 2017-8-16 
 * @description TODO
 * @version 
 */
public class ReplenishmentOrderRepositoryDaoImpl extends BaseDAOImpl<ReplenishmentOrderRepositoryPO, Integer>
implements ReplenishmentOrderRepositoryDao{

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentOrderPO;

/** 
 * @author wanghw
 * @date 2016-12-3 
 * @description TODO
 * @version 1.2.2
 */
public class ReplenishmentOrderDaoImpl extends BaseDAOImpl<ReplenishmentOrderPO, Integer>
implements ReplenishmentOrderDao{

}

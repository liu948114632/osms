package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentTaskProductPO;

/** 
 * @author wanghw
 * @date 2016-12-7 
 * @description TODO
 * @version 1.2.2
 */
public class ReplenishmentTaskProductDaoImpl extends BaseDAOImpl<ReplenishmentTaskProductPO,Integer>
implements ReplenishmentTaskProductDao{
}

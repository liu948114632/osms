package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.FbaFromAddressSnapshotPO;

/**
 * @author taozihao
 * @date 2018年6月11日 下午12:32:27
 * @description
 */
public interface FbaFromAddressSnapshotDao extends BaseDAO<FbaFromAddressSnapshotPO, Integer> {

}

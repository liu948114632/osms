package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.ReplenishmentTaskLogPO;

/** 
 * @author whw
 * @date 2018-2-27 
 * @description TODO
 * @version 
 */
public interface ReplenishmentTaskLogDao extends BaseDAO<ReplenishmentTaskLogPO, Integer>{

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.AmazonStockReportPO;


/**
 * @Auther: liteng
 * @Date: 2018/7/3 09:42
 * @Description:
 */
public class AmazonStockReportDaoImpl extends BaseDAOImpl<AmazonStockReportPO, Integer> implements AmazonStockReportDao {

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.ReplenishmentOrderRepositoryPO;

/** 
 * @author whw
 * @date 2017-8-16 
 * @description TODO
 * @version 
 */
public interface ReplenishmentOrderRepositoryDao extends BaseDAO<ReplenishmentOrderRepositoryPO, Integer>{

}

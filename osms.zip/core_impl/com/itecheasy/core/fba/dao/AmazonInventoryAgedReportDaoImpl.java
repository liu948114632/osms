/*
 * Copyright (c) 2018. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.AmazonInventoryAgedReportPO;
import com.itecheasy.core.po.AmazonStockReportPO;
import com.itecheasy.webservice.amazon.AmazonStockReportVO;

import java.util.List;

/**
 * @Auther: liteng
 * @Date: 2018/8/9 17:14
 * @Description:
 */
public class AmazonInventoryAgedReportDaoImpl extends BaseDAOImpl<AmazonInventoryAgedReportPO,Integer> implements AmazonInventoryAgedReportDao   {


    /**
     * where sku in and shopId
     * @param amazonStockReport
     * @param shopId
     * @return
     */
    public List<AmazonInventoryAgedReportPO> findByShopIdAndSkuIn(List<AmazonInventoryAgedReportPO> agedReportPOS, Integer shopId){
        String hql = "FROM AmazonInventoryAgedReportPO WHERE shopId=? ";
        StringBuilder builder = new StringBuilder();
        for (AmazonInventoryAgedReportPO po : agedReportPOS) {
            builder.append(",'").append(po.getSku()).append("'");
        }
        hql+="  AND sku in ( "+builder.substring(1).toString()+" )";

        return findListByHql(hql, new Object[]{shopId});
    }

}

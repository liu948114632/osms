package com.itecheasy.core.fba.dao;

import com.itecheasy.core.po.ReplenishmentTaskPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-12-7 
 * @description TODO
 * @version 1.2.2
 */
public interface ReplenishmentTaskDao extends BaseDAO<ReplenishmentTaskPO,Integer>{

}

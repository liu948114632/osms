package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.FbaFromAddressSnapshotPO;

/**
 * @author taozihao
 * @date 2018年6月11日 下午12:33:18
 * @description
 */
public class FbaFromAddressSnapshotDaoImpl extends BaseDAOImpl<FbaFromAddressSnapshotPO, Integer> implements FbaFromAddressSnapshotDao {


}

package com.itecheasy.core.fba.dao;

import com.itecheasy.core.po.FbaShopProductInventoryPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-12-3 
 * @description TODO
 * @version 1.2.2
 */
public interface FbaShopProductInventoryDao extends BaseDAO<FbaShopProductInventoryPO,Integer>{

}

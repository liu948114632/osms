package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentTaskPO;

/** 
 * @author wanghw
 * @date 2016-12-7 
 * @description TODO
 * @version 1.2.2
 */
public class ReplenishmentTaskDaoImpl extends BaseDAOImpl<ReplenishmentTaskPO, Integer>
implements ReplenishmentTaskDao{

}

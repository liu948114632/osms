package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.ShopProductCmsInfoPO;

/** 
 * @author wanghw
 * @date 2016-12-2 
 * @description TODO
 * @version 1.2.2
 */
public interface ShopProductCmsInfoDao extends BaseDAO<ShopProductCmsInfoPO, Integer>{

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.FbaReplenishmentPlanPO;

/**
 * 
 * @author taozihao
 * @date 2018-6-6
 * @description 
 */
public interface FbaReplenishmentPlanDao extends BaseDAO<FbaReplenishmentPlanPO, Integer> {

}

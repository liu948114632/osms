package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.FbaReplenishmentPlanOperateLogPO;

/**
 * 
 * @author taozihao
 * @date 2018-6-6
 * @description 
 */
public interface FbaReplenishmentPlanOperateLogDao extends BaseDAO<FbaReplenishmentPlanOperateLogPO, Integer>{

}

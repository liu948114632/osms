package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentTaskLogPO;

/** 
 * @author whw
 * @date 2018-2-27 
 * @description TODO
 * @version 
 */
public class ReplenishmentTaskLogDaoImpl extends BaseDAOImpl<ReplenishmentTaskLogPO, Integer>
implements ReplenishmentTaskLogDao{

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.FbaReplenishmentPlanItemPO;

/**
 * 
 * @author taozihao
 * @date 2018-6-6
 * @description 
 */
public class FbaReplenishmentPlanItemDaoImpl extends BaseDAOImpl<FbaReplenishmentPlanItemPO, Integer> implements FbaReplenishmentPlanItemDao {

}

package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ReplenishmentOrderShippingListPO;

/** 
 * @author wanghw
 * @date 2016-12-3 
 * @description TODO
 * @version 1.2.2
 */
public class ReplenishmentOrderShippingListDaoImpl extends BaseDAOImpl<ReplenishmentOrderShippingListPO, Integer>
implements ReplenishmentOrderShippingListDao{

}

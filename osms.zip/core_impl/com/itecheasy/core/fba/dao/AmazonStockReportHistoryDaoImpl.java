package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.AmazonStockReportHistoryPO;
import com.itecheasy.core.po.AmazonStockReportPO;


/**
 * @Auther: liteng
 * @Date: 2018/7/3 09:42
 * @Description:
 */
public class AmazonStockReportHistoryDaoImpl extends BaseDAOImpl<AmazonStockReportHistoryPO, Integer> implements AmazonStockReportHistoryDao {

}

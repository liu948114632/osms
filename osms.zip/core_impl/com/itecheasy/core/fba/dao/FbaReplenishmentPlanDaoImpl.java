package com.itecheasy.core.fba.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.FbaReplenishmentPlanPO;

/**
 * 
 * @author taozihao
 * @date 2018-6-6
 * @description 
 */
public class FbaReplenishmentPlanDaoImpl extends BaseDAOImpl<FbaReplenishmentPlanPO, Integer> implements FbaReplenishmentPlanDao {

}

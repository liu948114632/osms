package com.itecheasy.core.fba;


import com.itecheasy.common.PageList;
import com.itecheasy.common.util.*;

import com.itecheasy.core.fba.dao.AmazonInventoryAgedReportDao;
import com.itecheasy.core.fba.dao.AmazonStockReportDao;
import com.itecheasy.core.fba.dao.AmazonStockReportHistoryDao;
import com.itecheasy.core.fba.dao.ReplenishmentOrderItemDao;


import com.itecheasy.core.order.AmazonInventoryAgedReportDTO;
import com.itecheasy.core.order.AmazonStockReportSearchForm;
import com.itecheasy.core.order.AmazonStockReport;

import com.itecheasy.core.po.AmazonInventoryAgedReportPO;
import com.itecheasy.core.po.AmazonStockReportHistoryPO;
import com.itecheasy.core.po.AmazonStockReportPO;

import com.itecheasy.core.system.Shop;
import com.itecheasy.core.system.SystemService;

import com.itecheasy.core.util.StaticUtils;

import com.itecheasy.webservice.amazon.AmazonStockReportVO;
import com.itecheasy.webservice.amazon.RequestReportVO;
import com.itecheasy.webservice.client.AmazonClient;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.JavaType;
import org.codehaus.jackson.type.TypeReference;


import javax.xml.datatype.XMLGregorianCalendar;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Auther: liteng
 * @Date: 2018/7/2 14:05
 * @Description:
 */
public class AmazonReportServiceImpl implements AmazonReportService  {
    private SystemService systemService;
    private AmazonStockReportDao amazonStockReportDao;
    private AmazonStockReportHistoryDao amazonStockReportHistoryDao;

    private ReplenishmentOrderItemDao replenishmentOrderItemDao;

    private static final Logger LOGGER = Logger.getLogger(AmazonReportServiceImpl.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private AmazonInventoryAgedReportDao amazonInventoryAgedReportDao;

    public void setAmazonInventoryAgedReportDao(AmazonInventoryAgedReportDao amazonInventoryAgedReportDao) {
        this.amazonInventoryAgedReportDao = amazonInventoryAgedReportDao;
    }

    public void setReplenishmentOrderItemDao(ReplenishmentOrderItemDao replenishmentOrderItemDao) {
        this.replenishmentOrderItemDao = replenishmentOrderItemDao;
    }

    public void setAmazonStockReportHistoryDao(AmazonStockReportHistoryDao amazonStockReportHistoryDao) {
        this.amazonStockReportHistoryDao = amazonStockReportHistoryDao;
    }

    public void setAmazonStockReportDao(AmazonStockReportDao amazonStockReportDao) {
        this.amazonStockReportDao = amazonStockReportDao;
    }

    public void setSystemService(SystemService systemService) {
        this.systemService = systemService;
    }

    @Override
    @Deprecated
    public AmazonStockReport getAmazonStockBySku(AmazonStockReportSearchForm form) {
        return null;
    }


    public PageList<AmazonStockReport> getAmazonStocksAll(AmazonStockReportSearchForm form) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        byte[] bytes = workbook.getBytes();

        return null;
    }

    @Override
    public PageList<AmazonStockReport> getAmazonStocks(AmazonStockReportSearchForm form) {
        //根据店铺id ， sku,productCode查询出该店铺的补货计划
        StringBuffer buffer = new StringBuffer();
        buffer.append("SELECT distinct a FROM AmazonStockReportPO a,ShopPo b WHERE a.shopId=b.id ");
        List<Object> o = new ArrayList<Object>();
        if(form.getShopId()!=-1){
            buffer.append("AND a.shopId = ? ");
            o.add(form.getShopId());
        }else{
            buffer.append("AND a.shopId in ( ");
            List<Shop> shops = systemService.getShopsByUserId(form.getOperatorId());   //查看该用户的权限，可用的shopId，不能把所有的shop的信息都给显示出来
            for (int i = 0; i < shops.size(); i++) {
                if(i==shops.size()-1){
                    buffer.append(shops.get(i).getId()+" )");
                }else{
                    buffer.append(shops.get(i).getId()+",");
                }
            }
        }

        if(form.getSku()!=null&&!form.getSku().trim().equals("")){
            String[] skus = form.getSku().split(";");
            if(skus.length==1){
                buffer.append("AND a.sku = ? ");
                o.add(form.getSku().trim());
            }else{
                buffer.append("AND a.sku in ( ");
                for (int i = 0; i < skus.length; i++) {
                    if(i==skus.length-1){
                        buffer.append("'"+skus[i].trim()+"' )");
                    }else{
                        buffer.append("'"+skus[i].trim()+"',");
                    }
                }
            }
        }

        buffer.append(" ORDER BY a.syncLast DESC");
        //从report中查出这些信息
        PageList<AmazonStockReportPO> pageList = amazonStockReportDao.findPageListByHql(form.getCurrentPage(), form.getPageSize(), buffer.toString(), o.toArray());

        PageList<AmazonStockReport> amazonStockReportPageList = BeanUtils.copyPageList(pageList, AmazonStockReport.class);
        List<AmazonStockReport> data = amazonStockReportPageList.getData();
        String[] skus =new String[amazonStockReportPageList.getData().size()];
        for (int i = 0; i <skus.length ; i++) {
            skus[i] = data.get(i).getSku();
        }

        // TODO: 2018/7/19 计算海运的

        Map<String, Integer> map = null;
        if (skus.length > 0 && !skus[0].trim().equals("")) {
            map = replenishmentOrderItemDao.getSeaTransOnPassageQuantity(form.getShopId(), skus, DateUtils.getRealDate(new Date()), null);
        }
        if(map!=null && map.size()>0){
            for (AmazonStockReport report : amazonStockReportPageList.getData()) {
                report.setFbaSeaTransit(map.get(report.getSku())==null ? 0 : map.get(report.getSku()));
            }
        }
        return amazonStockReportPageList;
    }












    public static void main(String[] args) throws IOException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date realDate = DateUtils.getRealDate(new Date());

        XMLGregorianCalendar xmlGregorianCalendar = DateUtils.getXMLGregorianCalendar(new Date());
        System.out.println(xmlGregorianCalendar);
        String jsonStr = ":";
        JavaType javaType4 = MAPPER.getTypeFactory().constructParametricType(List.class, AmazonStockReportVO.class);
        List<AmazonStockReportVO> list = MAPPER.readValue(jsonStr, javaType4);
        System.out.println("集合里是对象 对象里有集合转换:" + list);

    }


    /**
     * 封装传给亚马逊的vo
     * @param enableShop
     * @param reportType
     * @return
     * @throws ParseException
     */
    private RequestReportVO setTimeAndOtherParam(Shop enableShop,String reportType,String startDate,String endDate) throws ParseException {
        RequestReportVO requestReportVO = new RequestReportVO();
        requestReportVO.setReportType(reportType);
        requestReportVO.setShopId(enableShop.getId());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //开始日期
        requestReportVO.setStartDate(DateUtils.getXMLGregorianCalendar(format.parse(startDate)));
        //结束日期
        if (StringUtils.isNotEmpty(endDate)){
            requestReportVO.setEndDate(DateUtils.getXMLGregorianCalendar(format.parse(endDate)));
        }else{
            requestReportVO.setEndDate(DateUtils.getXMLGregorianCalendar(new Date()));
        }

        return requestReportVO;
    }

    //"_GET_FBA_MYI_UNSUPPRESSED_INVENTORY_DATA_"    时间也传进来
    //责任，把库存从亚马逊跑回来，根据店铺来跑，根据服务器的url来跑
    //每一个枚举不同的方法
    public void syncAmazonAgedItemReport(Shop enableShop,String reportType){
        try {
            String startDateProperty = DeployProperties.getInstance().getProperty("amazon.Aged.item.report.start.date","2018-03-03 09:15:12");
            String endDateProperty = DeployProperties.getInstance().getProperty("amazon.Aged.item.report.end.date", null);

            RequestReportVO requestReportVO = setTimeAndOtherParam(enableShop, reportType, startDateProperty, endDateProperty);

            String jsonString = AmazonClient.getAmazonStockReport3(enableShop.getId(), requestReportVO);    //call amazon

            List<AmazonInventoryAgedReportDTO> amazonInventoryAgedReportVOS =  MAPPER.readValue(jsonString,new TypeReference<List<AmazonInventoryAgedReportDTO>>(){});

            List<AmazonInventoryAgedReportPO> amazonInventoryAgedReportPOS = BeanUtils.copyList(amazonInventoryAgedReportVOS, AmazonInventoryAgedReportPO.class);


            //传入pos
            //存储到历史表中的数据
                //过滤掉一些不用存储的记录

                //sku的库龄只有大于180天的，标记然后存储

                //其他的数据有不同的计算是否清仓的方式

            //筛选到主表中的数据，存储到主表
            //返回pos
            //数据是否必须要方法唯一

            //把从亚马逊所有的记录都从dao中拿到,用于比较时间,根据shopIdid和sku来进行判断
            List<AmazonInventoryAgedReportPO> byShopIdAndSkuIn = amazonInventoryAgedReportDao.findByShopIdAndSkuIn(amazonInventoryAgedReportPOS, enableShop.getId());
            //set时间
            //根据shopIdid和sku来进行判断，如果没有这个商品的报告记录，就设置首次同步时间，从中间服务同步回来时，首次和最后同步时间都有
//            for (AmazonInventoryAgedReportPO newPo : amazonInventoryAgedReportPOS) {
//                for (AmazonInventoryAgedReportPO po : byShopIdAndSkuIn) {
//                    if (newPo.getShopId().equals(po.getShopId()) && newPo.getSku().equals(po.getSku())){
//                        newPo.setSyncFirst(po.getSyncFirst());
//                    }
//                }
//            }



            //encapsulation
//            amazonInventoryAgedReportDao.addObject(amazonInventoryAgedReportPOS);
//            amazonInventoryAgedReportDao.flush();
//            amazonInventoryAgedReportDao.updateBySql
//                    (" delete from amazon_inventory_aged_report where id in (  select min(id) from amazon_stock_report where shopid = "+ enableShop.getId()+"  group by sku having(count(1)>1)  ) ");

            if (CollectionUtils.isNotEmpty(amazonInventoryAgedReportPOS)){
                StaticUtils.addEmail("OSMS系统:同步amazon_aged报告成功", "\r\n" + "shopId："+enableShop.getId());
            } else{
                StaticUtils.addEmail("OSMS系统:同步amazon_aged报告出错", "\r\n" + "shopId："+enableShop.getId());
            }
        } catch (ParseException e) {
            LOGGER.error("date convert error 时间转换错误,请在配置文件deploy_config.properties中重新配置正确的时间格式 “yyyy-MM-dd HH:mm:ss” ");
            e.printStackTrace();
        } catch (IOException e) {
            LOGGER.error("json 格式转换错误");
            e.printStackTrace();
        } catch (Exception e){
            LOGGER.error(e.getMessage(),e);
        }

    }


    /**
     * auto task
     */
    @Override
    public void syncAmazonStockReportFromAmazon(List<Shop> shopList) {
        for (Shop enableShop : shopList) {   //只有一个shopId
            RequestReportVO requestReportVO = new RequestReportVO();
            requestReportVO.setReportType("_GET_FBA_MYI_UNSUPPRESSED_INVENTORY_DATA_");
            requestReportVO.setShopId(enableShop.getId());
            try {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                //开始日期
                requestReportVO.setStartDate(DateUtils.getXMLGregorianCalendar(format.parse(DeployProperties.getInstance().getProperty("amazon.stock.report.start.date",null))));

                //结束日期
                String endDateProperty = DeployProperties.getInstance().getProperty("amazon.stock.report.end.date", null);
                if (StringUtils.isNotEmpty(endDateProperty)){
                    requestReportVO.setEndDate(DateUtils.getXMLGregorianCalendar(format.parse(endDateProperty)));
                }else{
                    requestReportVO.setEndDate(DateUtils.getXMLGregorianCalendar(new Date()));
                }

            } catch (ParseException e) {
                LOGGER.info("date convert error 时间转换错误,请在配置文件deploy_config.properties中重新配置正确的时间格式 “yyyy-MM-dd HH:mm:ss” ");
                throw new RuntimeException(e);
            }

            //同步回单个店铺的所有报告
            LOGGER.error("getAmazonStockReport step 0 ,店铺ID为："+enableShop.getId());
            List<AmazonStockReportVO> amazonStockReport = AmazonClient.getAmazonStockReport(enableShop.getId(), requestReportVO);//调用amazon
            LOGGER.error("getAmazonStockReport step 1 ,店铺ID为："+enableShop.getId());
            LOGGER.error("getAmazonStockReport step 1 amazonStockReport size "+amazonStockReport ==null?0:amazonStockReport.size());
            if (amazonStockReport != null) { //把商店信息设置回来
                for (AmazonStockReportVO amazonStockReportVO : amazonStockReport) {
                    amazonStockReportVO.setShopId(enableShop.getId());
                }
            }

            if (CollectionUtils.isNotEmpty(amazonStockReport)){
                try {
                    String amazonStockReportJson = MAPPER.writeValueAsString(amazonStockReport);
                    int shopID = enableShop.getId();
                    LOGGER.error("店铺ID为："+shopID+"已获取到结果，同步回的数量为"+amazonStockReport.size()+"内容为"+amazonStockReportJson);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(CollectionUtils.isNotEmpty(amazonStockReport)){
                LOGGER.error("getAmazonStockReport step 3 ,店铺ID为："+enableShop.getId());
                //更新到历史记录的表中,并且确保时间唯一   可以考虑分批写
                amazonStockReportHistoryDao.addObject(BeanUtils.copyList(encapsulationToAmazonStockReportPo(amazonStockReport), AmazonStockReportHistoryPO.class));

                //把从亚马逊所有的记录都从dao中拿到,用于比较时间,根据shopIdid和sku来进行判断
                List<AmazonStockReportPO> daoStockReportList = findFromDao(amazonStockReport, enableShop.getId());
                LOGGER.error("getAmazonStockReport step 4 ,店铺ID为："+enableShop.getId());
                //根据shopIdid和sku来进行判断，如果没有这个商品的报告记录，就设置首次同步时间，从中间服务同步回来时，首次和最后同步时间都有
                List<AmazonStockReportVO> amazonStockReportVOS = updateData(amazonStockReport, daoStockReportList);
                LOGGER.error("getAmazonStockReport step 5 ,店铺ID为："+enableShop.getId());
                //写入数据库，但是要自己包装
                amazonStockReportDao.addObject(encapsulationToAmazonStockReportPo(amazonStockReportVOS));
                amazonStockReportDao.flush();
                LOGGER.error("getAmazonStockReport step 6 ,店铺ID为："+enableShop.getId());
                amazonStockReportDao.updateBySql(" delete from amazon_stock_report where id in (  select min(id) from amazon_stock_report where shopid = "+ enableShop.getId()+"  group by sku having(count(1)>1)  ) ");
                //同步成功，发送邮件
            }
            LOGGER.error("getAmazonStockReport step 7 ,店铺ID为："+enableShop.getId());
            if (CollectionUtils.isNotEmpty(amazonStockReport)){
                StaticUtils.addEmail("OSMS系统:同步库存报告成功", "\r\n" + "shopId："+enableShop.getId());
            } else{
                StaticUtils.addEmail("OSMS系统:同步库存报告出错", "\r\n" + "shopId："+enableShop.getId());
            }
            LOGGER.error("getAmazonStockReport step 8 ,店铺ID为："+enableShop.getId());
        }
    }

    //读取数据库
    public List<AmazonStockReportPO> findFromDao(List<AmazonStockReportVO> amazonStockReport, Integer shopId){
        String hql = "FROM AmazonStockReportPO WHERE shopId=? ";
        StringBuilder builder = new StringBuilder();
        for (AmazonStockReportVO vo : amazonStockReport) {
            builder.append(",'").append(vo.getSku()).append("'");
        }
        hql+="  AND sku in ( "+builder.substring(1).toString()+" )";

        return amazonStockReportDao.findListByHql(hql, new Object[]{shopId});
    }

    //返回的多个报告对象里，如果是旧的报告，则不跟新创建时间
    public List<AmazonStockReportVO> updateData(List<AmazonStockReportVO> amazonStockReport,List<AmazonStockReportPO> daoStockReportList) {
        for (AmazonStockReportVO amazonStockReportVO : amazonStockReport) { //new
            for (AmazonStockReportPO daoStockReport : daoStockReportList) {     //old
                if (amazonStockReportVO.getShopId().equals(daoStockReport.getShopId()) &&
                        amazonStockReportVO.getSku().equalsIgnoreCase(daoStockReport.getSku())) {   //没有这个商品才设置第一次同步时间
                    amazonStockReportVO.setSyncFirst(DateUtils.getXMLGregorianCalendar(daoStockReport.getSyncFirst()));
                }
            }
        }
        return amazonStockReport;
    }

    public List<AmazonStockReportPO> encapsulationToAmazonStockReportPo(List<AmazonStockReportVO> amazonStockReport){
        List<AmazonStockReportPO> po = new ArrayList<AmazonStockReportPO>();
        for (AmazonStockReportVO reportVO : amazonStockReport) {
            AmazonStockReportPO _po = new AmazonStockReportPO();

            _po.setAfnFulfillableQuantity(reportVO.getAfnFulfillableQuantity());
            _po.setAfnInboundReceivingQuantity(reportVO.getAfnInboundReceivingQuantity());
            _po.setAfnInboundShippedQuantity(reportVO.getAfnInboundShippedQuantity());
            _po.setAfnInboundWorkingQuantity(reportVO.getAfnInboundWorkingQuantity());
            _po.setAfnReservedQuantity(reportVO.getAfnReservedQuantity());
            _po.setAfnUnsellableQuantity(reportVO.getAfnUnsellableQuantity());
            _po.setAfnWarehouseQuantity(reportVO.getAfnWarehouseQuantity());
            _po.setAfnTotalQuantity(reportVO.getAfnTotalQuantity());
            _po.setSku(reportVO.getSku());
            _po.setShopId(reportVO.getShopId());
            _po.setSyncFirst(DateUtils.getDateByXMLGregorianCalendar(reportVO.getSyncFirst()));
            _po.setSyncLast(DateUtils.getDateByXMLGregorianCalendar(reportVO.getSyncLast()));

            //other property
            _po.setFnsku(reportVO.getFnsku());
            _po.setAmazonStockReportAsin(reportVO.getAmazonStockReportAsin());
            _po.setProductName(reportVO.getProductName());
            _po.setCondition(reportVO.getCondition());
            _po.setYourPrice(reportVO.getYourPrice());
            _po.setMfnListingExists(reportVO.getMfnListingExists());
            _po.setMfnFulfillableQuantity(reportVO.getMfnFulfillableQuantity());
            _po.setAfnListingExists(reportVO.getAfnListingExists());
            _po.setPerUnitVolume(reportVO.getPerUnitVolume());

            po.add(_po);
        }
        return po;
    }

}

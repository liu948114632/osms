/*
 * Copyright (c) 2018. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.itecheasy.core.operation;

import com.itecheasy.common.PageList;
import com.itecheasy.common.util.BeanUtils;
import com.itecheasy.common.util.CollectionUtils;
import com.itecheasy.common.util.DateUtils;
import com.itecheasy.core.fba.ReplenishmentTask;
import com.itecheasy.core.fba.dao.AmazonInventoryAgedReportDao;
import com.itecheasy.core.po.AmazonInventoryAgedReportPO;
import com.itecheasy.core.po.ReplenishmentTaskPO;
import com.itecheasy.core.system.Shop;
import com.itecheasy.core.system.SystemService;
import com.itecheasy.osms.operation.AmazonAgedReportVO;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: liteng
 * @Date: 2018/8/11 16:46
 * @Description:
 */
public class ShowAmazonAgedReportImpl implements ShowAmazonAgedReport {
    private SystemService systemService;

    private AmazonInventoryAgedReportDao amazonInventoryAgedReportDao;

    public void setAmazonInventoryAgedReportDao(AmazonInventoryAgedReportDao amazonInventoryAgedReportDao) {
        this.amazonInventoryAgedReportDao = amazonInventoryAgedReportDao;
    }

    public void setSystemService(SystemService systemService) {
        this.systemService = systemService;
    }

    @Override
    public PageList<AmazonAgedReportVO> getAmazonAgedReport(AmazonAgedReportForm amazonAgedReportForm) {
        StringBuilder sql = new StringBuilder();
        List<Object> params = new ArrayList<Object>();
        sql.append("SELECT * FROM amazon_inventory_aged_report");

        if (amazonAgedReportForm.getShopId() < 0) {
            sql.append("AND a.shop_id IN ( ");
            List<Shop> shops = systemService.getShopsByUserId(amazonAgedReportForm.getOperatorId());
            for (int i = 0; i < shops.size(); i++) {
                if (i == shops.size() - 1) {
                    sql.append(shops.get(i).getId() + " ) ");
                } else {
                    sql.append(shops.get(i).getId() + ",");
                }
            }
        } else {
            sql.append("AND a.shop_id = ? ");
            params.add(amazonAgedReportForm.getShopId());
        }

        List<String> skuList = amazonAgedReportForm.getSkuList();
        if(CollectionUtils.isNotEmpty(skuList)){
            if(skuList.size()==1){
                sql.append("AND a.sku = ? ");
                params.add(skuList.get(0).trim());
            }else if (skuList.size()>1){
                sql.append("AND a.sku in ( ");
                for (int i = 0; i < skuList.size(); i++) {
                    if(i==skuList.size()-1){
                        sql.append("'"+ skuList.get(i).trim()+"' )");
                    }else{
                        sql.append("'"+ skuList.get(i).trim()+"',");
                    }
                }
            }
        }
        //是否需要清仓
        if(amazonAgedReportForm.getIsClearanceItem()>-1){
            sql.append(" AND is_clearance_item = ? ");
            params.add(amazonAgedReportForm.getIsClearanceItem());
        }

        //库龄
        int agingQueryCondition = amazonAgedReportForm.getAgingQueryCondition();
        if (agingQueryCondition==-1) {
            sql.append(" AND is_clearance_item = ? ");
//                params.add();
        } else if (agingQueryCondition==0) {

        } else if (agingQueryCondition==1) {

        }
        //起始日期的开始时间
        if(amazonAgedReportForm.getOriginationStartDate()!=null){
            sql.append(" and start_date >=? ");
            params.add(amazonAgedReportForm.getOriginationStartDate());
//            params.add(DateUtils.getRealDate(amazonAgedReportForm.getOrderedDateBegin()));
        }
        //起始日期的截止时间
        if(amazonAgedReportForm.getOriginationEndDate()!=null){
            sql.append(" and start_date<=? ");
            params.add(  amazonAgedReportForm.getOriginationEndDate());
//            params.add(DateUtils.getFullDate(amazonAgedReportForm.getOrderedDateEnd()));
        }
        //更新日期的开始时间
        if(amazonAgedReportForm.getOriginationStartDate()!=null){
            sql.append(" and sync_last>=? ");
            params.add(amazonAgedReportForm.getUpdateStartDate());
        }
        //更新日期的截止时间
        if(amazonAgedReportForm.getOriginationEndDate()!=null){
            sql.append(" and sync_last<=? ");
            params.add( amazonAgedReportForm.getUpdateEndDate());
        }

        PageList<AmazonInventoryAgedReportPO> amazonInventoryAgedReportPOPageList =
                amazonInventoryAgedReportDao.findPageListByHql(amazonAgedReportForm.getCurrentPage(), amazonAgedReportForm.getPageSize(),
                        sql.toString(), params.toArray());


//        PageList<ReplenishmentTaskPO> pl = replenishmentTaskDao.findPageListBySql(amazonAgedReportForm.getCurrentPage(),
//                amazonAgedReportForm.getPageSiez(), sql.toString(), where.toString(), "   CASE status " +
//                        "WHEN 1 THEN 1 " +
//                        " WHEN 4 THEN 2 " +
//                        "WHEN 5 THEN 3 " +
//                        "WHEN 2 THEN 4" +
//                        " WHEN 3 THEN 5 WHEN 6 THEN 6" +
//                        " END ,create_date desc ", params);
//        return BeanUtils.copyPageList(pl, ReplenishmentTask.class);
        return null;
    }
}

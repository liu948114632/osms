package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.BaseOrderViewDetailPO;

/** 
 * @author wanghw
 * @date 2016-12-16 
 * @description TODO
 * @version 1.2.2
 */
public class BaseOrderViewDetailDaoImpl extends BaseDAOImpl<BaseOrderViewDetailPO, String>
implements BaseOrderViewDetailDao{

}

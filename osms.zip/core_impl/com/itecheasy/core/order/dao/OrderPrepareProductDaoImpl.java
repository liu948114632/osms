package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderPrepareProductPO;

/**
 * @author wanghw
 * @date 2015-5-11
 * @description TODO
 * @version
 */
public class OrderPrepareProductDaoImpl extends BaseDAOImpl<OrderPrepareProductPO, Integer> implements
		OrderPrepareProductDao {

}

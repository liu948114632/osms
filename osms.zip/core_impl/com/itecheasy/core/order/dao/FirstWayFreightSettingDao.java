package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.FirstWayFreightSettingPO;

/** 
 * @author wanghw
 * @date 2016-3-7 
 * @description TODO
 * @version 1.1.7
 */
public interface FirstWayFreightSettingDao extends BaseDAO<FirstWayFreightSettingPO, Integer>{

}

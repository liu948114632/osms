package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderOperateLogPO;

/** 
 * @author wanghw
 * @date 2015-5-12 
 * @description TODO
 * @version
 */
public class OrderOperateLogDaoImpl extends BaseDAOImpl<OrderOperateLogPO, Integer> implements OrderOperateLogDao{

}

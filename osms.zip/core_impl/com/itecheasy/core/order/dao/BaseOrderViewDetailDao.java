package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.BaseOrderViewDetailPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-12-16 
 * @description TODO
 * @version 1.2.2
 */
public interface BaseOrderViewDetailDao extends BaseDAO<BaseOrderViewDetailPO,String>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderAddressAmazonPO;

/** 
 * @author wanghw
 * @date 2015-5-12 
 * @description TODO
 * @version
 */
public interface OrderAddressAmazonDao extends BaseDAO<OrderAddressAmazonPO, Integer>{

}

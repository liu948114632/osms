package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.VFBAStoreProductReportPO;

/** 
 * @author wanghw
 * @date 2016-3-15 
 * @description TODO
 * @version 1.1.7
 */
public class VFBAStoreProductReportDaoImpl extends BaseDAOImpl<VFBAStoreProductReportPO, Integer>
	implements VFBAStoreProductReportDao{

}

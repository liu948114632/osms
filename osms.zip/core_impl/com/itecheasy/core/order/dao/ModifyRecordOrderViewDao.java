package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.ModifyRecordOrderViewPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2017-1-12 
 * @description TODO
 * @version 1.2.2
 */
public interface ModifyRecordOrderViewDao extends BaseDAO<ModifyRecordOrderViewPO,Integer>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderProductPO;

/**
 * @author wanghw
 * @date 2015-5-11
 * @description TODO
 * @version
 */
public class OrderProductDaoImpl extends BaseDAOImpl<OrderProductPO, Integer> implements OrderProductDao {

}

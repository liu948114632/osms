package com.itecheasy.core.order.dao;


import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.PackageProblemPO;

/** 
 * @author wanghw
 * @date 2016-2-23 
 * @description TODO
 * @version 1.1.7
 */
public interface PackageProblemDao extends BaseDAO<PackageProblemPO, Integer>{
	
}

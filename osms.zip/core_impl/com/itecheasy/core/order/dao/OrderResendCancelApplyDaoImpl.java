package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderResendCancelApplyPO;

/** 
 * @author wanghw
 * @date 2016-12-3 
 * @description TODO
 * @version 1.2.2
 */
public class OrderResendCancelApplyDaoImpl extends BaseDAOImpl<OrderResendCancelApplyPO, Integer>
implements OrderResendCancelApplyDao{

}

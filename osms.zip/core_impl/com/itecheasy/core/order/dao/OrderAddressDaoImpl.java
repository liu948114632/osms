package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderAddressPO;

/** 
 * @author wanghw
 * @date 2015-5-12 
 * @description TODO
 * @version
 */
public class OrderAddressDaoImpl extends BaseDAOImpl<OrderAddressPO, Integer> implements OrderAddressDao{

}

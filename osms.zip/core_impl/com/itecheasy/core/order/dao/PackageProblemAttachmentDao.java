package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.PackageProblemAttachmentPO;

/** 
 * @author wanghw
 * @date 2016-2-23 
 * @description TODO
 * @version 1.1.7
 */
public interface PackageProblemAttachmentDao extends BaseDAO<PackageProblemAttachmentPO, Integer>{

}

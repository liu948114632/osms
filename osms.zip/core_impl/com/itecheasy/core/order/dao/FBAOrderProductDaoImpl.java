package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.FBAOrderProductPO;

/** 
 * @author wanghw
 * @date 2016-2-25 
 * @description TODO
 * @version 1.1.7
 */
public class FBAOrderProductDaoImpl extends BaseDAOImpl<FBAOrderProductPO, Integer>
	implements FBAOrderProductDao{

}

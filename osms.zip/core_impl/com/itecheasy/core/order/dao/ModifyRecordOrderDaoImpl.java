package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.ModifyRecordOrderPO;


import com.itecheasy.common.BaseDAOImpl;

/** 
 * @author wanghw
 * @date 2017-1-11 
 * @description TODO
 * @version 1.2.2
 */
public class ModifyRecordOrderDaoImpl extends BaseDAOImpl<ModifyRecordOrderPO,Integer>
implements ModifyRecordOrderDao{

}

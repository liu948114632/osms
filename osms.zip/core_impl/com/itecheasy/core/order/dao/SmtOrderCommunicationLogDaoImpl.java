package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.SmtOrderCommunicationLogPo;

/** 
 * @author whw
 * @date 2017-5-18 
 * @description TODO
 * @version 3.9.42
 */
public class SmtOrderCommunicationLogDaoImpl extends BaseDAOImpl<SmtOrderCommunicationLogPo, Integer>
implements SmtOrderCommunicationLogDao{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderCountReportPO;

/** 
 * @author wanghw
 * @date 2016-1-14 
 * @description TODO
 * @version
 */
public class OrderCountReportDaoImpl extends BaseDAOImpl<OrderCountReportPO, Integer>
	implements OrderCountReportDao{

}

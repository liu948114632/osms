package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.VFBAStoreProductReportPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-3-15 
 * @description TODO
 * @version 1.1.7
 */
public interface VFBAStoreProductReportDao extends BaseDAO<VFBAStoreProductReportPO, Integer>{

}

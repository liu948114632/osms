package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderTrackingLogPO;

/** 
 * @author whw
 * @date 2017-8-23 
 * @description TODO
 * @version 
 */
public class OrderTrackingLogDaoImpl extends BaseDAOImpl<OrderTrackingLogPO, Integer>
implements OrderTrackingLogDao{

}

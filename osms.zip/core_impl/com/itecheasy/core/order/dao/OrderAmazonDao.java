package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderAmazonPO;

/** 
 * @author wanghw
 * @date 2015-5-11 
 * @description TODO
 * @version
 */
public interface OrderAmazonDao extends BaseDAO<OrderAmazonPO, Integer>{

}

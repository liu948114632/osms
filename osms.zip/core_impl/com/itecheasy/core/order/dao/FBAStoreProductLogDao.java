package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.FBAStoreProductLogPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-3-12 
 * @description TODO
 * @version 1.1.7
 */
public interface FBAStoreProductLogDao extends BaseDAO<FBAStoreProductLogPO, Integer>{

}

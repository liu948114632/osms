package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.OrderCancelResendApplyPO;


import com.itecheasy.common.BaseDAOImpl;

/** 
 * @author wanghw
 * @date 2016-12-9 
 * @description TODO
 * @version 1.2.2
 */
public class OrderCancelResendApplyDaoImpl extends BaseDAOImpl<OrderCancelResendApplyPO, Integer>
implements OrderCancelResendApplyDao{

}

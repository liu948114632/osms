package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderProductPO;

/** 
 * @author wanghw
 * @date 2015-5-11 
 * @description TODO
 * @version
 */
public interface OrderProductDao extends BaseDAO<OrderProductPO, Integer>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.PackageProblemAttachmentPO;

/** 
 * @author wanghw
 * @date 2016-2-23 
 * @description TODO
 * @version 1.1.7
 */
public class PackageProblemAttachmentDaoImpl extends BaseDAOImpl<PackageProblemAttachmentPO, Integer>
	implements PackageProblemAttachmentDao{

}

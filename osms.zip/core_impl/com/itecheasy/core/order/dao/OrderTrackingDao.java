package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderTrackingPO;

/** 
 * @author whw
 * @date 2017-8-23 
 * @description TODO
 * @version 
 */
public interface OrderTrackingDao extends BaseDAO<OrderTrackingPO, Integer>{

}

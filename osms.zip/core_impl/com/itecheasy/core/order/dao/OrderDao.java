package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderPO;

/** 
 * @author wanghw
 * @date 2015-5-11 
 * @description TODO
 * @version
 */
public interface OrderDao extends BaseDAO<OrderPO, Integer>{

}

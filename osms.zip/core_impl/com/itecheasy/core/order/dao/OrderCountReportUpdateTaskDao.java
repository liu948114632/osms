package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.OrderCountReportUpdateTaskPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-1-15 
 * @description TODO
 * @version
 */
public interface OrderCountReportUpdateTaskDao extends BaseDAO<OrderCountReportUpdateTaskPO, Integer>{

}

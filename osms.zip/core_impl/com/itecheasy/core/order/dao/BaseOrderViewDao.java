package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.BaseOrderViewPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-12-6 
 * @description TODO
 * @version 1.2.2
 */
public interface BaseOrderViewDao extends BaseDAO<BaseOrderViewPO, String>{

}

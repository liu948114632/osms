package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderCustomerPO;

/**
 * @author wanghw
 * @date 2015-5-21
 * @description TODO
 * @version
 */
public class OrderCustomerDaoImpl extends BaseDAOImpl<OrderCustomerPO, Integer> implements OrderCustomerDao {

}

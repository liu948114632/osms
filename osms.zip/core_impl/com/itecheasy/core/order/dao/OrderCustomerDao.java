package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderCustomerPO;

/** 
 * @author wanghw
 * @date 2015-5-21 
 * @description TODO
 * @version
 */
public interface OrderCustomerDao extends BaseDAO<OrderCustomerPO, Integer>{

}

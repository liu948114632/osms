package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderCountReportPO;

/** 
 * @author wanghw
 * @date 2016-1-14 
 * @description TODO
 * @version
 */
public interface OrderCountReportDao extends BaseDAO<OrderCountReportPO, Integer>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.FBAOrderProductPO;

/** 
 * @author wanghw
 * @date 2016-2-25 
 * @description TODO
 * @version 1.1.7
 */
public interface FBAOrderProductDao extends BaseDAO<FBAOrderProductPO, Integer>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.FBAStoreProductLogPO;

/** 
 * @author wanghw
 * @date 2016-3-12 
 * @description TODO
 * @version 1.1.7
 */
public class FBAStoreProductLogDaoImpl extends BaseDAOImpl<FBAStoreProductLogPO, Integer>
	implements FBAStoreProductLogDao{

}

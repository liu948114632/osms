package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.SmtOrderCommunicationLogPo;


import com.itecheasy.common.BaseDAO;

/** 
 * @author whw
 * @date 2017-5-18 
 * @description TODO
 * @version 
 */
public interface SmtOrderCommunicationLogDao extends BaseDAO<SmtOrderCommunicationLogPo,Integer>{

}

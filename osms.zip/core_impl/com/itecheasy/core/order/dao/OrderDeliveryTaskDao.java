package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderDeliveryTaskPO;

/** 
 * @author wanghw
 * @date 2015-6-26 
 * @description TODO
 * @version
 */
public interface OrderDeliveryTaskDao extends BaseDAO<OrderDeliveryTaskPO, Integer>{

}

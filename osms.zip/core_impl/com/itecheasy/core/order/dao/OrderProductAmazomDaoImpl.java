package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderProductAmazonPO;

/** 
 * @author wanghw
 * @date 2015-5-11 
 * @description TODO
 * @version
 */
public class OrderProductAmazomDaoImpl extends BaseDAOImpl<OrderProductAmazonPO, Integer>
	implements OrderProductAmazomDao{

}

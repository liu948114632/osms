package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.VOrderTracePO;

/** 
 * @author wanghw
 * @date 2015-12-17 
 * @description TODO
 * @version
 */
public class VOrderTraceDaoImpl extends BaseDAOImpl<VOrderTracePO, Integer> 
	implements VOrderTraceDao{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderDeliveryTaskPO;

/** 
 * @author wanghw
 * @date 2015-6-26 
 * @description TODO
 * @version
 */
public class OrderDeliveryTaskDaoImpl extends BaseDAOImpl<OrderDeliveryTaskPO, Integer> implements OrderDeliveryTaskDao{

}

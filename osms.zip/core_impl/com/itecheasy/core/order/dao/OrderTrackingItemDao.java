package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.OrderTrackingItemPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author whw
 * @date 2017-8-23 
 * @description TODO
 * @version 
 */
public interface OrderTrackingItemDao extends BaseDAO<OrderTrackingItemPO,Integer>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.VOrderPO;

/** 
 * @author wanghw
 * @date 2015-6-25 
 * @description TODO
 * @version
 */
public class VOrderDaoImpl extends BaseDAOImpl<VOrderPO, Integer> implements VOrderDao{

}

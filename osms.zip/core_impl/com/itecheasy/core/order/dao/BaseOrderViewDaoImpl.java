package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.BaseOrderViewPO;

/** 
 * @author wanghw
 * @date 2016-12-6 
 * @description TODO
 * @version 1.2.2
 */
public class BaseOrderViewDaoImpl extends BaseDAOImpl<BaseOrderViewPO, String>
implements BaseOrderViewDao{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.FirstWayFreightSettingPO;


import com.itecheasy.common.BaseDAOImpl;

/** 
 * @author wanghw
 * @date 2016-3-7 
 * @description TODO
 * @version 1.1.7
 */
public class FirstWayFreightSettingDaoImpl extends BaseDAOImpl<FirstWayFreightSettingPO, Integer>
	implements FirstWayFreightSettingDao{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderAddressPO;

/** 
 * @author wanghw
 * @date 2015-5-12 
 * @description TODO
 * @version
 */
public interface OrderAddressDao extends BaseDAO<OrderAddressPO, Integer>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.EbayOrderDataPO;

/** 
 * @author wanghw
 * @date 2016-7-27 
 * @description TODO
 * @version 1.2.0
 */
public interface EbayOrderDataDao extends BaseDAO<EbayOrderDataPO, Integer>{

}

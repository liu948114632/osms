package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.FBAStoreProductPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-2-25 
 * @description TODO
 * @version 1.1.7
 */
public interface FBAStoreProductDao extends BaseDAO<FBAStoreProductPO,Integer>{

}

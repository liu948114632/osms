package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderPaymentReportPO;

/** 
 * @author wanghw
 * @date 2016-1-14 
 * @description TODO
 * @version
 */
public class OrderPaymentReportDaoImpl extends BaseDAOImpl<OrderPaymentReportPO, Integer>
	implements OrderPaymentReportDao{

}

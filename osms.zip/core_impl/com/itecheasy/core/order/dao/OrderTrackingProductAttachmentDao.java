package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderTrackingProductAttachmentPO;

/** 
 * @author whw
 * @date 2017-8-23 
 * @description TODO
 * @version 
 */
public interface OrderTrackingProductAttachmentDao extends BaseDAO<OrderTrackingProductAttachmentPO, Integer>
{

}

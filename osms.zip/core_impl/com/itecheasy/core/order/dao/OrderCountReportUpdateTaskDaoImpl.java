package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderCountReportUpdateTaskPO;

/** 
 * @author wanghw
 * @date 2016-1-15 
 * @description TODO
 * @version
 */
public class OrderCountReportUpdateTaskDaoImpl extends BaseDAOImpl<OrderCountReportUpdateTaskPO, Integer>
	implements OrderCountReportUpdateTaskDao{

}

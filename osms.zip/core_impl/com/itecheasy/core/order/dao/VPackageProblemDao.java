package com.itecheasy.core.order.dao;

import com.itecheasy.core.po.VPackageProblemPO;


import com.itecheasy.common.BaseDAO;

/** 
 * @author wanghw
 * @date 2016-2-23 
 * @description TODO
 * @version 1.1.7
 */
public interface VPackageProblemDao extends BaseDAO<VPackageProblemPO, Integer>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.ModifyRecordOrderItemPO;

/** 
 * @author wanghw
 * @date 2017-1-11 
 * @description TODO
 * @version 1.2.2
 */
public interface ModifyRecordOrderItemDao extends BaseDAO<ModifyRecordOrderItemPO, Integer>{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.ModifyRecordOrderItemPO;

/** 
 * @author wanghw
 * @date 2017-1-11 
 * @description TODO
 * @version 1.2.2
 */
public class ModifyRecordOrderItemDaoImpl extends BaseDAOImpl<ModifyRecordOrderItemPO, Integer>
implements ModifyRecordOrderItemDao{

}

package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.core.po.OrderTrackingProductPO;

/** 
 * @author whw
 * @date 2017-8-23 
 * @description TODO
 * @version 
 */
public class OrderTrackingProductDaoImpl extends BaseDAOImpl<OrderTrackingProductPO, Integer>
implements OrderTrackingProductDao{

}

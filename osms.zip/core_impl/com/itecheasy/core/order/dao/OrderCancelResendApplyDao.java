package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.OrderCancelResendApplyPO;

/** 
 * @author wanghw
 * @date 2016-12-9 
 * @description TODO
 * @version 1.2.2
 */
public interface OrderCancelResendApplyDao extends BaseDAO<OrderCancelResendApplyPO, Integer>{

}

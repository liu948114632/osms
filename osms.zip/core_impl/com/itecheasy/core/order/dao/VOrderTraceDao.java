package com.itecheasy.core.order.dao;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.core.po.VOrderTracePO;

/** 
 * @author wanghw
 * @date 2015-12-17 
 * @description TODO
 * @version
 */
public interface VOrderTraceDao extends BaseDAO<VOrderTracePO, Integer>{

}

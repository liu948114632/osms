package com.itecheasy.communication.util;

import java.io.File;
import java.util.Date;

public class FileDate {
	private File file;
	private Date createDate;

	public FileDate() {

	}

	public FileDate(File file, Date createDate) {
		this.file = file;
		this.createDate = createDate;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

}

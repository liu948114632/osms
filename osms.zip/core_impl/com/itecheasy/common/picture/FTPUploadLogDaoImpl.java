package com.itecheasy.common.picture;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.common.po.FTPUploadLogPO;

/** 
 * @author wanghw
 * @date 2015-5-25 
 * @description TODO
 * @version
 */
public class FTPUploadLogDaoImpl extends BaseDAOImpl<FTPUploadLogPO, Integer> implements FTPUploadLogDao{

}

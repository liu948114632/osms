package com.itecheasy.common.picture;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.common.po.FTPUploadLogPO;

/** 
 * @author wanghw
 * @date 2015-5-25 
 * @description TODO
 * @version
 */
public interface FTPUploadLogDao extends BaseDAO<FTPUploadLogPO, Integer>{

}

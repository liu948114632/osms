package com.itecheasy.common.picture;
/** 
 * @author wanghw
 * @date 2015-5-25 
 * @description TODO
 * @version
 */
public enum FTPStatus {
	SUCCESS,FAILED,CANCEL
}

package com.itecheasy.common.attachment;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.common.po.AttachmentStore;
import com.itecheasy.common.po.AttachmentStoreRule;
import java.util.List;

public abstract interface AttachmentDAO extends BaseDAO<AttachmentStore, String>
{
  public abstract List<AttachmentStoreRule> getAllAttachmentStoreRule();
}
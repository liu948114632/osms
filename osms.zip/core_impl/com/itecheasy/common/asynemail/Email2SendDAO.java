package com.itecheasy.common.asynemail;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.common.po.Email2SendPO;

public abstract interface Email2SendDAO extends BaseDAO<Email2SendPO, Long>
{
}
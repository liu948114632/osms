package com.itecheasy.common.asynemail;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.common.po.Email2SendPO;

public class Email2SendDAOImpl extends BaseDAOImpl<Email2SendPO, Long>
  implements Email2SendDAO
{
}
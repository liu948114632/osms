package com.itecheasy.common.asynemail;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.common.po.EmailSentPO;

public class EmailSentDAOImpl extends BaseDAOImpl<EmailSentPO, Long>
  implements EmailSentDAO
{
}
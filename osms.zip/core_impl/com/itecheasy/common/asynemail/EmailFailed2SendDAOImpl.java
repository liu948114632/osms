package com.itecheasy.common.asynemail;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.common.po.EmailFailed2SendPO;

public class EmailFailed2SendDAOImpl extends BaseDAOImpl<EmailFailed2SendPO, Long>
  implements EmailFailed2SendDAO
{
}
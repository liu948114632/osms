package com.itecheasy.common.asynemail;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.common.po.EmailFailed2SendPO;

public abstract interface EmailFailed2SendDAO extends BaseDAO<EmailFailed2SendPO, Long>
{
}
package com.itecheasy.common.asynemail;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.common.po.EmailSentPO;

public abstract interface EmailSentDAO extends BaseDAO<EmailSentPO, Long>
{
}
package com.itecheasy.common.sysconfig;

import com.itecheasy.common.BaseDAOImpl;
import com.itecheasy.common.po.SysConfigPO;

public class SysConfigDAOImpl extends BaseDAOImpl<SysConfigPO, Integer>
  implements SysConfigDAO
{
}
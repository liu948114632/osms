package com.itecheasy.common.sysconfig;

import com.itecheasy.common.BaseDAO;
import com.itecheasy.common.po.SysConfigPO;

public abstract interface SysConfigDAO extends BaseDAO<SysConfigPO, Integer>
{
}